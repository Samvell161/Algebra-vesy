"""A hand-drawn discovery workshop, rendered only when the scene cache changes."""
import math
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QColor,QPainterPath,QPen,QPolygonF


def fill(p,color):
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(color))


def shape(p,points,color):
    fill(p,color);p.drawPolygon(QPolygonF([QPointF(x,y) for x,y in points]))


def rounded(p,x,y,w,h,color,r=8):
    fill(p,color);p.drawRoundedRect(QRectF(x,y,w,h),r,r)


def star(p,x,y,size,color):
    points=[]
    for i in range(10):
        a=math.radians(-90+i*36);r=size if i%2==0 else size*.46
        points.append((x+math.cos(a)*r,y+math.sin(a)*r))
    shape(p,points,color)


def draw_workshop(p,width,height):
    """Scale a quiet storybook set; keep the central work area free of ornaments."""
    p.save()
    clip=QPainterPath();clip.addRoundedRect(QRectF(1,1,width-2,height-2),24,24)
    p.setClipPath(clip);p.scale(width/1000,height/360)
    fill(p,'#fff4d9');p.drawRect(QRectF(0,0,1000,360))
    # Rounded wall alcove and a mint cornice, with stable, solid material colours.
    rounded(p,162,16,676,284,'#fff9ea',110)
    rounded(p,-10,-12,1020,29,'#c8e9d9',6)
    rounded(p,-10,13,1020,7,'#acd7c5',2)
    # An arched window into a tiny, sunlit world, away from the balance cups.
    p.save()
    window=QPainterPath();window.moveTo(30,210);window.lineTo(30,88)
    window.cubicTo(30,2,164,2,164,88);window.lineTo(164,210);window.closeSubpath()
    p.setPen(QPen(QColor('#dbb881'),12));p.setBrush(QColor('#a9e4ea'));p.drawPath(window)
    p.setClipPath(window,Qt.ClipOperation.IntersectClip)
    fill(p,'#e0f5eb');p.drawEllipse(QRectF(31,99,68,20));p.drawEllipse(QRectF(86,71,90,21))
    fill(p,'#ffd565');p.drawEllipse(QPointF(91,65),22,22)
    fill(p,'#fff1ad');p.drawEllipse(QPointF(85,60),14,14)
    shape(p,[(14,205),(71,136),(117,191),(156,137),(184,206)],'#92cbb0')
    hill=QPainterPath(QPointF(15,202));hill.cubicTo(60,156,107,166,183,212);hill.lineTo(183,230);hill.lineTo(15,230);hill.closeSubpath()
    fill(p,'#57b89e');p.drawPath(hill)
    p.setClipping(False);p.restore()
    p.setPen(QPen(QColor('#f5dfb8'),5));p.drawLine(QPointF(97,47),QPointF(97,210));p.drawLine(QPointF(31,131),QPointF(163,131))
    rounded(p,20,206,156,12,'#c79e69',5);rounded(p,20,203,156,8,'#f4d6a1',4)
    # A hanging mobile: small stars remain still, so the task keeps visual priority.
    p.setPen(QPen(QColor('#d6b984'),1.5))
    for x,y,s,color in [(191,46,7,'#f0b541'),(217,76,9,'#e49b8b'),(240,43,5,'#6dbba3')]:
        p.drawLine(QPointF(x,20),QPointF(x,y-s));star(p,x,y,s,color)
        p.setPen(QPen(QColor('#d6b984'),1.5))
    # Two wall shelves, books with distinct spines, and a small toy telescope.
    rounded(p,861,112,119,11,'#d5b07d',4);rounded(p,859,108,123,8,'#f0d4a2',3)
    rounded(p,864,218,116,11,'#d5b07d',4);rounded(p,861,214,122,8,'#f0d4a2',3)
    for x,y,w,h,color in [(872,62,15,46,'#68b9b1'),(889,55,15,53,'#e89b8c'),(907,68,13,40,'#e6bf61')]:
        rounded(p,x,y,w,h,color,2);rounded(p,x+3,y+7,w-6,3,'#fff3d5',1)
    p.save();p.translate(946,89);p.rotate(-19)
    rounded(p,-22,-8,43,14,'#497f8a',4);rounded(p,-23,-8,12,14,'#80c8c8',3)
    rounded(p,17,-9,6,16,'#315966',2);p.restore()
    shape(p,[(943,96),(931,108),(937,108),(948,99),(959,108),(965,108),(953,95)],'#8e9b8e')
    # A flask, two flat books, and a little plant, drawn with a small number of paths.
    rounded(p,870,202,49,11,'#77b8b1',3);rounded(p,874,198,44,6,'#f2d18c',2)
    flask=QPainterPath(QPointF(940,165));flask.lineTo(940,183);flask.cubicTo(916,209,931,214,945,214)
    flask.cubicTo(968,214,977,206,951,183);flask.lineTo(951,165);flask.closeSubpath()
    p.setPen(QPen(QColor('#85b8ac'),2));p.setBrush(QColor('#dcf0df'));p.drawPath(flask)
    fill(p,'#8bceb9');p.drawEllipse(QRectF(930,197,31,13));rounded(p,937,162,17,5,'#7aafab',2)
    p.setPen(QPen(QColor('#fffefa'),2));p.drawLine(QPointF(937,189),QPointF(933,199))
    # The warm wood workbench replaces the old perspective grid.
    shape(p,[(0,274),(1000,274),(1000,360),(0,360)],'#ebcea0')
    shape(p,[(0,274),(1000,274),(1000,337),(0,337)],'#f4dfb8')
    p.setPen(QPen(QColor('#e6c799'),1.5))
    for y in [290,317]:p.drawLine(QPointF(0,y),QPointF(1000,y))
    for a,b in [(106,247),(750,867)]:
        grain=QPainterPath(QPointF(a,328));grain.quadTo((a+b)/2,321,b,328);p.drawPath(grain)
    rounded(p,0,337,1000,5,'#d7b482',0)
    # A potted sprout at the edge of the workbench, not behind the teaching blocks.
    p.setPen(QPen(QColor('#4c997e'),3));p.drawLine(QPointF(59,280),QPointF(59,232))
    for x,y,angle in [(47,244,-30),(70,251,30),(48,262,-25),(69,237,25)]:
        p.save();p.translate(x,y);p.rotate(angle);fill(p,'#72b99a');p.drawEllipse(QRectF(-11,-5,22,10));p.restore()
    shape(p,[(40,271),(78,271),(72,302),(46,302)],'#dc9c7e')
    rounded(p,37,268,44,9,'#eeb494',4)
    # An understated mascot rocket makes the workbench feel like a discovery lab.
    p.save();p.translate(941,275)
    shape(p,[(-12,18),(-22,36),(-10,32),(10,32),(22,36),(12,18)],'#7eb9ac')
    body=QPainterPath(QPointF(-11,30));body.lineTo(-11,3);body.quadTo(0,-23,11,3);body.lineTo(11,30);body.closeSubpath()
    fill(p,'#eea291');p.drawPath(body);fill(p,'#ffe8b0');p.drawEllipse(QPointF(0,8),7,7)
    fill(p,'#78b9c2');p.drawEllipse(QPointF(0,8),4,4);rounded(p,-10,27,20,5,'#cf806e',2);p.restore()
    p.restore()
