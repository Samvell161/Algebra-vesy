"""Decor remains in its own space, with neutral resting poses and no state."""
import math
import unittest
from algebra_lab.qt_ui.scene3d.room_motion import room_pose,ROBOT_CYCLE,ROBOT_Y
from algebra_lab.qt_ui.scene3d.model import build_workshop

class RoomMotionTests(unittest.TestCase):
    def test_neutral_pose_and_bounded_long_running_motion(self):
        neutral=room_pose(0)
        self.assertEqual(neutral.clouds,(0,0,0));self.assertEqual(neutral.feet,(0,0))
        self.assertEqual(neutral.robot_x,-5.8);self.assertEqual(neutral.owl_angle,0)
        self.assertEqual(neutral.pendulum,0)
        for i in range(1500):
            pose=room_pose(i*.137)
            values=[*pose.clouds,pose.robot_x,pose.robot_bob,*pose.feet,pose.owl_angle,pose.pendulum]
            self.assertTrue(all(math.isfinite(v) for v in values))
            self.assertLessEqual(abs(pose.robot_x),5.8)
            self.assertEqual(pose.robot_y,ROBOT_Y)
            self.assertTrue(all(abs(v)<=.8 for v in pose.clouds))
            self.assertLessEqual(abs(pose.owl_angle),30)
            self.assertLessEqual(abs(pose.pendulum),8)
            self.assertEqual(min(pose.feet),0)
            self.assertTrue(all(0<=v<=.095 for v in pose.feet))

    def test_robot_long_route_turns_and_swinging_limbs_are_continuous(self):
        scene=build_workshop(False)
        moving=[k for k in scene.parts if k.startswith('room-robot-')]
        self.assertEqual(len(moving),9)
        self.assertEqual(len([k for k in scene.parts if k.startswith('room-owl-head-')]),2)
        self.assertLess(sum(m.vertex_count for m in scene.static.values())+sum(m.vertex_count for m in scene.parts.values()),550000)
        poses=[room_pose(t*.02) for t in range(round(ROBOT_CYCLE/.02)+1)]
        self.assertGreater(max(p.robot_x for p in poses)-min(p.robot_x for p in poses),11)
        self.assertLess(min(p.robot_heading for p in poses),-89)
        self.assertGreater(max(p.robot_heading for p in poses),89)
        for a,b in zip(poses,poses[1:]):
            self.assertLess(abs(a.robot_x-b.robot_x),.04)
            self.assertLess(abs(a.robot_heading-b.robot_heading),5)
        self.assertGreater(max(abs(p.arms[0]) for p in poses),25)
        self.assertAlmostEqual(poses[0].robot_x,poses[-1].robot_x,places=5)

    def test_slow_clouds_and_robot_have_continuous_positions(self):
        for frame in range(900):
            a,b=[room_pose(t/30) for t in [frame,frame+1]]
            self.assertLess(abs(a.robot_x-b.robot_x),.06)
            self.assertLess(max(abs(x-y) for x,y in zip(a.clouds,b.clouds)),.008)
            self.assertLess(abs(a.owl_angle-b.owl_angle),.9)

    def test_cars_stay_off_the_base_and_robot_lane_and_do_not_collide(self):
        for i in range(1500):
            pose=room_pose(i*.073)
            for car in pose.cars:
                angle=math.radians(car.heading)
                hx=.26*abs(math.cos(angle))+.37*abs(math.sin(angle))
                hy=.26*abs(math.sin(angle))+.37*abs(math.cos(angle))
                self.assertTrue(abs(car.x)-hx>1.25 or abs(car.y)-hy>.55)
                self.assertGreater(car.y-hy,ROBOT_Y+.34)
                self.assertLess(abs(car.x)+hx,7.4)
                self.assertLess(abs(car.y)+hy,3.0)
            a,b=pose.cars
            self.assertGreater(math.hypot(a.x-b.x,a.y-b.y),1.7)
