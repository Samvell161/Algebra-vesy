"""Fixed-height control pages with a small painted fade curtain, no blur."""
from PyQt6.QtCore import Qt,QPropertyAnimation,QEasingCurve,QEvent,pyqtProperty
from PyQt6.QtGui import QPainter,QColor
from PyQt6.QtWidgets import QWidget,QStackedWidget

class FadeCurtain(QWidget):
    def __init__(self,parent):
        super().__init__(parent);self._opacity=0.0
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAutoFillBackground(False);self.setStyleSheet('background:transparent;')
        self.animation=QPropertyAnimation(self,b'opacity',self)
        self.animation.setDuration(180);self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.animation.finished.connect(self.hide);parent.installEventFilter(self);self.hide()

    @pyqtProperty(float)
    def opacity(self):return self._opacity
    @opacity.setter
    def opacity(self,value):self._opacity=value;self.update()

    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Resize:self.setGeometry(obj.rect())
        return False

    def start(self):
        self.animation.stop();self.setGeometry(self.parentWidget().rect());self.opacity=1.0;self.show();self.raise_()
        self.animation.setStartValue(1.0);self.animation.setEndValue(0.0);self.animation.start()

    def cancel(self):self.animation.stop();self.opacity=0.0;self.hide()

    def paintEvent(self,event):
        painter=QPainter(self);color=QColor('#f6eddb');color.setAlphaF(self._opacity);painter.fillRect(self.rect(),color)

class ControlStrip(QStackedWidget):
    def __init__(self,parent=None):
        super().__init__(parent);self.setFixedHeight(44);self._curtains={}

    def show_page(self,page,animate=False):
        if self.currentWidget() is page:
            if not animate:
                for curtain in self._curtains.values():curtain.cancel()
            return
        for curtain in self._curtains.values():curtain.cancel()
        self.setCurrentWidget(page)
        if animate:
            if page not in self._curtains:self._curtains[page]=FadeCurtain(page)
            self._curtains[page].start()

    def hideEvent(self,event):
        for curtain in self._curtains.values():curtain.cancel()
        super().hideEvent(event)
