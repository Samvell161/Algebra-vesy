"""Shared world-space light positions, matching the visible room fixtures."""
import math

WINDOW_DIRECTION=(-5.0,2.5,7.5)
LAMP_POSITION=(6.95,2.67,2.88)
# Aim the visible shade and real spotlight onto the right side of the floor.
LAMP_ROTATION=(-16,24,0)
LAMP_DIRECTION=(-math.sin(math.radians(24))*math.cos(math.radians(16)),
                -math.sin(math.radians(16)),
                -math.cos(math.radians(24))*math.cos(math.radians(16)))
CLOCK_POSITION=(-4.25,3.10,2.90)
