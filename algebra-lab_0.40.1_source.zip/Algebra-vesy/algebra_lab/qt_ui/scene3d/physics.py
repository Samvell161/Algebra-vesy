"""Three-axis visual blocks inside a radial bowl, independent of lesson rules."""
import math
from dataclasses import dataclass
from ..cube_motion import Body,CupMotion,HEIGHT,DEPTH_SCALE,inner_depth

DEPTH=36

@dataclass
class Body3D(Body):
    depth:float=0
    depth_target:float=0
    depth_velocity:float=0
    pitch:float=0
    pitch_velocity:float=0
    pitch_target:float=0

class CupMotion3D(CupMotion):
    def __init__(self,radius=135):
        super().__init__(radius,Body3D,gravity=981)
        self.recoil=0.0;self.recoil_velocity=0.0

    def target(self,values,animate=True):
        super().target(values,animate)
        active=[b for b in self.bodies if not b.removing]
        for i,body in enumerate(active):body.depth_target=0 if len(active)==1 or body.row else (-3 if i%2 else 3)
        if not animate:self.finish()

    def support(self,body,bodies=None):
        values=self.bodies if bodies is None else bodies
        half=body.width/2;deep=DEPTH/2
        corners=[(x,y,inner_depth(math.hypot(body.x+x,body.depth+y),self.radius)/DEPTH_SCALE) for x in (-half,half) for y in (-deep,deep)]
        left=sum(z for x,y,z in corners if x<0)/2;right=sum(z for x,y,z in corners if x>0)/2
        front=sum(z for x,y,z in corners if y<0)/2;back=sum(z for x,y,z in corners if y>0)/2
        roll=max(-7,min(7,math.degrees(math.atan2(right-left,body.width))))
        body.pitch_target=max(-7,min(7,math.degrees(math.atan2(front-back,DEPTH))))
        floor=min(inner_depth(math.hypot(x,y),self.radius)/DEPTH_SCALE+z for x,y,z in self.bottom_corners(body))
        if body.row:
            below=[b for b in values if not b.removing and b.row<body.row and abs(b.x-body.x)<(b.width+body.width)/2-3 and abs(b.depth-body.depth)<DEPTH-2]
            if below:
                floor=min(b.y-HEIGHT*math.cos(math.radians(b.roll))*math.cos(math.radians(b.pitch))
                          -abs(b.width/2*math.sin(math.radians(b.roll))*math.cos(math.radians(b.pitch)))-abs(deep*math.sin(math.radians(b.pitch))) for b in below)
                roll=sum(b.roll for b in below)/len(below);body.pitch_target=sum(b.pitch for b in below)/len(below)
        return floor,roll

    @staticmethod
    def bottom_corners(body):
        roll,pitch=math.radians(body.roll),math.radians(body.pitch)
        return [(body.x+x*math.cos(roll),body.depth+y*math.cos(pitch)+x*math.sin(roll)*math.sin(pitch),
                 -x*math.sin(roll)*math.cos(pitch)+y*math.sin(pitch))
                for x in (-body.width/2,body.width/2) for y in (-DEPTH/2,DEPTH/2)]

    def step(self,seconds,pan_acceleration=0,lateral_acceleration=0):
        remaining=min(.1,max(0,seconds));impact=0
        while remaining>0:
            dt=min(1/120,remaining);remaining-=dt
            for body in self.bodies:
                if body.removing:continue
                body.depth_velocity+=(100*(body.depth_target-body.depth)-22*body.depth_velocity)*dt
                body.depth+=body.depth_velocity*dt
                self.support(body)
                body.pitch_velocity+=(170*(body.pitch_target-body.pitch)-26*body.pitch_velocity)*dt
                body.pitch+=body.pitch_velocity*dt
            hit=super().step(dt,pan_acceleration,lateral_acceleration);impact=max(impact,hit)
            if hit>90:self.recoil_velocity+=min(55,hit*.16)
            self.recoil_velocity+=(-450*self.recoil-30*self.recoil_velocity)*dt
            self.recoil=max(-.30,min(1.5,self.recoil+self.recoil_velocity*dt))
        return impact

    def finish(self):
        self.recoil=0.0;self.recoil_velocity=0.0
        for body in self.bodies:
            body.depth=body.depth_target;body.depth_velocity=body.pitch_velocity=0
        super().finish()
        for body in sorted(self.bodies,key=lambda b:b.row):
            for _ in range(2):
                _,body.roll=self.support(body);body.pitch=body.pitch_target
            body.y,_=self.support(body)
