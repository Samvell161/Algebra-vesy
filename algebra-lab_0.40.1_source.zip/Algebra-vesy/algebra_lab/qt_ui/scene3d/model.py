"""The complete workshop is geometry: furniture, window, landscape and toys.

Static meshes are merged by surface finish. Moving parts stay separate and
are transformed on the GPU; there is no generated-room image in this scene.
"""
import math
from dataclasses import dataclass,field
from functools import lru_cache
from .geometry import Mesh,box,cylinder,lathe,sphere,torus,rod,star,refine_profile

HERO_SCALE=1.08
PIVOT=4.15
ARM=2.35
RIM=1.45
RADIUS=1.35
from .lighting import CLOCK_POSITION
CLOCK=CLOCK_POSITION

@lru_cache(maxsize=48)
def ball(color):return sphere(1,color,16,10)

@dataclass
class Workshop:
    static:dict=field(default_factory=dict)
    parts:dict=field(default_factory=dict)
    names:list=field(default_factory=list)
    ambient_nodes:list=field(default_factory=list)
    room_bounds:dict=field(default_factory=dict)
    contacts:list=field(default_factory=list)
    contact_atlas:bytes=b''

    def add(self,name,mesh,position=(0,0,0),scale=1,rotation=(0,0,0),finish='matte'):
        self.static.setdefault(finish,Mesh()).add(mesh,position,scale,rotation)
        self.names.append(name)

def build_workshop(detailed=False):
    s=Workshop();add=s.add
    bevel=7 if detailed else 3
    radial=128 if detailed else 64
    def block(name,pos,size,color,finish='matte',radius=.035,rotation=(0,0,0)):
        add(name,box(size,color,radius),pos,rotation=rotation,finish=finish)
    def orb(name,pos,scale,color,finish='matte'):
        add(name,ball(color),pos,scale,finish=finish)
    def bar(name,a,b,r,color,finish='wood'):
        add(name,rod(a,b,r,color),finish=finish)

    from .room import populate_room
    populate_room(s,detailed)
    def add(name,mesh,position=(0,0,0),scale=1,rotation=(0,0,0),finish='matte'):
        position=tuple(v*HERO_SCALE for v in position)
        scale=scale*HERO_SCALE if isinstance(scale,(int,float)) else tuple(v*HERO_SCALE for v in scale)
        s.add(name,mesh,position,scale,rotation,finish)

    # Fixed balance support: level feet and one continuous turned column.
    for x in [-.78,.78]:
        for y in [-.30,.30]:add('balance-foot',cylinder(.09,.06,'#6b7569',16),(x,y,0),finish='enamel')
    add('balance-base',box((2.30,1.02,.24),'#cfb28d',.09,bevel),(0,0,.18),finish='wood')
    add('balance-base-top',box((2.18,.92,.06),'#dfc28f',.025,bevel),(0,0,.33),finish='metal')
    column=[(.32,.35),(.32,.42),(.25,.48),(.20,.58),(.16,.73),(.14,1.05),(.13,1.30),(.12,3.42),(.14,3.68),(.19,3.78),(.19,3.89),(.16,4.00),(.12,PIVOT)]
    add('balance-column',lathe(refine_profile(column,4 if detailed else 2),'#4cbba2',radial),(0,.10,0),finish='enamel')
    for z,r,h in [(.38,.32,.07),(.58,.20,.035),(1.02,.14,.025),(3.68,.15,.035),(PIVOT-.12,.15,.10)]:
        add('column-collar',cylinder(r,h,'#ddbb7d',radial),(0,.1,z),finish='metal')

    if detailed:
        # Mechanical details are genuine meshes, batched with their material.
        for x in [-.78,.78]:
            for y in [-.30,.30]:
                add('base-fastener',cylinder(.045,.018,'#cdb986',24),(x,y,.363),finish='metal')
                block('fastener-slot',(x,y,.383),(.048,.009,.004),'#59685f',radius=0)
        for z,r in [(.46,.28),(.72,.17),(3.42,.13)]:
            add('column-beading',torus(r,.018,'#d8c493',64,10),(0,.1,z),finish='metal')
        for x in [-.095,.095]:
            bar('column-fluting',(x,.015,.77),(x,.015,3.37),.012,'#c0dec9','enamel')
    s.parts['beam']=box((ARM*2,.26,.20),'#dcb66e',.07,bevel)
    s.parts['beam'].add(box((ARM*2-.32,.015,.045),'#fff0b8',.006,3),(0,-.135,0))
    if detailed:
        for x in [-ARM,ARM]:
            s.parts['beam'].add(torus(.085,.020,'#d7c292',40,10),(x,0,-.035),rotation=(90,0,0))
            s.parts['beam'].add(box((.09,.24,.20),'#d8bf89',.025),(x,0,0))
    s.parts['pivot']=lathe(refine_profile([(.25,0),(.25,.07),(.23,.105),(.16,.13),(0,.135)],3),'#dcbb7e',radial,True)
    s.parts['pivot-inlay']=lathe([(.115,0),(.115,.01),(.10,.025),(0,.032)],'#54c8a5',radial,True)
    gauge=Mesh()
    for degrees in [-40,-24,-12,12,24,40]:
        a=math.radians(degrees)
        gauge.add(rod((.169*math.sin(a),0,.169*math.cos(a)),(.203*math.sin(a),0,.203*math.cos(a)),.007,'#76592e',10))
    for z in [.175,.202]:gauge.add(rod((-.034,0,z),(.034,0,z),.008,'#574b31',10))
    s.parts['pivot-scale']=gauge
    needle=Mesh().add(rod((0,0,0),(0,0,.148),.012,'#e7cf8c',12))
    needle.add(rod((0,-.009,0),(0,-.009,.151),.006,'#294e53',10))
    needle.triangle((-.022,-.012,.12),(.022,-.012,.12),(0,-.012,.16),'#294e53',((0,-1,0),)*3)
    needle.add(sphere(.025,'#e2c38a',16,8))
    s.parts['pivot-needle']=needle
    profile=[(0,-.39),(RADIUS*.3,-.40),(RADIUS*.65,-.355),(RADIUS*.85,-.265),(RADIUS*.97,-.12),
             (RADIUS,-.025),(RADIUS,0),(RADIUS-.025,.025),(RADIUS-.045,.005),(RADIUS-.05,-.04),
             (RADIUS*.84,-.24),(RADIUS*.6,-.26),(0,-.26)]
    profile=refine_profile(profile[:8],4 if detailed else 2)+profile[8:]
    for index,color in enumerate(['#25b5ad','#e58a5c']):
        s.parts['bowl-'+str(index)]=lathe(profile,color,160 if detailed else 80)
    s.parts['bowl-rim']=torus(RADIUS-.025,.032,'#e0c48b',128 if detailed else 64,14 if detailed else 8)
    for key,color in [('block','#f6d98e'),('xblock','#49cda6'),('negative','#ef8d83')]:
        s.parts[key]=box((.52,.36,.58),color,.045,bevel)
        s.parts[key+'-wide']=box((2.20,.36,.58),color,.045,bevel)
    # Three actual chains form a tripod suspension for each pan. Links are
    # interlocking torus meshes in alternating planes, merged into one VBO.
    chain=Mesh();height=PIVOT-RIM-.16
    for theta in [math.pi/2,math.pi*7/6,math.pi*11/6]:
        end=(math.cos(theta)*(RADIUS-.10),math.sin(theta)*(RADIUS-.10),0)
        chain.add(torus(.056,.016,'#bea16d',32 if detailed else 20,8),(end[0],end[1],.01),rotation=(90,0,math.degrees(theta)))
        start=(0,0,height)
        length=math.sqrt(sum((b-a)**2 for a,b in zip(start,end)));count=round(length/.10)
        direction=tuple((end[j]-start[j])/length for j in range(3))
        # Torus starts in XY. Rotate its plane into the chain's vertical plane.
        rz=math.degrees(math.atan2(direction[1],direction[0]))
        for i in range(count+1):
            t=i/count;p=tuple(start[j]+(end[j]-start[j])*t for j in range(3))
            link=torus(.041,.011,'#bea16d',24 if detailed else 12,10 if detailed else 6)
            chain.add(link,p,(1,1.36,1),rotation=(90,35 if i%2 else -35,rz))
    s.parts['chains']=chain
    s.parts['hook']=torus(.075,.022,'#d4b47b',48 if detailed else 24,12 if detailed else 6)
    s.parts['hour-hand']=rod((0,0,0),(0,0,.14),.014,'#52675b')
    s.parts['minute-hand']=rod((0,0,0),(0,0,.21),.010,'#52675b')
    s.parts['second-hand']=rod((0,0,0),(0,0,.24),.005,'#b18460')
    pendulum=Mesh();pendulum.add(rod((0,0,0),(0,0,-.42),.012,'#c5a770'))
    pendulum.add(ball('#d6ba83'),(0,0,-.42),(.075,.035,.075));s.parts['pendulum']=pendulum
    for name,color in [('star-gold','#f1c56a'),('star-mint','#7ecbb0'),('star-peach','#e4b39a')]:s.parts[name]=star(.085,color,.025)
    from .room_light import Contact,bake_contacts
    s.contacts.append(Contact('floor',0,.10*HERO_SCALE,1.12*HERO_SCALE,.40*HERO_SCALE,.17,.18))
    for x in [-.78,.78]:
        for y in [-.30,.30]:s.contacts.append(Contact('floor',x*HERO_SCALE,y*HERO_SCALE,.060,.060,.070,.42,True))
    s.contact_atlas=bake_contacts(tuple(s.contacts))
    return s
