"""A furnished workshop with spaced display objects and real light fixtures.

All furniture and props are meshes. Named assemblies retain their actual mesh
bounds for layout checks, but are merged by material before reaching OpenGL.
"""
import math
from functools import lru_cache
from .geometry import Mesh,box,cylinder,lathe,sphere,torus,rod,star
from .lighting import CLOCK_POSITION,LAMP_POSITION,LAMP_ROTATION
from .room_light import Contact

@lru_cache(maxsize=48)
def ball(color):return sphere(1,color,12,8)

class Item:
    def __init__(self,scene,name):self.scene=scene;self.name=name;self.meshes={};self.moving={}
    def add(self,name,mesh,position=(0,0,0),scale=1,rotation=(0,0,0),finish='matte',motion=None):
        target=self.meshes if motion is None else self.moving
        target.setdefault(finish if motion is None else (motion,finish),Mesh()).add(mesh,position,scale,rotation)
        self.scene.names.append(name)
    def finish(self,offset=(0,0,0)):
        if any(offset):
            self.meshes={k:Mesh().add(m,offset) for k,m in self.meshes.items()}
            self.moving={k:Mesh().add(m,offset) for k,m in self.moving.items()}
        bounds=[mesh.bounds() for mesh in [*self.meshes.values(),*self.moving.values()]]
        self.scene.room_bounds[self.name]=tuple(tuple(fn(bound[axis][j] for bound in bounds) for j in range(3)) for axis,fn in [(0,min),(1,max)])
        for finish,mesh in self.meshes.items():self.scene.static.setdefault(finish,Mesh()).add(mesh)
        for (motion,finish),mesh in self.moving.items():self.scene.parts['room-'+self.name+'-'+motion+'-'+finish]=mesh


def populate_room(s,detailed=False):
    add=s.add
    def block(name,pos,size,color,finish='matte',radius=.02,rotation=(0,0,0)):
        add(name,box(size,color,radius),pos,rotation=rotation,finish=finish)
    def orb(name,pos,scale,color,finish='matte'):
        add(name,ball(color),pos,scale,finish=finish)
    def bar(name,a,b,r,color,finish='wood'):
        add(name,rod(a,b,r,color),finish=finish)
    def begin(name):
        item=Item(s,name)
        return item,item.add
    frame='#cfb895';brass='#cbb58b'
    block('workbench',(0,.4,-.19),(15,7,.38),'#d8bd98','floor',.12)
    block('bench-front',(0,-3.02,-.60),(14.8,.18,.65),'#b4d5bc','enamel',.06)
    for x in [-5.5,-2.75,0,2.75,5.5]:
        block('drawer',(x,-3.14,-.57),(2.55,.15,.45),'#bedbc6','enamel',.06)
        orb('drawer-handle',(x,-3.25,-.52),.065,brass,'metal')

    # Architectural opening: light rays and the view really pass through it.
    wy=3.70;cx=-5.70;radius=.90;bottom=1.22;spring=2.17;top=spring+radius
    wall='#ded7cc'
    block('wall-right',(1.60,wy,2.9),(12.8,.26,6.2),wall,'plaster',radius=0)
    block('wall-left',(-7.30,wy,2.9),(1.40,.26,6.2),wall,'plaster',radius=0)
    block('wall-window-bottom',(cx,wy,(bottom-.2)/2),(radius*2,.26,bottom+.2),wall,'plaster',radius=0)
    block('wall-window-top',(cx,wy,(top+6)/2),(radius*2,.26,6-top),wall,'plaster',radius=0)
    infill=Mesh()
    for i in range(28):
        a,b=math.pi*i/28,math.pi*(i+1)/28
        x,z=cx+radius*math.cos(a),spring+radius*math.sin(a)
        xx,zz=cx+radius*math.cos(b),spring+radius*math.sin(b)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,zz),(xx,wy-.14,top+.01),wall,((0,-1,0),)*3)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,top+.01),(x,wy-.14,top+.01),wall,((0,-1,0),)*3)
    add('arch-wall-infill',infill,finish='plaster')
    for x in [-8,8]:block('side-room-wall',(x,0,2.7),(.24,7.6,6),'#ded5c6','plaster',radius=0)
    block('wall-dado',(0,3.52,.12),(16,.12,.18),'#cfc6b5','matte',.025)
    block('ceiling-cornice',(0,3.50,4.58),(16,.22,.10),'#d6c7ae','wood',.025)
    # An upper-floor view: only sky and clouds behind the real aperture.
    block('sky',(cx,8.9,3.1),(6,.10,7),'#c2e8ee','emissive',0)
    orb('sun',(-6.15,7.0,2.35),.22,'#ffdc8d','emissive')
    for index,(x,z) in enumerate([(-6.15,1.55),(-5.45,2.0),(-5.9,2.7)]):
        cloud=Mesh()
        for dx,r in [(-.28,.25),(0,.33),(.28,.24)]:cloud.add(ball('#f6fbf1'),(dx,0,0),(r,.14,r*.58))
        key='cloud-'+str(index);s.parts[key]=cloud;s.ambient_nodes.append((key,(x,5.5,z)));s.names.append('cloud')
    item,put=begin('window')
    for x in [cx-radius,cx+radius]:put('window-jamb',rod((x,3.42,bottom),(x,3.42,spring),.085,frame),finish='wood')
    put('window-arch',torus(radius,.085,frame,40,8,math.pi),(cx,3.42,spring),rotation=(90,0,0),finish='wood')
    put('window-sill',box((2.04,.55,.12),'#ecd0a4',.04),(cx,3.22,bottom-.02),finish='wood')
    put('window-centre',rod((cx,3.4,bottom),(cx,3.4,top),.032,frame),finish='wood')
    put('window-crossbar',rod((cx-radius,3.4,1.95),(cx+radius,3.4,1.95),.032,frame),finish='wood');item.finish()

    # Left station: each toy has a clear silhouette and its own footprint.
    item,put=begin('plant')
    put('plant-pot',lathe([(.15,0),(.22,.29),(.23,.32),(.19,.34)],'#e9ad8c',20,True),(-6.98,2.65,0),finish='enamel')
    for i in range(7):
        a=i*2.4;tip=(-6.98+math.cos(a)*.20,2.65+math.sin(a)*.16,.43+i*.045)
        put('plant-stem',rod((-6.98,2.65,.25),tip,.009,'#63996c'))
        put('plant-leaf',ball('#82b98a' if i%2 else '#b1cb88'),tip,(.16,.06,.06),rotation=(0,i*7,i*47))
    item.finish((.20,-.15,.68))
    item,put=begin('globe')
    put('globe-foot',cylinder(.24,.06,frame,24),(-6.06,2.72,0),finish='wood')
    put('globe-stand',rod((-6.06,2.72,.04),(-6.06,2.72,.32),.035,brass),finish='metal')
    put('globe-ocean',ball('#79b9ce'),(-6.06,2.72,.62),.30,finish='enamel')
    put('globe-meridian',torus(.34,.018,brass,32,6),(-6.06,2.72,.62),rotation=(84,20,0),finish='metal')
    for dx,dy,dz,scale in [(-.10,-.24,.06,(.12,.045,.18)),(.12,-.23,-.09,(.10,.05,.13))]:
        put('globe-land',ball('#a8cf99'),(-6.06+dx,2.72+dy,.62+dz),scale)
    item.finish((.12,-.35,.68))
    item,_=begin('robot')
    def put(*args,**kwargs):item.add(*args,motion=kwargs.pop('motion','body'),**kwargs)
    for i,x in enumerate([-5.20,-4.99]):
        put('robot-foot',box((.15,.23,.08),'#85b6ad',.025),(x,2.71,.04),finish='enamel',motion='foot'+str(i))
        put('robot-leg',cylinder(.032,.10,brass,12),(x,2.75,.08),finish='metal',motion='foot'+str(i))
    put('robot-neck',cylinder(.035,.05,brass,12),(-5.10,2.75,.45),finish='metal')
    put('robot-body',box((.39,.25,.32),'#e7ba7c',.05),(-5.10,2.75,.30),finish='enamel')
    put('robot-head',box((.37,.27,.25),'#91cbbd',.045),(-5.10,2.75,.60),finish='enamel')
    for x in [-5.20,-5.00]:
        put('robot-eye',ball('#fff7db'),(x,2.604,.62),(.046,.018,.048))
        put('robot-pupil',ball('#365d62'),(x,2.585,.62),(.020,.009,.023))
    put('robot-smile',rod((-5.18,2.608,.53),(-5.02,2.608,.53),.010,'#527c78'))
    for i,x in enumerate([-5.34,-4.86]):
        put('robot-shoulder',ball('#e3cc9b'),(x,2.75,.42),.050,finish='metal',motion='arm'+str(i))
        put('robot-arm',rod((x,2.75,.42),(x,2.75,.21),.026,brass),finish='metal',motion='arm'+str(i))
        put('robot-hand',ball('#e3cc9b'),(x,2.75,.19),.057,finish='metal',motion='arm'+str(i))
    put('robot-antenna',rod((-5.10,2.75,.72),(-5.10,2.75,.82),.012,brass),finish='metal')
    put('robot-antenna-tip',ball('#edaa88'),(-5.10,2.75,.85),.043,finish='enamel');item.finish()
    # Resting route bounds are world-space, while articulated meshes retain
    # their construction coordinates around the shared hip/shoulder pivots.
    s.room_bounds['robot']=tuple(tuple(p[i]+[-.70,-4.30,0][i] for i in range(3)) for p in s.room_bounds['robot'])
    item,put=begin('boat')
    boat=Mesh()
    for a,b,c in [((-.24,0,0),(.24,0,0),(0,0,.18)),((-.24,0,0),(0,.12,.04),(.24,0,0)),((-.24,0,0),(.24,0,0),(0,-.12,.04))]:boat.triangle(a,b,c,'#f8dfab')
    put('paper-boat',boat,(-4.33,2.85,.003));item.finish()

    # Three rows of distinct educational objects, with space around each group.
    for z in [.75,1.75,2.75]:
        block('shelf',(5.30,3.03,z),(2.45,.78,.12),frame,'wood',.045)
        for x in [4.05,6.45]:bar('shelf-bracket',(x,3.48,z-.22),(x,2.83,z-.07),.022,brass,'metal')
    for x in [4.10,6.52]:block('bookcase-upright',(x,3.36,1.65),(.075,.12,3.30),'#bba47e','wood')
    colors=['#8cb6a6','#d5b49e','#a8b9bd','#d1be96']
    for i,(x,h) in enumerate([(4.27,.42),(4.56,.58),(4.85,.50)]):
        item,put=begin('book-'+str(i))
        put('book',box((.22,.36,h),colors[i],.016),(x,3.0,2.82+h/2))
        for z in [2.90,3.01]:put('book-band',box((.20,.008,.015),'#efdbaf',0),(x,2.815,z),finish='metal')
        item.finish()
    item,put=begin('brass-weights')
    for x,r,h in [(5.34,.15,.35),(5.72,.12,.27)]:
        profile=[(r*.82,0),(r,.025),(r,h*.70),(r*.82,h*.82),(r*.29,h*.82),(r*.29,h*.94),(0,h)]
        put('brass-weight',lathe(profile,'#cbb17f',32,True),(x,3.0,2.82),finish='metal')
        put('weight-knob',torus(.038,.011,'#d5bf92',20,6),(x,3.0,2.82+h+.014),rotation=(90,0,0),finish='metal')
    item.finish()
    item,put=begin('jar')
    put('specimen-jar',lathe([(.14,0),(.15,.07),(.14,.31),(.11,.36),(.11,.40)],'#9ecbbb',24,True),(6.08,3.0,2.82),finish='enamel')
    put('jar-cork',cylinder(.12,.055,frame,20),(6.08,3.0,3.22),finish='wood')
    put('jar-label',box((.18,.012,.12),'#fff0c8',.01),(6.08,2.85,3.02));item.finish()
    item,put=begin('telescope')
    for x,y in [(4.22,2.76),(4.77,2.76),(4.49,3.20)]:put('telescope-tripod',rod((4.49,2.98,2.28),(x,y,1.82),.022,brass),finish='metal')
    put('telescope-body',rod((4.21,2.97,2.18),(4.85,2.97,2.42),.09,'#dfbd7a'),finish='metal')
    put('telescope-lens',ball('#6baeba'),(4.86,2.97,2.42),(.032,.078,.076),finish='enamel');item.finish()
    item,put=begin('abacus')
    put('abacus-foot',box((1.18,.25,.06),frame,.02),(5.80,2.99,1.83),finish='wood')
    for x in [5.27,6.33]:put('abacus-post',rod((x,2.99,1.85),(x,2.99,2.44),.032,frame),finish='wood')
    for j,z in enumerate([1.98,2.16,2.34]):
        put('abacus-rod',rod((5.28,2.99,z),(6.32,2.99,z),.012,brass),finish='metal')
        for i in range(5):put('abacus-bead',ball(colors[j]),(5.42+i*.17,2.99,z),(.065,.055,.07),finish='enamel')
    item.finish()
    item,put=begin('pencils')
    put('pencil-cup',lathe([(.14,0),(.17,.25),(.17,.30),(.14,.30),(.12,.07)],'#8ac7be',24),(4.33,2.96,.82),finish='enamel')
    for i in range(5):
        x=4.33+(i-2)*.047;h=.47+(i%3)*.05
        put('pencil',cylinder(.019,h,colors[i%4],8),(x,2.96,.89))
        put('pencil-tip',lathe([(.019,0),(0,.055)],'#d7b683',8),(x,2.96,.89+h),finish='wood')
    item.finish()
    item,put=begin('rings')
    put('ring-toy-foot',box((.50,.33,.06),frame,.025),(5.18,2.98,.85),finish='wood')
    put('ring-toy-post',cylinder(.025,.50,brass,12),(5.18,2.98,.86),finish='metal')
    for i,r in enumerate([.20,.16,.12]):put('counting-ring',torus(r,.035,colors[i],24,6),(5.18,2.98,.925+i*.07),finish='enamel')
    item.finish()
    item,put=begin('shape-toys')
    put('shape-board',box((.72,.38,.055),frame,.02),(6.00,2.98,.85),finish='wood')
    put('shape-cube',box((.20,.22,.22),'#dba485',.024),(5.77,2.98,.99),finish='enamel')
    put('shape-ball',ball('#91bcba'),(6.03,2.98,1.01),.14,finish='enamel')
    put('shape-cone',lathe([(.105,0),(0,.32)],'#e5c56f',20),(6.23,2.98,.88),finish='enamel');item.finish()

    # Quiet, narrow accents in the gaps inside the balance silhouette.
    item,put=begin('chalkboard')
    put('chalkboard-slate',box((.44,.035,.61),'#71847a',.012),(-.67,3.35,1.77))
    for x in [-.925,-.415]:put('chalkboard-frame',box((.035,.10,.70),frame,.010),(x,3.36,1.77),finish='wood')
    for z in [1.435,2.105]:put('chalkboard-frame',box((.54,.10,.035),frame,.010),(-.67,3.36,z),finish='wood')
    chalk='#c3cdbd';y=3.326
    for a,b in [((-.67,y,1.65),(-.67,y,1.95)),((-.79,y,1.65),(-.55,y,1.65)),
                ((-.84,y,1.93),(-.50,y,1.93)),((-.82,y,1.93),(-.84,y,1.79)),
                ((-.52,y,1.93),(-.50,y,1.79)),((-.90,y,1.79),(-.78,y,1.79)),
                ((-.56,y,1.79),(-.44,y,1.79)),((-.72,y,1.55),(-.62,y,1.55)),
                ((-.72,y,1.51),(-.62,y,1.51))]:
        put('chalk-balance-sketch',rod(a,b,.007, chalk,8))
    for x in [-.83,-.51]:put('chalk-bowl',torus(.055,.005, chalk,20,6,math.pi),(x,y,1.795),rotation=(-90,0,0))
    item.finish()
    item,put=begin('owl')
    put('owl-shelf',box((.57,.48,.115),frame,.025),(.65,3.05,1.365),finish='wood')
    put('owl-body',ball('#e9cda0'),(.65,3.0,1.64),(.17,.12,.21),finish='enamel')
    put('owl-head',ball('#eee0bc'),(.65,2.99,1.85),(.18,.13,.16),finish='enamel',motion='head')
    for x in [.50,.80]:put('owl-wing',ball('#86bca7'),(x,3.0,1.64),(.06,.09,.14),finish='enamel')
    eyes=Mesh()
    for x in [-.07,.07]:
        eyes.add(ball('#fff2cf'),(x,0,0),(.065,.026,.07))
        eyes.add(ball('#31575b'),(x,-.028,0),(.024,.013,.032))
        put('owl-goggles',torus(.066,.009,brass,20,6),(.65+x,2.826,1.86),rotation=(90,0,0),finish='metal',motion='head')
    s.parts['owl-eyes']=eyes
    for x in [.48,.82]:
        put('owl-shelf-support',rod((x,3.49,1.18),(x,3.13,1.31),.018,frame),finish='wood')
        put('owl-shelf-mount',cylinder(.034,.07,brass,16),(x,3.56,1.18),rotation=(90,0,0),finish='metal')
    put('owl-beak',ball('#d7a962'),(.65,2.83,1.77),(.027,.035,.028),finish='metal',motion='head');item.finish()

    # Small wall displays stay outside the pan/chain sweep.
    item,put=begin('planet-badge')
    put('planet-frame',torus(.27,.025,frame,32,6),(-4.37,3.29,1.50),rotation=(90,0,0),finish='wood')
    put('planet-disc',cylinder(.25,.025,'#81a9bd',28),(-4.37,3.33,1.50),rotation=(90,0,0))
    put('planet',ball('#a7d6d2'),(-4.37,3.23,1.50),(.13,.05,.13),finish='enamel')
    put('planet-ring',torus(.18,.016,'#e8d69b',24,6),(-4.37,3.19,1.50),rotation=(74,-25,0),finish='metal');item.finish()
    item,put=begin('mini-map')
    put('map-backing',box((.56,.07,.72),'#a1cfc6',.025),(6.99,3.35,1.55),finish='enamel')
    for x in [6.69,7.29]:put('map-frame',box((.045,.11,.80),frame,.01),(x,3.29,1.55),finish='wood')
    for z in [1.16,1.94]:put('map-frame',box((.64,.11,.045),frame,.01),(6.99,3.29,z),finish='wood')
    for x,z in [(6.84,1.76),(7.12,1.60),(6.91,1.35)]:put('map-island',ball('#bed197'),(x,3.26,z),(.105,.03,.065))
    for i in range(7):put('map-path',ball(brass),(6.86+i*.032,3.21,1.37+i*.055),.012,finish='metal')
    for x in [7.06,7.16]:
        put('map-castle-tower',box((.045,.04,.12),'#f0dcae',0),(x,3.20,1.66))
        put('map-castle-roof',lathe([(.038,0),(0,.07)],'#d6a084',10),(x,3.20,1.72),finish='enamel')
    item.finish()
    item,put=begin('garland')
    for i in range(12):
        x=-3.03+i*.55;xx=x+.55;z=4.59+.035*(x/3.1)**2;zz=4.59+.035*(xx/3.1)**2
        put('garland-cord',rod((x,3.32,z),(xx,3.32,zz),.007,brass),finish='metal')
        if i<11:
            flag=Mesh();flag.triangle((-.08,0,0),(0,0,-.13),(.08,0,0),colors[i%4])
            put('garland-pennant',flag,(x+.28,3.30,z-.015))
    item.finish()

    item,put=begin('star-badge')
    put('badge-disc',cylinder(.14,.035,'#9bcbbd',28),(0,3.31,4.24),rotation=(90,0,0),finish='enamel')
    put('badge-rim',torus(.14,.016,brass,28,6),(0,3.27,4.24),rotation=(90,0,0),finish='metal')
    put('badge-star',star(.09,'#f1d184',.025),(0,3.24,4.24),rotation=(90,0,0),finish='metal');item.finish()

    cx,cy,cz=CLOCK_POSITION
    item,put=begin('clock')
    put('clock-back',box((.53,.16,1.01),'#bf9c6c',.07),(cx,cy+.09,cz-.29),finish='wood')
    for x in [cx-.20,cx+.20]:put('clock-post',box((.06,.14,.54),'#c29d70',.015),(x,cy-.04,cz-.39),finish='wood')
    put('clock-bottom',box((.48,.18,.07),frame,.02),(cx,cy-.04,cz-.70),finish='wood')
    put('clock-rim',torus(.28,.04,brass,32,8),(cx,cy-.08,cz),rotation=(90,0,0),finish='metal')
    put('clock-face',cylinder(.26,.03,'#fff1ca',32),(cx,cy-.045,cz),rotation=(90,0,0))
    for i in range(12):
        a=i*math.pi/6
        put('clock-tick',rod((cx+.21*math.sin(a),cy-.09,cz+.21*math.cos(a)),(cx+.235*math.sin(a),cy-.09,cz+.235*math.cos(a)),.008,'#628374'))
    item.finish()

    # The shade, bulb and spotlight use the exact same world-space placement.
    item,put=begin('lamp')
    put('lamp-mount',cylinder(.115,.055,brass,24),(6.98,3.48,3.25),rotation=(90,0,0),finish='metal')
    put('lamp-arm',rod((6.98,3.43,3.25),(6.98,2.83,3.25),.025,brass),finish='metal')
    put('lamp-arm',rod((6.98,2.83,3.25),(7.08,2.73,3.05),.025,brass),finish='metal')
    shade=lathe([(.235,-.10),(.22,-.02),(.15,.19),(.10,.23),(.08,.23),(.13,.17),(.20,-.03),(.215,-.10),(.235,-.10)],'#75b9ad',40 if detailed else 28)
    put('lamp-shade',shade,LAMP_POSITION,rotation=LAMP_ROTATION,finish='enamel')
    lip=Mesh().add(torus(.225,.015,brass,32,6),(0,0,-.10))
    put('lamp-lip',lip,LAMP_POSITION,rotation=LAMP_ROTATION,finish='metal');item.finish()
    s.parts['lamp-bulb']=Mesh().add(ball('#ffe0a0'),LAMP_POSITION,.085)

    from .room_props import populate_playroom
    populate_playroom(s,begin,detailed)

    # Receiver-space soft contacts supplement the two geometric shadow maps.
    for x in [4.10,6.52]:s.contacts.append(Contact('floor',x,3.36,.038,.060,.070,.42))
    for z in [.75,1.75,2.75]:s.contacts.append(Contact('wall',5.30,z-.055,1.22,.045,.11,.22))
    for x in [4.10,6.52]:s.contacts.append(Contact('wall',x+.04,1.65,.028,1.57,.095,.16))
    s.contacts += [Contact('wall',.65,1.29,.29,.045,.12,.28),
                   Contact('wall',.65,1.66,.16,.22,.16,.10,True),
                   Contact('wall',-.65,1.75,.25,.32,.09,.18),
                   Contact('wall',-4.25,2.68,.24,.52,.11,.14)]
