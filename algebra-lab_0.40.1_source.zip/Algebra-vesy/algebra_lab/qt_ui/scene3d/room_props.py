"""Low-cost playroom props: a supported desk, wooden toys, atlas and toy cars."""
from .geometry import Mesh,box,cylinder,rod,sphere,torus
from .room_light import Contact

def populate_playroom(scene,begin,detailed=False):
    wood='#ccb18a';cream='#f4dfac'
    item,put=begin('left-desk')
    put('desk-top',box((2.50,1.05,.12),wood,.045),(-6.15,2.30,.62),finish='wood')
    for x in [-7.20,-5.10]:
        for y in [1.95,2.65]:
            put('desk-leg',box((.10,.12,.56),'#b7cbb8',.02),(x,y,.28),finish='wood')
            scene.contacts.append(Contact('floor',x,y,.055,.065,.08,.36))
    put('desk-drawer',box((2.20,.15,.18),'#9fc8bb',.025),(-6.15,1.82,.47),finish='enamel')
    put('desk-knob',sphere(.035,cream,12,8),(-6.15,1.73,.47),finish='metal')
    put('desk-low-shelf',box((2.22,.80,.055),wood,.02),(-6.15,2.30,.17),finish='wood')
    for i,color in enumerate(['#d6b99e','#92b8b1']):
        put('desk-notebook',box((.62,.40,.055),color,.012),(-5.75,2.22,.23+i*.06),rotation=(0,0,-8+i*13))
    item.finish()

    # Each pile is a small, deliberately irregular arrangement off both routes.
    for side in [-1,1]:
        item,put=begin('floor-toys-'+str(side))
        for i,(dx,dy,z,rz,color) in enumerate([(-.29,.05,.14,17,'#8cc9b7'),(.13,-.12,.13,-21,'#e3ac8c'),(.10,.18,.12,8,'#e5cd88')]):
            pos=(side*4.70+dx,.05+dy,z)
            put('scattered-wooden-block',box((.26,.27,.26),color,.025),pos,rotation=(0,0,rz),finish='wood')
            scene.contacts.append(Contact('floor',pos[0],pos[1],.11,.11,.06,.25))
        put('toy-counting-ring',torus(.20,.035,'#a2b9d0',28,8),(side*4.70-.20,.36,.04),finish='enamel')
        item.finish()

    item,put=begin('world-poster')
    cx,cy,cz=5.35,3.43,3.91
    put('world-map-paper',box((2.15,.035,.72),'#b9d9d6',.012),(cx,cy,cz))
    for x in [cx-1.12,cx+1.12]:put('poster-frame',box((.05,.09,.83),wood,.012),(x,cy-.01,cz),finish='wood')
    for z in [cz-.39,cz+.39]:put('poster-frame',box((2.29,.09,.05),wood,.012),(cx,cy-.01,z),finish='wood')
    # Stylised continents in a calm classroom atlas palette.
    continents=[(-.68,.10,[(-.26,.14),(-.08,.25),(.18,.19),(.27,.06),(.11,-.07),(-.08,-.05)]),
                (-.42,-.15,[(-.11,.14),(.09,.12),(.15,-.04),(.02,-.25),(-.06,-.09)]),
                (.16,-.06,[(-.14,.15),(.12,.13),(.16,-.04),(.02,-.22),(-.10,-.11)]),
                (.45,.15,[(-.33,.02),(-.14,.16),(.13,.13),(.40,.03),(.28,-.13),(.05,-.06)]),
                (.78,-.19,[(-.13,.04),(.03,.09),(.15,-.01),(.02,-.09)])]
    land=Mesh()
    for x,z,points in continents:
        for a,b in zip(points,points[1:]+points[:1]):
            land.triangle((cx+x,cy-.025,cz+z),(cx+x+a[0],cy-.025,cz+z+a[1]),
                          (cx+x+b[0],cy-.025,cz+z+b[1]),'#93b58c',((0,-1,0),)*3)
    put('world-map-continents',land)
    for z in [-.23,0,.23]:put('map-latitude',rod((cx-1.03,cy-.022,cz+z),(cx+1.03,cy-.022,cz+z),.0025,'#cfdfcb',8))
    item.finish()

    # Car front points along local -Y; four wheel matrices spin a shared mesh.
    for i,color in enumerate(['#de9b78','#76b7c6']):
        mesh=Mesh()
        mesh.add(box((.44,.72,.13),color,.045),(0,0,.17))
        mesh.add(box((.35,.36,.16),color,.05),(0,.03,.30))
        mesh.add(box((.29,.012,.10),'#c1e4e4',.015),(0,-.155,.31))
        mesh.add(box((.29,.012,.10),'#b1d4d8',.015),(0,.215,.31))
        for x in [-.11,.11]:mesh.add(box((.075,.014,.04),'#fff1bb',.009),(x,-.365,.18))
        scene.parts['room-car'+str(i)+'-body-enamel']=mesh
        scene.names.append('toy-car')
    wheel=Mesh().add(cylinder(.09,.055,'#52636b',20),(0,0,-.0275))
    wheel.add(cylinder(.045,.060,'#d6c398',20),(0,0,-.03))
    for z in [-.033,.033]:wheel.add(box((.065,.010,.004),'#52636b',0),(0,0,z))
    scene.parts['room-car-wheel']=wheel
