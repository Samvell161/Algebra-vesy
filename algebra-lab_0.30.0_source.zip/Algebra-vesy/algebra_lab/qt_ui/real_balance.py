"""Native touch container and controller for the genuine 3D workshop."""
import math
import os
import platform
from PyQt6.QtCore import Qt,QTimer,QElapsedTimer
from PyQt6.QtGui import QSurfaceFormat,QPainter,QColor
from PyQt6.QtWidgets import QApplication,QWidget,QLabel,QPushButton
from .balance import Balance
from .workshop_clock import WorkshopClock
from .scene3d.physics import CupMotion3D


class SceneClock(WorkshopClock):
    def _tick(self):
        from PyQt6.QtCore import QTime
        if QApplication.activeModalWidget() is not None:return
        self._time=QTime.currentTime();self._phase=self._elapsed.elapsed()/1000
        if getattr(self._owner,'surface',None) is not None:self._owner.surface.update()


class RealBalance(Balance):
    """Same lesson/control contract; rendering and contacts use an XYZ scene."""
    is_3d=True

    def __init__(self,parent=None):
        super().__init__(parent,cup_factory=CupMotion3D,clock_factory=SceneClock)
        self._timer.setInterval(33)
        self.camera_yaw=0.;self.camera_pitch=0.;self._camera_start=0.;self._camera_target=0.
        self._camera_clock=QElapsedTimer();self._camera_timer=QTimer(self)
        self._camera_timer.setInterval(33);self._camera_timer.timeout.connect(self._camera_tick)
        self._context_check=QTimer(self);self._context_check.setSingleShot(True)
        self._context_check.timeout.connect(self._check_context)
        self.surface=None;self.container=None;self.graphics_error=None
        self.status=QLabel('Строю трёхмерную мастерскую…',self)
        self.status.setWordWrap(True);self.status.setStyleSheet('background:#fff5df;color:#47685f;border-radius:12px;padding:12px;font-size:18px;')
        try:
            from .scene3d.renderer import SceneSurface
            self.surface=SceneSurface(self)
            fmt=QSurfaceFormat();gles=os.environ.get('ALGEBRA_GL_API')=='gles' or platform.machine().lower().startswith(('arm','aarch'))
            fmt.setRenderableType(QSurfaceFormat.RenderableType.OpenGLES if gles else QSurfaceFormat.RenderableType.OpenGL)
            fmt.setVersion(2,0 if gles else 1);fmt.setDepthBufferSize(24);fmt.setSamples(2)
            self.surface.setFormat(fmt);self.surface.ready.connect(self._scene_ready,Qt.ConnectionType.QueuedConnection);self.surface.failed.connect(self._graphics_failed,Qt.ConnectionType.QueuedConnection)
            self.container=QWidget.createWindowContainer(self.surface,self)
            self.container.setAccessibleName('Трёхмерная мастерская')
        except ImportError as exc:self._graphics_failed('Не установлена 3D-библиотека: '+str(exc))
        self.camera_button=QPushButton('Ракурс',self);self.camera_button.setFixedSize(94,44)
        self.camera_button.setToolTip('Посмотреть сцену сбоку. Можно также провести пальцем по комнате.')
        self.camera_button.clicked.connect(self.cycle_camera)
        self.camera_button.hide()
        self.setAccessibleName('Алгебраические весы · настоящая 3D-сцена')

    def _graphics_failed(self,message):
        self.graphics_error=message
        if self.container is not None:self.container.hide()
        self.status.setText(message+'\nПроверьте драйвер OpenGL и зависимости приложения. Совместимый вид можно запустить с --software-view.')
        self.status.show();self.status.raise_()

    def _scene_ready(self):
        self.status.hide()
        self.camera_button.show()
        for button in self.findChildren(QPushButton):button.update()
        self.update()

    def _geometry(self):return 1.,1000.,360.,235.,235*math.sin(math.radians(10))

    def _invalidate(self):
        if getattr(self,'surface',None) is not None:self.surface.update()
        self.update()

    def resizeEvent(self,event):
        if getattr(self,'container',None) is not None:self.container.setGeometry(0,0,self.width(),max(40,self.height()-64))
        if hasattr(self,'status'):
            if self.graphics_error:self.status.setGeometry(18,30,max(100,self.width()-36),160)
            else:self.status.setGeometry(190,self.height()-54,max(100,self.width()-380),44)
        if hasattr(self,'camera_button'):self.camera_button.move(self.width()//2-47,self.height()-54)
        QWidget.resizeEvent(self,event)

    def paintEvent(self,event):
        painter=QPainter(self);painter.fillRect(self.rect(),QColor('#f6eddb'));painter.end()

    def showEvent(self,event):
        super().showEvent(event)
        self._context_check.start(1200)

    def hideEvent(self,event):
        self._context_check.stop();super().hideEvent(event)

    def _check_context(self):
        if self.isVisible() and self.surface is not None and not self.surface.isValid():
            self._graphics_failed('Не удалось создать контекст OpenGL 2.1 / OpenGL ES 2.0.')

    def set_camera(self,yaw,pitch=0):
        self._camera_timer.stop()
        self.camera_yaw=max(-24,min(24,yaw));self.camera_pitch=max(-5,min(7,pitch));self._invalidate()

    def cycle_camera(self):
        target=14 if abs(self.camera_yaw)<3 else -14 if self.camera_yaw>0 else 0
        if not self._motion:self.set_camera(target);return
        self._camera_start=self.camera_yaw;self._camera_target=target
        self._camera_clock.start();self._camera_timer.start()

    def _camera_tick(self):
        t=min(1,self._camera_clock.elapsed()/350);ease=t*t*(3-2*t)
        self.camera_yaw=self._camera_start+(self._camera_target-self._camera_start)*ease
        self._invalidate()
        if t==1:self._camera_timer.stop()

    def stop_animation(self):
        super().stop_animation()
        if hasattr(self,'_camera_timer'):self._camera_timer.stop()

    def shutdown(self):
        self._context_check.stop()
        self.stop_animation();self.clock.stop()
        surface=self.surface
        if surface is not None:surface.cleanup()
        if self.container is not None:
            from PyQt6 import sip
            container=self.container;self.container=None
            # Release the native GL window while QApplication and its display
            # connection still exist, before interpreter/module teardown.
            sip.delete(container)
        self.surface=None
