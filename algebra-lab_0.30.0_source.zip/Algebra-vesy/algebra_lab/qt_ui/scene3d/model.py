"""The complete workshop is geometry: furniture, window, landscape and toys.

Static meshes are merged by surface finish. Moving parts stay separate and
are transformed on the GPU; there is no generated-room image in this scene.
"""
import math
from dataclasses import dataclass,field
from functools import lru_cache
from .geometry import Mesh,box,cylinder,lathe,sphere,torus,rod,star

PIVOT=3.25
ARM=2.35
RIM=1.30
RADIUS=1.35
CLOCK=(-3.30,2.85,3.0)

@lru_cache(maxsize=48)
def ball(color):return sphere(1,color,16,10)

@dataclass
class Workshop:
    static:dict=field(default_factory=dict)
    parts:dict=field(default_factory=dict)
    names:list=field(default_factory=list)
    ambient_nodes:list=field(default_factory=list)

    def add(self,name,mesh,position=(0,0,0),scale=1,rotation=(0,0,0),finish='matte'):
        if name.startswith('map-'):position=(position[0]+.55,position[1],position[2])
        if name.startswith('planet-') or name=='planet':position=(position[0],position[1],position[2]-.2)
        if name.startswith('rocket-'):
            mesh=Mesh().add(mesh,position,scale,rotation)
            position=(5.7*.2,3*.2,3.1*.2-.65);scale=.8;rotation=(0,0,0)
        self.static.setdefault(finish,Mesh()).add(mesh,position,scale,rotation)
        self.names.append(name)

def build_workshop():
    s=Workshop();add=s.add
    def block(name,pos,size,color,finish='matte',radius=.035,rotation=(0,0,0)):
        add(name,box(size,color,radius),pos,rotation=rotation,finish=finish)
    def orb(name,pos,scale,color,finish='matte'):
        add(name,ball(color),pos,scale,finish=finish)
    def bar(name,a,b,r,color,finish='wood'):
        add(name,rod(a,b,r,color),finish=finish)

    # A real thick worktop, front apron, drawers and turned brass handles.
    block('workbench', (0,.4,-.19),(15,7,.38),'#e2bb83','wood',.12)
    block('bench-front', (0,-3.02,-.60),(14.8,.18,.65),'#b4d5bc','enamel',.06)
    for x in [-5.5,-2.75,0,2.75,5.5]:
        block('drawer',(x,-3.14,-.57),(2.55,.15,.45),'#bedbc6','enamel',.06)
        orb('drawer-handle',(x,-3.25,-.52),.065,'#d2aa64','metal')
    for x in [-5.6,5.6]:block('bench-leg',(x,1,-1.1),(.32,.4,1.8),'#c6a271','wood')

    # The rear wall has an actual arched opening, not a picture of a window.
    wall='#f1e4ca';wy=3.7
    block('wall-right',(2.3,wy,2.9),(11.8,.26,6.2),wall,radius=0)
    block('wall-left',(-7.1,wy,2.9),(2.2,.26,6.2),wall,radius=0)
    block('wall-window-bottom',(-4.8,wy,.35),(2.4,.26,.9),wall,radius=0)
    block('wall-window-top',(-4.8,wy,4.7),(2.4,.26,2.9),wall,radius=0)
    # Infill above the arch follows its curved edge.
    infill=Mesh()
    for i in range(24):
        a,b=math.pi*i/24,math.pi*(i+1)/24
        x,z=-4.8+1.2*math.cos(a),2.05+1.2*math.sin(a)
        xx,zz=-4.8+1.2*math.cos(b),2.05+1.2*math.sin(b)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,zz),(xx,wy-.14,3.27),wall,((0,-1,0),)*3)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,3.27),(x,wy-.14,3.27),wall,((0,-1,0),)*3)
    add('arch-wall-infill',infill)
    block('left-room-wall',(-8,0,2.7),(.24,7.6,6),'#e8d7b7',radius=0)
    block('right-room-wall',(8,0,2.7),(.24,7.6,6),'#e8d7b7',radius=0)
    block('cornice',(0,3.45,5.4),(16,.4,.22),'#d4ba8b','wood',.06)
    # Outside, solid hills and clouds are genuinely behind the window opening.
    block('sky',(-4.8,9,3.6),(11,.1,8),'#c7eaf0',radius=0)
    for x,y,z,sc in [(-5.6,5.4,.6,(2.1,1.7,1.5)),(-3.8,6.8,.5,(1.9,2,1.3)),(-6.6,7,.7,(2.2,2,1.5))]:
        orb('distant-hill',(x,y,z),sc,'#a3caa8')
    orb('sun',(-5.8,7.0,2.25),.30,'#f9e1a1','emissive')
    for index,(x,z) in enumerate([(-5.6,2.5),(-4.7,2.8),(-4.0,2.4)]):
        cloud=Mesh()
        for dx,dy,r in [(-.18,0,.23),(0,-.02,.3),(.22,0,.22)]:cloud.add(ball('#f8fcf3'),(dx,dy,0),(r,.16,r*.7))
        key='cloud-'+str(index);s.parts[key]=cloud;s.ambient_nodes.append((key,(x,5.5,z)));s.names.append('cloud')
    for x,y,z in [(-5.7,6.2,1.7),(-4.0,7.3,1.4),(-6.5,7.2,1.8)]:
        bar('garden-tree-trunk',(x,y,z-.4),(x,y,z+.5),.055,'#b7996b')
        for dx,dz,scale in [(-.15,.30,.31),(.13,.40,.35),(0,.65,.32)]:orb('garden-tree',(x+dx,y,z+dz),(scale,scale*.8,scale),'#9fc29c')
    frame='#dfb77e'
    for x in [-6,-3.6]:bar('window-jamb',(x,3.42,.8),(x,3.42,2.05),.115,frame)
    add('window-arch',torus(1.2,.115,frame,40,8,math.pi),(-4.8,3.42,2.05),rotation=(90,0,0),finish='wood')
    block('window-sill',(-4.8,3.15,.77),(2.8,1,.15),'#edcfa1','wood',.07)
    bar('window-crossbar',(-6,3.4,1.8),(-3.6,3.4,1.8),.045,'#e6c28c')
    bar('window-centre',(-4.8,3.4,.85),(-4.8,3.4,3.23),.045,'#e6c28c')

    # Shelves, separate books, rocket, working telescope and wooden abacus.
    for z in [1.05,2.35]:block('shelf',(5.2,3.05,z),(2.6,1,.14),'#dfbd8e','wood',.055)
    colors=['#6aaca0','#ecb08c','#b9cfb0','#ddc180']
    for i,(x,h) in enumerate([(4.25,.68),(4.55,.86),(4.84,.72)]):
        block('book',(x,3.0,2.45+h*.4),(.25,.43,h*.8),colors[i],'matte',.025,rotation=(0,(-4 if i==2 else 0),0))
        block('book-gold-band',(x,2.773,2.56),(.23,.012,.025),'#e8ce9a','metal',.002)
    rocket=lathe([(0,0),(.20,0),(.20,.57),(.17,.70),(.11,.86),(0,1.05)],'#f2dfbb',32)
    add('rocket-body',rocket,(5.7,3,3.1),finish='enamel')
    add('rocket-nose',lathe([(.17,.7),(.12,.86),(0,1.05)],'#db9477',24),(5.7,3,3.1),finish='enamel')
    add('rocket-window',torus(.086,.019,'#d6b276'),(5.7,2.797,3.66),rotation=(90,0,0),finish='metal')
    orb('rocket-glass',(5.7,2.79,3.66),(.075,.022,.075),'#79b9c2','enamel')
    for x in [-.22,.22]:block('rocket-fin',(5.7+x,3,3.2),(.14,.28,.3),'#d69c83','enamel',.04,rotation=(0,-x*70,0))
    for x in [4.35,4.85]:bar('telescope-tripod',(4.6,2.98,1.43),(x,2.70,1.14),.026,'#c7a266','metal')
    bar('telescope-tripod',(4.6,2.98,1.43),(4.65,3.3,1.14),.026,'#c7a266','metal')
    bar('telescope-body',(4.30,2.96,1.55),(4.98,2.96,1.91),.105,'#c7a264','metal')
    orb('telescope-lens',(4.99,2.958,1.91),(.045,.09,.09),'#699eaa','enamel')
    for x in [5.35,6.4]:bar('abacus-upright',(x,2.94,1.15),(x,2.94,2.01),.045,frame)
    block('abacus-foot',(5.875,2.94,1.13),(1.22,.3,.07),frame,'wood')
    for j,z in enumerate([1.36,1.60,1.84]):
        bar('abacus-rod',(5.38,2.94,z),(6.38,2.94,z),.014,'#c7a16c','metal')
        for i in range(5):orb('abacus-bead',(5.51+i*.17,2.94,z),(.075,.065,.085),colors[j],'enamel')

    # Framed miniature island map made of individual raised objects.
    block('map-backing',(-2.45,3.37,2.35),(2.2,.14,1.46),'#b7d6d1','enamel',.055)
    for x in [-3.57,-1.33]:block('map-frame', (x,3.23,2.35),(.09,.16,1.62),frame,'wood')
    for z in [1.56,3.14]:block('map-frame',(-2.45,3.23,z),(2.3,.16,.10),frame,'wood')
    for x,z,r in [(-3.0,2.7,.28),(-2.3,2.1,.34),(-1.7,2.7,.23),(-3.1,1.9,.19)]:
        orb('map-island',(x,3.21,z),(r,.10,r*.48),'#d8d49a')
        orb('map-hill',(x,3.12,z+.04),(r*.6,.08,r*.45),'#a0be9b')
    for x,z in [(-3.2,2.95),(-2.3,2.65),(-1.7,1.9)]:add('map-star',star(.10,'#f1cf81'),(x,3.12,z),rotation=(90,0,0),finish='metal')
    for x,z in [(-1.82,2.74),(-1.63,2.77),(-1.72,2.88)]:
        add('map-castle-tower',cylinder(.045,.18,'#eddbb6',12),(x,3.05,z))
        add('map-castle-roof',lathe([(.06,0),(0,.10)],'#d7a286',12),(x,3.05,z+.18),finish='enamel')
    for i in range(13):
        t=i/12;orb('map-path',(-3.0+1.35*t,3.06,1.91+.62*t+.13*math.sin(t*math.tau)),.018,'#e8c68c','metal')
    for x,z in [(-3.15,2.77),(-2.95,2.79),(-2.4,2.14),(-2.2,2.13)]:
        bar('map-tree-trunk',(x,3.03,z),(x,3.03,z+.10),.011,'#bc9e70')
        orb('map-tree',(x,3.03,z+.12),(.06,.04,.08),'#9fbf92')
    # Circular planetary relief: all shapes stand out from the wooden frame.
    add('planet-frame',torus(.63,.06,frame,40,8),(2.45,3.37,2.70),rotation=(90,0,0),finish='wood')
    add('planet-disc',cylinder(.60,.05,'#789bb0',40),(2.45,3.42,2.70),rotation=(90,0,0))
    orb('planet',(2.40,3.22,2.72),(.30,.10,.30),'#a1d2d4','enamel')
    add('planet-ring',torus(.41,.035,'#d4dfce',32,6),(2.4,3.15,2.72),scale=(1,.65,1),rotation=(72,-22,0),finish='metal')
    for x,z in [(2.8,3.0),(2.1,3.1),(2.8,2.4)]:add('planet-star',star(.065,'#e9d39a'),(x,3.23,z),rotation=(90,0,0),finish='metal')

    # Pot, stems and thick leaves at different depths.
    add('plant-pot',lathe([(.19,0),(.28,.36),(.30,.38),(.30,.43),(.26,.44)],'#dca88b',28,True),(-5.6,2.5,.03),finish='enamel')
    for i in range(9):
        a=i*2.4;tip=(-5.6+math.cos(a)*.4,2.5+math.sin(a)*.3,.52+i*.055)
        bar('plant-stem',(-5.6,2.5,.38),tip,.012,'#659b75','matte')
        add('plant-leaf',ball('#85b783' if i%2 else '#a9c68a'),tip,(.24,.085,.07),rotation=(0,i*7,i*47))

    # Owl mascot on a real shelf, kept to the right of the central stand.
    block('owl-shelf',(.65,3.05,1.4),(1.35,.68,.10),frame,'wood',.045)
    orb('owl-body',(.46,3.0,1.67),(.18,.13,.22),'#e3cb9e')
    orb('owl-head',(.46,2.98,1.90),(.19,.14,.18),'#e9d9b5')
    for x in [.27,.65]:orb('owl-wing',(x,3.0,1.68),(.07,.11,.17),'#8bbba8','enamel')
    for x in [.38,.54]:
        orb('owl-eye',(x,2.846,1.92),(.075,.032,.082),'#fff4d5')
        orb('owl-pupil',(x,2.815,1.92),(.029,.018,.038),'#354e4b','enamel')
        orb('owl-highlight',(x-.009,2.797,1.936),.009,'#ffffff','emissive')
        add('owl-goggles',torus(.078,.009,'#c5a268',20,6),(x,2.806,1.92),rotation=(90,0,0),finish='metal')
    for x in [.35,.57]:add('owl-ear',lathe([(.045,0),(0,.085)],'#d9bc8d',14),(x,2.98,2.035))
    orb('owl-beak',(.46,2.82,1.83),(.035,.04,.036),'#d7aa66','metal')
    for x in [.36,.56]:orb('owl-foot',(x,2.98,1.46),(.045,.07,.026),'#bf985d')
    boat=Mesh()
    for a,b,c in [((-.2,0,0),(.2,0,0),(0,0,.13)),((-.2,0,0),(0,.11,.04),(.2,0,0)),((-.2,0,0),(.2,0,0),(0,-.11,.04))]:boat.triangle(a,b,c,'#f2e5c8')
    add('paper-boat',boat,(1.0,2.98,1.46))

    # Wood clock case and face; hands and pendulum are moving meshes below.
    cx,cy,cz=CLOCK
    block('clock-back',(cx,cy+.10,cz-.28),(.59,.19,1.03),'#b9976c','wood',.10)
    for x in [cx-.22,cx+.22]:block('clock-post',(x,cy-.04,cz-.39),(.075,.16,.58),'#b9976c','wood')
    block('clock-bottom',(cx,cy-.04,cz-.69),(.50,.20,.09),'#bf9d70','wood')
    add('clock-rim',torus(.31,.055,'#d7ba82',36,8),(cx,cy-.08,cz),rotation=(90,0,0),finish='metal')
    add('clock-face',cylinder(.29,.035,'#f9efce',36),(cx,cy-.045,cz),rotation=(90,0,0))
    for i in range(12):
        a=i*math.pi/6
        bar('clock-tick',(cx+.235*math.sin(a),cy-.09,cz+.235*math.cos(a)),
            (cx+.262*math.sin(a),cy-.09,cz+.262*math.cos(a)),.009,'#657361','matte')

    # Fixed balance support: level feet and one continuous turned column.
    for x in [-.78,.78]:
        for y in [-.30,.30]:add('balance-foot',cylinder(.09,.06,'#6b7569',16),(x,y,0),finish='enamel')
    add('balance-base',box((2.15,.95,.24),'#c6ac84',.08),(0,0,.18),finish='wood')
    add('balance-base-top',box((2.03,.85,.06),'#ecdbb3',.025),(0,0,.33),finish='metal')
    add('balance-column',lathe([(.30,.35),(.29,.42),(.22,.50),(.16,.64),(.13,1.05),(.11,2.25),(.095,2.95),(.12,PIVOT)],'#96c6b5',48),(0,.10,0),finish='enamel')
    for z,r,h in [(.38,.30,.07),(.52,.22,.035),(PIVOT-.1,.13,.10)]:add('column-collar',cylinder(r,h,'#e3cc9e',40),(0,.1,z),finish='metal')

    s.parts['beam']=box((ARM*2,.19,.15),'#dfc795',.045)
    s.parts['pivot']=cylinder(.25,.11,'#d9be89',40)
    s.parts['pivot-inlay']=cylinder(.115,.018,'#99c9b7',32)
    profile=[(0,-.33),(RADIUS*.3,-.36),(RADIUS*.65,-.32),(RADIUS*.85,-.23),(RADIUS*.97,-.10),
             (RADIUS,-.025),(RADIUS,0),(RADIUS-.025,.025),(RADIUS-.045,.005),(RADIUS-.05,-.04),
             (RADIUS*.84,-.24),(RADIUS*.6,-.26),(0,-.26)]
    for index,color in enumerate(['#a1d0cb','#e7b99f']):
        s.parts['bowl-'+str(index)]=lathe(profile,color,64)
    s.parts['bowl-rim']=torus(RADIUS-.025,.026,'#e5d0ab',64,8)
    for key,color in [('block','#f1dfb8'),('xblock','#a9d8c5'),('negative','#e8bba8')]:
        s.parts[key]=box((.52,.36,.58),color,.035)
        s.parts[key+'-wide']=box((2.20,.36,.58),color,.035)
    # Three actual chains form a tripod suspension for each pan. Links are
    # interlocking torus meshes in alternating planes, merged into one VBO.
    chain=Mesh();height=PIVOT-RIM-.16
    for theta in [math.pi/2,math.pi*7/6,math.pi*11/6]:
        end=(math.cos(theta)*(RADIUS-.10),math.sin(theta)*(RADIUS-.10),0)
        start=(0,0,height)
        length=math.sqrt(sum((b-a)**2 for a,b in zip(start,end)));count=round(length/.10)
        direction=tuple((end[j]-start[j])/length for j in range(3))
        # Torus starts in XY. Rotate its plane into the chain's vertical plane.
        rz=math.degrees(math.atan2(direction[1],direction[0]))
        for i in range(count+1):
            t=i/count;p=tuple(start[j]+(end[j]-start[j])*t for j in range(3))
            link=torus(.041,.009,'#d8c9a9',12,5)
            chain.add(link,p,(1,1.36,1),rotation=(90,35 if i%2 else -35,rz))
    s.parts['chains']=chain
    s.parts['hook']=torus(.07,.018,'#cdbd99',20,6)
    s.parts['hour-hand']=rod((0,0,0),(0,0,.14),.014,'#52675b')
    s.parts['minute-hand']=rod((0,0,0),(0,0,.21),.010,'#52675b')
    s.parts['second-hand']=rod((0,0,0),(0,0,.24),.005,'#b18460')
    pendulum=Mesh();pendulum.add(rod((0,0,0),(0,0,-.42),.012,'#c5a770'))
    pendulum.add(ball('#d6ba83'),(0,0,-.42),(.075,.035,.075));s.parts['pendulum']=pendulum
    for name,color in [('star-gold','#e9c47d'),('star-mint','#9dc8b4'),('star-peach','#e4b39a')]:s.parts[name]=star(.085,color,.025)
    return s
