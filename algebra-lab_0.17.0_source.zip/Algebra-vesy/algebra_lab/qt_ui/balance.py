"""A small software-rendered 3D-style balance, with finite action animations.

The scene and block sprites are cached. No OpenGL context, animation at idle,
blur effects, or equipment/model work happens in this widget.
"""
import math
from collections import Counter, OrderedDict
from PyQt6.QtCore import Qt, QRectF, QPointF, QTimer, QElapsedTimer
from PyQt6.QtGui import (QColor, QPainter, QPen, QBrush, QFont, QPainterPath,
                        QLinearGradient, QRadialGradient, QPixmap, QPolygonF)
from PyQt6.QtWidgets import QWidget, QSizePolicy

INK = '#343360'


def gradient(y, height, light, dark):
    value = QLinearGradient(0, y, 0, y + height)
    value.setColorAt(0, QColor(light)); value.setColorAt(1, QColor(dark))
    return QBrush(value)


def polygon(p, points, brush, pen=Qt.PenStyle.NoPen):
    p.setPen(pen); p.setBrush(brush)
    p.drawPolygon(QPolygonF([QPointF(x, y) for x, y in points]))


class Balance(QWidget):
    DURATION = 460
    CELEBRATION_DURATION = 680

    def __init__(self, parent=None):
        super().__init__(parent)
        self.left, self.right, self.tilt = [], [], 0
        self._angle = 0.0
        self._start_angle = 0.0
        self._progress = 1.0
        self._old = ([], [])
        self._motion = True
        self._initialized = False
        self._cache = self._stage = None
        self._cache_key = self._stage_key = None
        self._sprites = OrderedDict()
        self._clock = QElapsedTimer()
        self._celebration = QElapsedTimer()
        self._timer = QTimer(self)
        self._timer.setInterval(33)  # At most about 30 frames/s, only during an action.
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self.attachments = []
        self.setMinimumSize(400, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAccessibleName('Алгебраические весы')

    @property
    def is_animating(self):
        return self._timer.isActive()

    def set_motion(self, enabled):
        if self._motion == bool(enabled):
            return
        self._motion = bool(enabled)
        if not self._motion:
            self.stop_animation()

    def set_blocks(self, left, right, tilt=0):
        left, right = list(left), list(right)
        tilt = max(-5, min(5, tilt))
        if (left, right, tilt) == (self.left, self.right, self.tilt):
            return
        self._old = (self.left[:], self.right[:])
        self._start_angle = self._angle
        self.left, self.right, self.tilt = left, right, tilt
        self.setAccessibleDescription('Левая чаша: %s. Правая чаша: %s.' %
                                      (', '.join(map(str, left)) or 'пусто', ', '.join(map(str, right)) or 'пусто'))
        if self._motion and self.isVisible() and self._initialized:
            self._progress = 0.0
            self._clock.start(); self._timer.start()
        else:
            self.stop_animation()
        self._initialized = True
        self._invalidate()

    def celebrate(self):
        if self._motion and self.isVisible():
            self._celebration.start(); self._timer.start(); self._invalidate()

    def stop_animation(self):
        self._timer.stop(); self._clock.invalidate(); self._celebration.invalidate()
        self._angle = float(self.tilt); self._progress = 1.0
        self._old = (self.left[:], self.right[:])
        self._invalidate()

    def hideEvent(self, event):
        self.stop_animation()
        super().hideEvent(event)

    def _invalidate(self):
        self._cache_key = None; self.update()

    def _tick(self):
        moving = False
        if self._clock.isValid():
            self._progress = min(1.0, self._clock.elapsed()/self.DURATION)
            t = self._progress
            eased = (1-math.exp(-7*t)*math.cos(2*math.pi*t))/(1-math.exp(-7))
            self._angle = self._start_angle+(self.tilt-self._start_angle)*eased
            if t >= 1:
                self._angle = float(self.tilt); self._clock.invalidate()
                self._old = (self.left[:], self.right[:])
            else:
                moving = True
        if self._celebration.isValid():
            if self._celebration.elapsed() >= self.CELEBRATION_DURATION:
                self._celebration.invalidate()
            else:
                moving = True
        if not moving:
            self._timer.stop()
        self._invalidate()

    def _geometry(self):
        scale = min(1.1, self.width()/1000, self.height()/260)
        w, h = self.width()/scale, self.height()/scale
        arm = w*.275
        clearance = arm*math.sin(math.radians(6))
        return scale, w, h, arm, clearance

    def paintEvent(self, event):
        ratio = self.devicePixelRatioF()
        key = (self.width(), self.height(), ratio, self.font().family())
        if key != self._stage_key:
            self._stage = QPixmap(round(self.width()*ratio), round(self.height()*ratio))
            self._stage.setDevicePixelRatio(ratio); self._stage.fill(Qt.GlobalColor.transparent)
            p = QPainter(self._stage); p.setRenderHint(QPainter.RenderHint.Antialiasing)
            self._draw_stage(p); p.end(); self._stage_key = key
            self._cache_key = None
        frame_key = (key, self._angle, self._progress, tuple(self.left), tuple(self.right),
                     self._celebration.elapsed()//33 if self._celebration.isValid() else -1)
        if frame_key != self._cache_key:
            self._cache = self._stage.copy()
            painter = QPainter(self._cache)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            self.draw_balance(painter); painter.end()
            self._cache_key = frame_key
        painter = QPainter(self); painter.drawPixmap(0, 0, self._cache); painter.end()

    def _draw_stage(self, p):
        w, h = self.width(), self.height()
        p.setPen(QPen(QColor('#e0e4f4'), 1))
        p.setBrush(gradient(0, h, '#eaf2ff', '#fff6e8'))
        p.drawRoundedRect(QRectF(1, 1, w-2, h-2), 22, 22)
        p.save()
        clip = QPainterPath(); clip.addRoundedRect(QRectF(1, 1, w-2, h-2), 22, 22)
        p.setClipPath(clip)
        # A perspective floor, kept in the static cache with the pedestal.
        horizon = h*.57
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(gradient(horizon, h-horizon, '#f1f1f8', '#e9e7f3'))
        p.drawRect(QRectF(1, horizon, w-2, h-horizon))
        p.setPen(QPen(QColor('#dcdfea'), 1))
        for step in [-3, -2, -1, 0, 1, 2, 3]:
            p.drawLine(QPointF(w/2+step*w*.08, horizon), QPointF(w/2+step*w*.26, h))
        for y in [.70, .82, .98]:
            p.drawLine(QPointF(0, h*y), QPointF(w, h*y))
        scale, width, height, arm, clearance = self._geometry()
        p.scale(scale, scale)
        cx, cy, floor = width/2, max(40, clearance+18), height-19
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor('#d3d0e2'))
        p.drawEllipse(QRectF(cx-126, floor-8, 252, 19))
        # The base is a short elliptical cylinder with a lit top and a deep front.
        p.setBrush(gradient(floor-30, 31, '#9d91d6', '#50478b'))
        p.drawRoundedRect(QRectF(cx-104, floor-26, 208, 26), 12, 12)
        p.setBrush(gradient(floor-40, 24, '#d0c8f2', '#8a7bc5'))
        p.setPen(QPen(QColor('#51478c'), 1.6)); p.drawEllipse(QRectF(cx-104, floor-39, 208, 27))
        p.setPen(QPen(QColor('#e9e4ff'), 2));p.drawArc(QRectF(cx-98, floor-36, 196, 23), 0, 180*16)
        # Three faces of the upright, including a narrow illuminated edge.
        polygon(p, [(cx,cy+8),(cx-37,floor-31),(cx+8,floor-23),(cx+12,cy+13)],
                gradient(cy, floor-cy, '#b7a7eb', '#6a56af'))
        polygon(p, [(cx+12,cy+13),(cx+8,floor-23),(cx+39,floor-32),(cx+22,cy+13)],
                gradient(cy, floor-cy, '#7360ba', '#45377e'))
        polygon(p, [(cx,cy+8),(cx+12,cy+13),(cx+22,cy+13),(cx+7,cy+5)], QColor('#e4d8ff'))
        p.setPen(QPen(QColor('#d2c8f7'), 2));p.drawLine(QPointF(cx-1,cy+36),QPointF(cx-23,floor-44))
        p.restore()

    def draw_balance(self, p):
        scale, w, h, arm, clearance = self._geometry()
        p.save();p.scale(scale, scale)
        cx, cy = w/2, max(40, clearance+18)
        radius = min(w*.175, 174)
        # Ground contact shadows are simple ellipses, not expensive blur effects.
        p.setPen(Qt.PenStyle.NoPen)
        for direction in [-1, 1]:
            p.setBrush(QColor('#d7d6e5'))
            p.drawEllipse(QRectF(cx+direction*arm-radius*.78, h-29, radius*1.56, 13))
        p.save();p.translate(cx, cy);p.rotate(self._angle)
        beam = [(-arm,-9),(-9,-14),(arm,-9),(arm,7),(0,13),(-arm,7)]
        polygon(p, [(x+3,y+7) for x,y in beam], gradient(-10, 34, '#d89726', '#bd7a20'), QPen(QColor('#916322'),1.5))
        polygon(p, beam, gradient(-14, 28, '#ffe88d', '#efb326'), QPen(QColor('#bd8b27'),1.6))
        polygon(p, [(-arm,-9),(-arm+7,-14),(6,-20),(arm+7,-14),(arm,-9),(-9,-14)], QColor('#fff2b9'))
        p.setPen(QPen(QColor('#fff6cd'), 2));p.drawLine(QPointF(-arm+17,-5),QPointF(arm-17,-5))
        for x in [-arm, arm]:
            self._orb(p, x, 0, 12, '#fff2ba', '#c58e26', '#9e7429')
            p.setBrush(QColor('#725839'));p.setPen(Qt.PenStyle.NoPen);p.drawEllipse(QPointF(x,2),3,3)
        p.restore()
        radians = math.radians(self._angle)
        self.attachments = []
        for index, (direction, values) in enumerate([(-1,self.left),(1,self.right)]):
            x = cx+direction*arm*math.cos(radians)
            y = cy+direction*arm*math.sin(radians)
            rim = h-78-clearance+direction*arm*math.sin(radians)
            light, middle, dark = ('#a7efff','#38bde8','#147eaf') if index==0 else ('#ffd2ca','#f68591','#bd4269')
            p.setPen(QPen(QColor('#77738d'), 1.6));p.setBrush(gradient(y+8, 18, '#ffffff','#ada8c4'))
            p.drawEllipse(QRectF(x-6,y+9,12,17))
            for edge in [-1,1]:
                start, end = QPointF(x+edge*3,y+24), QPointF(x+edge*(radius-8),rim+1)
                self.chain(p,start,end,1)
                self.attachments.append((QPointF(start.x()*scale,start.y()*scale),QPointF(end.x()*scale,end.y()*scale)))
            # Concave bowl: back rim, inner well, front shell and reflection.
            p.setPen(QPen(QColor(dark), 1.8));p.setBrush(gradient(rim-14, 29, light,dark))
            p.drawEllipse(QRectF(x-radius,rim-14,radius*2,28))
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(gradient(rim-10, 20, dark,middle))
            p.drawEllipse(QRectF(x-radius+6,rim-10,radius*2-12,20))
            shell=QPainterPath(QPointF(x-radius,rim))
            shell.cubicTo(x-radius*.85,rim+48,x+radius*.85,rim+48,x+radius,rim)
            shell.quadTo(x,rim+24,x-radius,rim)
            p.setPen(QPen(QColor(dark),1.6));p.setBrush(gradient(rim,36,light,dark));p.drawPath(shell)
            p.setPen(QPen(QColor(light),2.5));shine=QPainterPath(QPointF(x-radius+18,rim+10))
            shine.cubicTo(x-radius*.45,rim+34,x+radius*.40,rim+34,x+radius*.68,rim+18);p.drawPath(shine)
            self._draw_blocks(p,values,self._old[index],x,rim,radius,scale)
            # Front lip partly occludes the block feet, grounding them in the bowl.
            lip=QPainterPath(QPointF(x-radius,rim))
            lip.quadTo(x,rim+24,x+radius,rim);lip.quadTo(x,rim+15,x-radius,rim)
            p.setPen(QPen(QColor(dark),1.3));p.setBrush(gradient(rim,18,light,middle));p.drawPath(lip)
            p.setPen(QPen(QColor('#f5ffff' if index==0 else '#fff1ea'),2.2))
            shine=QPainterPath(QPointF(x-radius+6,rim+1));shine.quadTo(x,rim+18,x+radius-6,rim+1);p.drawPath(shine)
            for edge in [-1,1]:
                self._orb(p,x+edge*(radius-8),rim+1,4,'#ffffff','#9b96b5','#68627e')
        self._orb(p,cx+3,cy+4,26,'#c99a36','#9d7028','#805927')
        self._orb(p,cx,cy,26,'#fff4b7','#e7ac27','#bd8729')
        self._orb(p,cx,cy,12,'#c9c2f2','#7561b3','#56438c')
        p.setPen(QPen(QColor('#eae4ff'),1.5));p.drawLine(QPointF(cx-4,cy),QPointF(cx+4,cy))
        if self._celebration.isValid():
            self._draw_celebration(p,cx,cy,h)
        p.restore()

    @staticmethod
    def _orb(p,x,y,r,light,dark,edge):
        g=QRadialGradient(QPointF(x-r*.30,y-r*.40),r*1.45)
        g.setColorAt(0,QColor(light));g.setColorAt(1,QColor(dark))
        p.setPen(QPen(QColor(edge),1.3));p.setBrush(QBrush(g));p.drawEllipse(QPointF(x,y),r,r)

    @staticmethod
    def _items(values):
        return list(map(str, values)) if len(values)<=5 else [' · '.join(map(str,values))]

    def _draw_blocks(self,p,values,old_values,x,rim,radius,scale):
        items, old = self._items(values), self._items(old_values)
        counts = Counter(old); new_flags=[]
        for item in items:
            new_flags.append(counts[item]==0)
            if counts[item]:counts[item]-=1
        def widths(strings):return [54 if len(text)<=2 else min(2*radius-35,232) for text in strings]
        sizes=widths(items); bx=x-(sum(sizes)+max(0,len(items)-1)*9)/2
        for text,bw,new in zip(items,sizes,new_flags):
            t=self._progress
            lift=(-28*(1-t)**2) if new else 0
            p.save()
            if new:p.setOpacity(.35+.65*min(1,t*3))
            p.drawPixmap(QPointF(bx-2,rim-53-11+lift),self._block_sprite(text,bw,scale))
            p.restore();bx+=bw+9
        # Removed blocks rise and fade, then leave the cacheable final scene.
        if self._progress<1:
            sizes=widths(old);bx=x-(sum(sizes)+max(0,len(old)-1)*9)/2
            removed=Counter(old)-Counter(items)
            for text,bw in zip(old,sizes):
                if removed[text]:
                    p.save();p.setOpacity((1-self._progress)*.65)
                    p.drawPixmap(QPointF(bx-2,rim-64-24*self._progress),self._block_sprite(text,bw,scale));p.restore()
                    removed[text]-=1
                bx+=bw+9

    def _block_sprite(self,text,width,scale):
        ratio=self.devicePixelRatioF()*scale
        key=(text,width,round(ratio,5),self.font().family())
        if key in self._sprites:
            self._sprites.move_to_end(key);return self._sprites[key]
        depth,height=10,53
        sprite=QPixmap(math.ceil((width+depth+4)*ratio),math.ceil((height+depth+5)*ratio))
        sprite.setDevicePixelRatio(ratio);sprite.fill(Qt.GlobalColor.transparent)
        p=QPainter(sprite);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.translate(2,depth+1)
        is_x='x' in text.lower();negative=text.startswith(('−','-'))
        front,shade,top,edge,ink=('#57cfff','#168bbf','#b4efff','#1f83ac','#113f66') if is_x else (
            ('#ffa5a2','#cd566c','#ffe0d4','#bb5367','#681d37') if negative else
            ('#ffe17b','#dda231','#fff1b7','#c49331','#604514'))
        polygon(p,[(width,0),(width+depth,-depth),(width+depth,height-depth),(width,height)],gradient(0,height,front,shade),QPen(QColor(edge),1))
        polygon(p,[(0,0),(depth,-depth),(width+depth,-depth),(width,0)],QColor(top),QPen(QColor(edge),1))
        p.setPen(QPen(QColor(edge),1.5));p.setBrush(gradient(0,height,front,shade));p.drawRoundedRect(QRectF(0,0,width,height),6,6)
        p.setPen(QPen(QColor(top),2));p.drawLine(QPointF(7,5),QPointF(width-7,5))
        font=QFont(self.font());font.setPixelSize(33 if len(text)<=2 else 20);font.setBold(True);p.setFont(font)
        # Shrink long exact expressions until they fit; never clip the mathematical label.
        while p.fontMetrics().horizontalAdvance(text)>width-10 and font.pixelSize()>12:
            font.setPixelSize(font.pixelSize()-1);p.setFont(font)
        p.setPen(QColor(ink));p.drawText(QRectF(2,0,width-4,height),int(Qt.AlignmentFlag.AlignCenter),text);p.end()
        self._sprites[key]=sprite
        while len(self._sprites)>64:self._sprites.popitem(last=False)
        return sprite

    def _draw_celebration(self,p,cx,cy,h):
        t=min(1,self._celebration.elapsed()/self.CELEBRATION_DURATION)
        p.save();p.setOpacity((1-t)**.65);p.setPen(Qt.PenStyle.NoPen)
        colors=['#f0b936','#1dbaaa','#8d79d9','#ec8196']
        for i in range(12):
            angle=math.radians(25+i*360/12)
            distance=36+105*t
            x,y=cx+math.cos(angle)*distance,cy+38+math.sin(angle)*distance*.65-18*t
            p.save();p.translate(x,y);p.rotate(i*31+t*100);p.setBrush(QColor(colors[i%4]))
            if i%2:p.drawRoundedRect(QRectF(-3,-5,6,10),1.5,1.5)
            else:
                star=[]
                for j in range(10):
                    r=7 if j%2==0 else 3
                    a=math.radians(-90+j*36);star.append((math.cos(a)*r,math.sin(a)*r))
                polygon(p,star,QColor(colors[i%4]))
            p.restore()
        p.restore()

    @staticmethod
    def chain(p,start,end,scale):
        dx,dy=end.x()-start.x(),end.y()-start.y()
        length=math.hypot(dx,dy);count=max(2,min(30,round(length/12)))
        step=length/count
        p.save();p.translate(start);p.rotate(math.degrees(math.atan2(dy,dx))-90)
        for i in range(count):
            wide=3.6 if i%2==0 else 2.5
            p.setPen(QPen(QColor('#666780'),2.2));p.setBrush(QColor('#d5dae8'))
            p.drawEllipse(QRectF(-wide,i*step-2,wide*2,step+4))
            p.setPen(QPen(QColor('#ffffff'),1.2));p.drawArc(QRectF(-wide+1,i*step-1,wide*2-2,step+2),20*16,170*16)
        p.restore()
