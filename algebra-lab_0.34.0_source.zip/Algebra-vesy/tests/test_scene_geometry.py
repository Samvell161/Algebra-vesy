import math
import unittest
from algebra_lab.qt_ui.scene3d.geometry import box,sphere,torus,lathe,rod
from algebra_lab.qt_ui.scene3d.model import build_workshop

class Geometry3DTests(unittest.TestCase):
    def test_meshes_are_finite_solid_xyz_with_unit_normals(self):
        meshes=[box((2,1,.6),radius=0),box((2,1,.6)),sphere(),torus(),
                lathe([(.2,0),(.1,1)],caps=True),rod((0,0,0),(1,2,3))]
        for mesh in meshes:
            self.assertGreater(mesh.vertex_count,12)
            self.assertEqual(mesh.vertex_count%3,0)
            self.assertTrue(all(math.isfinite(v) for v in mesh.data))
            low,high=mesh.bounds()
            self.assertTrue(all(a<b for a,b in zip(low,high)))
            for i in range(0,len(mesh.data),9):self.assertAlmostEqual(sum(v*v for v in mesh.data[i+3:i+6]),1,places=5)

    def test_triangle_winding_agrees_with_normals_for_depth_culling(self):
        from algebra_lab.qt_ui.scene3d.geometry import cross,sub
        for mesh in [box(radius=0),box(),sphere(),torus(),lathe([(.2,0),(.1,1)],caps=True)]:
            for i in range(0,len(mesh.data),27):
                a,b,c=[mesh.data[i+k:i+k+3] for k in (0,9,18)]
                face=cross(sub(b,a),sub(c,a))
                normal=[sum(mesh.data[i+k+3+j] for k in (0,9,18)) for j in range(3)]
                self.assertGreaterEqual(sum(x*y for x,y in zip(face,normal)),-1e-8)

    def test_workshop_contains_room_and_background_as_batched_meshes(self):
        scene=build_workshop()
        for name in ['workbench','wall-right','window-arch','garden-tree','cloud','shelf','book',
                     'map-castle-tower','planet-ring','owl-goggles','paper-boat','abacus-bead','clock-face','balance-foot']:
            self.assertIn(name,scene.names)
        self.assertLessEqual(len(scene.static),6)
        self.assertLess(sum(m.vertex_count for m in scene.static.values()),200000)
        for key in ['beam','chains','bowl-0','bowl-1','xblock','hour-hand','pendulum']:
            low,high=scene.parts[key].bounds()
            self.assertTrue(all(a<b for a,b in zip(low,high)),key)


    def test_dense_bevels_preserve_size_and_supply_smooth_curved_normals(self):
        low=box((.52,.36,.58),radius=.045,bevel_steps=3)
        high=box((.52,.36,.58),radius=.045,bevel_steps=7)
        self.assertEqual(low.bounds(),high.bounds())
        self.assertGreater(high.vertex_count,low.vertex_count*3)
        def normals(mesh):return {tuple(round(v,5) for v in mesh.data[i+3:i+6]) for i in range(0,len(mesh.data),9)}
        self.assertGreater(len(normals(high)),len(normals(low))*2)
        for i in range(0,len(high.data),9):
            self.assertTrue(all(math.isfinite(v) for v in high.data[i:i+9]))
            self.assertAlmostEqual(sum(v*v for v in high.data[i+3:i+6]),1,places=5)
