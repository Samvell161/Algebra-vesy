"""Verify the installed payload on a real GL display; optionally record it.

Use a dedicated X display when recording: screenshots include the native child
window. NumPy and the old room image are deliberately unavailable in this test.
"""
import argparse
import hashlib
import io
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('package',type=Path);parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--record',action='store_true')
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
sys.modules['numpy']=None
frames=[];timestamps=[]
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);subprocess.run(['dpkg-deb','-x',str(args.package),str(root)],check=True)
    payload=root/'usr/share/algebra-lab';sys.path.insert(0,str(payload))
    manifest=json.loads((root/'usr/share/doc/algebra-lab/third-party.json').read_text())
    archive=payload/'algebra_lab/_vendor'/manifest['runtime_archive']
    assert manifest['source_wheel_sha256']=='15995fd3b0deb991376805da36137a4ae5aba6ddbb5e29ac1f35462d130a3f77'
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['runtime_sha256']
    with zipfile.ZipFile(archive) as z:assert not any(n.endswith(('.dll','.so','.pyd')) for n in z.namelist())
    from PyQt6 import sip
    from PyQt6.QtCore import QElapsedTimer,QTimer,QBuffer,QIODevice
    from PyQt6.QtGui import QFontDatabase,QFontInfo
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtTest import QTest
    from algebra_lab.qt_ui.app import Window
    from algebra_lab.qt_ui.workshop import BACKGROUND,background_texture
    BACKGROUND.unlink()
    app=QApplication([])
    for font in (root/'usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):assert QFontDatabase.addApplicationFont(str(font))>=0
    app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
    data=root/'profile';data.mkdir();w=Window(data);w.start('cups-4');w.move(0,0);w.show()
    surface=w.board.surface
    def wait_for(predicate):
        for _ in range(300):
            if predicate():return
            assert not w.board.graphics_error,w.board.graphics_error
            QTest.qWait(50)
        raise AssertionError('3D rendering timed out')
    def screenshot():return app.primaryScreen().grabWindow(0,w.x(),w.y(),w.width(),w.height())
    def save(name):screenshot().save(str(args.output/name))
    clock=QElapsedTimer()
    def pause(seconds):
        if not args.record:QTest.qWait(round(seconds*1000));return
        from PIL import Image
        for _ in range(round(seconds*18)):
            QTest.qWait(max(1,round((len(frames)+1)*1000/18)-clock.elapsed()))
            buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly);screenshot().save(buffer,'PNG')
            frames.append(Image.open(io.BytesIO(bytes(buffer.data()))).convert('RGB'));timestamps.append(clock.elapsed())
    try:
        wait_for(lambda:surface.frames>0);QTest.qWait(200);clock.start()
        assert w.board.is_3d and w.height()<=600 and w.width()==1024
        assert surface.height()>=375
        assert surface.scene_size[0]>surface.width()
        assert background_texture.cache_info().misses==0
        assert surface.scene and surface.isValid() and surface.vp.isAffine()
        assert all(c.gravity==981 for c in w.board._cups)
        assert QFontInfo(w.condition.font()).family()=='Algebra Rounded'
        import OpenGL
        assert str(archive) in OpenGL.__file__
        assert sys.modules.get('numpy') is None
        image=surface.grabFramebuffer()
        assert len({image.pixelColor(x,y).name() for x in range(0,image.width(),12) for y in range(0,image.height(),12)})>80
        assert w.board.container.geometry().bottom()<w.left.geometry().top()
        for button in w.centralWidget().findChildren(QPushButton):
            if button.isVisible():assert min(button.width(),button.height())>=44,button.text()
        w.board.set_quality('detail');wait_for(lambda:surface._applied_quality=='detail')
        assert surface.shadow_size==2048 and surface.info['contact_shading']
        original=w.condition.text();initial_progress=w.store.progress()
        pause(.5);save('game.png');image.save(str(args.output/'gpu-frame.png'))
        assert len(surface.scene.room_bounds)>=22 and surface.lamp_shadow_frames>0
        assert surface.lamp_shadow_size==1024
        lamp_maps=surface.lamp_shadow_frames
        w.store.save_settings({'room_lamp':False});w.refresh();pause(.5);save('lamp-off.png')
        assert not surface.lamp_enabled and surface.lamp_shadow_frames==lamp_maps
        assert w.condition.text()==original and w.store.progress()==initial_progress
        w.store.save_settings({'room_lamp':True});w.refresh();pause(.4)
        assert surface.lamp_enabled and surface.lamp_shadow_frames==lamp_maps
        handles=dict(surface.buffers);shadow_frames=surface.shadow_frames
        pause(.7)
        assert surface.info['view']=='fixed-front' and surface.eye.x()==0
        assert surface.buffers==handles and surface.shadow_frames==shadow_frames
        save('front-view.png')
        assert w.condition.text()==original and w.store.progress()==initial_progress
        detail_textures=dict(surface.textures)
        w.store.save_settings({'graphics_quality':'smooth'});w.refresh()
        wait_for(lambda:surface._applied_quality=='smooth');pause(.1);save('smooth.png')
        assert surface.shadow_size==1024 and dict(surface.textures)==detail_textures
        assert w.condition.text()==original and w.store.progress()==initial_progress
        w.store.save_settings({'graphics_quality':'detail'});w.refresh()
        wait_for(lambda:surface._applied_quality=='detail');pause(.1)

        w.store.bind('A1','1');w.store.bind('A2','2');w.operation('add')
        w.reader.emit({'uid':'A1','source':'left'});w.poll();pause(1.5)
        assert w.board.tilt==-1.8 and not w.board.is_animating
        assert w.condition.text()==original;save('one-unit.png')
        w.undo();pause(1.35);w.operation('add');w.reader.emit({'uid':'A2','source':'left'});w.poll();pause(1.5)
        assert w.board.tilt==-3
        assert len(w.board._cups[0].bodies)==5 and any(b.row==1 for b in w.board._cups[0].bodies)
        for cup in w.board._cups:
            for body in cup.bodies:assert abs(body.y-cup.support(body)[0])<.001
        save('stacked.png');w.undo();pause(1.35)
        w.operation('remove');w.reader.emit({'uid':'A2','source':'left'});w.poll();pause(1.4)
        assert w.board.tilt==3;save('left-changed.png')
        w.reader.emit({'uid':'A2','source':'right'});w.poll();pause(1.4)
        assert w.session.cup_phase=='answer' and not w.session.completed
        assert w.condition.text()==original and w.height()<=600;save('answer.png')
        w.session.cup_guess=2;w.check();pause(.2);save('success.png');pause(.7)
        assert w.session.completed and w.store.solutions()
        assert not w.board.is_animating
        modal_seen=[]
        def close_adult():
            dialog=QApplication.activeModalWidget()
            assert dialog is not None
            modal_seen.append(dialog.windowTitle());save('adult.png');dialog.reject()
        QTimer.singleShot(180,close_adult);w.adult()
        assert modal_seen and surface.isValid() and not w.closed
        def close_lighting():
            dialog=QApplication.activeModalWidget()
            lamp=next(b for b in dialog.findChildren(QPushButton) if b.text().startswith('Светильник'))
            assert not lamp.visibleRegion().isEmpty()
            save('lighting-settings.png');dialog.accept()
        QTimer.singleShot(180,close_lighting);w.visual_settings()
        from unittest.mock import patch
        from algebra_lab import lesson_queue
        w.store.save_settings({'mobile_lessons_enabled':True})
        lesson_queue.submit(w.store.db,'a'*32,w.store.profile_id,'cups-1')
        with patch.object(w.mobile,'running',True):
            w.check_remote();app.processEvents();assert not w.remote_bar.isHidden()
            w.respond_remote('accepted');assert w.session.task_id=='cups-1'
        w.board.set_motion(False)
        assert not w.board.clock.is_running
        assert not w.board.is_animating
        report={'version':'0.34.0','ok':True,'graphics':dict(surface.info),'framebuffer':[image.width(),image.height()],
                'static_vertices':sum(m.vertex_count for m in surface.scene.static.values()),
                'cube_triangles':surface.scene.parts['block'].vertex_count//3,'bowl_triangles':surface.scene.parts['bowl-0'].vertex_count//3,
                'large_viewport_verified':True,'controls_below_native_surface':True,
                'moving_part_vertices':sum(m.vertex_count for m in surface.scene.parts.values()),
                'static_batches':len(surface.scene.static),'room_prop_assemblies':len(surface.scene.room_bounds),'room_lighting':['daylight','warm spotlight'],'lamp_shadow_size':surface.lamp_shadow_size,'lamp_setting_verified':True,'background_room_image_deleted':True,'numpy_unavailable':True,
                'quality_switch_and_glyph_cache':True,'quality_preference':w.store.settings()['graphics_quality'],
                'bundled_binding_verified':True,'fixed_frontal_orthographic_camera':True,'xyz_contacts':True,
                'rfid_pair_and_explicit_answer':True,'adult_return_and_android_proposal':True,'touch_targets_minimum':44}
    finally:w.close()
    assert surface._dead and sip.isdeleted(surface)
    report['native_gl_window_released_before_application_exit']=True
    from algebra_lab.qt_ui.app import icon
    from algebra_lab.qt_ui.gui_lifecycle import release_gui_caches
    sip.delete(w)
    del surface,w
    import gc
    gc.collect()
    icon.cache_clear();release_gui_caches();sip.delete(app)
    del app
    gc.collect()
if args.record:
    frames=[frame.quantize(colors=192) for frame in frames]
    durations=[max(10,b-a) for a,b in zip(timestamps,timestamps[1:])]+[56]
    frames[0].save(args.output/'real-3d.gif',save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True)
(args.output/'3d-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
