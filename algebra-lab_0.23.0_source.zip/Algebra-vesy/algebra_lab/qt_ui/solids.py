"""Small orthographic mesh renderer for the balance's manufactured parts.

Coordinates are x (left/right), y (depth, positive away), z (up). A level
horizontal plane always projects symmetrically. No OpenGL/runtime engine.
"""
import math
from PyQt6.QtCore import QPointF,Qt
from PyQt6.QtGui import QColor,QPainter,QPolygonF,QPen

PITCH=math.radians(12)
SIN,COS=math.sin(PITCH),math.cos(PITCH)
VIEW=(0,-COS,SIN)
LIGHT=(-.43,-.48,.77)


def dot(a,b):return sum(x*y for x,y in zip(a,b))


def project(point,origin=(0,0)):
    x,y,z=point
    return QPointF(origin[0]+x,origin[1]-z*COS-y*SIN)


def normal(points):
    a,b,c=points[:3]
    u=tuple(b[i]-a[i] for i in range(3));v=tuple(c[i]-a[i] for i in range(3))
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
    length=math.sqrt(dot(n,n)) or 1
    return tuple(value/length for value in n)


def shade(color,n):
    c=QColor(color);diff=max(0,dot(n,LIGHT))
    half=(-.23,-.78,.58)
    spec=max(0,dot(n,half))**18*.23
    factor=.57+.56*diff
    return QColor(*[min(255,round(channel*factor+255*spec)) for channel in (c.red(),c.green(),c.blue())])


def draw_mesh(p,faces,origin=(0,0),half=None):
    visible=[]
    for points,color in faces:
        center=tuple(sum(v[i] for v in points)/len(points) for i in range(3))
        if half=='back' and center[1]<0:continue
        if half=='front' and center[1]>=0:continue
        n=normal(points)
        if dot(n,VIEW)<=.00001:continue
        visible.append((dot(center,VIEW),points,shade(color,n)))
    for _,points,color in sorted(visible,key=lambda value:value[0]):
        # An overlapping subpixel stroke seals antialiasing gaps between coplanar faces.
        pen=QPen(color,.7);pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin);p.setPen(pen)
        p.setBrush(color);p.drawPolygon(QPolygonF([project(v,origin) for v in points]))


def rounded_ring(width,depth,radius,steps=4):
    result=[]
    for cx,cy,start in [(width/2-radius,depth/2-radius,0),(-width/2+radius,depth/2-radius,90),
                         (-width/2+radius,-depth/2+radius,180),(width/2-radius,-depth/2+radius,270)]:
        for i in range(steps+1):
            angle=math.radians(start+i*90/steps)
            result.append((cx+radius*math.cos(angle),cy+radius*math.sin(angle)))
    return result


def plinth(width,depth,z,height,color,bevel=3,radius=12):
    rings=[(width-2*bevel,depth-2*bevel,z),(width,depth,z+bevel),
           (width,depth,z+height-bevel),(width-2*bevel,depth-2*bevel,z+height)]
    vertices=[[(x,y,zz) for x,y in rounded_ring(w,d,min(radius,d/2-1))] for w,d,zz in rings]
    faces=[];count=len(vertices[0])
    for lower,upper in zip(vertices,vertices[1:]):
        for k in range(count):
            j=(k+1)%count
            faces.append(([lower[k],lower[j],upper[j],upper[k]],color))
    faces.append((vertices[-1],color))
    return faces


def cylinder(radius,z,height,color,x=0,y=0,top_radius=None,segments=48):
    top_radius=radius if top_radius is None else top_radius
    rings=[]
    for r,zz in [(radius,z),(top_radius,z+height)]:
        rings.append([(x+r*math.cos(i*2*math.pi/segments),y+r*math.sin(i*2*math.pi/segments),zz) for i in range(segments)])
    faces=[]
    for i in range(segments):
        j=(i+1)%segments
        faces.append(([rings[0][i],rings[0][j],rings[1][j],rings[1][i]],color))
    faces.append((rings[-1],color));return faces


def bowl(radius,color,segments=48,layer=None):
    # Closed lathed cross-section: exterior underside -> inner well -> polished rim.
    profile=[(radius,0),(radius*.98,-5),(radius*.88,-20),(radius*.64,-32),
             (radius*.27,-37),(radius*.25,-26),(radius*.60,-26),(radius*.84,-24),
             (radius-5,-4),(radius-4,1),(radius,0)]
    rings=[[(r*math.cos(i*2*math.pi/segments),r*math.sin(i*2*math.pi/segments),z)
            for i in range(segments)] for r,z in profile]
    faces=[]
    for k,(lower,upper) in enumerate(zip(rings,rings[1:])):
        material='#d7c9ad' if k>=8 else color
        for i in range(segments):
            j=(i+1)%segments
            vertices=[lower[i],upper[i],upper[j],lower[j]]
            front=sum(v[1] for v in vertices)<0
            exterior=k<=4 or k>=8
            # The well/floor is behind the cubes, even on the near side. Only the
            # physical outside wall and rim may occlude a cube's bottom edge.
            if layer=='front' and (not exterior or not front):continue
            if layer=='back' and exterior and front:continue
            faces.append((vertices,material))
    # Bottom of the inside well, facing the viewer from above.
    disk=[(radius*.25*math.cos(i*2*math.pi/segments),radius*.25*math.sin(i*2*math.pi/segments),-26) for i in range(segments)]
    if layer!='front':faces.append((disk,color))
    return faces
