"""Soft cached button shadows without a live blur filter per widget."""
import math
from functools import lru_cache
from PyQt6.QtCore import QObject,QEvent,QRectF,QPointF,Qt
from PyQt6.QtGui import QPainter,QColor,QPixmap
from PyQt6.QtWidgets import QApplication,QGraphicsEffect,QPushButton

@lru_cache(maxsize=64)
def shadow_image(width,height,ratio,radius):
    image=QPixmap(math.ceil((width+10)*ratio),math.ceil((height+9)*ratio))
    image.setDevicePixelRatio(ratio);image.fill(Qt.GlobalColor.transparent)
    p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
    for spread,alpha in [(5,3),(4,5),(3,7),(2,9),(1,11)]:
        p.setBrush(QColor(42,36,26,alpha))
        p.drawRoundedRect(QRectF(5-spread,6-spread*.4,width+2*spread,height+spread*.8),radius+spread,radius+spread)
    p.end();return image

class ButtonShadow(QGraphicsEffect):
    def boundingRectFor(self,rect):return rect.adjusted(-5,-2,5,7)
    def draw(self,painter):
        button=self.parent()
        rect=self.sourceBoundingRect(Qt.CoordinateSystem.LogicalCoordinates)
        if rect.isEmpty():return
        radius=36 if button.objectName().startswith('route-') else 13
        image=shadow_image(round(rect.width()),round(rect.height()),round(button.devicePixelRatioF(),3),radius)
        painter.save();painter.setOpacity(.30 if not button.isEnabled() else .45 if button.isDown() else 1)
        painter.drawPixmap(QPointF(rect.x()-5,rect.y()-2),image);painter.restore();self.drawSource(painter)

class ShadowFilter(QObject):
    def eventFilter(self,obj,event):
        if event.type() in (QEvent.Type.Polish,QEvent.Type.Show) and isinstance(obj,QPushButton) and obj.graphicsEffect() is None:
            obj.setGraphicsEffect(ButtonShadow(obj))
        return False

def install_button_shadows():
    app=QApplication.instance()
    if app is not None and not hasattr(app,'_algebra_button_shadows'):
        app._algebra_button_shadows=ShadowFilter(app)
        app.installEventFilter(app._algebra_button_shadows)
