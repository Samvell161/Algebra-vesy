# Workshop background

`workshop-luxury.png` is an original, AI-generated background illustration prepared for Algebra LAB: a CGI-style miniature workshop in warm maple, ivory plaster and teal, with brass details. It was generated for this project with the OpenAI image generation tool and is bundled locally. No external asset store, stock artwork or third-party runtime is used.

Native size: 2042 × 770 pixels. The application preserves its aspect ratio with a centred cover crop. The image is decoded once per process; the scaled room and the ground shadows are drawn into the balance widget's static cache. It has no animation timer or network requests. The existing vector workshop remains the fallback if the artwork is missing or cannot be decoded.

Keep this asset in the installed `algebra_lab/qt_ui/assets/` directory. It is included by the normal recursive Qt payload packaging, and verified from the extracted DEB.

Version 0.21 uses an edited illustration with a framed adventure-map and planetary artwork, lighter daylight and pastel accents. The animated clock is deliberately excluded from the PNG and composed by the application behind the foreground solids.
