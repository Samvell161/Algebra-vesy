"""Small contact-based visual simulation, independent of the equation model.

Positions are in a cup's local coordinates: y increases downwards. All cubes
share a fixed size; a fifth cube stacks on the lower row rather than shrinking.
"""
import math
from dataclasses import dataclass

HEIGHT=58
WIDTH=52
GAP=6
GRAVITY=1800
DEPTH_SCALE=math.cos(math.radians(12))


def inner_depth(x,radius):
    r=abs(x)
    points=[(0,26),(.60*radius,26),(.84*radius,24),(radius-5,4),(radius,0)]
    for (a,ya),(b,yb) in zip(points,points[1:]):
        if r<=b:return (ya+(yb-ya)*max(0,r-a)/max(.01,b-a))*DEPTH_SCALE
    return 0


@dataclass
class Body:
    label:str
    x:float
    y:float
    width:float
    target_x:float
    row:int=0
    vx:float=0
    vy:float=0
    roll:float=0
    omega:float=0
    removing:bool=False
    age:float=0


class CupMotion:
    def __init__(self,radius=135):
        self.radius=radius;self.bodies=[]

    @staticmethod
    def items(values):
        return list(map(str,values)) if len(values)<=5 else [' · '.join(map(str,values))]

    def target(self,values,animate=True):
        labels=self.items(values);pool=[b for b in self.bodies if not b.removing]
        result=[]
        bottom=min(4,len(labels))
        for i,label in enumerate(labels):
            row=i//4;count=bottom if row==0 else len(labels)-4
            width=WIDTH if len(label)<=2 else min(2*self.radius-42,220)
            x=(i%4-(count-1)/2)*(WIDTH+GAP) if len(labels)>1 else 0
            match=next((b for b in pool if b.label==label and b.width==width),None)
            created=match is None
            if match is not None:pool.remove(match)
            else:match=Body(label,x,0,width,x,row)
            match.target_x=x;match.row=row;result.append(match)
            if created:
                floor,roll=self.support(match,result)
                match.y=floor-(64 if animate else 0);match.roll=roll
        if animate:
            for body in pool:
                body.removing=True;body.age=0;body.vy=-140
            result.extend(pool)
        self.bodies=result
        if not animate:self.finish()

    def support(self,body,bodies=None):
        # A rigid bottom edge touches the inside of the real bowl cross-section.
        values=self.bodies if bodies is None else bodies
        left,right=inner_depth(body.x-body.width/2,self.radius),inner_depth(body.x+body.width/2,self.radius)
        roll=max(-7,min(7,math.degrees(math.atan2(right-left,body.width))))
        angle=math.radians(body.roll)
        floor=min(left+body.width/2*math.sin(angle),right-body.width/2*math.sin(angle))
        if body.row:
            below=[b for b in values if not b.removing and b.row<body.row and abs(b.x-body.x)<(b.width+body.width)/2-3]
            if below:
                floor=min(b.y-HEIGHT*math.cos(math.radians(b.roll))-abs(b.width/2*math.sin(math.radians(b.roll))) for b in below)
                roll=sum(b.roll for b in below)/len(below)
        return floor,roll

    def step(self,seconds):
        # Bounded substeps prevent tunnelling after a delayed GUI frame.
        remaining=min(.10,max(0,seconds))
        while remaining>0:
            dt=min(1/120,remaining);remaining-=dt
            for body in sorted(self.bodies,key=lambda b:b.row):
                body.age+=dt
                if body.removing:
                    body.vy-=220*dt;body.y+=body.vy*dt
                    continue
                body.vx+=(140*(body.target_x-body.x)-24*body.vx)*dt
                body.x+=body.vx*dt
                floor,roll=self.support(body)
                body.omega+=(180*(roll-body.roll)-26*body.omega)*dt
                body.roll+=body.omega*dt
                body.vy+=GRAVITY*dt;body.y+=body.vy*dt
                if body.y>=floor:
                    body.y=floor
                    body.vy=-body.vy*.10 if body.vy>60 else 0
            # Side contacts: cubes opening space for a new neighbour cannot pass through it.
            active=sorted((b for b in self.bodies if not b.removing),key=lambda b:b.x)
            for _ in range(16):
                worst=0
                for i,left in enumerate(active):
                    for right in active[i+1:]:
                        if left.row!=right.row or min(left.y,right.y)-max(left.y-HEIGHT,right.y-HEIGHT)<=2:continue
                        overlap=(left.width+right.width)/2+1-(right.x-left.x)
                        if overlap>0:
                            worst=max(worst,overlap)
                            left.x-=overlap/2;right.x+=overlap/2
                            left.vx=min(0,left.vx);right.vx=max(0,right.vx)
                if worst<.01:break
            for body in active:
                limit=self.radius-8-body.width/2
                body.x=max(-limit,min(limit,body.x))
                floor,_=self.support(body)
                if body.y>floor:body.y=floor;body.vy=0
            self.bodies=[b for b in self.bodies if not b.removing or b.age<.30]

    def finish(self):
        self.bodies=[b for b in self.bodies if not b.removing]
        for body in sorted(self.bodies,key=lambda b:b.row):
            body.x=body.target_x;body.vx=body.vy=body.omega=0
            _,body.roll=self.support(body)
            body.y,_=self.support(body)
