import unittest
from algebra_lab.qt_ui.cube_motion import CupMotion,HEIGHT

class CubeContactTests(unittest.TestCase):
    def test_dense_repeated_insertions_never_cross_existing_neighbours(self):
        cup=CupMotion();cup.target(['1'],False)
        for count in [2,4,3,5,1,4,2,5,3,4,1]:
            cup.target(['1']*count,True)
            for _ in range(40):
                cup.step(.016)
                active=[b for b in cup.bodies if not b.removing]
                for i,left in enumerate(active):
                    for right in active[i+1:]:
                        if left.row==right.row and min(left.y,right.y)-max(left.y-HEIGHT,right.y-HEIGHT)>2:
                            self.assertGreaterEqual(abs(right.x-left.x),(right.width+left.width)/2-.1)
    def test_drop_contacts_bowl_and_does_not_tunnel_after_delayed_frame(self):
        cup=CupMotion();cup.target(['x'],False);cup.target(['x','1'],True)
        added=cup.bodies[1]
        self.assertLess(added.y,cup.support(added)[0]-50)
        previous=added.y
        cup.step(.04);self.assertGreater(added.y,previous)
        for _ in range(90):
            cup.step(.016)
            for body in cup.bodies:
                self.assertLessEqual(body.y,cup.support(body)[0]+1e-8)
        self.assertAlmostEqual(added.y,cup.support(added)[0],places=4)
        cup.target(['x','1','1'],True);cup.step(10)
        self.assertTrue(all(b.y<=cup.support(b)[0]+1e-8 for b in cup.bodies))

    def test_fifth_cube_rests_on_two_others_without_shrinking(self):
        cup=CupMotion();cup.target(['1']*4,False);cup.target(['1']*5,True)
        for _ in range(120):cup.step(.01)
        cup.finish()
        lower=[b for b in cup.bodies if b.row==0];top=next(b for b in cup.bodies if b.row==1)
        self.assertEqual(len(lower),4)
        self.assertEqual(len({b.width for b in cup.bodies}),1)
        supports=[b for b in lower if abs(b.x-top.x)<b.width]
        self.assertEqual(len(supports),2)
        self.assertAlmostEqual(top.y,min(b.y-HEIGHT for b in supports),places=4)

    def test_rapid_add_remove_and_side_contacts_preserve_latest_arrangement(self):
        cup=CupMotion();cup.target(['1'],False)
        for target in [['1','1'],['1']*4,['x','1','1'],['x','1']]:
            cup.target(target,True)
            for _ in range(4):cup.step(.016)
        for _ in range(100):cup.step(.01)
        cup.finish()
        self.assertEqual([b.label for b in cup.bodies],['x','1'])
        first,second=sorted(cup.bodies,key=lambda b:b.x)
        self.assertGreaterEqual(second.x-first.x,(first.width+second.width)/2)
        for body in cup.bodies:
            self.assertEqual(body.vy,0)
            self.assertAlmostEqual(body.y,cup.support(body)[0])
