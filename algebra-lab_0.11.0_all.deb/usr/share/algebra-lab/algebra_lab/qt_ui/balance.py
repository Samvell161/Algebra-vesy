"""Lightweight Qt balance illustration for the in-progress Qt interface."""
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QPainterPath
from PyQt6.QtWidgets import QWidget, QSizePolicy


class Balance(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.left, self.right = [], []
        self.tilt = 0
        self.setMinimumSize(400, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_blocks(self, left, right, tilt=0):
        left, right = list(left), list(right)
        if (left, right, tilt) != (self.left, self.right, self.tilt):
            self.left, self.right, self.tilt = left, right, tilt
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.scale(self.width()/1000, self.height()/360)
        ink = QColor('#35317c')
        p.setPen(QPen(ink, 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.setBrush(QColor('#ffc83d'))
        p.save(); p.translate(500,57); p.rotate(self.tilt); p.translate(-500,-57)
        p.drawRoundedRect(QRectF(220, 45, 560, 24), 12, 12)
        p.restore()
        p.setBrush(QColor('#6053ad'))
        base = QPainterPath(QPointF(500,55)); base.lineTo(455,320); base.lineTo(545,320);base.closeSubpath();p.drawPath(base)
        p.drawRoundedRect(QRectF(405, 315, 190, 24), 10, 10)
        p.setBrush(QColor('#ffc83d'));p.drawEllipse(QPointF(500,57), 22, 22)
        for side, x, color, blocks in [('left', 230, '#45b9ee', self.left), ('right', 770, '#ff8582', self.right)]:
            p.save(); p.translate(0, (1 if side=='right' else -1)*self.tilt*4.9)
            p.setPen(QPen(ink, 4))
            p.drawLine(QPointF(x, 59), QPointF(x-145, 246))
            p.drawLine(QPointF(x, 59), QPointF(x+145, 246))
            p.setBrush(QColor(color))
            pan=QPainterPath(QPointF(x-150,246));pan.quadTo(QPointF(x,330),QPointF(x+150,246));pan.closeSubpath();p.drawPath(pan)
            items=blocks if len(blocks)<=5 else [str(len(blocks))+' блоков']
            for i, block in enumerate(items):
                width=55 if len(str(block))<=2 else 180
                bx=x-(len(items)*60)/2+i*60
                p.setBrush(QColor('#42b7ec' if 'x' in str(block).lower() else '#ffca43'))
                p.drawRoundedRect(QRectF(bx,188,width,55), 8, 8)
                p.setPen(ink);p.setFont(QFont('DejaVu Sans', 21, QFont.Weight.Bold))
                p.drawText(QRectF(bx,188,width,55), int(Qt.AlignmentFlag.AlignCenter), str(block))
            p.restore()
        p.end()
