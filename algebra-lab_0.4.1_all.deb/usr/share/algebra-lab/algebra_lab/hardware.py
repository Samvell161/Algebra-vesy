"""One UID per presentation. No assumption of bulk RFID inventory or measured algebra."""
import threading
import time
from collections import deque

from .math_engine import Linear
from .rc522 import CardReadError
from fractions import Fraction

BLOCKS = {
    "x": {"label": "x", "a": 1, "b": 0},
    "-x": {"label": "−x", "a": -1, "b": 0},
    "1": {"label": "+1", "a": 0, "b": 1},
    "-1": {"label": "−1", "a": 0, "b": -1},
    "2": {"label": "+2", "a": 0, "b": 2},
    "-2": {"label": "−2", "a": 0, "b": -2},
    "5": {"label": "+5", "a": 0, "b": 5},
}


COMMANDS = {
    "add": {"label": "+ Прибавить"},
    "subtract": {"label": "− Вычесть"},
    "multiply": {"label": "× Умножить"},
    "divide": {"label": "÷ Разделить"},
    "apply": {"label": "✓ Применить"},
    "clear": {"label": "Очистить набор"},
    "undo": {"label": "↶ Отмена"},
    "hint": {"label": "? Подсказка"},
    "next": {"label": "→ Следующее"},
    "guide": {"label": "Шаг с подсказкой"},
}
TAG_KINDS = {**BLOCKS, **COMMANDS}


def normalize_uid(uid):
    uid = str(uid).strip().upper()
    if not uid or len(uid) > 64 or not all(c in "0123456789ABCDEF:-" for c in uid):
        raise ValueError("UID: используйте до 64 символов 0–9, A–F, : или −.")
    return uid


def expression(blocks):
    result = Linear()
    for block in blocks:
        kind = BLOCKS[block["kind"]]
        result += Linear(Fraction(kind["a"]), Fraction(kind["b"]))
    return result


class Reader:
    POLL_SECONDS = 0.35
    CONFIRM_READS = 2
    REMOVE_SECONDS = 1.2

    def __init__(self, mode="simulator"):
        self.mode = mode
        self.error = None
        self.warning = None
        self.events = deque(maxlen=100)
        self.sequence = 0
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.driver = None
        self.configure(mode)

    def configure(self, mode):
        if mode not in ("simulator", "rc522"):
            raise ValueError("Неизвестный режим считывателя.")
        self.close()
        if self.thread and self.thread.is_alive():
            raise OSError("Предыдущий опрос ещё завершается. Повторите подключение.")
        self.mode, self.error, self.driver = mode, None, None
        self.warning = None
        self.stop_event = threading.Event()
        if mode == "rc522":
            self.thread = threading.Thread(target=self._connect, daemon=True)
            self.thread.start()

    def _connect(self):
        try:
            from .rc522 import RC522
            self.driver = RC522()
            self._poll()
        except ImportError:
            self.error = "Нужны системные библиотеки. В терминале: sudo apt install python3-spidev python3-rpi.gpio"
        except Exception as exc:
            self.error = "RC522 недоступен: " + str(exc)
        finally:
            if self.driver:
                self.driver.close()
                self.driver = None

    def _poll(self):
        last, candidate = None, None
        confirmations = 0
        absent_since = None
        try:
            while not self.stop_event.wait(self.POLL_SECONDS):
                try:
                    uid = self.driver.read_id_no_block()
                except CardReadError as exc:
                    # An unreadable sample proves neither removal nor a new tag.
                    candidate, confirmations, absent_since = None, 0, None
                    self.warning = str(exc) + " Повторяю чтение; держите метку неподвижно."
                    self.driver.recover()
                    continue
                if uid is None:
                    candidate, confirmations = None, 0
                    now = time.monotonic()
                    if absent_since is None:
                        absent_since = now
                    if now - absent_since >= self.REMOVE_SECONDS:
                        last = None
                    continue
                absent_since = None
                self.warning = None
                uid = format(uid, "X")
                if uid == candidate:
                    confirmations += 1
                else:
                    candidate, confirmations = uid, 1
                if last is None and confirmations >= self.CONFIRM_READS:
                    with self.lock:
                        self.sequence += 1
                        self.events.append({"sequence": self.sequence, "uid": uid})
                    last = uid
        except Exception as exc:
            self.error = f"Чтение остановлено: {type(exc).__name__}: {exc}. Нажмите «Считать метку» для повторного подключения."

    def status(self):
        return {"mode": self.mode, "connected": self.driver is not None and self.error is None,
                "error": self.error, "warning": self.warning, "hx711": "not_configured", "sequence": self.sequence}

    def since(self, sequence):
        with self.lock:
            return [event.copy() for event in self.events if event["sequence"] > sequence]

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=0.3)
