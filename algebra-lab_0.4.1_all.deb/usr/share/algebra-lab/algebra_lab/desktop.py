"""Native Raspberry Pi application. One Python/Tk process; no HTTP server or browser."""
import argparse
import fcntl
import logging
import math
import os
import sqlite3
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .hardware import BLOCKS, COMMANDS, TAG_KINDS, Reader, normalize_uid
from .service import Service, Session
from .storage import Store
from .tasks import TASKS
from .learning import CHAPTERS, daily_task, learning_stats, progress_csv

PAPER, WHITE, INK, MUTED, GREEN = "#f4f6f1", "#ffffff", "#213c36", "#64766b", "#256858"
LINE, MINT, GOLD, BLUE = "#dce3d5", "#edf2e6", "#e8bc76", "#bfcee6"


def data_directory():
    """Use a user-writable location regardless of launcher working directory."""
    base = os.environ.get("XDG_DATA_HOME")
    return (Path(base) if base and Path(base).is_absolute() else Path.home() / ".local/share") / "algebra-lab"


class ScrollArea(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, style="Paper.TFrame")
        self.canvas = tk.Canvas(self, bg=PAPER, highlightthickness=0)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = ttk.Frame(self.canvas, padding=(24, 18), style="Paper.TFrame")
        self.window = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window, width=e.width))
        self.body.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))


class Scale(tk.Canvas):
    def __init__(self, parent, left, right, tilt=0, motion=True, height=175):
        super().__init__(parent, bg=MINT, highlightthickness=0, height=height)
        self.left, self.right = left, right
        self.angle, self.target = (0 if motion else tilt * 6), tilt * 6
        self.timer = None
        self.bind("<Configure>", lambda e: self.draw())
        if motion and tilt:
            self.timer = self.after(20, self.animate)

    def animate(self):
        self.angle += (self.target - self.angle) * .3
        self.draw()
        self.timer = self.after(20, self.animate) if abs(self.angle - self.target) > .1 else None

    def draw(self):
        self.delete("all")
        w, h = max(300, self.winfo_width()), max(100, self.winfo_height())
        cx, cy, length = w / 2, h * .31, min(w * .31, 160)
        angle = math.radians(self.angle)
        self.create_oval(cx - 95, h - 20, cx + 95, h - 4, fill="#e0e8d7", outline="")
        self.create_polygon(cx - 8, cy, cx + 8, cy, cx + 22, h - 20, cx - 22, h - 20, fill="#becdb9", outline="")
        self.create_line(cx - 55, h - 18, cx + 55, h - 18, width=9, fill=GREEN, capstyle="round")
        ends = [(cx - length * math.cos(angle), cy - length * math.sin(angle)),
                (cx + length * math.cos(angle), cy + length * math.sin(angle))]
        self.create_line(*ends[0], *ends[1], fill=GREEN, width=7, capstyle="round")
        for (x, y), label, color in zip(ends, [self.left, self.right], [GOLD, BLUE]):
            py, pw = y + h * .42, min(63, w * .13)
            self.create_line(x, y, x - pw, py, fill="#92a78c", width=2)
            self.create_line(x, y, x + pw, py, fill="#92a78c", width=2)
            self.create_rectangle(x - pw + 8, py - 37, x + pw - 8, py - 2, fill=color, outline="")
            text = label if len(label) <= 15 else label[:13] + "…"
            self.create_text(x, py - 20, text=text, font=("DejaVu Serif", 14), fill=INK)
            self.create_arc(x - pw, py - 16, x + pw, py + 22, start=180, extent=180, fill=GREEN, outline=GREEN)
        self.create_oval(cx - 9, cy - 9, cx + 9, cy + 9, fill=GOLD, outline="")
        self.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=WHITE, outline="")

    def destroy(self):
        if self.timer:
            self.after_cancel(self.timer)
        super().destroy()


class Desktop:
    def __init__(self, root, store, reader):
        self.root, self.store, self.reader = root, store, reader
        self.service, self.session = Service(store, reader), Session()
        self.service.restore_practice(self.session)
        self.page, self.side, self.level = "home", "left", 0
        self.hint_text, self.last_uid = "", ""
        self.feedback = ""
        self.closed, self.dialog = False, None
        self.tag_waiting = False
        self.controls, self.errors = {}, []
        self.event_sequence = reader.sequence
        self.timer_id = None
        self.operation = tk.StringVar(root, "subtract")
        self.operand, self.answer = tk.StringVar(root), tk.StringVar(root)
        self.x_value, self.custom = tk.StringVar(root, "1"), tk.StringVar(root)
        self.status = tk.StringVar(root, "Готово к открытиям · один локальный профиль")
        root.title("Алгебра LAB " + __version__)
        root.geometry("1024x600")
        root.minsize(1024, 480)
        root.configure(bg=PAPER)
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.report_callback_exception = self.callback_error
        root.bind("<F11>", lambda e: root.attributes("-fullscreen", not root.attributes("-fullscreen")))
        root.bind("<Escape>", lambda e: root.attributes("-fullscreen", False))
        root.bind_all("<MouseWheel>", lambda e: self.wheel(e, -int(e.delta / 120)))
        root.bind_all("<Button-4>", lambda e: self.wheel(e, -1))
        root.bind_all("<Button-5>", lambda e: self.wheel(e, 1))
        self.setup_styles()
        header = ttk.Frame(root, padding=(22, 12), style="Paper.TFrame")
        header.pack(fill="x")
        ttk.Label(header, text="⚖ алгебра LAB", style="Brand.TLabel").pack(side="left", padx=(0, 20))
        self.navigation = {}
        for page, label in [("home", "Главная"), ("practice", "Практика"), ("lab", "Лаборатория"), ("progress", "Прогресс")]:
            button = self.button(header, label, lambda p=page: self.navigate(p))
            button.pack(side="left", padx=2)
            self.navigation[page] = button
        self.button(header, "Настройки", self.settings).pack(side="right")
        ttk.Separator(root).pack(fill="x")
        bottom = ttk.Frame(root, style="Paper.TFrame", padding=(22, 6))
        bottom.pack(side="bottom", fill="x")
        ttk.Label(bottom, textvariable=self.status, style="Small.TLabel", wraplength=700).pack(side="left")
        self.button(bottom, "Справка", self.help).pack(side="right")
        self.area = ScrollArea(root)
        self.area.pack(fill="both", expand=True)
        self.render()
        self.tick()

    def setup_styles(self):
        prefs = self.store.settings()
        self.muted = INK if prefs["contrast"] else MUTED
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", font=("DejaVu Sans", 10), foreground=INK, background=PAPER)
        style.configure("Paper.TFrame", background=PAPER)
        style.configure("Card.TFrame", background=WHITE, borderwidth=1, bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, relief="solid")
        style.configure("Hero.TFrame", background=GREEN)
        style.configure("Hero.TLabel", background=GREEN, foreground=WHITE)
        style.configure("HeroSmall.TLabel", background=GREEN, foreground="#d9e9df", font=("DejaVu Sans", 10))
        style.configure("Success.TLabel", background=MINT, foreground=GREEN, font=("DejaVu Sans", 12, "bold"))
        style.configure("Mint.TFrame", background=MINT)
        for name, bg in [("TLabel", PAPER), ("Card.TLabel", WHITE), ("Mint.TLabel", MINT)]:
            style.configure(name, background=bg, foreground=INK)
        style.configure("Brand.TLabel", font=("DejaVu Sans", 19, "bold"), foreground=GREEN)
        style.configure("Title.TLabel", font=("DejaVu Sans", 24, "bold"))
        style.configure("Heading.TLabel", font=("DejaVu Sans", 15, "bold"))
        style.configure("Small.TLabel", font=("DejaVu Sans", 9), foreground=self.muted)
        style.configure("CardSmall.TLabel", background=WHITE, font=("DejaVu Sans", 9), foreground=self.muted)
        style.configure("Eyebrow.TLabel", font=("DejaVu Sans", 9, "bold"), foreground=GREEN)
        style.layout("TButton", [("Button.padding", {"sticky": "nswe", "children": [("Button.focus", {"sticky": "nswe", "children": [("Button.label", {"sticky": "nswe"})]})]})])
        style.configure("TButton", padding=(12, 10), background="#e7ede5", borderwidth=0, focusthickness=1)
        style.map("TButton", background=[("active", MINT)])
        style.configure("Primary.TButton", background=GREEN, foreground=WHITE, padding=(12, 10))
        style.map("Primary.TButton", background=[("active", "#17473c"), ("disabled", "#9eada3")], foreground=[("disabled", WHITE)])
        style.configure("Tag.TButton", font=("DejaVu Sans", 9), padding=(7, 6))
        style.configure("SelectedTag.TButton", font=("DejaVu Sans", 9), padding=(7, 6), background=GREEN, foreground=WHITE)
        style.map("SelectedTag.TButton", background=[("active", "#17473c")])
        style.configure("TEntry", padding=7, fieldbackground=WHITE)
        style.configure("TRadiobutton", background=WHITE, padding=(6, 8))
        style.configure("TCheckbutton", background=PAPER, padding=7)
        style.configure("TProgressbar", background=GREEN, troughcolor=MINT)

    def guard(self, command):
        try:
            return command()
        except (ValueError, sqlite3.Error, OSError) as exc:
            self.status.set(str(exc))
            return None

    def wheel(self, event, units):
        widget = event.widget
        while widget is not None:
            if isinstance(widget, ScrollArea):
                widget.canvas.yview_scroll(units, "units")
                return
            widget = getattr(widget, "master", None)
        self.area.canvas.yview_scroll(units, "units")

    def callback_error(self, kind, value, traceback):
        self.errors.append(value)
        logging.error("Desktop callback failed", exc_info=(kind, value, traceback))
        self.status.set("Ошибка интерфейса. Закройте окно и запустите приложение снова.")

    def button(self, parent, text, command, key=None, primary=False):
        button = ttk.Button(parent, text=text, command=lambda: self.guard(command), style="Primary.TButton" if primary else "TButton")
        if key:
            self.controls[key] = button
        return button

    def label(self, parent, text, style="TLabel", **kwargs):
        kwargs.setdefault("wraplength", 900 if parent is self.body else 430)
        widget = ttk.Label(parent, text=text, style=style, **kwargs)
        widget.pack(anchor="w", pady=(0, 8))
        return widget

    def card(self, parent, **kwargs):
        return ttk.Frame(parent, style="Card.TFrame", padding=16, **kwargs)

    def heading(self, eyebrow, title, subtitle=""):
        self.label(self.body, eyebrow.upper(), "Eyebrow.TLabel")
        self.label(self.body, title, "Title.TLabel")
        if subtitle:
            self.label(self.body, subtitle, "Small.TLabel", wraplength=900)

    def navigate(self, page):
        self.page = page
        self.render()
        self.area.canvas.yview_moveto(0)

    def render(self):
        self.service.save_practice(self.session)
        for page, button in self.navigation.items():
            button.configure(style="Primary.TButton" if page == ("practice" if self.page == "exercise" else self.page) else "TButton")
        for child in self.area.body.winfo_children():
            child.destroy()
        self.body = self.area.body
        self.controls = {key: widget for key, widget in self.controls.items() if widget.winfo_exists()}
        {"home": self.home, "practice": self.practice, "exercise": self.exercise,
         "lab": self.lab, "progress": self.progress}[self.page]()

    def next_task(self):
        best = self.store.progress()["best"]
        return next((t for t in TASKS if t["id"] not in best), TASKS[0])

    def start(self, task_id=None, mode="practice"):
        self.service.start(self.session, {"task_id": task_id or self.next_task()["id"], "mode": mode})
        self.operand.set("")
        self.answer.set("")
        self.operation.set("subtract")
        self.hint_text = ""
        self.feedback = ""
        self.navigate("exercise")

    def home(self):
        progress = self.store.progress()
        stats = learning_stats(progress)
        self.label(self.body, "ТВОЯ ЛАБОРАТОРИЯ ОТКРЫТИЙ  /  ЭКСПЕДИЦИЯ 01", "Eyebrow.TLabel")
        hero = ttk.Frame(self.body, style="Hero.TFrame", padding=18)
        hero.pack(fill="x", pady=(4, 16))
        copy = ttk.Frame(hero, style="Hero.TFrame")
        copy.pack(side="left", fill="both", expand=True)
        self.label(copy, "Большие открытия.\nМаленькими шагами.", "Hero.TLabel", font=("DejaVu Sans", 21, "bold"))
        self.label(copy, "Уравновешивай чаши. Проверяй идеи.\nСтань мастером своей лаборатории.", "HeroSmall.TLabel")
        continuing = self.session.current and not self.session.completed
        self.button(copy, "Продолжить решение  →" if continuing else "Начать исследование  →",
                    lambda: self.navigate("exercise") if continuing else self.start(), "start").pack(anchor="w", pady=(6, 0))
        self.button(copy, "Решать физическими метками", self.start_physical, "physical-start", True).pack(anchor="w", pady=(5, 0))
        Scale(hero, "x + 3", "7", height=150).pack(side="right", fill="both", expand=True, padx=(22, 0))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(0, 16))
        for title, value, note in [("ТВОЙ УРОВЕНЬ", stats["rank"], f'{stats["xp"]} XP · за лучшие результаты'),
                                   ("РИТМ ПРАКТИКИ", f'{stats["streak"]} дн. подряд', f'Сегодня: {stats["today"]} / 3 разных задания'),
                                   ("КОЛЛЕКЦИЯ ЗВЁЗД", f'{progress["stars"]} / {len(TASKS) * 3}', f'{progress["completed"]} из {len(TASKS)} открытий')]:
            card = ttk.Frame(row, style="Card.TFrame", padding=12)
            card.pack(side="left", fill="both", expand=True, padx=(0, 8))
            self.label(card, title, "CardSmall.TLabel")
            self.label(card, value, "Card.TLabel", font=("DejaVu Sans", 15, "bold"))
            self.label(card, note, "CardSmall.TLabel")
        daily = daily_task()
        mission = ttk.Frame(self.body, style="Card.TFrame", padding=12)
        mission.pack(fill="x", pady=(0, 16))
        self.button(mission, "Повторить" if stats["daily_done"] else "Решить задание  →", lambda: self.start(daily["id"]), "daily", True).pack(side="right", padx=(12, 0))
        self.label(mission, "✓ ЗАДАНИЕ ДНЯ ВЫПОЛНЕНО" if stats["daily_done"] else "НОВАЯ ИДЕЯ КАЖДЫЙ ДЕНЬ", "CardSmall.TLabel")
        self.label(mission, daily["title"] + "   ·   " + daily["equation"], "Card.TLabel", font=("DejaVu Sans", 14, "bold"))
        self.label(self.body, "Твоя экспедиция", "Heading.TLabel")
        chapters = ttk.Frame(self.body)
        chapters.pack(fill="x")
        for i, chapter in enumerate(CHAPTERS):
            chapters.columnconfigure(i, weight=1, uniform="chapters")
            card = self.card(chapters)
            card.grid(row=0, column=i, sticky="nsew", padx=(0, 8))
            count = stats["chapters"][i]
            badge = tk.Canvas(card, height=42, width=160, bg=chapter[2], highlightthickness=0)
            badge.pack(fill="x", pady=(0, 12))
            badge.create_oval(12, 7, 40, 35, fill=GREEN, outline="")
            badge.create_text(26, 21, text=str(i+1), fill=WHITE, font=("DejaVu Sans", 12, "bold"))
            badge.create_line(48, 21, 152, 21, fill="#a2b7ab", width=2, dash=(3, 5))
            self.label(card, f'0{i+1}  /  {count["completed"]} из {count["total"]}', "CardSmall.TLabel")
            self.label(card, chapter[0], "Card.TLabel", font=("DejaVu Sans", 12, "bold"), wraplength=182)
            self.label(card, chapter[1], "CardSmall.TLabel", wraplength=182)
            ttk.Progressbar(card, maximum=count["total"], value=count["completed"]).pack(fill="x", pady=(0, 12))
            self.button(card, "Открыть  →", lambda v=i+1: self.open_chapter(v), "chapter-" + str(i+1)).pack(fill="x")

    def open_chapter(self, level):
        self.level = level
        self.navigate("practice")

    def lesson(self, level=None):
        level = level or (self.service.exercise(self.session)["task"]["level"] if self.page == "exercise" and self.session.current else self.level or 1)
        chapter = CHAPTERS[level - 1]
        dialog, frame = self.modal("Открытие " + str(level) + " · " + chapter[3], scroll=True)
        self.label(frame, chapter[4], wraplength=430)
        example = ttk.Frame(frame, style="Mint.TFrame", padding=16)
        example.pack(fill="x", pady=12)
        self.label(example, chapter[5], "Mint.TLabel", font=("DejaVu Sans", 15), wraplength=400)
        self.label(frame, chapter[6], "Small.TLabel", wraplength=430)
        def try_task():
            dialog.destroy()
            self.start(next(t["id"] for t in TASKS if t["level"] == level))
        self.button(frame, "Попробовать самому  →", try_task, "lesson-try", True).pack(fill="x", pady=12)

    def task_grid(self, tasks):
        frame = ttk.Frame(self.body, style="Paper.TFrame")
        frame.pack(fill="x", pady=8)
        for col in range(3):
            frame.columnconfigure(col, weight=1, uniform="task")
        best = self.store.progress()["best"]
        for index, task in enumerate(tasks):
            card = self.card(frame)
            card.grid(row=index // 3, column=index % 3, sticky="nsew", padx=(0, 10), pady=(0, 10))
            self.label(card, f"УРОВЕНЬ {task['level']}  ·  {task['minutes']} МИН", "CardSmall.TLabel")
            self.label(card, task["title"], "Card.TLabel", font=("DejaVu Sans", 11, "bold"), wraplength=220)
            self.label(card, task["equation"].replace("-", "−"), "Card.TLabel", font=("DejaVu Serif", 18), wraplength=230)
            self.button(card, "Решить  →" + ("  " + "★" * best[task["id"]] if task["id"] in best else ""),
                        lambda t=task: self.start(t["id"]), "task-" + task["id"]).pack(fill="x")

    def practice(self):
        self.heading("ЭКСПЕДИЦИЯ / 24 ОТКРЫТИЯ", CHAPTERS[self.level - 1][0] if self.level else "Собери свою коллекцию открытий.")
        self.button(self.body, "Как это работает?  ·  Мини-урок", self.lesson, "lesson").pack(anchor="w", pady=(0, 10))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(6, 14))
        for level in range(5):
            self.button(row, f"Уровень {level}" if level else "Все задания", lambda v=level: self.filter_tasks(v),
                        "level-" + str(level), self.level == level).pack(side="left", padx=(0, 7))
        self.button(row, "Вызов · 3 минуты", lambda: self.start(mode="challenge"), "challenge").pack(side="right")
        self.task_grid([t for t in TASKS if not self.level or t["level"] == self.level])

    def filter_tasks(self, level):
        self.level = level
        self.render()

    def math_field(self, parent, variable, key, numeric=False, width=12):
        frame = ttk.Frame(parent, style="Paper.TFrame")
        entry = ttk.Entry(frame, textvariable=variable, width=width, font=("DejaVu Sans", 13))
        entry.pack(side="left", fill="x", expand=True)
        self.controls[key] = entry
        keyboard = self.button(frame, "⌨", lambda: self.keypad(variable, numeric), "keys-" + key)
        keyboard.configure(width=3)
        keyboard.pack(side="left", padx=(4, 0))
        return frame

    def exercise(self):
        ex = self.service.exercise(self.session)
        if ex and self.reader.mode == "rc522":
            self.physical_exercise(ex)
            return
        if not ex:
            self.heading("Практика", "Выбери первое задание.")
            self.button(self.body, "К заданиям", lambda: self.navigate("practice")).pack(anchor="w")
            return
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 10))
        self.button(top, "← Задания", lambda: self.navigate("practice")).pack(side="left")
        self.button(top, "Начать заново", lambda: self.start(ex["task"]["id"], ex["mode"]), "restart").pack(side="right")
        self.clock = ttk.Label(top, text=self.clock_text(ex), style="Small.TLabel")
        self.clock.pack(side="right", padx=14)
        title_row = ttk.Frame(self.body)
        title_row.pack(fill="x", pady=(0, 10))
        ttk.Label(title_row, text=ex["task"]["title"], style="Heading.TLabel").pack(side="left")
        self.button(title_row, "Правило", self.lesson, "lesson").pack(side="right")
        grid = ttk.Frame(self.body)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=16)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        eq = ex["equation"]
        self.label(left, f"{eq['left']} = {eq['right']}", "Mint.TLabel", font=("DejaVu Serif", 28), wraplength=560, anchor="center")
        Scale(left, eq["left"], eq["right"], height=130).pack(fill="x")
        self.label(left, "Схема уравнения · не показание датчика массы", "Mint.TLabel", font=("DejaVu Sans", 8))
        if ex["completed"]:
            self.label(left, "ОТКРЫТИЕ СОСТОЯЛОСЬ", "Success.TLabel")
            self.label(left, f"Верно! x = {eq['solution']['value']}    {'★' * ex['stars']}", "Mint.TLabel", font=("DejaVu Sans", 16, "bold"))
            self.button(left, "Следующее задание  →", self.next_exercise, "next", True).pack(anchor="w")
        elif ex["expired"]:
            self.label(left, "Время вышло. Можно попробовать ещё раз.", "Mint.TLabel")
            self.button(left, "Решать без таймера", lambda: self.start(ex["task"]["id"]), "untimed").pack(anchor="w")
        else:
            answer = ttk.Frame(left, style="Mint.TFrame")
            answer.pack(fill="x", pady=(8, 0))
            ttk.Label(answer, text="Ответ: x =", style="Mint.TLabel").pack(side="left", padx=(0, 8))
            self.math_field(answer, self.answer, "answer", True, 7).pack(side="left", fill="x", expand=True)
            self.button(answer, "Проверить", self.check_answer, "check-answer").pack(side="left", padx=(8, 0))
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        self.label(right, "Сохраним равенство", "Card.TLabel", font=("DejaVu Sans", 13, "bold"))
        self.label(right, "Действие с обеими частями:", "CardSmall.TLabel")
        operations = ttk.Frame(right, style="Card.TFrame", relief="flat")
        operations.pack(fill="x", pady=(0, 8))
        for index, (op, text) in enumerate([("add", "+ Прибавить"), ("subtract", "− Вычесть"), ("multiply", "× Умножить"), ("divide", "÷ Разделить")]):
            radio = ttk.Radiobutton(operations, text=text, value=op, variable=self.operation)
            radio.grid(row=index // 2, column=index % 2, sticky="w")
            if ex["completed"] or ex["expired"]:
                radio.state(["disabled"])
        self.label(right, "Число / выражение с x\nДля × и ÷ — только число", "CardSmall.TLabel")
        self.math_field(right, self.operand, "operand", width=15).pack(fill="x")
        apply = self.button(right, "Применить к обеим частям", self.transform, "transform", True)
        apply.pack(fill="x", pady=8)
        extras = ttk.Frame(right, style="Card.TFrame", relief="flat")
        extras.pack(fill="x")
        hint = self.button(extras, "Подсказка", self.hint, "hint")
        hint.pack(side="left", expand=True, fill="x", padx=(0, 5))
        undo = self.button(extras, "Отменить", self.undo, "undo")
        undo.pack(side="left", expand=True, fill="x")
        if ex["completed"] or ex["expired"]:
            for button in [apply, hint, undo]:
                button.state(["disabled"])
        elif len(ex["history"]) < 2:
            undo.state(["disabled"])
        if self.feedback:
            self.label(self.body, self.feedback, "Small.TLabel", wraplength=900)
        if self.hint_text:
            self.label(self.body, self.hint_text, "Small.TLabel", wraplength=900)
        self.button(self.body, f"Путь к решению · {len(ex['history']) - 1} шагов", self.history, "history").pack(anchor="w", pady=(12, 0))

    def rfid_style(self):
        style = self.store.settings().get("rfid_style", "guided")
        return style if style in ("guided", "independent") else "guided"

    def set_rfid_style(self, style):
        self.store.save_settings({"rfid_style": style})
        self.event_sequence = self.reader.sequence
        self.session.rfid_terms = []
        self.feedback = "Режим выбран. Уберите метку на две секунды и поднесите снова."
        self.render()

    def start_physical(self):
        if self.reader.mode != "rc522" or self.reader.error:
            self.reader.configure("rc522")
        self.store.save_settings({"reader_mode": "rc522"})
        self.event_sequence = self.reader.sequence
        if self.session.current and not self.session.completed:
            self.navigate("exercise")
        else:
            self.start()

    def physical_exercise(self, ex):
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 6))
        self.button(top, "← Задания", lambda: self.navigate("practice")).pack(side="left")
        self.button(top, "Мои метки", self.tags, "exercise-tags").pack(side="right")
        self.clock = ttk.Label(top, text=self.clock_text(ex), style="Small.TLabel")
        self.clock.pack(side="right", padx=10)
        modes = ttk.Frame(self.body)
        modes.pack(fill="x", pady=(0, 8))
        style = self.rfid_style()
        self.button(modes, "Одна метка · обучение", lambda: self.set_rfid_style("guided"), "rfid-guided", style == "guided").pack(side="left", padx=(0, 6))
        self.button(modes, "Набор меток · свои действия", lambda: self.set_rfid_style("independent"), "rfid-independent", style == "independent").pack(side="left")
        grid = ttk.Frame(self.body)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.label(left, ex["task"]["title"] + " · " + ex["task"]["equation"], "Mint.TLabel", wraplength=500)
        eq = ex["equation"]
        self.label(left, eq["left"] + " = " + eq["right"], "Mint.TLabel", font=("DejaVu Serif", 27), wraplength=510)
        Scale(left, eq["left"], eq["right"], height=115).pack(fill="x")
        self.label(left, "Символические весы · одинаковое действие с обеими частями", "Mint.TLabel", font=("DejaVu Sans", 9), wraplength=510)
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        if ex["completed"]:
            self.label(right, "✓ Решение получено", "Card.TLabel", font=("DejaVu Sans", 15, "bold"), wraplength=310)
            self.label(right, "x = " + eq["solution"]["value"], "Card.TLabel", font=("DejaVu Serif", 24), wraplength=310)
            text = "Поднесите любую привязанную метку для следующего задания." if style == "guided" else "Поднесите метку «Следующее»."
            self.label(right, text, "CardSmall.TLabel", wraplength=310)
        elif ex["expired"]:
            self.label(right, "Время вышло", "Card.TLabel", wraplength=310)
            self.button(right, "Без таймера", lambda: self.start(ex["task"]["id"]), "untimed").pack(fill="x")
        elif style == "guided":
            step = self.service.guided_step(self.session)
            self.label(right, "ПОДНЕСИТЕ МЕТКУ", "CardSmall.TLabel", wraplength=310)
            self.label(right, step["label"] if step else "Подтвердить решение", "Card.TLabel", font=("DejaVu Sans", 14, "bold"), wraplength=310)
            self.label(right, "Любая привязанная метка — пульт этого шага. Уберите на 2 секунды и поднесите снова.", "CardSmall.TLabel", wraplength=310)
            self.label(right, "Обучение с подсказкой: помощь учитывается в результате.", "CardSmall.TLabel", wraplength=310)
        else:
            self.label(right, "СОБЕРИТЕ ДЕЙСТВИЕ МЕТКАМИ", "CardSmall.TLabel", wraplength=310)
            self.label(right, TAG_KINDS[self.session.rfid_operation]["label"], "Card.TLabel", font=("DejaVu Sans", 14, "bold"), wraplength=310)
            self.label(right, "Набрано: " + self.service.rfid_pending(self.session) + "  ·  " + str(len(self.session.rfid_terms)) + " меток", "Card.TLabel", wraplength=310)
            self.label(right, "Команда → числа / x → «Применить». Повторное поднесение +1 добавляет ещё единицу в набор.", "CardSmall.TLabel", wraplength=310)
            self.label(right, "Без команды действует вычитание. «Очистить набор» начинает набор заново.", "CardSmall.TLabel", wraplength=310)
        self.physical_status = tk.StringVar(self.root)
        ttk.Label(self.body, textvariable=self.physical_status, style="Small.TLabel", wraplength=900).pack(fill="x", pady=(6, 0))
        self.update_physical_status()
        if self.feedback:
            self.label(self.body, self.feedback, "Small.TLabel", wraplength=900)
        self.button(self.body, "История физических шагов · " + str(len(ex["history"]) - 1), self.history, "history").pack(anchor="w", pady=(4, 0))

    def update_physical_status(self):
        if self.page != "exercise" or self.reader.mode != "rc522" or not hasattr(self, "physical_status"):
            return
        state = self.reader.status()
        text = state["error"] or state.get("warning")
        if not text:
            text = "RC522 готов · держите метку неподвижно около секунды" if state["connected"] else "Подключение RC522…"
        self.physical_status.set(text)

    def handle_physical_scan(self, uid):
        if uid not in self.store.tags():
            self.tags(uid)
            return
        if self.page != "exercise":
            if self.session.current and not self.session.completed:
                self.navigate("exercise")
            else:
                self.start()
            self.feedback = "Метка считана. Задание открыто. Уберите метку на 2 секунды и поднесите для действия."
        else:
            try:
                result = self.service.scan_exercise(self.session, {"uid": uid, "style": self.rfid_style()})
                self.feedback = "Метка «" + TAG_KINDS[result["kind"]]["label"] + "» → " + result["message"]
            except (ValueError, sqlite3.Error, OSError) as exc:
                self.feedback = "Метка считана; действие не выполнено: " + str(exc)
        self.status.set(self.feedback)
        self.render()

    def transform(self):
        self.service.transform(self.session, {"operation": self.operation.get(), "value": self.operand.get()})
        self.hint_text = ""
        self.feedback = ""
        self.render()

    def check_answer(self):
        result = self.service.answer(self.session, {"answer": self.answer.get()})
        self.status.set(result["message"])
        self.feedback = "" if result["correct"] else result["message"]
        self.render()

    def hint(self):
        self.hint_text = self.service.hint(self.session)["text"]
        self.status.set(self.hint_text)
        self.render()

    def undo(self):
        self.service.undo(self.session)
        self.hint_text = ""
        self.feedback = ""
        self.render()

    def next_exercise(self):
        index = next(i for i, task in enumerate(TASKS) if task["id"] == self.session.task_id)
        self.start(TASKS[(index + 1) % len(TASKS)]["id"], self.session.mode)

    def history(self):
        dialog, frame = self.modal("Путь к решению", scroll=True)
        for i, step in enumerate(self.session.history):
            self.label(frame, f"{i:02} · {step['label']}", "Small.TLabel", wraplength=440)
            self.label(frame, f"{step['left']} = {step['right']}", font=("DejaVu Serif", 18), wraplength=440)

    def mutate_lab(self, endpoint, data):
        lab = self.service.dispatch("/api/lab/" + endpoint, self.session, data)
        if endpoint == "x":
            self.status.set(f"При x = {lab['x']}: слева {lab['left_value']}, справа {lab['right_value']}. " + ("Равенство выполняется." if lab["balanced"] else "Значения отличаются."))
        self.render()

    def lab(self):
        lab = self.service.lab(self.session)
        top = ttk.Frame(self.body)
        top.pack(fill="x")
        self.button(top, "Решать задание метками →", self.start_physical, "lab-physical", True).pack(side="right")
        self.label(top, "Твоя лаборатория.", "Title.TLabel", wraplength=500)
        self.label(self.body, "Здесь — реестр блоков на чашах. Для преобразования заданий нажми «Решать задание метками».", "Small.TLabel", wraplength=900)
        grid = ttk.Frame(self.body)
        grid.pack(fill="x", pady=(6, 0))
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=14)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        self.label(left, f"{lab['equation']['left']} = {lab['equation']['right']}", "Mint.TLabel", font=("DejaVu Serif", 24), wraplength=550)
        Scale(left, lab["equation"]["left"], lab["equation"]["right"], lab["tilt"], self.store.settings()["motion"], 105).pack(fill="x")
        trays = ttk.Frame(left, style="Mint.TFrame")
        trays.pack(fill="x", pady=8)
        for i, side in enumerate(["left", "right"]):
            trays.columnconfigure(i, weight=1, uniform="tray")
            tray = ttk.Frame(trays, style="Card.TFrame", padding=8)
            tray.grid(row=0, column=i, sticky="nsew", padx=(0, 7))
            self.button(tray, ("Левая" if side == "left" else "Правая") + " чаша", lambda s=side: self.select_side(s), "side-" + side, side == self.side).pack(fill="x")
            if not lab["blocks"][side]:
                self.label(tray, "Пока без блоков", "CardSmall.TLabel")
            chips = ttk.Frame(tray, style="Card.TFrame", relief="flat")
            chips.pack(fill="x", pady=(5, 0))
            for n, block in enumerate(lab["blocks"][side]):
                chip = self.button(chips, BLOCKS[block["kind"]]["label"] + " ×", lambda uid=block["uid"]: self.mutate_lab("remove", {"uid": uid}), "remove-" + block["uid"])
                chip.configure(width=4)
                chip.grid(row=n // 3, column=n % 3, sticky="w", padx=1, pady=2)
        row = ttk.Frame(left, style="Mint.TFrame")
        row.pack(fill="x")
        ttk.Label(row, text="При x =", style="Mint.TLabel").pack(side="left", padx=(0, 8))
        self.math_field(row, self.x_value, "lab-x", True, 7).pack(side="left", fill="x", expand=True)
        self.button(row, "Подставить", lambda: self.mutate_lab("x", {"value": self.x_value.get()}), "substitute").pack(side="left", padx=8)
        self.label(left, f"Значения: {lab['left_value']} {'=' if lab['balanced'] else '≠'} {lab['right_value']} · {self.solution_text(lab['equation']['solution'])}", "Mint.TLabel", wraplength=550)
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        self.label(right, "Палитра блоков", "Card.TLabel", font=("DejaVu Sans", 14, "bold"))
        self.label(right, f"На {'левую' if self.side == 'left' else 'правую'} чашу", "CardSmall.TLabel")
        palette = ttk.Frame(right, style="Card.TFrame", relief="flat")
        palette.pack(fill="x")
        if self.reader.mode == "simulator":
            for i, (kind, block) in enumerate(BLOCKS.items()):
                button = self.button(palette, block["label"], lambda k=kind: self.mutate_lab("simulate", {"kind": k, "side": self.side}), "block-" + kind)
                button.configure(width=3)
                button.grid(row=i // 4, column=i % 4, sticky="ew", padx=3, pady=4)
        else:
            self.label(right, self.reader.error or self.reader.warning or "Поднеси метку и держи неподвижно около секунды", "CardSmall.TLabel", wraplength=220)
        self.button(right, "RFID-метки", self.tags, "tags").pack(fill="x", pady=(14, 6))
        self.button(right, "Очистить чаши", lambda: self.mutate_lab("clear", {}), "clear-lab").pack(fill="x")
        self.label(right, "HX711 не подключён.\nНаклон вычислен по выражениям,\nа не по массе блоков.", "CardSmall.TLabel", wraplength=220)
        custom = ttk.Frame(self.body)
        custom.pack(fill="x", pady=(14, 0))
        ttk.Label(custom, text="Своё уравнение:").pack(side="left", padx=(0, 10))
        self.math_field(custom, self.custom, "custom", width=20).pack(side="left", fill="x", expand=True)
        self.button(custom, "Исследовать", self.check_custom, "check-custom", True).pack(side="left", padx=(8, 0))

    def select_side(self, side):
        self.side = side
        self.render()

    @staticmethod
    def solution_text(solution):
        return f"x = {solution['value']}" if solution["kind"] == "one" else "любое x" if solution["kind"] == "all" else "решений нет"

    def check_custom(self):
        result = self.service.dispatch("/api/equation/check", self.session, {"equation": self.custom.get()})
        self.status.set(f"{result['left']} = {result['right']}: {self.solution_text(result['solution'])}")
        dialog, frame = self.modal("Математический вывод")
        self.label(frame, f"{result['left']} = {result['right']}", font=("DejaVu Serif", 23), wraplength=440)
        self.label(frame, self.solution_text(result["solution"]), "Heading.TLabel")

    def progress(self):
        progress = self.store.progress()
        self.heading("Каждый шаг имеет значение", "Твои открытия в цифрах.")
        stats = learning_stats(progress)
        self.label(self.body, f"{stats['rank']}  ·  {stats['xp']} XP  ·  {stats['streak']} дней практики подряд", "Small.TLabel")
        self.button(self.body, "Экспорт результатов CSV", self.export_progress, "export").pack(anchor="w", pady=(0, 8))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(10, 18))
        for title, value in [("ПРОЙДЕНО", f"{progress['completed']} / {len(TASKS)}"), ("ЗВЁЗДЫ", f"{progress['stars']} / {len(TASKS)*3}"), ("УСПЕШНЫХ ПОПЫТОК", str(len(progress["attempts"])))]:
            card = self.card(row)
            card.pack(side="left", fill="both", expand=True, padx=(0, 12))
            self.label(card, title, "CardSmall.TLabel")
            self.label(card, value, "Card.TLabel", font=("DejaVu Sans", 26, "bold"))
        goals = [("Первое открытие", progress["completed"] >= 1), ("В ритме науки · 3 задания", progress["completed"] >= 3),
                 ("Без подсказок", 3 in progress["best"].values()), ("Мастер равновесия", progress["completed"] == len(TASKS))]
        self.label(self.body, "Коллекция достижений", "Heading.TLabel")
        self.label(self.body, "   ·   ".join(("★ " if done else "☆ ") + title for title, done in goals), wraplength=900)
        self.label(self.body, "Карта навыков", "Heading.TLabel")
        for i, chapter in enumerate(CHAPTERS):
            count = stats["chapters"][i]
            self.label(self.body, f"{chapter[0]}  ·  {count['completed']} / {count['total']}", "Small.TLabel")
            ttk.Progressbar(self.body, maximum=count["total"], value=count["completed"]).pack(fill="x", pady=(0, 10))
        self.label(self.body, "Последние решения", "Heading.TLabel")
        for attempt in progress["attempts"][:15]:
            task = next((t for t in TASKS if t["id"] == attempt["task_id"]), {"title": attempt["task_id"]})
            self.label(self.body, f"{task['title']}    {'★' * attempt['stars']}    ·    {attempt['steps']} шагов    ·    {attempt['hints']} подсказок    ·    {attempt['seconds']} сек", wraplength=900)
        if not progress["attempts"]:
            self.label(self.body, "Первое решение появится здесь после практики.", "Small.TLabel")

    def export_progress(self):
        filename = filedialog.asksaveasfilename(parent=self.root, title="Сохранить результаты", defaultextension=".csv", initialfile="algebra-progress.csv", filetypes=[("CSV", "*.csv")])
        if filename:
            Path(filename).write_text(progress_csv(self.store.progress()), encoding="utf-8-sig")
            self.status.set("Результаты сохранены: " + str(filename))

    def modal(self, title, scroll=False):
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
        dialog = tk.Toplevel(self.root)
        self.dialog = dialog
        dialog.title(title)
        dialog.configure(bg=PAPER)
        dialog.transient(self.root)
        dialog.resizable(False, False)
        width, height = 530, min(520, self.root.winfo_screenheight() - 60)
        x = max(0, self.root.winfo_rootx() + (self.root.winfo_width() - width) // 2)
        y = max(0, self.root.winfo_rooty() + (self.root.winfo_height() - height) // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")
        bottom = ttk.Frame(dialog, padding=(18, 8))
        bottom.pack(side="bottom", fill="x")
        self.button(bottom, "Закрыть", dialog.destroy, "close-dialog").pack(side="right")
        if scroll:
            area = ScrollArea(dialog)
            area.pack(fill="both", expand=True)
            frame = area.body
        else:
            frame = ttk.Frame(dialog, padding=22)
            frame.pack(fill="both", expand=True)
        self.label(frame, title, "Heading.TLabel")
        dialog.grab_set()
        dialog.bind("<Escape>", lambda e: dialog.destroy())
        return dialog, frame

    def keypad(self, variable, numeric=False):
        dialog, frame = self.modal("Сенсорный ввод")
        draft = tk.StringVar(dialog, variable.get())
        entry = ttk.Entry(frame, textvariable=draft, font=("DejaVu Sans", 18))
        entry.pack(fill="x", pady=(0, 10))
        self.controls["keypad-entry"] = entry
        entry.focus_set()
        entry.icursor("end")
        keys = ["7", "8", "9", "+", "−", "4", "5", "6", "×", "÷", "1", "2", "3", "(", ")", "0", ".", "/", "x", "="]
        if numeric:
            keys = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "−", "0", "/", "."]
        grid = ttk.Frame(frame)
        grid.pack(fill="both", expand=True)
        columns = 4 if numeric else 5
        for col in range(columns):
            grid.columnconfigure(col, weight=1)

        def insert(key):
            text = {"−": "-", "×": "*", "÷": "/"}.get(key, key)
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
            entry.insert("insert", text)
            entry.focus_set()

        def backspace():
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
            elif entry.index("insert"):
                pos = entry.index("insert")
                entry.delete(pos - 1, pos)

        def accept():
            variable.set(draft.get())
            dialog.destroy()

        for i, key in enumerate(keys):
            button = self.button(grid, key, lambda k=key: insert(k), "key-" + key)
            button.configure(width=3)
            button.grid(row=i // columns, column=i % columns, sticky="nsew", padx=3, pady=3)
        tools = ttk.Frame(frame)
        tools.pack(fill="x", pady=(8, 0))
        self.button(tools, "Очистить", lambda: draft.set(""), "key-clear").pack(side="left")
        self.button(tools, "⌫", backspace, "key-back").pack(side="left", padx=8)
        self.button(tools, "Готово", accept, "key-accept", True).pack(side="right")
        entry.bind("<Return>", lambda e: accept())

    def settings(self):
        dialog, frame = self.modal("Настроим под тебя", scroll=True)
        prefs = self.store.settings()
        name = tk.StringVar(dialog, prefs["name"])
        motion, contrast = tk.BooleanVar(dialog, prefs["motion"]), tk.BooleanVar(dialog, prefs["contrast"])
        self.label(frame, "Как тебя называть?")
        entry = ttk.Entry(frame, textvariable=name)
        entry.pack(fill="x", pady=(0, 10))
        self.controls["name"] = entry
        ttk.Checkbutton(frame, text="Анимация весов", variable=motion).pack(anchor="w")
        ttk.Checkbutton(frame, text="Повышенный контраст текста", variable=contrast).pack(anchor="w")

        def save():
            self.service.dispatch("/api/settings", self.session, {"name": name.get(), "motion": motion.get(), "contrast": contrast.get()})
            self.setup_styles()
            dialog.destroy()
            self.render()
            self.status.set("Настройки сохранены на этом устройстве.")

        self.button(frame, "Сохранить настройки", save, "save-settings", True).pack(fill="x", pady=12)
        self.button(frame, "RFID-метки", self.tags).pack(fill="x")
        self.button(frame, "Использовать экранные блоки без RC522", self.use_simulator, "reader-simulator").pack(fill="x", pady=6)
        self.button(frame, "Сбросить учебный прогресс", self.reset_progress, "reset-progress").pack(fill="x", pady=8)
        self.label(frame, f"Режим: {self.reader.mode}\n{self.reader.error or 'HX711 не подключён.'}", "Small.TLabel", wraplength=430)

    def use_simulator(self):
        self.reader.configure("simulator")
        self.store.save_settings({"reader_mode": "simulator"})
        self.dialog.destroy()
        self.render()
        self.status.set("Включены экранные блоки. RC522 выключен.")

    def reset_progress(self):
        if messagebox.askyesno("Сброс прогресса", "Удалить историю, звёзды и достижения? Имя и метки сохранятся.", parent=self.dialog):
            self.service.dispatch("/api/progress/reset", self.session, {"confirm": "RESET"})
            self.dialog.destroy()
            self.render()
            self.status.set("Учебный прогресс сброшен.")

    def tags(self, known_uid=None):
        dialog, frame = self.modal("Привязать метку")
        dialog.geometry("820x540+%d+%d" % (
            max(0, self.root.winfo_rootx() + (self.root.winfo_width() - 820) // 2),
            max(0, self.root.winfo_rooty() + (self.root.winfo_height() - 540) // 2)))
        columns = ttk.Frame(frame)
        columns.pack(fill="both", expand=True)
        left, right = ttk.Frame(columns), ttk.Frame(columns)
        left.pack(side="left", fill="both", expand=True, padx=(0, 18))
        right.pack(side="left", fill="both", expand=True)
        def close_tags():
            dialog.destroy()
            self.render()
        self.controls["close-dialog"].configure(command=close_tags)
        dialog.protocol("WM_DELETE_WINDOW", close_tags)
        dialog.bind("<Escape>", lambda e: close_tags())
        self.tag_dialog = dialog
        self.tag_waiting = False
        self.tag_uid = tk.StringVar(dialog, known_uid or "")
        self.tag_kind = tk.StringVar(dialog, "")
        self.tag_message = tk.StringVar(dialog, "Метка уже считана. Выберите её значение." if known_uid else "Начните с кнопки «Считать метку».")
        self.tag_connection = tk.StringVar(dialog)
        self.label(left, "1. Считайте метку", "Heading.TLabel", wraplength=330)
        self.button(left, "Считать метку / считать другую", self.capture_tag, "read-tag", True).pack(fill="x")
        ttk.Label(left, textvariable=self.tag_connection, wraplength=330, style="Small.TLabel").pack(fill="x", pady=4)
        entry = ttk.Entry(left, textvariable=self.tag_uid, state="readonly")
        entry.pack(fill="x")
        self.controls["tag-uid"] = entry
        self.label(right, "2. Выберите роль метки", "Heading.TLabel", wraplength=350)
        tabs = ttk.Frame(right)
        tabs.pack(fill="x", pady=(0, 4))
        self.button(tabs, "Числа и x", lambda: self.show_tag_roles("blocks"), "tag-blocks").pack(side="left")
        self.button(tabs, "Команды", lambda: self.show_tag_roles("commands"), "tag-commands").pack(side="left")
        choices = ttk.Frame(right)
        choices.pack(fill="x")
        self.tag_choices = {}
        for kind, definition in TAG_KINDS.items():
            button = self.button(choices, definition["label"], lambda k=kind: self.choose_tag(k), "tag-kind-" + kind)
            self.tag_choices[kind] = button
        self.show_tag_roles("blocks")
        ttk.Label(right, textvariable=self.tag_message, wraplength=350).pack(fill="x", pady=6)
        self.button(right, "3. Сохранить привязку", self.save_tag, "bind-tag", True).pack(fill="x")
        tools = ttk.Frame(frame)
        tools.pack(fill="x", pady=4)
        self.button(tools, "Мои метки (" + str(len(self.store.tags())) + ")", self.tag_list, "tag-list").pack(side="left")
        self.button(left, "UID вручную", self.manual_tag, "manual-tag").pack(fill="x", pady=12)
        self.refresh_tag_controls()
        self.update_tag_connection()

    def show_tag_roles(self, group):
        kinds = list(BLOCKS) if group == "blocks" else list(COMMANDS)
        for button in self.tag_choices.values():
            button.grid_remove()
        for index, kind in enumerate(kinds):
            button = self.tag_choices[kind]
            button.grid(row=index // 3, column=index % 3, sticky="ew", padx=2, pady=2)
            button.master.columnconfigure(index % 3, weight=1)

    def tag_window_open(self):
        dialog = getattr(self, "tag_dialog", None)
        return bool(dialog and dialog.winfo_exists())

    def update_tag_connection(self):
        if not self.tag_window_open():
            return
        state = self.reader.status()
        if state["error"]:
            text = state["error"]
        elif state.get("warning"):
            text = state["warning"]
        elif state["mode"] == "simulator":
            text = "Считыватель выключен. «Считать метку» включит RC522 на SPI0."
        elif state["connected"]:
            text = "RC522 подключён · SPI0 CE0 · RST GPIO25"
        else:
            text = "Подключение RC522…"
        self.tag_connection.set(text)

    def refresh_tag_controls(self):
        ready = bool(self.tag_uid.get()) and not self.tag_waiting
        for kind, button in self.tag_choices.items():
            button.state(["!disabled"] if ready else ["disabled"])
            button.configure(style="SelectedTag.TButton" if self.tag_kind.get() == kind else "Tag.TButton")
        self.controls["bind-tag"].state(["!disabled"] if ready and self.tag_kind.get() else ["disabled"])

    def capture_tag(self):
        self.tag_uid.set("")
        self.tag_kind.set("")
        self.tag_waiting = True
        self.controls["tag-uid"].configure(state="readonly")
        self.tag_message.set("Уберите метку на 2 секунды, затем поднесите и держите неподвижно около секунды.")
        self.event_sequence = self.reader.sequence
        try:
            if self.reader.mode != "rc522" or self.reader.error or not self.reader.status()["connected"]:
                self.reader.configure("rc522")
            self.store.save_settings({"reader_mode": "rc522"})
        except (OSError, ValueError) as exc:
            self.tag_message.set(str(exc))
        self.refresh_tag_controls()
        self.update_tag_connection()

    def receive_tag(self, uid):
        if not self.tag_window_open() or not self.tag_waiting:
            return
        self.tag_waiting = False
        self.tag_uid.set(uid)
        existing = self.store.tags().get(uid)
        self.tag_kind.set(existing or "")
        self.show_tag_roles("commands" if existing in COMMANDS else "blocks")
        self.tag_message.set("Метка считана. " + ("Сейчас: " + TAG_KINDS[existing]["label"] + ". Выберите новое значение или сохраните." if existing else "Теперь выберите значение ниже."))
        self.refresh_tag_controls()

    def manual_tag(self):
        self.tag_waiting = False
        self.tag_kind.set("")
        self.controls["tag-uid"].configure(state="normal")
        self.controls["tag-uid"].focus_set()
        self.tag_message.set("Ручной ввод для проверки. Введите UID, затем выберите значение.")
        self.tag_uid.trace_add("write", lambda *args: self.refresh_tag_controls() if self.tag_window_open() else None)
        self.refresh_tag_controls()

    def choose_tag(self, kind):
        self.tag_kind.set(kind)
        self.tag_message.set("Выбрано: " + TAG_KINDS[kind]["label"] + ". Нажмите «Сохранить привязку».")
        self.refresh_tag_controls()

    def save_tag(self):
        try:
            uid, kind = normalize_uid(self.tag_uid.get()), self.tag_kind.get()
            self.service.dispatch("/api/tags/bind", self.session, {"uid": uid, "kind": kind})
        except (ValueError, sqlite3.Error, OSError) as exc:
            self.tag_message.set("Не сохранено: " + str(exc))
            return
        self.tag_message.set("✓ Сохранено: эта метка = " + TAG_KINDS[kind]["label"] + ". Закройте окно и поднесите метку снова.")
        self.status.set("Метка привязана: " + TAG_KINDS[kind]["label"])
        self.controls["bind-tag"].state(["disabled"])
        self.controls["tag-list"].configure(text="Мои метки (" + str(len(self.store.tags())) + ")")

    def tag_list(self):
        dialog, frame = self.modal("Мои метки", scroll=True)
        tags = self.store.tags()
        if not tags:
            self.label(frame, "Пока нет привязанных меток.")
        self.button(frame, "Привязать новую метку", self.tags, "new-tag", True).pack(fill="x", pady=6)
        for uid, kind in tags.items():
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=TAG_KINDS[kind]["label"] + " · " + uid, wraplength=200).pack(side="left")
            self.button(row, "Изменить", lambda u=uid: self.tags(u), "edit-" + uid).pack(side="right")
            self.button(row, "Удалить", lambda u=uid: self.unbind(u), "unbind-" + uid).pack(side="right")

    def unbind(self, uid):
        self.service.dispatch("/api/tags/remove", self.session, {"uid": uid})
        self.tag_list()

    def help(self):
        dialog, frame = self.modal("Здесь всё можно понять", scroll=True)
        for title, text in [
            ("01 · Равенство — это баланс", "Блок x — неизвестное число. В практике сохраняй одинаковые значения обеих частей уравнения."),
            ("02 · Одно действие — две стороны", "Прибавляй или вычитай одно и то же выражение. Умножай и дели на одно и то же ненулевое число. Например, для x + 3 = 7 вычти 3 с обеих сторон."),
            ("03 · Физические блоки — по одному", "Выбери чашу, поднеси одну метку и убери её из зоны RC522. Программа ведёт реестр. При снятии или переносе блока удали запись с прежней чаши."),
            ("04 · Числа без клавиатуры", "Кнопка ⌨ открывает сенсорный ввод. F11 включает полный экран, Esc возвращает обычное окно. Прогресс хранится локально."),
        ]:
            self.label(frame, title, "Heading.TLabel", wraplength=430)
            self.label(frame, text, wraplength=430)

    @staticmethod
    def clock_text(ex):
        if ex["mode"] != "challenge":
            return "Практика без спешки"
        if ex["completed"]:
            return "Вызов завершён"
        return f"Осталось {ex['remaining'] // 60}:{ex['remaining'] % 60:02}"

    def tick(self):
        if self.closed:
            return
        if self.page == "exercise" and self.session.current:
            ex = self.service.exercise(self.session)
            self.clock.configure(text=self.clock_text(ex))
            if ex["expired"] and not self.controls.get("untimed"):
                self.render()
        if self.reader.mode == "rc522":
            for event in self.reader.since(self.event_sequence):
                self.event_sequence = event["sequence"]
                self.last_uid = event["uid"]
                if self.dialog and self.dialog.winfo_exists():
                    self.receive_tag(self.last_uid)
                elif self.page == "lab":
                    if self.last_uid not in self.store.tags():
                        self.tags(self.last_uid)
                    else:
                        self.guard(lambda: self.service.scan(self.session, {"uid": self.last_uid, "side": self.side}))
                        self.render()
                else:
                    self.handle_physical_scan(self.last_uid)
        self.update_tag_connection()
        self.update_physical_status()
        self.timer_id = self.root.after(150, self.tick)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.timer_id:
            self.root.after_cancel(self.timer_id)
        self.service.save_practice(self.session)
        self.reader.close()
        self.store.close()
        self.root.destroy()
        # Release the application reference on the Tk owner thread.
        del self.root.report_callback_exception


def main(argv=None):
    parser = argparse.ArgumentParser(description="Алгебра LAB — нативное приложение для Raspberry Pi")
    parser.add_argument("--data-dir", type=Path, default=data_directory())
    parser.add_argument("--reader", choices=["simulator", "rc522"], default=None)
    parser.add_argument("--fullscreen", action="store_true")
    args = parser.parse_args(argv)
    args.data_dir.mkdir(parents=True, exist_ok=True)
    # Do not let two GUI instances consume memory or share the physical reader.
    with (args.data_dir / "desktop.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("Алгебра LAB уже запущена для этого профиля.", file=sys.stderr)
            return 1
        try:
            root = tk.Tk(className="AlgebraLAB")
        except tk.TclError:
            print("Нужен графический рабочий стол. Запустите Алгебра LAB из меню Raspberry Pi OS.", file=sys.stderr)
            return 1
        store = Store(args.data_dir / "algebra.sqlite3")
        mode = args.reader or store.settings().get("reader_mode", "simulator")
        reader = Reader(mode if mode in ("simulator", "rc522") else "simulator")
        app = Desktop(root, store, reader)
        root.attributes("-fullscreen", args.fullscreen)
        try:
            root.mainloop()
        finally:
            if not app.closed:
                app.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
