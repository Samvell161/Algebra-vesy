import time
import uuid
from dataclasses import dataclass, field
from typing import Optional
from fractions import Fraction

from .hardware import BLOCKS, TAG_KINDS, expression, normalize_uid
from .math_engine import Equation, Linear, MathError, equation, fmt, number
from .tasks import BY_ID, TASKS


@dataclass
class Session:
    task_id: Optional[str] = None
    mode: str = "practice"
    current: Optional[Equation] = None
    history: list = field(default_factory=list)
    hints: int = 0
    started: float = 0
    attempt: str = ""
    completed: bool = False
    blocks: dict = field(default_factory=lambda: {"left": [], "right": []})
    x: Fraction = Fraction(1)
    rfid_operation: str = "subtract"
    rfid_terms: list = field(default_factory=list)


class Service:
    def __init__(self, store, reader):
        self.store = store
        self.reader = reader

    def bootstrap(self, session):
        return {"tasks": TASKS, "progress": self.store.progress(), "settings": self.store.settings(),
                "hardware": self.reader.status(), "tags": self.store.tags(), "blocks": BLOCKS,
                "exercise": self.exercise(session), "lab": self.lab(session)}

    def exercise(self, session):
        if not session.current:
            return None
        elapsed = int(time.monotonic() - session.started)
        return {"task": BY_ID[session.task_id], "equation": session.current.json(),
                "history": session.history, "hints": session.hints, "mode": session.mode,
                "completed": session.completed, "expired": session.mode == "challenge" and elapsed >= 180 and not session.completed,
                "seconds": elapsed, "remaining": max(0, 180 - elapsed),
                "stars": max(1, 3 - min(2, session.hints)) if session.completed else 0}

    def lab(self, session):
        left, right = expression(session.blocks["left"]), expression(session.blocks["right"])
        lv, rv = left.at(session.x), right.at(session.x)
        return {"blocks": session.blocks, "equation": Equation(left, right).json(), "x": str(session.x),
                "left_value": fmt(lv), "right_value": fmt(rv), "balanced": lv == rv,
                "tilt": 0 if lv == rv else (-1 if lv > rv else 1)}

    def start(self, session, data):
        task_id = data.get("task_id")
        if task_id not in BY_ID:
            raise ValueError("Задание не найдено.")
        mode = data.get("mode", "practice")
        if mode not in ("practice", "challenge"):
            raise ValueError("Неизвестный режим.")
        session.task_id, session.mode = task_id, mode
        session.current = equation(BY_ID[task_id]["equation"])
        session.history = [{"label": "Начальное уравнение", **session.current.json()}]
        session.hints = 0
        session.started = time.monotonic()
        session.attempt = uuid.uuid4().hex
        session.completed = False
        session.rfid_operation, session.rfid_terms = "subtract", []
        return self.exercise(session)

    def active(self, session):
        if not session.current:
            raise ValueError("Сначала выберите задание.")
        if session.completed:
            raise ValueError("Задание уже завершено. Выберите следующее.")
        if session.mode == "challenge" and time.monotonic() - session.started >= 180:
            raise ValueError("Время вышло. Попробуйте задание ещё раз.")

    def transform(self, session, data):
        self.active(session)
        if len(session.history) >= 51:
            raise ValueError("Достигнут лимит 50 шагов. Начните задание заново.")
        op, value = data.get("operation"), str(data.get("value", ""))
        result = session.current.transform(op, value)
        if result == session.current:
            raise ValueError("Это действие ничего не меняет. Попробуйте другое число.")
        labels = {"add": "Прибавили", "subtract": "Вычли", "multiply": "Умножили на", "divide": "Разделили на"}
        session.current = result
        session.history.append({"label": f"{labels[op]} {value} с обеих сторон", **result.json()})
        if result.isolated():
            self.complete(session)
        return self.exercise(session)

    def complete(self, session):
        if not session.completed:
            self.store.record(session.attempt, session.task_id, session.mode, len(session.history) - 1,
                              session.hints, int(time.monotonic() - session.started))
            session.completed = True

    def answer(self, session, data):
        self.active(session)
        value = number(data.get("answer", ""))
        original = equation(BY_ID[session.task_id]["equation"])
        left, right = original.left.at(value), original.right.at(value)
        if left != right:
            return {"correct": False, "message": f"При x = {fmt(value)} слева получается {fmt(left)}, справа — {fmt(right)}. Значения отличаются: проверь последний шаг."}
        self.complete(session)
        return {"correct": True, "message": "Верно! Подстановка подтверждает равенство.", "exercise": self.exercise(session)}

    def save_practice(self, session):
        if not session.current or session.completed or session.mode != "practice":
            self.store.checkpoint(None)
            return
        self.store.checkpoint({"version": 1, "task_id": session.task_id, "history": session.history,
                               "hints": session.hints, "attempt": session.attempt,
                               "seconds": int(time.monotonic() - session.started)})

    def restore_practice(self, session):
        saved = self.store.settings().get("practice_session")
        if not saved:
            return False
        try:
            if saved["version"] != 1 or not isinstance(saved["history"], list) or not 1 <= len(saved["history"]) <= 51:
                raise ValueError("Invalid checkpoint")
            task = BY_ID[saved["task_id"]]
            original = equation(task["equation"])
            restored = []
            for step in saved["history"]:
                current = equation(step["left"] + "=" + step["right"])
                if current.solution() != original.solution() or not isinstance(step["label"], str):
                    raise ValueError("Invalid checkpoint equation")
                restored.append({"label": step["label"][:200], **current.json()})
            if equation(restored[0]["left"] + "=" + restored[0]["right"]) != original or current.isolated():
                raise ValueError("Invalid checkpoint history")
            hints, seconds = saved["hints"], saved["seconds"]
            if type(hints) is not int or type(seconds) is not int or not 0 <= hints <= 10000 or not 0 <= seconds <= 31536000:
                raise ValueError("Invalid checkpoint counters")
            attempt = saved["attempt"]
            if not isinstance(attempt, str) or len(attempt) != 32 or any(c not in "0123456789abcdef" for c in attempt):
                raise ValueError("Invalid checkpoint ID")
        except (ValueError, TypeError, KeyError):
            self.store.checkpoint(None)
            return False
        self.start(session, {"task_id": task["id"]})
        session.current, session.history = current, restored
        session.hints, session.attempt = hints, attempt
        session.started = time.monotonic() - seconds
        return True

    def hint(self, session):
        self.active(session)
        session.hints += 1
        eq = session.current
        if eq.right.a and eq.left.a:
            text = f"Уберите x с одной стороны: вычтите {eq.right.a}x из обеих частей."
        elif eq.left.a and eq.left.b:
            text = f"Оставьте блоки x отдельно: вычтите ({fmt(eq.left.b)}) из обеих частей."
        elif eq.right.a and eq.right.b:
            text = f"Оставьте блоки x отдельно: вычтите ({fmt(eq.right.b)}) из обеих частей."
        else:
            coefficient = eq.left.a or eq.right.a
            text = f"Чтобы получить один x, разделите обе части на {fmt(coefficient)}."
        return {"text": text, "hints": session.hints}

    def undo(self, session):
        self.active(session)
        if len(session.history) < 2:
            raise ValueError("Пока нет действий для отмены.")
        session.history.pop()
        last = session.history[-1]
        session.current = equation(last["left"] + "=" + last["right"])
        return self.exercise(session)

    def scan(self, session, data):
        side = data.get("side")
        if side not in ("left", "right"):
            raise ValueError("Выберите левую или правую чашу перед регистрацией.")
        uid = normalize_uid(data.get("uid", ""))
        tags = self.store.tags()
        if uid not in tags:
            raise ValueError(f"Неизвестная метка {uid}. Сначала свяжите её с блоком в настройках.")
        if tags[uid] not in BLOCKS:
            raise ValueError("Это метка команды. Откройте задание: команды работают при решении уравнений.")
        if any(block["uid"] == uid for blocks in session.blocks.values() for block in blocks):
            raise ValueError("Этот блок уже зарегистрирован. Для переноса сначала удалите его с чаши.")
        if sum(map(len, session.blocks.values())) >= 40:
            raise ValueError("На весах может быть до 40 блоков.")
        session.blocks[side].append({"uid": uid, "kind": tags[uid]})
        return self.lab(session)

    def guided_step(self, session):
        """Choose one equivalence-preserving step from the displayed equation."""
        eq = session.current
        if not eq:
            raise ValueError("Сначала выберите задание.")
        if eq.isolated():
            return None
        if eq.left.a and eq.right.a:
            op, value = "subtract", str(Linear(eq.right.a))
        else:
            variable_side = eq.left if eq.left.a else eq.right
            if not variable_side.a:
                raise ValueError("В этом уравнении нет единственного решения; учебный шаг недоступен.")
            if variable_side.b:
                op, value = "subtract", fmt(variable_side.b)
            else:
                op, value = "divide", fmt(variable_side.a)
        label = ("Вычесть (" + value + ") из обеих частей" if op == "subtract"
                 else "Разделить обе части на (" + value + ")")
        return {"operation": op, "value": value, "label": label}

    def rfid_pending(self, session):
        total = Linear()
        for kind in session.rfid_terms:
            block = BLOCKS[kind]
            total += Linear(Fraction(block["a"]), Fraction(block["b"]))
        return str(total)

    def scan_exercise(self, session, data):
        uid = normalize_uid(data.get("uid", ""))
        kind = self.store.tags().get(uid)
        if kind not in TAG_KINDS:
            raise ValueError("Неизвестная метка. Сначала привяжите её.")
        style = data.get("style", "guided")
        if style not in ("guided", "independent"):
            raise ValueError("Неизвестный режим решения метками.")
        if kind == "next" or (style == "guided" and session.completed):
            if not session.completed:
                raise ValueError("Сначала завершите текущее задание.")
            index = next(i for i, task in enumerate(TASKS) if task["id"] == session.task_id)
            self.start(session, {"task_id": TASKS[(index + 1) % len(TASKS)]["id"], "mode": session.mode})
            message = "Новое задание. Прочитайте условие и поднесите метку снова."
        else:
            self.active(session)
            if kind == "hint":
                message = self.hint(session)["text"]
            elif kind == "undo":
                self.undo(session)
                session.rfid_terms = []
                message = "Последний шаг отменён."
            elif style == "guided" or kind == "guide":
                step = self.guided_step(session)
                if step:
                    # Assisted steps use the existing hint penalty, before completion is recorded.
                    old_hints = session.hints
                    session.hints += 1
                    try:
                        self.transform(session, step)
                    except (ValueError, MathError):
                        session.hints = old_hints
                        raise
                    session.history[-1]["label"] = "Метка · шаг с подсказкой: " + session.history[-1]["label"]
                    message = step["label"] + "."
                else:
                    self.complete(session)
                    message = "Неизвестное уже выделено. Решение подтверждено."
                session.rfid_terms = []
            elif kind in ("add", "subtract", "multiply", "divide"):
                session.rfid_operation, session.rfid_terms = kind, []
                message = "Выбрано: " + TAG_KINDS[kind]["label"] + ". Поднесите метки чисел или x."
            elif kind == "clear":
                session.rfid_terms = []
                message = "Набранное выражение очищено. Уравнение сохранено."
            elif kind == "apply":
                if not session.rfid_terms:
                    raise ValueError("Сначала наберите выражение метками чисел или x.")
                value = self.rfid_pending(session)
                self.transform(session, {"operation": session.rfid_operation, "value": value})
                session.history[-1]["label"] = "Метки · " + session.history[-1]["label"]
                session.rfid_terms = []
                message = session.history[-1]["label"] + "."
            elif kind in BLOCKS:
                if len(session.rfid_terms) >= 40:
                    raise ValueError("Набрано 40 блоков. Примените действие или очистите набор.")
                session.rfid_terms.append(kind)
                message = "Добавлено " + BLOCKS[kind]["label"] + ". Набрано: " + self.rfid_pending(session) + ". Поднесите «Применить»."
            else:
                raise ValueError("Эта метка не поддерживается.")
        return {"message": message, "kind": kind, "uid": uid, "exercise": self.exercise(session),
                "pending": self.rfid_pending(session)}

    def dispatch(self, path, session, data):
        if path == "/api/exercise/start":
            return self.start(session, data)
        if path == "/api/exercise/scan":
            return self.scan_exercise(session, data)
        if path == "/api/exercise/transform":
            return self.transform(session, data)
        if path == "/api/exercise/answer":
            return self.answer(session, data)
        if path == "/api/exercise/hint":
            return self.hint(session)
        if path == "/api/exercise/undo":
            return self.undo(session)
        if path == "/api/lab/scan":
            return self.scan(session, data)
        if path == "/api/lab/simulate":
            if self.reader.mode != "simulator":
                raise ValueError("В аппаратном режиме используйте реальные метки.")
            kind, side = data.get("kind"), data.get("side")
            if kind not in BLOCKS or side not in ("left", "right"):
                raise ValueError("Выберите блок и чашу.")
            if sum(map(len, session.blocks.values())) >= 40:
                raise ValueError("На весах может быть до 40 блоков.")
            session.blocks[side].append({"uid": "SIM-" + uuid.uuid4().hex[:8], "kind": kind})
            return self.lab(session)
        if path == "/api/lab/remove":
            for side in session.blocks:
                session.blocks[side] = [b for b in session.blocks[side] if b["uid"] != data.get("uid")]
            return self.lab(session)
        if path == "/api/lab/clear":
            session.blocks = {"left": [], "right": []}
            return self.lab(session)
        if path == "/api/lab/x":
            session.x = number(data.get("value", ""))
            return self.lab(session)
        if path == "/api/equation/check":
            eq = equation(data.get("equation", ""))
            return eq.json()
        if path == "/api/tags/bind":
            kind = data.get("kind")
            uid = normalize_uid(data.get("uid", ""))
            if kind not in TAG_KINDS:
                raise ValueError("Неизвестный тип метки.")
            if any(b["uid"] == uid for blocks in session.blocks.values() for b in blocks):
                raise ValueError("Сначала удалите блок с чаши, затем измените его тип.")
            self.store.bind(uid, kind)
            return self.store.tags()
        if path == "/api/tags/remove":
            uid = normalize_uid(data.get("uid", ""))
            self.store.unbind(uid)
            return self.store.tags()
        if path == "/api/settings":
            values = {}
            if "name" in data:
                if not isinstance(data["name"], str) or not 1 <= len(data["name"].strip()) <= 32:
                    raise ValueError("Имя должно содержать от 1 до 32 символов.")
                values["name"] = data["name"].strip()
            for key in ("motion", "contrast"):
                if key in data:
                    if not isinstance(data[key], bool):
                        raise ValueError("Некорректная настройка интерфейса.")
                    values[key] = data[key]
            self.store.save_settings(values)
            return self.store.settings()
        if path == "/api/progress/reset":
            if data.get("confirm") != "RESET":
                raise ValueError("Подтвердите сброс прогресса.")
            self.store.reset_progress()
            return self.store.progress()
        raise LookupError("Маршрут не найден.")
