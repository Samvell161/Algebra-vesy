#!/usr/bin/python3
"""Entry point installed alongside the package, independent of current directory."""
from algebra_lab.desktop import main

raise SystemExit(main())
