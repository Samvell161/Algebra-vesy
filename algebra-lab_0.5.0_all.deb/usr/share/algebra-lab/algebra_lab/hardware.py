"""One UID per presentation. No assumption of bulk RFID inventory or measured algebra."""
import threading
import time
from collections import deque

from .math_engine import Linear
from .rc522 import CardReadError
from fractions import Fraction

BLOCKS = {
    "x": {"label": "x", "a": 1, "b": 0},
    "-x": {"label": "−x", "a": -1, "b": 0},
    "1": {"label": "+1", "a": 0, "b": 1},
    "-1": {"label": "−1", "a": 0, "b": -1},
    "2": {"label": "+2", "a": 0, "b": 2},
    "-2": {"label": "−2", "a": 0, "b": -2},
    "5": {"label": "+5", "a": 0, "b": 5},
}


COMMANDS = {
    "add": {"label": "+ Прибавить"},
    "subtract": {"label": "− Вычесть"},
    "multiply": {"label": "× Умножить"},
    "divide": {"label": "÷ Разделить"},
    "apply": {"label": "✓ Применить"},
    "clear": {"label": "Очистить набор"},
    "undo": {"label": "↶ Отмена"},
    "hint": {"label": "? Подсказка"},
    "next": {"label": "→ Следующее"},
    "guide": {"label": "Шаг с подсказкой"},
}
TAG_KINDS = {**BLOCKS, **COMMANDS}


def normalize_uid(uid):
    uid = str(uid).strip().upper()
    if not uid or len(uid) > 64 or not all(c in "0123456789ABCDEF:-" for c in uid):
        raise ValueError("UID: используйте до 64 символов 0–9, A–F, : или −.")
    return uid


def expression(blocks):
    result = Linear()
    for block in blocks:
        kind = BLOCKS[block["kind"]]
        result += Linear(Fraction(kind["a"]), Fraction(kind["b"]))
    return result


class Reader:
    POLL_SECONDS = 0.8
    REMOVE_SECONDS = 0.7
    ABSENT_READS = 2

    def __init__(self, mode="simulator"):
        self.mode = mode
        self.error = None
        self.warning = None
        self.last_error = None
        self.failures = 0
        self.present_uid = None
        self.events = deque(maxlen=100)
        self.sequence = 0
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.driver = None
        self.configure(mode)

    def configure(self, mode):
        if mode not in ("simulator", "rc522"):
            raise ValueError("Неизвестный режим считывателя.")
        self.close()
        if self.thread and self.thread.is_alive():
            raise OSError("Предыдущий опрос ещё завершается. Повторите подключение.")
        self.mode, self.error, self.driver = mode, None, None
        self.warning, self.last_error, self.failures, self.present_uid = None, None, 0, None
        self.stop_event = threading.Event()
        if mode == "rc522":
            self.thread = threading.Thread(target=self._connect, daemon=True)
            self.thread.start()

    def _connect(self):
        try:
            from .rc522 import RC522
            self.driver = RC522()
            self._poll()
        except ImportError:
            self.error = "Нужны системные библиотеки. В терминале: sudo apt install python3-spidev python3-rpi.gpio"
        except Exception as exc:
            self.error = "RC522 недоступен: " + str(exc)
        finally:
            if self.driver:
                self.driver.close()
                self.driver = None

    def _poll(self):
        last, absent_since, absent_reads = None, None, 0
        delay = self.POLL_SECONDS
        try:
            while not self.stop_event.wait(delay):
                try:
                    uid = self.driver.read_id_no_block()
                except CardReadError as exc:
                    # RF faults prove neither removal nor a different tag.
                    absent_since, absent_reads = None, 0
                    self.last_error = str(exc)
                    self.failures += 1
                    delay = min(2.0, self.POLL_SECONDS + self.failures * .2)
                    if self.failures >= 3:
                        self.warning = "Метка пока не прочитана. Попробуй поднести её чуть ближе. Взрослый может открыть «Проверка считывателя»."
                    # Do not continually interrupt the RF field on every sample.
                    if self.failures % 3 == 0:
                        self.driver.recover()
                    continue
                delay = self.POLL_SECONDS
                if uid is None:
                    now = time.monotonic()
                    absent_reads += 1
                    if absent_since is None:
                        absent_since = now
                    if absent_reads >= self.ABSENT_READS and now - absent_since >= self.REMOVE_SECONDS:
                        last = None
                        self.present_uid = None
                    continue
                absent_since, absent_reads = None, 0
                self.warning, self.failures = None, 0
                uid = format(uid, "X")
                self.present_uid = uid
                # The low-level driver has validated ATQA length, full UID and BCC.
                # One valid sample is sufficient; faults before/after it cannot
                # prevent recognition or create another presentation.
                if last is None:
                    with self.lock:
                        self.sequence += 1
                        self.events.append({"sequence": self.sequence, "uid": uid})
                    last = uid
        except Exception as exc:
            self.error = f"Чтение остановлено: {type(exc).__name__}: {exc}. Нажмите «Считать метку» для повторного подключения."
            self.last_error = self.error

    def status(self):
        return {"mode": self.mode, "connected": self.driver is not None and self.error is None,
                "error": self.error, "warning": self.warning, "last_error": self.last_error, "failures": self.failures,
                "present_uid": self.present_uid, "poll_seconds": self.POLL_SECONDS, "hx711": "not_configured", "sequence": self.sequence}

    def since(self, sequence):
        with self.lock:
            return [event.copy() for event in self.events if event["sequence"] > sequence]

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=0.3)
