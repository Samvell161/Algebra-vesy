"""Offline learning journey. Local calendar dates; no online clock or account needed."""
import csv
import io
from datetime import date, datetime, timedelta

from .tasks import TASKS, BY_ID, PLAY_TASKS

CHAPTERS = [
    ("Первое равновесие", "Освободи неизвестное", "#e2eee5",
     "Прибавление и вычитание", "Равенство сохраняется, когда к обеим частям прибавляют одно и то же число или выражение. Вычитать тоже нужно с обеих сторон.",
     "x + 3 = 7\nВычитаем 3 с обеих сторон:\nx + 3 − 3 = 7 − 3\nx = 4", "Проверь: 4 + 3 действительно равно 7."),
    ("Сила одного блока", "Раздели поровну", "#f5e9d5",
     "Умножение и деление", "Если несколько одинаковых блоков x имеют известную сумму, раздели обе части на их количество. Делить можно только на ненулевое число. Умножение на ноль теряет информацию об ответе.",
     "3x + 2 = 14\nВычитаем 2: 3x = 12\nДелим на 3: x = 4", "Дробный ответ тоже допустим: из 2x = 7 получаем x = 7/2."),
    ("Мост между чашами", "Собери x с одной стороны", "#e6e9f5",
     "Переменная с двух сторон", "Вычти одинаковое выражение с x из обеих частей. Затем убери свободное число и раздели на коэффициент при x. Скобки раскрываются умножением каждого слагаемого.",
     "3x + 2 = x + 10\nВычитаем x: 2x + 2 = 10\nВычитаем 2: 2x = 8\nДелим на 2: x = 4", "2(x + 3) = 2x + 6. Множитель относится к обоим слагаемым."),
    ("Мастерская открытий", "Подружись с дробями", "#e1edf1",
     "Дроби и скобки", "Чтобы убрать знаменатель, умножь обе части на него. Если знаменателей несколько, выбери их общий кратный. Проверяй ответ в исходном уравнении.",
     "x/2 + 3 = 8\nВычитаем 3: x/2 = 5\nУмножаем на 2: x = 10", "Движок хранит дроби точно: 1/3 + 1/3 + 1/3 = 1."),
]


def daily_task(today=None):
    return TASKS[(today or date.today()).toordinal() % len(TASKS)]


def learning_stats(progress, today=None):
    today = today or date.today()
    by_day = {}
    for attempt in progress["attempts"]:
        day = datetime.fromisoformat(attempt["completed_at"]).astimezone().date()
        by_day.setdefault(day, set()).add(attempt["task_id"])
    cursor = today if today in by_day else today - timedelta(days=1)
    streak = 0
    while cursor in by_day:
        streak += 1
        cursor -= timedelta(days=1)
    best = progress["best"]
    xp = sum(best.get(task["id"], 0) for task in PLAY_TASKS) * 10
    rank = next(name for threshold, name in [(540, "Мастер равновесия"), (300, "Исследователь"), (120, "Экспериментатор"), (0, "Первооткрыватель")] if xp >= threshold)
    return {"xp": xp, "rank": rank, "streak": streak, "today": len(by_day.get(today, set())),
            "daily_done": daily_task(today)["id"] in by_day.get(today, set()),
            "chapters": [{"completed": sum(t["id"] in best for t in TASKS if t["level"] == level),
                          "total": sum(t["level"] == level for t in TASKS)} for level in range(1, 5)]}


def progress_csv(progress):
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["Дата UTC", "Задание", "Режим", "Шаги", "Подсказки", "Звёзды", "Секунды"])
    for row in progress["attempts"]:
        title = BY_ID.get(row["task_id"], {}).get("title", "Неизвестное задание")
        writer.writerow([row["completed_at"], title, "Вызов" if row["mode"] == "challenge" else "Практика",
                         row["steps"], row["hints"], row["stars"], row["seconds"]])
    return output.getvalue()
