import json
import sqlite3
import threading
from datetime import datetime, timezone


class Store:
    def __init__(self, path):
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS attempts (
                id TEXT PRIMARY KEY, task_id TEXT NOT NULL, mode TEXT NOT NULL,
                steps INTEGER NOT NULL, hints INTEGER NOT NULL, stars INTEGER NOT NULL,
                seconds INTEGER NOT NULL, completed_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tags (uid TEXT PRIMARY KEY, kind TEXT NOT NULL);
        """)
        self.db.commit()

    def record(self, attempt, task_id, mode, steps, hints, seconds):
        stars = max(1, 3 - min(2, hints))
        with self.lock, self.db:
            self.db.execute("INSERT OR IGNORE INTO attempts VALUES (?,?,?,?,?,?,?,?)",
                            (attempt, task_id, mode, steps, hints, stars, seconds,
                             datetime.now(timezone.utc).isoformat()))
        return stars

    def progress(self):
        with self.lock:
            rows = [dict(row) for row in self.db.execute("SELECT * FROM attempts ORDER BY completed_at DESC")]
        best = {}
        for row in rows:
            best[row["task_id"]] = max(best.get(row["task_id"], 0), row["stars"])
        return {"attempts": rows, "best": best, "completed": len(best), "stars": sum(best.values()),
                "total_seconds": sum(row["seconds"] for row in rows)}

    def settings(self):
        result = {"name": "Исследователь", "motion": True, "contrast": False}
        with self.lock:
            result.update({row["key"]: json.loads(row["value"]) for row in self.db.execute("SELECT * FROM settings")})
        return result

    def save_settings(self, values):
        with self.lock, self.db:
            for key, value in values.items():
                self.db.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, json.dumps(value)))

    def tags(self):
        with self.lock:
            return {r["uid"]: r["kind"] for r in self.db.execute("SELECT * FROM tags")}

    def bind(self, uid, kind):
        with self.lock, self.db:
            self.db.execute("INSERT OR REPLACE INTO tags VALUES (?,?)", (uid, kind))

    def bind_many(self, tags):
        # One transaction: a failed import must not leave half the list applied.
        with self.lock, self.db:
            self.db.executemany("INSERT OR REPLACE INTO tags VALUES (?,?)", list(tags.items()))

    def unbind(self, uid):
        with self.lock, self.db:
            self.db.execute("DELETE FROM tags WHERE uid=?", (uid,))

    def reset_progress(self):
        with self.lock, self.db:
            self.db.execute("DELETE FROM attempts")

    def checkpoint(self, value):
        self.save_settings({"practice_session": value})

    def close(self):
        self.db.close()
