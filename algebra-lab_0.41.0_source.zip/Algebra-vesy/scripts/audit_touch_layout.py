"""Capture and check the actual touch UI, without touching a child's saved data.

Use a dedicated 1024x600 display for the real GL view. --software also works
with QT_QPA_PLATFORM=offscreen. --package checks an extracted release payload.
"""
import argparse
import gc
import json
import subprocess
import sys
import tempfile
from contextlib import ExitStack
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--package',type=Path)
parser.add_argument('--software',action='store_true')
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
repo=Path(__file__).resolve().parents[1]
stack=ExitStack()
if args.package:
    install=Path(stack.enter_context(tempfile.TemporaryDirectory()))
    subprocess.run(['dpkg-deb','-x',str(args.package),str(install)],check=True)
    payload=install/'usr/share/algebra-lab';fonts=install/'usr/share/fonts/truetype/algebra-lab'
else:
    payload=repo;fonts=repo/'packaging/fonts'
sys.path.insert(0,str(payload))
from PyQt6 import sip
from PyQt6.QtCore import Qt,QTimer
from PyQt6.QtGui import QFontDatabase
from PyQt6.QtWidgets import QApplication,QPushButton,QLabel,QScrollArea,QMessageBox,QInputDialog
from PyQt6.QtTest import QTest
from algebra_lab import __version__
from algebra_lab.adventure import ADVENTURE_TASKS,QUIZZES
from algebra_lab.qt_ui.app import Window,icon
from algebra_lab.qt_ui.touch_button import TouchButton
from algebra_lab.qt_ui.route_map import RouteMap
from algebra_lab.qt_ui.gui_lifecycle import release_gui_caches

app=QApplication([])
for font in fonts.glob('AlgebraRounded*.ttf'):
    assert QFontDatabase.addApplicationFont(str(font))>=0
app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
records=[];errors=[];screens=[];modal_errors=[]

def audit(widget,name,capture=True):
    app.processEvents()
    if capture:
        if widget is w and not args.software:
            image=app.primaryScreen().grabWindow(0,w.x(),w.y(),w.width(),w.height())
        else:image=widget.grab()
        assert image.save(str(args.output/(name+'.png')))
        screens.append(name+'.png')
    buttons=[b for b in widget.findChildren(QPushButton) if b.isVisible()]
    for b in buttons:
        if isinstance(b,TouchButton):
            content,ic,text,bounds=b.label_layout()
            record={'screen':name,'text':b.text(),'size':[b.width(),b.height()],
                    'text_bounds':[bounds.width(),bounds.height()],
                    'available_text':[text.width(),text.height()]}
            records.append(record)
            if b.text() and (bounds.width()>text.width() or bounds.height()>text.height()):errors.append(record)
            if min(b.width(),b.height())<44:errors.append(dict(record,error='small touch target'))
            if not b.icon().isNull() and (not content.contains(ic) or text.left()-ic.right()-1<8):
                errors.append(dict(record,error='icon spacing'))
        for other in buttons:
            if other is b or other.parentWidget() is not b.parentWidget():continue
            if b.geometry().intersects(other.geometry()):errors.append({'screen':name,'overlap':[b.text(),other.text()]})
    for parent in [w.condition_card,w.profile_button]:
        labels=parent.findChildren(QLabel)
        for label in labels:
            if (not parent.rect().contains(label.geometry()) or label.height()<label.fontMetrics().height()
                    or label.width()<label.fontMetrics().horizontalAdvance(label.text())):
                errors.append({'screen':name,'header_label':label.text(),'error':'clipped label'})


def modal(name,fn,extra=None):
    def capture():
        dialog=app.activeModalWidget()
        try:
            assert dialog is not None,'No active dialog'
            if extra:extra(dialog)
            audit(dialog,name)
            scroll=dialog.findChild(QScrollArea)
            if scroll and scroll.verticalScrollBar().maximum():
                scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
                app.processEvents();audit(dialog,name+'-bottom')
        except Exception as exc:modal_errors.append(name+': '+str(exc))
        finally:
            if dialog:dialog.reject()
    QTimer.singleShot(180,capture)
    fn()

with tempfile.TemporaryDirectory() as directory:
    w=Window(Path(directory),software_view=args.software);w.start('cups-4');w.move(0,0);w.show()
    if not args.software:
        for _ in range(200):
            assert not w.board.graphics_error,w.board.graphics_error
            if w.board.surface.frames>0:break
            QTest.qWait(50)
        assert w.board.surface.frames>0
    QTest.qWait(200);w.timer.stop();w.board.set_ambient(False)
    audit(w,'game')
    viewport=(w.board.container.geometry() if not args.software else w.board.geometry())
    for lesson in ADVENTURE_TASKS:
        w.start(lesson['id']);app.processEvents();audit(w,'lesson-'+lesson['id'],False)
        assert w.width()==1024 and w.height()==600
    w.start('cups-4')
    # The longest real hardware statuses must fit simultaneously on both sides.
    for status in ['экран','готова','нет связи','повтори чтение','убери метку','подключение']:
        for label,b in [('Левая чаша',w.left),('Правая чаша',w.right)]:b.setText(label+' · '+status)
        app.processEvents();audit(w,'status-'+status,False)
        assert w.width()==1024 and w.height()==600
    w.left.setText('Левая чаша · экран');w.right.setText('Правая чаша · экран')
    for name,fn in [('adult',w.adult),('profiles',w.choose_profile),('appearance',w.visual_settings),
                    ('phone',w.mobile_access),('hardware',w.hardware_check),('history',w.history),('script',w.show_script)]:
        modal(name,fn)
    def off(dialog):
        for b in dialog.findChildren(TouchButton):
            if b.text().startswith(('Анимации:','Живой фон:','Фоновые часы:','Светильник:')):b.click()
    modal('appearance-off',w.visual_settings,off)
    modal('new-profile',lambda:QInputDialog.getText(w,'Новый ребёнок','Имя или прозвище (до 24 символов):'))
    modal('backup',w.make_backup)
    modal('restore',w.load_backup)
    modal('export-log',w.export_log)
    modal('confirmation',lambda:QMessageBox.question(w,'Незавершённый ход','Продолжить действие на одной чаше?'))
    w.store.create_profile('Очень длинное имя ребёнка'[:24]);modal('profiles-long',w.choose_profile)
    for best_name,best in [('locked',{}),('complete',{t['id']:3 for t in ADVENTURE_TASKS})]:
        for chapter in range(4 if best else 1):
            dialog=RouteMap(best,'cups-4',chapter,w,motion=False)
            modal('map-'+best_name+'-'+str(chapter+1),dialog.exec)
            dialog.deleteLater();app.processEvents()
    for task in ADVENTURE_TASKS:w.store.record('audit-'+task['id'],task['id'],'practice',0,0,1)
    for quiz in QUIZZES:
        index=[0]
        def answer_question():
            dialog=app.activeModalWidget()
            try:
                assert dialog is not None
                question=quiz['questions'][index[0]]
                audit(dialog,quiz['id']+'-'+str(index[0]+1))
                buttons=dialog.findChildren(TouchButton)
                next(b for b in buttons if b.text()==question[1][question[2]]).click()
                audit(dialog,quiz['id']+'-'+str(index[0]+1)+'-answered',False)
                index[0]+=1
                if index[0]<len(quiz['questions']):QTimer.singleShot(150,answer_question)
                next(b for b in buttons if b.text()=='Дальше').click()
            except Exception as exc:
                modal_errors.append(quiz['id']+': '+str(exc))
                if dialog:dialog.reject()
        QTimer.singleShot(150,answer_question);w.quiz(quiz['id'])
    w.board.set_motion(True)
    if not args.software:w.board.set_lamp(True)
    w.start('cups-4');w.store.bind('A2','2');w.operation('remove')
    for side in ['left','right']:w.scan({'uid':'A2','source':side})
    for _ in range(100):
        app.processEvents()
        if w.answers.isVisible():break
        QTest.qWait(30)
    assert w.answers.isVisible()
    audit(w,'answer-entry')
    w.answer.setCurrentIndex(1);w.check()
    for _ in range(100):
        app.processEvents()
        if w.result_page.isVisible():break
        QTest.qWait(30)
    assert w.session.completed
    if not args.software:assert w.result_page.isVisible()
    audit(w,'result')
    assert viewport==(w.board.container.geometry() if not args.software else w.board.geometry())
    w.close();sip.delete(w);del w;gc.collect()
report={'version':__version__,'size':[1024,600],'software_view':args.software,
        'button_checks':len(records),'errors':errors,'modal_errors':modal_errors,'screens':screens,
        'viewport_preserved':True,'physical_pi_tested':False,'buttons':records}
(args.output/'touch-layout-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
icon.cache_clear();release_gui_caches();sip.delete(app);del app;gc.collect();stack.close()
print(json.dumps({k:v for k,v in report.items() if k not in ('buttons','screens')},ensure_ascii=False))
assert not errors and not modal_errors
