"""Exercise the production QSS and font at the actual touch-screen size."""
import tempfile
import unittest
from functools import partial
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtGui import QFontDatabase
    from algebra_lab.qt_ui.app import Window as AppWindow
    Window=partial(AppWindow,software_view=True)
    from algebra_lab.adventure import ADVENTURE_TASKS
except ImportError:
    QApplication=None

ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(QApplication,'Qt development dependencies required')
class WorkshopLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        for path in (ROOT/'packaging/fonts').glob('*.ttf'):
            QFontDatabase.addApplicationFont(str(path))

    def setUp(self):
        self.old_style=self.app.styleSheet()
        self.app.setStyleSheet((ROOT/'algebra_lab/qt_ui/theme.qss').read_text())
        self.tmp=tempfile.TemporaryDirectory();self.window=Window(Path(self.tmp.name))
        self.window.show();self.app.processEvents()

    def tearDown(self):
        self.window.close();self.app.setStyleSheet(self.old_style);self.tmp.cleanup()

    def assert_touch_layout(self):
        w=self.window
        self.assertEqual((w.width(),w.height()),(1024,600))
        for button in w.centralWidget().findChildren(QPushButton):
            if not button.isVisible():continue
            self.assertIsNotNone(button.graphicsEffect(),button.text())
            self.assertGreaterEqual(button.height(),44,button.text())
            self.assertGreaterEqual(button.width(),44,button.text())
            position=button.mapTo(w.centralWidget(),button.rect().topLeft())
            bottom=button.mapTo(w.centralWidget(),button.rect().bottomRight())
            self.assertTrue(w.centralWidget().rect().contains(position),button.text())
            self.assertTrue(w.centralWidget().rect().contains(bottom),button.text())

    def test_taller_scene_keeps_touch_targets_and_narrows_balance(self):
        w=self.window;w.start('cups-4');self.app.processEvents()
        self.assert_touch_layout()
        self.assertGreaterEqual(w.board.height(),340)
        scale,_,_,arm,_=w.board._geometry()
        self.assertLessEqual(2*arm*scale,w.board.width()*.51)
        self.assertIs(w.left.parent(),w.cup_controls)
        self.assertIs(w.right.parent(),w.cup_controls)
        w.board.grab()
        for start,end in w.board.attachments:
            self.assertGreater(end.y()-start.y(),w.board.height()*.30)
        frame=w.board._stage.cacheKey();w.board.grab()
        self.assertEqual(w.board._stage.cacheKey(),frame)

    def test_all_lesson_titles_and_answer_controls_fit_without_clipping(self):
        from PyQt6.QtTest import QTest
        w=self.window
        for lesson in ADVENTURE_TASKS:
            with self.subTest(lesson=lesson['id']):
                w.start(lesson['id']);self.app.processEvents();self.assert_touch_layout()
                self.assertGreaterEqual(w.board.height(),320)
                self.assertEqual(w.condition.text(),lesson['equation'])
        w.start('cups-4');w.store.bind('BB','2');w.operation('remove')
        for side in ['left','right']:w.scan({'uid':'BB','source':side})
        QTest.qWait(w.board.DURATION+240)
        self.app.processEvents();self.assert_touch_layout()
        self.assertTrue(w.answers.isVisible())
        self.assertGreaterEqual(w.board.height(),280)
        w.session.cup_guess=2;w.check();self.app.processEvents();self.assert_touch_layout()
        self.assertTrue(w.session.completed)

    def test_fixed_progress_card_keeps_full_name_and_header_positions(self):
        from unittest.mock import patch
        import algebra_lab.qt_ui.app as ui
        w=self.window;w.start('cups-4');self.app.processEvents()
        self.assertEqual(w.rank_label.text(),'Исследователь')
        self.assertGreaterEqual(w.brand.width(),w.brand.fontMetrics().horizontalAdvance(w.brand.text()))
        self.assertGreater(w.rank_label.width(),w.rank_label.fontMetrics().horizontalAdvance('Исследователь'))
        watched=[w.profile_button,w.heading,w.condition,w.board]
        before=[v.geometry() for v in watched];original=ui.game_progress
        for xp in [9,999,1234567]:
            def progress(data):
                result=original(data);result['xp']=xp;return result
            with patch.object(ui,'game_progress',side_effect=progress):w.refresh()
            w.feedback.setText('Длинное сообщение о ходе. '*12);self.app.processEvents()
            self.assertEqual(before,[v.geometry() for v in watched])
            self.assertEqual(w.rank_label.text(),'Исследователь')

    def test_button_labels_and_icons_fit_in_every_touch_state(self):
        from PyQt6.QtCore import Qt
        from PyQt6.QtTest import QTest
        from algebra_lab.qt_ui.touch_button import TouchButton
        w=self.window;w.start('cups-4');self.app.processEvents()
        for button in w.findChildren(TouchButton):
            if not button.isVisible() or not button.text():continue
            original=button.label_layout()[:3]
            checkable=button.isCheckable()
            for state in ['normal','hover','pressed','checked','disabled','focus']:
                with self.subTest(button=button.text(),state=state):
                    button.setEnabled(state!='disabled');button.setDown(state=='pressed')
                    button.setCheckable(True);button.setChecked(state=='checked')
                    QTest.mouseMove(button if state=='hover' else w)
                    if state=='focus':button.setFocus(Qt.FocusReason.TabFocusReason)
                    else:button.clearFocus()
                    self.app.processEvents()
                    content,icon,text,bounds=button.label_layout()
                    self.assertEqual((content,icon,text),original)
                    self.assertLessEqual(bounds.width(),text.width(),button.text())
                    self.assertLessEqual(bounds.height(),text.height(),button.text())
                    self.assertTrue(content.contains(text))
                    if icon.width():
                        self.assertTrue(content.contains(icon))
                        self.assertGreaterEqual(text.left()-icon.right()-1,8)
                    button.grab()  # Exercise the real QSS frame and label painter.
            button.setEnabled(True);button.setDown(False);button.setChecked(False);button.setCheckable(checkable)

    def test_header_labels_stay_inside_their_cards(self):
        from PyQt6.QtWidgets import QLabel
        w=self.window;self.app.processEvents()
        for parent in [w.condition_card,w.profile_button]:
            labels=parent.findChildren(QLabel)
            for label in labels:
                with self.subTest(label=label.text()):
                    self.assertTrue(parent.rect().contains(label.geometry()))
                    self.assertGreaterEqual(label.height(),label.fontMetrics().height())
                    self.assertGreaterEqual(label.width(),label.fontMetrics().horizontalAdvance(label.text()))
            for first,second in zip(labels,labels[1:]):
                self.assertFalse(first.geometry().intersects(second.geometry()))

    def test_long_dialog_button_wraps_and_keeps_neighbours_separate(self):
        from PyQt6.QtWidgets import QWidget,QVBoxLayout
        from algebra_lab.qt_ui.touch_button import TouchButton
        widget=QWidget();layout=QVBoxLayout(widget);layout.setSpacing(10)
        long=TouchButton('Настройки и дополнительные режимы прежнего интерфейса',wrap=True)
        other=TouchButton('Закрыть',wrap=True);layout.addWidget(long);layout.addWidget(other);layout.addStretch()
        widget.resize(310,300);widget.show();self.app.processEvents()
        try:
            self.assertEqual(widget.width(),310)
            self.assertGreater(long.height(),44)
            content,_,text,bounds=long.label_layout()
            self.assertLessEqual(bounds.width(),text.width())
            self.assertLessEqual(bounds.height(),content.height())
            self.assertGreaterEqual(other.y()-long.geometry().bottom()-1,10)
            widget.grab()
        finally:widget.close()
