#!/usr/bin/python3
import sys
if "--legacy" in sys.argv or "--check-hardware" in sys.argv:
    if "--legacy" in sys.argv: sys.argv.remove("--legacy")
    from algebra_lab.desktop import main
else:
    from algebra_lab.qt_ui.app import main
raise SystemExit(main())
