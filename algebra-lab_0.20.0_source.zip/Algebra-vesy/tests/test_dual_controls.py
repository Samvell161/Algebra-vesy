import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from algebra_lab.buttons import Debouncer, Buttons
from algebra_lab.hardware import Reader
from algebra_lab.rc522 import CardReadError
from algebra_lab.diagnostics import boot_info
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store


class DualReaderTests(unittest.TestCase):
    def channel(self, readings):
        driver = Mock(version=0x92)
        driver.read_id_no_block.side_effect = readings
        return {"driver": driver, "last": None, "present_uid": None, "absent_since": None,
                "absent_reads": 0, "failures": 0, "error": None, "warning": None,
                "last_error": None, "next": 0, "bus": 0, "rst": 25, "version": 0x92}

    def test_same_uid_on_different_sources_is_two_actions_but_holding_is_one(self):
        reader = Reader()
        left, right = self.channel([123,123]), self.channel([123,123])
        for _ in range(2):
            reader._sample_channel('left',left)
            reader._sample_channel('right',right)
        self.assertEqual(reader.since(0), [{'sequence':1,'uid':'7B','source':'left'},
                                          {'sequence':2,'uid':'7B','source':'right'}])
        left['driver'].antenna.assert_any_call(True)
        self.assertEqual(left['driver'].antenna.call_args.args,(False,))
        reader.close()

    def test_fault_and_reconnect_do_not_rearm_held_uid_clean_removal_does(self):
        reader = Reader()
        channel = self.channel([123,CardReadError('noise'),123,None,None,123])
        with patch('algebra_lab.hardware.time.monotonic', side_effect=[1,2,3,4,4,5,5.8,5.8,6]):
            for _ in range(6): reader._sample_channel('left',channel)
        self.assertEqual(len(reader.since(0)),2)
        self.assertEqual(channel['failures'],0)
        reader.close()

    def test_broken_reader_does_not_stop_other_channel(self):
        reader = Reader()
        broken, working = self.channel([OSError('SPI broken')]), self.channel([456])
        reader._sample_channel('left',broken)
        reader._sample_channel('right',working)
        self.assertIsNone(broken['driver'])
        self.assertIn('SPI broken',broken['error'])
        self.assertEqual(reader.since(0)[0]['source'],'right')
        reader.close()

    def test_worker_uses_independent_spi_rst_and_only_one_antenna(self):
        reader = Reader()
        active, opened = set(), []
        def factory(bus,device,rst):
            opened.append((bus,device,rst))
            self.assertFalse(active)
            driver=Mock(version=0x92)
            active.add(bus)  # Constructor briefly enables its own antenna.
            def antenna(on):
                if on:
                    self.assertFalse(active)
                    active.add(bus)
                else: active.discard(bus)
            driver.antenna.side_effect=antenna
            def read():
                self.assertEqual(active,{bus})
                return 123
            driver.read_id_no_block.side_effect=read
            driver.close.side_effect=lambda:active.discard(bus)
            return driver
        class Stop:
            cycles=0
            def wait(self,delay):
                if delay==.05: self.cycles+=1
                return self.cycles>2
            def is_set(self): return self.cycles>2
        reader.stop_event=Stop()
        with patch('algebra_lab.rc522.RC522',side_effect=factory): reader._connect_dual()
        self.assertEqual(opened,[(0,0,25),(1,0,5)])
        self.assertFalse(active)
        self.assertEqual([e['source'] for e in reader.since(0)],['left','right'])

    def test_partial_connection_failure_is_visible_and_healthy_channel_reads(self):
        reader=Reader()
        driver=Mock(version=0x92)
        driver.read_id_no_block.return_value=123
        class Stop:
            cycles=0
            def wait(self,delay):
                if delay==.05:self.cycles+=1
                return self.cycles>1
            def is_set(self):return self.cycles>1
        reader.stop_event=Stop()
        with patch('algebra_lab.rc522.RC522',side_effect=[driver,OSError('missing SPI1')]):
            reader._connect_dual()
        self.assertIn('missing SPI1',reader.channels['right']['error'])
        self.assertEqual(reader.since(0)[0]['source'],'left')
        driver.close.assert_called_once()


class ButtonsTests(unittest.TestCase):
    def test_debounce_hold_release_and_second_press(self):
        d=Debouncer()
        self.assertEqual(d.sample({13:True,26:True},0),[])
        self.assertEqual(d.sample({13:True,26:True},.07),[])
        d.sample({13:False,26:True},.08)
        d.sample({13:True,26:True},.09) # contact bounce
        d.sample({13:False,26:True},.10)
        self.assertEqual(d.sample({13:False,26:True},.17)[0]['operation'],'add')
        self.assertEqual(d.sample({13:False,26:True},3),[])
        d.sample({13:True,26:True},4)
        d.sample({13:True,26:True},4.07)
        d.sample({13:False,26:True},5)
        self.assertEqual(len(d.sample({13:False,26:True},5.07)),1)

    def test_held_at_start_and_simultaneous_press_are_ignored(self):
        d=Debouncer()
        d.sample({13:False,26:True},0)
        self.assertEqual(d.sample({13:False,26:True},.1),[])
        d.sample({13:True,26:True},1)
        d.sample({13:True,26:True},1.1)
        d.sample({13:False,26:False},2)
        self.assertEqual(d.sample({13:False,26:False},2.1),[])
        self.assertEqual(d.sample({13:False,26:False},4),[])

    def test_button_and_tag_events_share_ordered_queue(self):
        reader=Reader()
        reader.emit({'type':'button','operation':'remove','pin':26})
        reader.emit({'uid':'AA','source':'right'})
        self.assertEqual([e['sequence'] for e in reader.since(0)],[1,2])
        self.assertEqual(reader.since(0)[0]['operation'],'remove')
        reader.close()

    def test_gpio_failure_is_reported_off_ui_thread(self):
        buttons=Buttons(Mock())
        with patch.dict('sys.modules',{'RPi':None}):
            buttons.configure(True)
            buttons.thread.join(1)
        self.assertIsNotNone(buttons.status()['error'])
        self.assertFalse(buttons.status()['connected'])
        buttons.close()

    def test_gpio_inputs_use_pullups_and_cleanup_only_owned_pins(self):
        from types import ModuleType
        import sys
        gpio=ModuleType('RPi.GPIO')
        gpio.BCM, gpio.IN, gpio.PUD_UP = 11, 1, 22
        gpio.setmode, gpio.setup, gpio.cleanup = Mock(), Mock(), Mock()
        gpio.input=Mock(return_value=1)
        parent=ModuleType('RPi'); parent.GPIO=gpio
        buttons=Buttons(Mock())
        buttons.stop=Mock()
        buttons.stop.wait.side_effect=[False,True]
        with patch.dict(sys.modules,{'RPi':parent,'RPi.GPIO':gpio}):buttons._run()
        self.assertEqual(gpio.setup.call_args_list[0].args,(13,gpio.IN))
        self.assertEqual(gpio.setup.call_args_list[0].kwargs,{'pull_up_down':gpio.PUD_UP})
        self.assertEqual(gpio.setup.call_args_list[1].args,(26,gpio.IN))
        gpio.cleanup.assert_called_once_with([13,26])

    def test_rc522_parameterized_spi_and_reset_cleanup(self):
        from types import ModuleType
        import sys
        from algebra_lab.rc522 import RC522
        gpio=ModuleType('RPi.GPIO')
        gpio.BCM, gpio.OUT, gpio.HIGH = 11, 0, 1
        gpio.setmode, gpio.setup, gpio.cleanup = Mock(), Mock(), Mock()
        parent=ModuleType('RPi');parent.GPIO=gpio
        spi=Mock();spi.xfer2.return_value=[0,0x92]
        spidev=ModuleType('spidev');spidev.SpiDev=Mock(return_value=spi)
        with patch.dict(sys.modules,{'RPi':parent,'RPi.GPIO':gpio,'spidev':spidev}), patch('algebra_lab.rc522.time.sleep'):
            driver=RC522(bus=1,device=0,rst=5)
            driver.close()
        spi.open.assert_called_once_with(1,0)
        gpio.setup.assert_called_once_with(5,gpio.OUT,initial=gpio.HIGH)
        gpio.cleanup.assert_called_once_with(5)


class SolutionTests(unittest.TestCase):
    def test_paired_hardware_steps_restore_and_final_proof_persist(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'progress.db'
            store=Store(path)
            reader=Reader()
            service,session=Service(store,reader),Session()
            store.bind('AA','1')
            service.start(session,{'task_id':'cups-3'}) # x+2=3
            service.begin_student(session)
            for _ in range(2):
                session.cup_operation='remove'
                service.scan_cup(session,{'uid':'AA','source':'right'})
                self.assertEqual(store.solutions(),[])
                service.scan_cup(session,{'uid':'AA','source':'left'})
            service.save_practice(session)
            restored=Session()
            self.assertTrue(service.restore_practice(restored))
            self.assertEqual(restored.history[1]['actions'][0]['side'],'right')
            self.assertFalse(service.student_answer(restored,2)['correct'])
            self.assertEqual(store.solutions(),[])
            self.assertTrue(service.student_answer(restored,1)['correct'])
            store.close()
            store=Store(path)
            rows=store.solutions()
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['data']['original'],'x + 2 = 3')
            self.assertEqual(len(rows[0]['data']['steps']),3)
            self.assertEqual(rows[0]['data']['check'],{'x':'1','left':'3','right':'3'})
            store.reset_progress()
            self.assertEqual(store.solutions(),[])
            self.assertEqual(store.tags(),{'AA':'1'})
            store.close();reader.close()

    def test_boot_probe_selects_actual_config_and_existing_overlay(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            (root/'boot/firmware/overlays').mkdir(parents=True)
            (root/'boot/firmware/config.txt').write_text('')
            self.assertIsNone(boot_info(root)['spi1_line'])
            (root/'boot/firmware/overlays/spi1-1cs.dtbo').write_bytes(b'overlay')
            self.assertEqual(boot_info(root)['spi1_line'],'dtoverlay=spi1-1cs')
            self.assertEqual(boot_info(root)['config'],str(root/'boot/firmware/config.txt'))
