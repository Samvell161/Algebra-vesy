import tempfile
import unittest
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtCore import QTimer
    from algebra_lab.qt_ui.route_map import RouteMap
    from algebra_lab.qt_ui.app import Window
    from algebra_lab.adventure import ADVENTURE_TASKS
except ImportError:
    QApplication=None

@unittest.skipUnless(QApplication,'Qt dependencies required')
class RouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def test_first_lesson_gate_replay_and_quiz_gate(self):
        dialog=RouteMap({},'cups-1');dialog.show();self.app.processEvents()
        try:
            self.assertTrue(dialog.trail.nodes['cups-1'].isEnabled())
            self.assertFalse(dialog.trail.nodes['cups-2'].isEnabled())
            self.assertFalse(dialog.tabs[1].isEnabled())
            dialog.choose_task('cups-2');self.assertIsNone(dialog.chosen_task)
            dialog.choose_quiz();self.assertIsNone(dialog.chosen_quiz)
        finally:dialog.close()
        best={t['id']:3 for t in ADVENTURE_TASKS[:6]}
        dialog=RouteMap(best,'cups-6');dialog.show();self.app.processEvents()
        try:
            self.assertTrue(dialog.tabs[1].isEnabled())
            self.assertTrue(dialog.quiz_button.isEnabled())
            dialog.trail.nodes['cups-1'].click();self.assertEqual(dialog.chosen_task,'cups-1')
        finally:dialog.close()
        dialog=RouteMap(best,'cups-6')
        try:
            dialog.quiz_button.click();self.assertEqual(dialog.chosen_quiz,'quiz-1')
        finally:dialog.close()

    def test_all_chapters_fit_and_cache_background_with_six_touch_stops(self):
        best={t['id']:3 for t in ADVENTURE_TASKS}
        dialog=RouteMap(best,'duet-1');dialog.show();self.app.processEvents()
        try:
            for chapter in range(4):
                dialog.select_chapter(chapter);self.app.processEvents()
                self.assertLessEqual(dialog.width(),1000);self.assertLessEqual(dialog.height(),560)
                self.assertEqual(len(dialog.trail.nodes),6)
                for button in dialog.trail.nodes.values():
                    self.assertGreaterEqual(button.width(),44);self.assertGreaterEqual(button.height(),44)
                    self.assertTrue(dialog.trail.rect().contains(button.geometry()))
                dialog.trail.grab();key=dialog.trail.cache.cacheKey();dialog.trail.grab()
                self.assertEqual(dialog.trail.cache.cacheKey(),key)
        finally:dialog.close()

    def test_route_click_starts_selected_task_in_real_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.record('unlock','cups-1','practice',1,0,1)
                def choose():
                    dialog=QApplication.activeModalWidget()
                    dialog.findChild(QPushButton,'route-cups-4').click()
                QTimer.singleShot(0,choose);w.map()
                self.assertEqual(w.session.task_id,'cups-4')
                self.assertTrue(w.session.cup_play)
                self.assertEqual(w.condition.text(),'x + 2 = 4')
            finally:w.close()
