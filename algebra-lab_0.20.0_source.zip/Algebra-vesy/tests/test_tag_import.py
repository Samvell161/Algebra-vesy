import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from algebra_lab.hardware import Reader
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store
from algebra_lab.tag_import import parse_tags, phone_uid, export_tags


class ImportFormatTests(unittest.TestCase):
    def test_four_byte_uid_matches_legacy_reader_with_bcc(self):
        for value in ['12:34:56:78', '12 34 56 78', '12345678', '0x12345678', '12-34-56-78']:
            self.assertEqual(phone_uid(value), '1234567808')
        self.assertEqual(phone_uid('00:00:00:01'), '101')

    def test_long_uid_is_not_appended_with_four_byte_bcc(self):
        self.assertEqual(phone_uid('04:01:02:03:04:05:06'), '4010203040506')
        self.assertEqual(phone_uid('00 01 02 03 04 05 06 07 08 09'), '10203040506070809')

    def test_wrong_lengths_text_and_non_hex_are_rejected(self):
        for value in ['AA', '1234567808', 'E0040123456789AB', 'текст', '12:34:56:GG', '']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                phone_uid(value)

    def test_phone_csv_and_json_have_same_result(self):
        expected = {'1234567808': '1', 'AABBCCDD00': '-x'}
        self.assertEqual(parse_tags('\ufeffUID;значение\n12:34:56:78;+1\nAA BB CC DD;−x'), expected)
        self.assertEqual(parse_tags(json.dumps({'tags': {'12345678': 1, 'AABBCCDD': '-x'}})), expected)
        self.assertEqual(parse_tags('[{"uid":"12345678","kind":"+1"},{"uid":"AABBCCDD","kind":"-x"}]'), expected)

    def test_existing_reader_identifiers_export_and_roundtrip_exactly(self):
        tags = {'AA:BB': 'x', '1234567808': '1', '101': '-1'}
        self.assertEqual(parse_tags(export_tags(tags)), tags)

    def test_conflicting_duplicate_phone_uid_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'разными значениями'):
            parse_tags('12:34:56:78;1\n12345678;x')
        self.assertEqual(parse_tags('12:34:56:78;1\n12345678;+1'), {'1234567808': '1'})

    def test_bad_documents_do_not_become_partial_lists(self):
        for value in ['', '{}', '[]', '12345678;1\nBAD;x', '{bad', '12345678;hello',
                      '{"format":"guess","tags":{"12345678":"1"}}', '[{"uid":"12345678"}]']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_tags(value)
        with self.assertRaises(ValueError):
            parse_tags('x' * (128 * 1024 + 1))


class ImportPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'tags.sqlite3')
        self.service, self.session = Service(self.store, Reader()), Session()
        self.store.bind('FF', 'x')
        self.store.record('old', 'first', 'practice', 1, 0, 30)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def test_import_preserves_other_tags_and_progress_and_is_ready_for_reader(self):
        self.service.import_tags(self.session, parse_tags('12345678;+1'))
        self.assertEqual(self.store.tags(), {'FF': 'x', '1234567808': '1'})
        self.service.start(self.session, {'task_id': 'cups-1'})
        self.service.scan_cup(self.session, {'uid': '1234567808'})
        self.assertEqual(self.session.cup_side, 'right')
        self.assertEqual(self.store.progress()['best']['first'], 3)
        reopened = Store(Path(self.temp.name) / 'tags.sqlite3')
        self.assertEqual(reopened.tags()['1234567808'], '1')
        reopened.close()

    def test_invalid_and_active_inventory_changes_do_not_partially_apply(self):
        self.service.scan(self.session, {'uid': 'FF', 'side': 'left'})
        with self.assertRaises(ValueError):
            self.service.import_tags(self.session, {'AA': '1', 'FF': '2'})
        self.assertEqual(self.store.tags(), {'FF': 'x'})
        with self.assertRaises(ValueError):
            self.service.import_tags(self.session, {'AA': '1', 'BB': 'unknown'})
        self.assertEqual(self.store.tags(), {'FF': 'x'})

    def test_database_failure_rolls_back_entire_import(self):
        self.store.db.executescript("CREATE TRIGGER fail_import BEFORE INSERT ON tags WHEN NEW.uid = 'BB' BEGIN SELECT RAISE(ABORT, 'test failure'); END;")
        with self.assertRaises(sqlite3.IntegrityError):
            self.service.import_tags(self.session, {'AA': '1', 'BB': '2'})
        self.assertEqual(self.store.tags(), {'FF': 'x'})
