"""Learners choose actions and sides; isolating x is not an automatic victory."""
import tempfile
import unittest
from pathlib import Path
from algebra_lab.hardware import Reader
from algebra_lab.math_engine import Linear
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store


class StudentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'student.sqlite3')
        self.service, self.session = Service(self.store, Reader()), Session()
        for uid, kind in [('AA', '1'), ('BB', '2'), ('CC', 'x')]:
            self.store.bind(uid, kind)
        self.start('cups-2')

    def start(self, task):
        self.service.start(self.session, {'task_id': task})
        self.service.begin_student(self.session)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def scan(self, uid='AA'):
        return self.service.scan_cup(self.session, {'uid': uid})

    def choose(self, operation, side):
        self.session.cup_operation, self.session.cup_side = operation, side

    def test_choices_are_required_and_other_side_is_not_auto_selected(self):
        with self.assertRaisesRegex(ValueError, 'действие'):
            self.scan()
        self.session.cup_operation = 'remove'
        with self.assertRaisesRegex(ValueError, 'чашу'):
            self.scan()
        self.session.cup_side = 'right'
        self.scan()
        self.assertIsNone(self.session.cup_side)
        self.assertFalse(self.session.completed)
        self.session.cup_side = 'left'
        self.scan()
        self.assertEqual(self.session.cup_phase, 'answer')
        self.assertFalse(self.session.completed)
        self.assertEqual(self.store.progress()['completed'], 0)

    def test_wrong_action_can_preserve_equality_without_being_a_solution(self):
        original = self.session.current.solution()
        self.choose('add', 'left')
        self.scan('BB')
        self.session.cup_side = 'right'
        self.scan('BB')
        self.assertEqual(self.session.current.solution(), original)
        self.assertEqual(str(self.session.current.left), 'x + 3')
        self.assertFalse(self.session.completed)
        self.assertIsNone(self.session.cup_operation)
        self.assertIsNone(self.session.cup_side)
        self.service.undo(self.session)
        self.assertEqual(str(self.session.current.left), 'x + 1')

    def test_plus_two_is_a_meaningful_operand_not_an_arbitrary_wrong_tag(self):
        self.start('cups-3')
        self.choose('remove', 'left')
        self.scan('BB')
        self.session.cup_side = 'right'
        self.scan('BB')
        self.assertEqual(str(self.session.current.left), 'x')
        self.assertEqual(str(self.session.current.right), '1')
        self.assertFalse(self.session.completed)
        self.scan('AA')
        self.assertTrue(self.session.completed)

    def test_nonexistent_blocks_are_explained_and_do_not_mutate(self):
        original = self.session.current
        self.choose('remove', 'left')
        with self.assertRaisesRegex(ValueError, 'нет столько'):
            self.scan('BB')
        self.assertEqual(self.session.current, original)
        self.assertFalse(self.service.cup_state(self.session)['pending'])

    def test_wrong_final_answer_does_not_award_xp_then_correct_tag_wins(self):
        self.choose('remove', 'left')
        self.scan()
        self.session.cup_side = 'right'
        self.scan()
        result = self.scan('AA')
        self.assertIn('отличаются', result['message'])
        self.assertFalse(self.session.completed)
        self.assertEqual(self.store.progress()['completed'], 0)
        self.scan('BB')
        self.assertTrue(self.session.completed)
        self.assertEqual(self.store.progress()['best']['cups-2'], 3)

    def test_x_tag_confirms_only_a_selected_answer(self):
        self.start('cups-1')
        self.scan()
        self.scan()
        with self.assertRaisesRegex(ValueError, 'Выбери ответ'):
            self.scan('CC')
        self.session.cup_guess = 1
        self.scan('CC')
        self.assertTrue(self.session.completed)

    def test_resume_isolated_equation_still_requires_child_answer(self):
        self.start('cups-1')
        self.scan()
        self.scan()
        self.service.save_practice(self.session)
        restored = Session()
        self.assertTrue(self.service.restore_practice(restored))
        self.assertTrue(restored.cup_play)
        self.assertEqual(restored.cup_phase, 'answer')
        self.assertFalse(restored.completed)
        self.assertEqual(restored.cup_delta, {'left': Linear(), 'right': Linear()})

    def test_hint_is_explicit_and_next_lesson_keeps_student_mode(self):
        self.start('cups-1')
        self.service.student_hint(self.session)
        self.scan()
        self.scan()
        self.scan()
        self.assertEqual(self.store.progress()['best']['cups-1'], 2)
        self.scan()
        self.assertEqual(self.session.task_id, 'cups-2')
        self.assertTrue(self.session.cup_play)
        self.assertIsNone(self.session.cup_operation)
        self.assertIsNone(self.session.cup_side)

    def test_every_starter_is_solved_with_real_choices_and_a_final_numeric_tag(self):
        from fractions import Fraction
        from algebra_lab.tasks import STARTER_TASKS
        for task in STARTER_TASKS:
            self.start(task['id'])
            original = self.session.current.solution()
            for _ in range(8):
                if self.session.current.isolated():
                    break
                value = 2 if abs(self.session.current.left.b) >= 2 and task['id'] != 'cups-1' else 1
                self.choose('remove' if self.session.current.left.b > 0 else 'add', 'left')
                uid = 'BB' if value == 2 else 'AA'
                self.scan(uid)
                if self.service.student_stage(self.session) != 'demo':
                    self.session.cup_side = 'right'
                self.scan(uid)
                self.assertEqual(self.session.current.solution(), original)
            self.assertTrue(self.session.current.isolated(), task['id'])
            self.assertFalse(self.session.completed)
            self.scan('AA' if Fraction(original['value']) == 1 else 'BB')
            self.assertTrue(self.session.completed)
        self.assertEqual(self.store.progress()['completed'], 6)
