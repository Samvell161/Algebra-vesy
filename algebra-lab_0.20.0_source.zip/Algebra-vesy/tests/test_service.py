import tempfile
import time
import unittest
from pathlib import Path

from algebra_lab.hardware import Reader, normalize_uid
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store
from algebra_lab.tasks import TASKS


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "test.sqlite3"
        self.store = Store(self.path)
        self.reader = Reader()
        self.service = Service(self.store, self.reader)
        self.session = Session()

    def tearDown(self):
        self.reader.close()
        self.store.close()
        self.temp.cleanup()

    def start(self, task_id="first", mode="practice"):
        return self.service.start(self.session, {"task_id": task_id, "mode": mode})

    def test_solution_records_once(self):
        self.start()
        result = self.service.transform(self.session, {"operation": "subtract", "value": "3"})
        self.assertTrue(result["completed"])
        self.service.complete(self.session)
        self.assertEqual(self.store.progress()["completed"], 1)
        self.assertEqual(len(self.store.progress()["attempts"]), 1)
        self.assertEqual(self.store.progress()["stars"], 3)

    def test_wrong_answer_does_not_complete(self):
        self.start()
        self.assertFalse(self.service.answer(self.session, {"answer": "3"})["correct"])
        self.assertFalse(self.session.completed)
        self.assertEqual(self.store.progress()["completed"], 0)

    def test_every_task_can_be_solved_with_exact_answer(self):
        for task in TASKS:
            self.start(task["id"])
            result = self.service.answer(self.session, {"answer": self.session.current.solution()["value"]})
            self.assertTrue(result["correct"], task["id"])
        self.assertEqual(self.store.progress()["completed"], len(TASKS))
        self.assertEqual(self.store.progress()["stars"], len(TASKS)*3)

    def test_hint_penalty_and_best_result(self):
        self.start()
        self.assertIn("3", self.service.hint(self.session)["text"])
        self.service.hint(self.session)
        self.service.answer(self.session, {"answer": "4"})
        self.assertEqual(self.store.progress()["stars"], 1)
        self.start()
        self.service.answer(self.session, {"answer": "4"})
        self.assertEqual(self.store.progress()["stars"], 3)
        self.assertEqual(len(self.store.progress()["attempts"]), 2)

    def test_undo_restores_equation(self):
        self.start("double")
        before = self.session.current
        self.service.transform(self.session, {"operation": "subtract", "value": "2"})
        self.service.undo(self.session)
        self.assertEqual(before, self.session.current)
        self.assertEqual(len(self.session.history), 1)

    def test_expired_challenge_rejects_answer_and_transform(self):
        self.start(mode="challenge")
        self.session.started = time.monotonic() - 181
        with self.assertRaises(ValueError):
            self.service.answer(self.session, {"answer": "4"})
        with self.assertRaises(ValueError):
            self.service.transform(self.session, {"operation": "subtract", "value": "3"})
        self.assertTrue(self.service.exercise(self.session)["expired"])
        self.assertEqual(self.store.progress()["completed"], 0)

    def test_practice_has_no_time_limit(self):
        self.start()
        self.session.started = time.monotonic() - 1000
        self.assertTrue(self.service.answer(self.session, {"answer": "4"})["correct"])

    def test_duplicate_scan_and_transfer_protocol(self):
        self.store.bind("A1:B2", "x")
        self.service.scan(self.session, {"uid": "a1:b2", "side": "left"})
        with self.assertRaises(ValueError):
            self.service.scan(self.session, {"uid": "A1:B2", "side": "right"})
        self.service.dispatch("/api/lab/remove", self.session, {"uid": "A1:B2"})
        self.service.scan(self.session, {"uid": "A1:B2", "side": "right"})
        self.assertEqual(self.service.lab(self.session)["equation"]["right"], "x")

    def test_unknown_tag_does_not_enter_inventory(self):
        with self.assertRaises(ValueError):
            self.service.scan(self.session, {"uid": "AABB", "side": "left"})
        self.assertEqual(self.session.blocks["left"], [])

    def test_cannot_change_type_of_registered_block(self):
        self.store.bind("AABB", "x")
        self.service.scan(self.session, {"uid": "AABB", "side": "left"})
        with self.assertRaises(ValueError):
            self.service.dispatch("/api/tags/bind", self.session, {"uid": "AABB", "kind": "5"})
        self.assertEqual(self.store.tags()["AABB"], "x")

    def test_simulator_and_substitution(self):
        for side, kind in [("left", "x"), ("left", "1"), ("right", "5")]:
            self.service.dispatch("/api/lab/simulate", self.session, {"side": side, "kind": kind})
        lab = self.service.dispatch("/api/lab/x", self.session, {"value": "4"})
        self.assertTrue(lab["balanced"])
        self.assertEqual(lab["left_value"], "5")
        self.assertEqual(lab["equation"]["solution"]["value"], "4")
        lab = self.service.dispatch("/api/lab/x", self.session, {"value": "2"})
        self.assertFalse(lab["balanced"])
        self.assertEqual(lab["tilt"], 1)

    def test_simulator_limit_is_enforced(self):
        for _ in range(40):
            self.service.dispatch("/api/lab/simulate", self.session, {"side": "left", "kind": "1"})
        with self.assertRaises(ValueError):
            self.service.dispatch("/api/lab/simulate", self.session, {"side": "right", "kind": "1"})

    def test_persistence_in_new_connection(self):
        self.start()
        self.service.answer(self.session, {"answer": "4"})
        self.store.save_settings({"name": "Саша", "motion": False})
        self.store.bind("ABCD", "x")
        other = Store(self.path)
        try:
            self.assertEqual(other.progress()["completed"], 1)
            self.assertEqual(other.settings()["name"], "Саша")
            self.assertFalse(other.settings()["motion"])
            self.assertEqual(other.tags(), {"ABCD": "x"})
        finally:
            other.close()

    def test_reset_retains_settings_and_tags(self):
        self.start()
        self.service.answer(self.session, {"answer": "4"})
        self.store.bind("ABCD", "x")
        self.store.save_settings({"name": "Саша"})
        with self.assertRaises(ValueError):
            self.service.dispatch("/api/progress/reset", self.session, {})
        self.service.dispatch("/api/progress/reset", self.session, {"confirm": "RESET"})
        self.assertEqual(self.store.progress()["completed"], 0)
        self.assertEqual(self.store.tags(), {"ABCD": "x"})
        self.assertEqual(self.store.settings()["name"], "Саша")

    def test_uid_validation(self):
        self.assertEqual(normalize_uid(" ab:cd "), "AB:CD")
        for uid in ["", "<script>", "A"*65, "hello", None]:
            with self.subTest(uid=uid), self.assertRaises(ValueError):
                normalize_uid(uid)
