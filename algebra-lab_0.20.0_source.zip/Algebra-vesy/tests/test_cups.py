"""One reader, explicitly selected side, and atomic equivalence after two scans."""
import tempfile
import unittest
from pathlib import Path
from algebra_lab.hardware import Reader
from algebra_lab.math_engine import Linear, equation
from algebra_lab.service import Session, Service
from algebra_lab.storage import Store
from algebra_lab.tasks import STARTER_TASKS


class CupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'test.sqlite3')
        self.service, self.session = Service(self.store, Reader()), Session()
        self.store.bind('AA', '1')
        self.store.bind('BB', 'x')
        self.service.start(self.session, {'task_id': 'cups-1'})

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def scan(self, **data):
        return self.service.scan_cup(self.session, {'uid': 'AA', **data})

    def test_first_scan_changes_only_left_preview_and_waits_for_right(self):
        original = self.session.current
        self.scan()
        preview = self.service.cup_state(self.session)['preview']
        self.assertEqual(str(preview.left), 'x')
        self.assertEqual(str(preview.right), '2')
        self.assertEqual(self.session.current, original)
        self.assertFalse(self.session.completed)
        self.assertEqual(self.session.cup_side, 'right')
        self.assertEqual(self.store.progress()['completed'], 0)
        self.scan()
        self.assertTrue(self.session.completed)
        self.assertEqual(self.session.current.solution(), original.solution())
        self.assertEqual(str(self.session.current.right), '1')
        self.assertEqual(len(self.session.history), 2)

    def test_right_first_is_supported_and_then_left(self):
        self.scan(side='right')
        self.assertEqual(str(self.service.cup_state(self.session)['preview'].left), 'x + 1')
        self.assertEqual(self.session.cup_side, 'left')
        self.scan()
        self.assertTrue(self.session.completed)

    def test_same_side_cannot_be_changed_twice_in_a_pair(self):
        self.scan(side='left')
        with self.assertRaises(ValueError):
            self.scan(side='left')
        self.assertEqual(self.session.cup_side, 'right')
        self.assertEqual(str(self.session.cup_delta['left']), '−1')
        self.scan()
        self.assertTrue(self.session.completed)

    def test_wrong_tag_and_wrong_action_are_explained_without_mutation(self):
        original = self.session.current
        for data in [{'uid': 'BB'}, {'operation': 'add'}]:
            with self.assertRaisesRegex(ValueError, 'убрать'):
                self.scan(**data)
            self.assertEqual(self.session.current, original)
            self.assertFalse(self.service.cup_state(self.session)['pending'])

    def test_all_six_starters_work_with_same_unit_tag_and_progression(self):
        for task in STARTER_TASKS:
            self.service.start(self.session, {'task_id': task['id']})
            solution = equation(task['equation']).solution()
            scans = 0
            while not self.session.completed and scans < 8:
                self.scan()
                scans += 1
            self.assertTrue(self.session.completed, task['id'])
            self.assertEqual(self.session.current.solution(), solution)
            self.assertEqual(scans % 2, 0)
            self.assertEqual(len(self.session.history) - 1, scans // 2)
        self.assertEqual(self.store.progress()['completed'], 6)

    def test_pending_half_step_is_not_restored_as_a_completed_transform(self):
        self.scan()
        self.service.save_practice(self.session)
        restored = Session()
        self.assertTrue(self.service.restore_practice(restored))
        self.assertEqual(restored.task_id, 'cups-1')
        self.assertEqual(str(restored.current.left), 'x + 1')
        self.assertEqual(restored.cup_delta, {'left': Linear(), 'right': Linear()})

    def test_matching_magnitude_required_on_the_other_side(self):
        self.service.start(self.session, {'task_id': 'first'})
        self.store.bind('CC', '2')
        self.scan()
        with self.assertRaisesRegex(ValueError, 'то же действие'):
            self.scan(uid='CC')
        self.assertEqual(self.session.cup_delta['right'], Linear())
