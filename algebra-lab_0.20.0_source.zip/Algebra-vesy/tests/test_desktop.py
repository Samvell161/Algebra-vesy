"""Native GUI integration tests. Run with DISPLAY set to a desktop or Xvfb."""
import ast
import gc
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    import tkinter as tk
except ImportError:
    tk = None


@unittest.skipUnless(tk and os.environ.get("DISPLAY"), "Native GUI requires Tk and a graphical display")
class DesktopTests(unittest.TestCase):
    def setUp(self):
        from algebra_lab.desktop import Desktop
        from algebra_lab.hardware import Reader
        from algebra_lab.storage import Store
        self.temp = tempfile.TemporaryDirectory()
        self.root = tk.Tk()
        store = Store(Path(self.temp.name) / "test.sqlite3")
        store.save_settings({"simple_ui": False})
        self.app = Desktop(self.root, store, Reader())
        self.root.update()

    def tearDown(self):
        errors = list(self.app.errors)
        self.app.close()
        self.app = None
        self.root = None
        gc.collect()
        self.temp.cleanup()
        self.assertEqual(errors, [])

    def click(self, key):
        self.app.controls[key].invoke()
        self.root.update()

    def test_exercise_and_progress(self):
        self.click("start")
        self.app.operand.set("3")
        self.click("transform")
        self.assertTrue(self.app.session.completed)
        self.assertEqual(self.app.store.progress()["stars"], 3)
        self.click("next")
        self.click("hint")
        self.app.answer.set("9")
        self.click("check-answer")
        self.assertEqual(self.app.store.progress()["completed"], 2)
        self.assertEqual(self.app.store.progress()["stars"], 5)
        self.app.navigate("progress")
        self.root.update()

    def test_invalid_operation_preserves_equation(self):
        self.app.start("first")
        self.app.operation.set("divide")
        self.app.operand.set("0")
        self.click("transform")
        self.assertIn("ноль", self.app.status.get().lower())
        self.assertEqual(str(self.app.session.current.left), "x + 3")

    def test_undo_and_history(self):
        self.app.start("double")
        self.app.operand.set("2")
        self.click("transform")
        self.click("undo")
        self.assertEqual(str(self.app.session.current.left), "3x + 2")
        self.click("history")
        self.assertTrue(self.app.dialog.winfo_exists())

    def test_expired_challenge(self):
        self.app.start("first", "challenge")
        self.app.session.started = time.monotonic() - 181
        self.app.render()
        self.root.update()
        self.assertTrue(self.app.controls["transform"].instate(["disabled"]))
        self.click("untimed")
        self.assertEqual(self.app.session.mode, "practice")

    def test_laboratory_and_substitution(self):
        self.app.navigate("lab")
        self.click("block-x")
        self.click("block-1")
        self.click("side-right")
        self.click("block-5")
        self.app.x_value.set("4")
        self.click("substitute")
        self.assertTrue(self.app.service.lab(self.app.session)["balanced"])
        uid = self.app.session.blocks["left"][0]["uid"]
        self.click("remove-" + uid)
        self.assertEqual(len(self.app.session.blocks["left"]), 1)
        self.click("clear-lab")
        self.assertEqual(self.app.session.blocks, {"left": [], "right": []})

    def test_custom_equation_and_keypad(self):
        self.app.navigate("lab")
        self.app.custom.set("x+1=x+2")
        self.click("check-custom")
        self.assertIn("решений нет", self.app.status.get())
        self.app.dialog.destroy()
        self.click("keys-lab-x")
        self.click("key-clear")
        self.click("key-4")
        self.click("key-accept")
        self.assertEqual(self.app.x_value.get(), "4")
        self.click("substitute")
        self.assertEqual(str(self.app.session.x), "4")

    def test_settings_tags_and_progress_reset(self):
        self.app.settings()
        self.app.controls["name"].delete(0, "end")
        self.app.controls["name"].insert(0, "Саша")
        self.click("save-settings")
        self.assertEqual(self.app.store.settings()["name"], "Саша")
        self.app.tags()
        self.click("manual-tag")
        self.app.controls["tag-uid"].insert(0, "AA:BB")
        self.click("tag-kind-x")
        self.click("bind-tag")
        self.assertEqual(self.app.store.tags()["AA:BB"], "x")
        self.click("tag-list")
        self.click("unbind-AA:BB")
        self.assertEqual(self.app.store.tags(), {})
        self.app.dialog.destroy()
        self.app.start("first")
        self.app.answer.set("4")
        self.click("check-answer")
        self.app.settings()
        with patch("algebra_lab.desktop.messagebox.askyesno", return_value=True):
            self.click("reset-progress")
        self.assertEqual(self.app.store.progress()["completed"], 0)

    def test_all_pages_fit_target_width(self):
        self.app.start("both")
        for width, height in [(1024, 600), (1280, 720)]:
            self.root.geometry(f"{width}x{height}")
            for page in ["home", "practice", "exercise", "lab", "progress"]:
                self.app.navigate(page)
                self.root.update()
                with self.subTest(page=page, width=width):
                    self.assertLessEqual(self.app.body.winfo_reqwidth(), self.app.area.canvas.winfo_width())

    def test_core_touch_controls_fit_lcd_without_scrolling(self):
        self.root.geometry("1024x600")
        self.app.start("first")
        self.root.update()
        bottom = self.app.area.canvas.winfo_rooty() + self.app.area.canvas.winfo_height()
        for key in ["transform", "hint", "answer", "check-answer"]:
            control = self.app.controls[key]
            self.assertLessEqual(control.winfo_rooty() + control.winfo_height(), bottom, key)
        self.app.navigate("lab")
        for key in ["block-x", "block-1", "side-right", "block-5"]:
            self.click(key)
        self.root.update()
        for key in ["substitute", "lab-x", "clear-lab"]:
            control = self.app.controls[key]
            self.assertLessEqual(control.winfo_rooty() + control.winfo_height(), bottom, key)

    def test_chapters_lessons_and_daily_mission(self):
        self.click("chapter-4")
        self.assertEqual(self.app.level, 4)
        self.assertEqual(len([key for key in self.app.controls if key.startswith("task-")]), 6)
        self.click("lesson")
        self.click("lesson-try")
        self.assertEqual(self.app.service.exercise(self.app.session)["task"]["level"], 4)
        self.app.navigate("home")
        self.click("daily")
        from algebra_lab.learning import daily_task
        self.assertEqual(self.app.session.task_id, daily_task()["id"])

    def test_progress_export_and_cancel(self):
        self.app.start("first")
        self.app.answer.set("4")
        self.click("check-answer")
        self.app.navigate("progress")
        target = Path(self.temp.name) / "export.csv"
        with patch("algebra_lab.desktop.filedialog.asksaveasfilename", return_value=str(target)):
            self.click("export")
        self.assertIn("Первое равновесие", target.read_text(encoding="utf-8-sig"))
        before = target.read_bytes()
        with patch("algebra_lab.desktop.filedialog.asksaveasfilename", return_value=""):
            self.click("export")
        self.assertEqual(before, target.read_bytes())

    def test_home_resume_button_keeps_current_exercise(self):
        self.app.start("double")
        self.app.operand.set("2")
        self.click("transform")
        self.app.navigate("home")
        self.click("start")
        self.assertEqual(self.app.session.task_id, "double")
        self.assertEqual(str(self.app.session.current.left), "3x")

    def test_desktop_restart_restores_practice_and_keeps_legacy_results(self):
        self.app.store.record("legacy", "first", "practice", 1, 0, 20)
        self.app.start("double")
        self.app.operand.set("2")
        self.click("transform")
        self.click("hint")
        self.app.close()
        self.app = None
        self.root = None
        gc.collect()
        from algebra_lab.desktop import Desktop
        from algebra_lab.hardware import Reader
        from algebra_lab.storage import Store
        self.root = tk.Tk()
        self.app = Desktop(self.root, Store(Path(self.temp.name) / "test.sqlite3"), Reader())
        self.root.update()
        self.click("start")
        self.assertEqual(str(self.app.session.current.left), "3x")
        self.assertEqual(self.app.session.hints, 1)
        self.assertEqual(self.app.store.progress()["best"]["first"], 3)

    def test_tag_capture_freezes_uid_and_persists_assignment(self):
        self.app.tags()
        self.assertTrue(self.app.controls["bind-tag"].instate(["disabled"]))
        def connect(mode):
            self.app.reader.mode = mode
            self.app.reader.error = None
            self.app.reader.driver = object()
        with patch.object(self.app.reader, "configure", side_effect=connect):
            self.click("read-tag")
        self.assertEqual(self.app.store.settings()["reader_mode"], "rc522")
        self.app.receive_tag("AA:BB")
        self.app.receive_tag("CC:DD")
        self.assertEqual(self.app.tag_uid.get(), "AA:BB")
        self.click("tag-kind--2")
        self.click("bind-tag")
        self.assertIn("Сохранено", self.app.tag_message.get())
        self.assertEqual(self.app.store.tags(), {"AA:BB": "-2"})
        from algebra_lab.storage import Store
        reopened = Store(Path(self.temp.name) / "test.sqlite3")
        self.assertEqual(reopened.tags(), {"AA:BB": "-2"})
        reopened.close()
        self.click("tag-list")
        self.click("edit-AA:BB")
        self.click("tag-kind-2")
        self.click("bind-tag")
        self.assertEqual(self.app.store.tags()["AA:BB"], "2")
        self.app.reader.driver = None

    def test_binding_error_visible_inside_dialog_and_old_mapping_kept(self):
        self.app.store.bind("AA", "x")
        self.app.service.scan(self.app.session, {"uid": "AA", "side": "left"})
        self.app.tags("AA")
        self.click("tag-kind-1")
        self.click("bind-tag")
        self.assertIn("Не сохранено", self.app.tag_message.get())
        self.assertIn("удалите блок", self.app.tag_message.get())
        self.assertEqual(self.app.store.tags()["AA"], "x")

    def test_connection_error_and_wizard_buttons_fit_screen(self):
        self.app.tags()
        self.app.reader.error = "Нужны системные библиотеки. В терминале: sudo apt install python3-spidev python3-rpi.gpio"
        self.app.update_tag_connection()
        self.root.update()
        self.assertIn("sudo apt", self.app.tag_connection.get())
        for key in ["read-tag", "bind-tag", "manual-tag", "tag-kind--2", "close-dialog"]:
            widget = self.app.controls[key]
            self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), self.app.dialog.winfo_rooty() + self.app.dialog.winfo_height(), key)
        self.app.reader.error = None

    def test_unknown_lab_tag_opens_assignment_without_adding_block(self):
        self.app.navigate("lab")
        self.app.reader.mode = "rc522"
        self.app.reader.sequence = 1
        self.app.reader.events.append({"sequence": 1, "uid": "AA"})
        self.root.after_cancel(self.app.timer_id)
        self.app.tick()
        self.root.update()
        self.assertEqual(self.app.tag_uid.get(), "AA")
        self.assertEqual(self.app.session.blocks, {"left": [], "right": []})
        self.click("tag-kind-1")
        self.click("bind-tag")
        self.assertEqual(self.app.store.tags()["AA"], "1")


    def test_main_physical_entry_enables_reader_and_discards_old_events(self):
        def connect(mode):
            self.app.reader.mode = mode
            self.app.reader.error = "SPI недоступен"
        self.app.reader.sequence = 1
        self.app.reader.events.append({"sequence": 1, "uid": "AA"})
        with patch.object(self.app.reader, "configure", side_effect=connect):
            self.click("physical-start")
        self.assertEqual(self.app.store.settings()["reader_mode"], "rc522")
        self.assertEqual(self.app.page, "exercise")
        self.assertEqual(self.app.event_sequence, 1)
        self.assertIn("Считыватель не подключён", self.app.physical_status.get())
        self.assertFalse(self.app.session.completed)
        self.app.reader.error = None

    def physical_event(self, uid):
        self.app.reader.sequence += 1
        self.app.reader.events.append({"sequence": self.app.reader.sequence, "uid": uid})
        self.root.after_cancel(self.app.timer_id)
        self.app.tick()
        self.root.update()

    def test_physical_event_opens_task_then_solves_it_without_answer_fields(self):
        self.app.reader.mode = "rc522"
        self.app.store.bind("AA", "1")
        self.physical_event("AA")
        self.assertEqual(self.app.page, "exercise")
        self.assertEqual(self.app.session.task_id, "cups-1")
        self.assertFalse(self.app.session.completed)
        self.assertNotIn("answer", self.app.controls)
        self.assertNotIn("transform", self.app.controls)
        self.physical_event("AA")
        self.assertFalse(self.app.session.completed)
        self.assertEqual(self.app.session.cup_side, "right")
        self.physical_event("AA")
        self.assertTrue(self.app.session.completed)
        self.assertIn("Решение получено", self.app.feedback)
        self.physical_event("AA")
        self.assertEqual(self.app.session.task_id, "cups-2")

    def test_independent_rfid_actions_and_feedback_in_exercise(self):
        self.app.reader.mode = "rc522"
        self.app.start("first")
        self.click("rfid-independent")
        self.app.store.bind("AA", "1")
        self.app.store.bind("BB", "apply")
        for uid in ['AA', 'AA', 'AA']:
            self.physical_event(uid)
        self.assertIn("Набрано: 3", self.app.feedback)
        self.physical_event("BB")
        self.assertTrue(self.app.session.completed)
        self.assertEqual(self.app.rfid_style(), "independent")
        self.assertEqual(self.app.store.settings()["rfid_style"], "independent")

    def test_command_binding_and_physical_controls_fit_lcd(self):
        self.app.tags("AA")
        self.click("tag-commands")
        self.click("tag-kind-apply")
        self.click("bind-tag")
        self.assertEqual(self.app.store.tags()["AA"], "apply")
        bottom = self.app.dialog.winfo_rooty() + self.app.dialog.winfo_height()
        for key in ['tag-kind-guide', 'bind-tag']:
            widget = self.app.controls[key]
            self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), bottom, key)
        self.app.dialog.destroy()
        self.app.reader.mode = "rc522"
        self.app.start("double")
        self.root.update()
        self.assertLessEqual(self.app.body.winfo_reqwidth(), self.app.area.canvas.winfo_width())
        bottom = self.app.area.canvas.winfo_rooty() + self.app.area.canvas.winfo_height()
        for key in ['rfid-guided', 'rfid-independent', 'exercise-tags', 'history']:
            widget = self.app.controls[key]
            self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), bottom, key)


    def test_cup_screen_side_selection_undo_and_diagnostics(self):
        self.app.reader.mode = "rc522"
        self.app.store.save_settings({"rfid_style": "cups"})
        self.app.store.bind("AA", "1")
        self.app.start("cups-1")
        self.click("cup-right")
        self.physical_event("AA")
        self.assertEqual(self.app.session.cup_side, "left")
        self.assertTrue(self.app.service.cup_state(self.app.session)["pending"])
        self.click("cup-undo")
        self.assertFalse(self.app.service.cup_state(self.app.session)["pending"])
        self.app.reader.last_error = "ProtocolErr ErrorReg=0x01"
        self.click("reader-details")
        self.assertTrue(self.app.dialog.winfo_exists())
        self.assertIn("0x01", self.app.reader.status()["last_error"])

    def test_cup_controls_fit_target_display_before_and_after_scan(self):
        self.app.reader.mode = "rc522"
        self.app.store.save_settings({"rfid_style": "cups"})
        self.app.store.bind("AA", "1")
        self.app.start("cups-3")
        self.physical_event("AA")
        self.assertLessEqual(self.app.body.winfo_reqwidth(), self.app.area.canvas.winfo_width())
        bottom = self.app.area.canvas.winfo_rooty() + self.app.area.canvas.winfo_height()
        for key in ['cup-left', 'cup-right', 'cup-op-add', 'cup-undo', 'cup-unit', 'reader-details']:
            widget = self.app.controls[key]
            self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), bottom, key)

    def test_wrong_tag_can_be_reassigned_to_unit_with_explicit_save(self):
        self.app.reader.mode = "rc522"
        self.app.store.save_settings({"rfid_style": "cups"})
        self.app.store.bind("AA", "x")
        self.app.start("cups-1")
        self.physical_event("AA")
        self.assertIn("нужно убрать +1", self.app.feedback)
        self.assertFalse(self.app.service.cup_state(self.app.session)["pending"])
        self.click("cup-unit")
        self.assertEqual(self.app.store.tags()['AA'], 'x')
        self.click("bind-tag")
        self.assertEqual(self.app.store.tags()['AA'], '1')


    def test_simple_child_home_and_cups_hide_adult_controls(self):
        self.app.store.save_settings({"simple_ui": True})
        self.app.navigate("home")
        self.root.update()
        self.assertNotIn("daily", self.app.controls)
        self.assertNotIn("chapter-1", self.app.controls)
        self.assertFalse(self.app.navigation["progress"].winfo_ismapped())
        self.assertFalse(self.app.navigation["lab"].winfo_ismapped())
        self.app.reader.mode = "rc522"
        self.app.store.bind("AA", "1")
        self.app.start("cups-1")
        for key in ['cup-unit', 'reader-details', 'exercise-tags']:
            self.assertNotIn(key, self.app.controls)
        self.physical_event('AA')
        self.physical_event('AA')
        self.assertFalse(self.app.session.completed)
        self.physical_event('AA')
        self.assertTrue(self.app.session.completed)
        self.click('adult')
        self.assertIn('manage-tags', self.app.controls)

    def test_phone_uid_can_be_added_without_any_rc522_event(self):
        self.app.phone_tag()
        self.app.controls['phone-uid'].insert(0, '12:34:56:78')
        self.click('phone-kind-1')
        self.click('save-phone-tag')
        self.assertEqual(self.app.store.tags()['1234567808'], '1')
        self.assertIn('Сохранено', self.app.import_notice.get())

    def test_tag_file_preview_cancel_confirm_and_export(self):
        path = Path(self.temp.name) / 'tags.csv'
        path.write_text('12345678;+1', encoding='utf-8')
        self.app.tag_manager()
        with patch('algebra_lab.desktop.filedialog.askopenfilename', return_value=str(path)):
            self.click('import-tags')
        self.assertEqual(self.app.store.tags(), {})
        self.app.dialog.destroy()
        self.app.tag_manager()
        with patch('algebra_lab.desktop.filedialog.askopenfilename', return_value=str(path)):
            self.click('import-tags')
        self.click('confirm-tag-import')
        self.assertEqual(self.app.store.tags()['1234567808'], '1')
        target = Path(self.temp.name) / 'backup.json'
        with patch('algebra_lab.desktop.filedialog.asksaveasfilename', return_value=str(target)):
            self.click('export-tags')
        from algebra_lab.tag_import import parse_tags
        self.assertEqual(parse_tags(target.read_text()), self.app.store.tags())

    def test_unknown_child_tag_does_not_open_adult_binding(self):
        self.app.store.save_settings({'simple_ui': True})
        self.app.reader.mode = 'rc522'
        self.app.start('cups-1')
        self.physical_event('AA')
        self.assertIn('ещё не подготовлена', self.app.feedback)
        self.assertFalse(self.app.tag_window_open())
        self.assertFalse(self.app.service.cup_state(self.app.session)['pending'])

    def test_adult_setting_can_restore_full_interface(self):
        self.app.store.save_settings({'simple_ui': True})
        self.app.navigate('home')
        self.app.full_settings()
        self.click('simple-ui')
        self.click('save-settings')
        self.root.update()
        self.assertTrue(self.app.navigation['practice'].winfo_ismapped())
        self.assertIn('chapter-1', self.app.controls)


    def test_existing_profile_without_ui_setting_gets_simple_default(self):
        with self.app.store.db:
            self.app.store.db.execute("DELETE FROM settings WHERE key='simple_ui'")
        self.app.navigate('home')
        self.root.update()
        self.assertTrue(self.app.simple_ui())
        self.assertNotIn('daily', self.app.controls)
        self.assertFalse(self.app.navigation['practice'].winfo_ismapped())
        self.app.phone_tag()
        self.app.controls['phone-uid'].insert(0, '12:34:56:78')
        self.root.update()
        button = self.app.controls['save-phone-tag']
        self.assertLessEqual(button.winfo_rooty() + button.winfo_height(), self.app.dialog.winfo_rooty() + self.app.dialog.winfo_height())


    def test_game_map_unlocks_sequentially_and_stats_use_saved_results(self):
        self.app.store.save_settings({'simple_ui': True})
        self.app.navigate('home')
        self.click('lesson-map')
        self.assertFalse(self.app.controls['map-cups-1'].instate(['disabled']))
        self.assertTrue(self.app.controls['map-cups-2'].instate(['disabled']))
        self.app.dialog.destroy()
        self.app.store.record('one', 'cups-1', 'practice', 1, 0, 15)
        self.app.lesson_map()
        self.root.update()
        self.assertFalse(self.app.controls['map-cups-2'].instate(['disabled']))
        self.app.dialog.destroy()
        self.app.child_statistics()
        self.root.update()
        self.assertTrue(self.app.dialog.winfo_exists())

    def test_rfid_balance_moves_then_levels_and_awards_only_new_xp(self):
        self.app.store.save_settings({'simple_ui': True, 'rfid_style': 'cups', 'motion': False})
        self.app.reader.mode = 'rc522'
        self.app.store.bind('AA', '1')
        self.app.start('cups-1')
        self.physical_event('AA')
        self.assertGreater(self.app.balance_widget.angle, 0)
        self.physical_event('AA')
        self.assertEqual(self.app.balance_widget.angle, 0)
        self.assertFalse(self.app.session.completed)
        self.physical_event('AA')
        self.assertIn('+30 XP', self.app.clock.cget('text'))
        self.root.after_cancel(self.app.timer_id)
        self.app.tick()
        self.assertIn('+30 XP', self.app.clock.cget('text'))
        self.app.start('cups-1')
        self.physical_event('AA')
        self.physical_event('AA')
        self.physical_event('AA')
        self.assertIn('повтор', self.app.clock.cget('text').lower())
        from algebra_lab.learning import game_progress
        self.assertEqual(game_progress(self.app.store.progress())['xp'], 30)


    def test_student_choices_answer_and_expanded_layout_fit_lcd(self):
        self.app.store.save_settings({'simple_ui': True, 'rfid_style': 'cups', 'motion': False})
        self.app.reader.mode = 'rc522'
        self.app.store.bind('AA', '1')
        self.app.store.bind('BB', '2')
        self.app.start('cups-2')
        def fit(keys):
            self.root.update()
            bottom = self.app.area.canvas.winfo_rooty() + self.app.area.canvas.winfo_height()
            self.assertLessEqual(self.app.body.winfo_reqwidth(), self.app.area.canvas.winfo_width())
            for key in keys:
                widget = self.app.controls[key]
                self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), bottom, key)
            self.assertGreaterEqual(self.app.balance_widget.winfo_height(), 210)
        fit(['cup-op-add', 'cup-op-remove', 'cup-left', 'cup-right', 'student-hint'])
        self.physical_event('AA')
        self.assertIn('Сначала выбери действие', self.app.feedback)
        self.click('cup-op-remove')
        self.click('cup-right')
        self.physical_event('AA')
        self.assertIsNone(self.app.session.cup_side)
        fit(['cup-left', 'cup-right', 'student-hint', 'cup-undo'])
        self.click('cup-left')
        self.physical_event('AA')
        self.assertFalse(self.app.session.completed)
        fit(['student-answer-1', 'student-answer-5', 'student-check'])
        self.physical_event('AA')
        self.assertFalse(self.app.session.completed)
        self.physical_event('BB')
        self.assertTrue(self.app.session.completed)
        fit(['student-next', 'student-map'])


    def test_new_lesson_starts_balanced_even_after_a_tilted_preview(self):
        self.app.store.save_settings({'simple_ui': True, 'rfid_style': 'cups', 'motion': False})
        self.app.reader.mode = 'rc522'
        self.app.store.bind('AA', '1')
        self.app.start('cups-1')
        self.physical_event('AA')
        self.assertGreater(self.app.balance_widget.angle, 0)
        self.app.store.save_settings({'motion': True})
        self.app.start('cups-3')
        self.root.update()
        self.assertEqual(self.app.balance_widget.angle, 0)
        self.assertIsNone(self.app.balance_widget.timer)


    def unlock_adventure_land(self, count):
        from algebra_lab.adventure import ADVENTURE_TASKS
        for task in ADVENTURE_TASKS[:count*6]:
            self.app.store.record('unlock-'+task['id'],task['id'],'practice',1,0,1)

    def test_new_adventure_map_changes_chapter_and_keeps_only_six_level_widgets(self):
        self.app.store.save_settings({'simple_ui': True})
        self.unlock_adventure_land(1)
        self.app.lesson_map(1)
        self.root.update()
        self.assertTrue(self.app.controls['map-trail-6'].winfo_exists())
        self.assertFalse(self.app.controls['map-trail-6'].instate(['disabled']))
        self.assertTrue(self.app.controls['land-3'].instate(['disabled']))
        self.app.dialog.destroy()
        self.app.lesson_map(0)
        self.root.update()
        self.assertFalse(self.app.controls['quiz-quiz-1'].instate(['disabled']))

    def test_touch_quiz_feedback_navigation_and_rfid_is_ignored(self):
        from algebra_lab.adventure import QUIZZES
        self.app.store.save_settings({'simple_ui': True})
        self.unlock_adventure_land(1)
        self.app.reader.mode='rc522'
        self.app.start('cups-2')
        original=self.app.session.current
        self.app.open_quiz('quiz-1')
        self.root.update()
        self.physical_event('AA')
        self.assertEqual(self.app.page,'quiz')
        self.assertEqual(self.app.session.current,original)
        self.click('quiz-choice-1')
        self.assertFalse(self.app.quiz_state['answered'])
        self.assertIn('Попробуй',self.app.quiz_state['feedback'])
        for question in QUIZZES[0]['questions']:
            self.click('quiz-choice-'+str(question[2]))
            self.assertTrue(self.app.quiz_state['answered'])
            bottom=self.app.area.canvas.winfo_rooty()+self.app.area.canvas.winfo_height()
            next_button=self.app.controls['quiz-next']
            self.assertLessEqual(next_button.winfo_rooty()+next_button.winfo_height(),bottom)
            self.click('quiz-next')
        self.assertTrue(self.app.quiz_state['completed'])
        self.assertIn('quiz-1',self.app.store.progress()['best'])

    def test_large_answer_and_x_removal_are_available_in_child_adventure(self):
        self.app.store.save_settings({'simple_ui': True,'rfid_style':'cups','motion':False})
        self.app.reader.mode='rc522'
        self.app.store.bind('CC','x')
        self.app.start('duet-1')
        self.click('cup-op-remove')
        self.click('cup-left')
        self.physical_event('CC')
        self.click('cup-right')
        self.physical_event('CC')
        self.assertEqual(str(self.app.session.current.left),'x + 1')
        self.app.start('trail-6')
        self.app.session.current=self.app.session.current.transform('add','4')
        self.app.session.cup_phase='answer'
        self.app.render()
        self.root.update()
        self.assertIn('student-answer-6',self.app.controls)
        self.click('student-answer-6')
        self.click('student-check')
        self.assertTrue(self.app.session.completed)



    def test_dual_reader_events_buttons_and_solution_history_survive_restart(self):
        self.app.store.save_settings({'simple_ui':True,'rfid_style':'cups'})
        for uid,kind in [('AA','2'),('BB','x')]: self.app.store.bind(uid,kind)
        self.app.start('cups-4') # x+2=4
        self.app.reader.mode='rc522_dual' # Inject real input events without GPIO on CI.
        self.app.render()
        self.app.reader.emit({'type':'button','operation':'remove','pin':26})
        self.app.reader.emit({'uid':'AA','source':'right'})
        self.app.reader.emit({'uid':'AA','source':'left'})
        self.app.tick();self.root.update()
        self.assertEqual(self.app.session.cup_phase,'answer')
        self.assertFalse(self.app.session.completed)
        self.click('student-answer-2')
        self.app.reader.emit({'uid':'BB','source':'left'})
        self.app.tick();self.root.update()
        self.assertTrue(self.app.session.completed)
        self.assertEqual(len(self.app.store.solutions()),1)
        self.click('history')
        self.assertTrue(self.app.dialog.winfo_exists())
        self.app.dialog.destroy()
        self.app.adult_menu();self.root.update()
        self.click('adult-solutions')
        self.click('saved-solution-0')
        self.assertTrue(self.app.dialog.winfo_exists())
        self.assertLessEqual(self.app.dialog.winfo_height(),600)

    def test_gpio_events_cannot_change_pending_pair_or_act_in_quiz_and_adult_dialog(self):
        from algebra_lab.adventure import ADVENTURE_TASKS
        self.app.store.save_settings({'simple_ui':True,'rfid_style':'cups'})
        self.app.store.bind('AA','1')
        self.app.start('cups-3')
        self.app.reader.mode='rc522_dual'
        self.app.reader.emit({'type':'button','operation':'remove','pin':26})
        self.app.reader.emit({'uid':'AA','source':'left'})
        self.app.reader.emit({'type':'button','operation':'add','pin':13})
        self.app.tick();self.root.update()
        self.assertEqual(self.app.session.cup_operation,'remove')
        self.assertIn('второй чаше',self.app.feedback)
        self.app.adult_menu()
        self.app.reader.emit({'type':'button','operation':'add','pin':13})
        self.app.reader.emit({'uid':'AA','source':'right'})
        self.app.tick();self.root.update()
        self.assertEqual(len(self.app.session.history),1)
        self.app.dialog.destroy()
        for task in ADVENTURE_TASKS[:6]:self.app.store.record(task['id'],task['id'],'practice',1,0,1)
        self.app.open_quiz('quiz-1')
        self.app.reader.emit({'type':'button','operation':'add','pin':13})
        self.app.reader.emit({'uid':'AA','source':'right'})
        self.app.tick();self.root.update()
        self.assertEqual(self.app.session.cup_operation,'remove')
        self.assertEqual(len(self.app.session.history),1)

    def test_hardware_settings_toggle_dual_readers_and_buttons(self):
        self.app.reader_details();self.root.update()
        self.click('dual-readers')
        self.click('gpio-buttons')
        with patch.object(self.app.reader,'configure') as configure, patch.object(self.app.buttons,'configure') as buttons:
            self.click('save-hardware')
        configure.assert_called_once_with('rc522_dual')
        buttons.assert_called_once_with(True)
        self.assertEqual(self.app.store.settings()['reader_mode'],'rc522_dual')
        self.assertTrue(self.app.store.settings()['buttons_enabled'])

    def test_return_button_saves_confirmed_steps_and_closes_resources(self):
        from algebra_lab.storage import Store
        self.app.start('cups-4')
        self.app.service.begin_student(self.app.session)
        self.app.service.transform(self.app.session, {'operation':'add','value':'-1'})
        self.app.render();self.root.update()
        button=self.app.controls['return-child']
        self.assertTrue(button.winfo_ismapped())
        self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),self.root.winfo_rootx()+self.root.winfo_width())
        button.invoke()
        self.assertTrue(self.app.closed)
        self.assertTrue(self.app.child_requested)
        saved_store=Store(Path(self.temp.name)/'test.sqlite3')
        try:
            saved=saved_store.settings()["practice_session"]
        finally:
            saved_store.close()
        self.assertEqual(saved['task_id'],'cups-4')
        self.assertEqual(saved['history'][-1]['left'],'x + 1')


class CompatibilityTests(unittest.TestCase):
    @unittest.skipIf(sys.version_info < (3, 8), "On Python 3.7 the interpreter itself validates the runtime syntax")
    def test_runtime_sources_parse_as_python37(self):
        root = Path(__file__).resolve().parents[1]
        from scripts.build_deb import RUNTIME
        for name in RUNTIME:
            with self.subTest(source=name):
                ast.parse((root / "algebra_lab" / name).read_text(), feature_version=(3, 7))

