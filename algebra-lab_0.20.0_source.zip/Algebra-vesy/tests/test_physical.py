"""Physical tags must change exercises through the same exact math engine."""
import tempfile
import time
import unittest
from pathlib import Path

from algebra_lab.hardware import Reader, BLOCKS, COMMANDS
from algebra_lab.math_engine import equation
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store
from algebra_lab.tasks import TASKS


class PhysicalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'test.sqlite3')
        self.service, self.session = Service(self.store, Reader()), Session()
        self.uids = {}
        for index, kind in enumerate(list(BLOCKS) + list(COMMANDS)):
            uid = format(index + 1, 'X')
            self.uids[kind] = uid
            self.service.dispatch('/api/tags/bind', self.session, {'uid': uid, 'kind': kind})
        self.service.start(self.session, {'task_id': 'first'})

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def scan(self, kind, style='independent'):
        return self.service.scan_exercise(self.session, {'uid': self.uids[kind], 'style': style})

    def test_one_tag_can_finish_every_catalog_task_with_exact_equivalence(self):
        for task in TASKS:
            with self.subTest(task=task['id']):
                self.service.start(self.session, {'task_id': task['id']})
                original = equation(task['equation']).solution()
                for _ in range(6):
                    if self.session.completed:
                        break
                    self.scan('1', 'guided')
                    self.assertEqual(self.session.current.solution(), original)
                self.assertTrue(self.session.completed)
                self.assertTrue(self.session.current.isolated())
                self.assertGreater(self.session.hints, 0)
                self.assertLessEqual(self.store.progress()['best'][task['id']], 2)
                self.assertIn('Метка', self.session.history[-1]['label'])

    def test_all_tasks_can_be_solved_independently_using_only_numeric_and_command_tags(self):
        from functools import reduce
        from math import gcd
        def apply(op, value, variable=False):
            self.scan(op)
            kind = ("-x" if value < 0 else "x") if variable else ("-1" if value < 0 else "1")
            for _ in range(abs(int(value))):
                self.scan(kind)
            self.scan("apply")
        for task in TASKS:
            with self.subTest(task=task['id']):
                self.service.start(self.session, {'task_id': task['id']})
                original = self.session.current.solution()
                eq = self.session.current
                denominator = reduce(lambda a, b: a * b // gcd(a, b),
                                     [v.denominator for v in (eq.left.a, eq.left.b, eq.right.a, eq.right.b)], 1)
                if denominator != 1:
                    apply('multiply', denominator)
                eq = self.session.current
                if eq.left.a and eq.right.a:
                    apply('subtract', eq.right.a, variable=True)
                eq = self.session.current
                side = eq.left if eq.left.a else eq.right
                if side.b and not self.session.completed:
                    apply('subtract', side.b)
                if not self.session.completed:
                    eq = self.session.current
                    apply('divide', eq.left.a or eq.right.a)
                self.assertTrue(self.session.completed)
                self.assertEqual(self.session.current.solution(), original)
                self.assertEqual(self.session.hints, 0)
                self.assertEqual(self.store.progress()['best'][task['id']], 3)

    def test_value_tags_and_apply_change_equation_and_record_independent_result(self):
        initial = self.session.current
        self.scan('subtract')
        self.scan('2')
        result = self.scan('1')
        self.assertEqual(result['pending'], '3')
        self.assertEqual(self.session.current, initial)
        self.scan('apply')
        self.assertEqual(str(self.session.current.left), 'x')
        self.assertEqual(str(self.session.current.right), '4')
        self.assertTrue(self.session.completed)
        self.assertEqual(self.store.progress()['best']['first'], 3)

    def test_multistep_solution_with_no_typed_operand_or_answer(self):
        self.service.start(self.session, {'task_id': 'double'})
        for kind in ['subtract', '2', 'apply', 'divide', '1', '2', 'apply']:
            self.scan(kind)
        self.assertTrue(self.session.completed)
        self.assertEqual(self.session.current.solution()['value'], '4')

    def test_variable_tag_then_undo(self):
        self.service.start(self.session, {'task_id': 'both'})
        original = self.session.current
        for kind in ['subtract', 'x', 'apply']:
            self.scan(kind)
        self.assertEqual(str(self.session.current.left), '2x + 2')
        self.scan('undo')
        self.assertEqual(self.session.current, original)
        self.assertEqual(self.session.rfid_terms, [])

    def test_zero_division_keeps_pending_and_equation(self):
        initial = self.session.current
        for kind in ['divide', '1', '-1']:
            self.scan(kind)
        with self.assertRaises(ValueError):
            self.scan('apply')
        self.assertEqual(self.session.current, initial)
        self.assertEqual(len(self.session.rfid_terms), 2)
        self.scan('clear')
        self.assertEqual(self.session.rfid_terms, [])

    def test_empty_apply_and_unknown_tag_leave_equation_unchanged(self):
        initial = self.session.current
        with self.assertRaises(ValueError):
            self.scan('apply')
        with self.assertRaises(ValueError):
            self.service.scan_exercise(self.session, {'uid': 'AB:CD'})
        self.assertEqual(self.session.current, initial)
        self.assertEqual(self.session.hints, 0)

    def test_expired_task_cannot_be_solved_by_tag(self):
        self.service.start(self.session, {'task_id': 'first', 'mode': 'challenge'})
        self.session.started = time.monotonic() - 181
        with self.assertRaises(ValueError):
            self.scan('1', 'guided')
        self.assertFalse(self.session.completed)
        self.assertEqual(self.session.hints, 0)

    def test_completed_task_moves_to_next_only_on_new_scan(self):
        self.scan('1', 'guided')
        self.assertTrue(self.session.completed)
        previous = self.session.task_id
        self.scan('1', 'guided')
        self.assertNotEqual(self.session.task_id, previous)
        self.assertFalse(self.session.completed)
        self.assertEqual(len(self.session.history), 1)

    def test_next_command_does_not_skip_an_unfinished_task(self):
        with self.assertRaises(ValueError):
            self.scan('next')
        self.assertEqual(self.session.task_id, 'first')

    def test_command_tags_do_not_become_blocks_on_lab_tray(self):
        with self.assertRaises(ValueError):
            self.service.scan(self.session, {'uid': self.uids['apply'], 'side': 'left'})
        self.assertEqual(self.session.blocks, {'left': [], 'right': []})

    def test_pending_terms_have_a_bounded_size(self):
        for _ in range(40):
            self.scan('1')
        with self.assertRaises(ValueError):
            self.scan('1')
        self.assertEqual(self.service.rfid_pending(self.session), '40')

    def test_hint_tag_and_explicit_assisted_step(self):
        self.scan('hint')
        self.scan('guide')
        self.assertTrue(self.session.completed)
        self.assertEqual(self.session.hints, 2)
        self.assertEqual(self.store.progress()['best']['first'], 1)

    def test_restart_does_not_replay_unapplied_terms(self):
        self.scan('2')
        self.service.save_practice(self.session)
        restored = Session()
        self.assertTrue(self.service.restore_practice(restored))
        self.assertEqual(restored.rfid_terms, [])
        self.assertEqual(restored.current, self.session.current)
