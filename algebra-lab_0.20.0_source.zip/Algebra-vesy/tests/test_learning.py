import csv
import io
import tempfile
import time
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

from algebra_lab.hardware import Reader
from algebra_lab.learning import daily_task, learning_stats, progress_csv
from algebra_lab.math_engine import equation
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store
from algebra_lab.tasks import TASKS


class JourneyTests(unittest.TestCase):
    def attempt(self, day, task_id="first"):
        return {"task_id": task_id, "completed_at": datetime.combine(day, datetime.min.time()).replace(hour=12).astimezone().isoformat()}

    def test_catalog_has_four_complete_chapters_and_preserves_legacy_ids(self):
        self.assertEqual(len(TASKS), 24)
        self.assertEqual(len({t["id"] for t in TASKS}), 24)
        self.assertEqual([sum(t["level"] == level for t in TASKS) for level in range(1, 5)], [6, 6, 6, 6])
        self.assertTrue({"first", "double", "final", "halves"} <= {t["id"] for t in TASKS})
        for task in TASKS:
            self.assertEqual(equation(task["equation"]).solution()["kind"], "one")

    def test_daily_cycle_and_reproducibility(self):
        today = date(2026, 10, 25)
        self.assertEqual(daily_task(today), daily_task(today))
        self.assertEqual(len({daily_task(today + timedelta(days=i))["id"] for i in range(24)}), 24)

    def test_streak_counts_calendar_days_not_attempts(self):
        today = date(2026, 10, 25)
        rows = [self.attempt(today), self.attempt(today), self.attempt(today - timedelta(days=1)), self.attempt(today - timedelta(days=2))]
        stats = learning_stats({"best": {"first": 3}, "attempts": rows}, today)
        self.assertEqual((stats["streak"], stats["today"], stats["xp"]), (3, 1, 30))
        self.assertEqual(learning_stats({"best": {}, "attempts": rows[2:]}, today)["streak"], 2)
        self.assertEqual(learning_stats({"best": {}, "attempts": rows[3:]}, today)["streak"], 0)

    def test_daily_done_requires_todays_completion(self):
        today = date(2026, 10, 25)
        task = daily_task(today)["id"]
        stats = learning_stats({"best": {task: 3}, "attempts": [self.attempt(today - timedelta(days=1), task)]}, today)
        self.assertFalse(stats["daily_done"])
        stats = learning_stats({"best": {task: 3}, "attempts": [self.attempt(today, task)]}, today)
        self.assertTrue(stats["daily_done"])

    def test_csv_is_readable_and_contains_real_results(self):
        row = dict(self.attempt(date(2026, 10, 25)), mode="practice", steps=2, hints=1, stars=2, seconds=45)
        result = list(csv.reader(io.StringIO(progress_csv({"attempts": [row]})), delimiter=";"))
        self.assertEqual(len(result), 2)
        self.assertEqual(result[1][1:], ["Первое равновесие", "Практика", "2", "1", "2", "45"])


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "progress.sqlite3"
        self.store = Store(self.path)
        self.reader = Reader()
        self.service = Service(self.store, self.reader)
        self.session = Session()
        self.service.start(self.session, {"task_id": "double"})

    def tearDown(self):
        self.store.close()
        self.reader.close()
        self.temp.cleanup()

    def test_resume_after_database_reopen_preserves_math_history_and_penalty(self):
        self.service.transform(self.session, {"operation": "subtract", "value": "2"})
        self.service.hint(self.session)
        self.session.started -= 60
        self.service.save_practice(self.session)
        other = Store(self.path)
        try:
            service, session = Service(other, self.reader), Session()
            self.assertTrue(service.restore_practice(session))
            self.assertEqual(session.current, equation("3x = 12"))
            self.assertEqual(len(session.history), 2)
            self.assertEqual(session.hints, 1)
            self.assertGreaterEqual(int(time.monotonic() - session.started), 60)
            service.transform(session, {"operation": "divide", "value": "3"})
            service.save_practice(session)
            self.assertEqual(other.progress()["stars"], 2)
            self.assertIsNone(other.settings()["practice_session"])
        finally:
            other.close()

    def test_timed_challenge_is_not_resumed(self):
        self.service.start(self.session, {"task_id": "first", "mode": "challenge"})
        self.service.save_practice(self.session)
        self.assertFalse(self.service.restore_practice(Session()))

    def test_corrupt_checkpoint_is_discarded_without_changing_progress(self):
        self.store.record("old-attempt", "first", "practice", 1, 0, 10)
        self.service.save_practice(self.session)
        checkpoint = self.store.settings()["practice_session"]
        checkpoint["history"][-1]["right"] = "999"
        self.store.checkpoint(checkpoint)
        self.assertFalse(self.service.restore_practice(Session()))
        self.assertEqual(self.store.progress()["stars"], 3)
        self.assertIsNone(self.store.settings()["practice_session"])

    def test_completed_attempt_cannot_be_recorded_twice_after_stale_resume(self):
        self.service.save_practice(self.session)
        self.service.answer(self.session, {"answer": "4"})
        resumed = Session()
        self.assertTrue(self.service.restore_practice(resumed))
        self.service.answer(resumed, {"answer": "4"})
        self.assertEqual(len(self.store.progress()["attempts"]), 1)

    def test_wrong_answer_reports_exact_substitution(self):
        result = self.service.answer(self.session, {"answer": "1/2"})
        self.assertFalse(result["correct"])
        self.assertIn("7/2", result["message"])
        self.assertIn("14", result["message"])
