import http.cookiejar
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from algebra_lab.__main__ import Application
from algebra_lab.hardware import Reader
from algebra_lab.storage import Store


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.store = Store(Path(cls.temp.name) / "http.sqlite3")
        cls.reader = Reader()
        cls.server = Application(("127.0.0.1", 0), cls.store, cls.reader)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        cls.store.close()
        cls.reader.close()
        cls.temp.cleanup()

    def setUp(self):
        self.client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def request(self, path, data=None, headers=None):
        req = urllib.request.Request(self.base+path, data=None if data is None else json.dumps(data).encode(),
                                     headers=headers if headers is not None else {"Content-Type": "application/json", "X-Lab-Request": "1"})
        try:
            with self.client.open(req) as response:
                return response.status, response.read(), response.headers
        except urllib.error.HTTPError as error:
            return error.code, error.read(), error.headers

    def test_startup_and_static_files(self):
        for path, mime in [("/", "text/html"), ("/app.js", "text/javascript"), ("/style.css", "text/css"), ("/favicon.svg", "image/svg+xml")]:
            with self.subTest(path=path):
                status, body, headers = self.request(path)
                self.assertEqual(status, 200)
                self.assertIn(mime, headers["Content-Type"])
                self.assertGreater(len(body), 100)
                self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_functional_flow_with_cookie(self):
        self.request("/api/exercise/start", {"task_id": "double"})
        status, body, _ = self.request("/api/exercise/transform", {"operation": "subtract", "value": "2"})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["equation"]["left"], "3x")
        status, body, _ = self.request("/api/exercise/transform", {"operation": "divide", "value": "3"})
        self.assertEqual(status, 200)
        self.assertTrue(json.loads(body)["completed"])
        self.assertEqual(json.loads(body)["equation"]["solution"]["value"], "4")

    def test_cross_origin_post_is_forbidden(self):
        status, _, _ = self.request("/api/settings", {"name": "X"}, {"Content-Type": "application/json", "X-Lab-Request": "1", "Origin": "https://example.org"})
        self.assertEqual(status, 403)

    def test_missing_request_header_is_forbidden(self):
        status, _, _ = self.request("/api/settings", {"name": "X"}, {"Content-Type": "application/json"})
        self.assertEqual(status, 403)

    def test_api_errors_are_json(self):
        status, body, _ = self.request("/api/equation/check", {"equation": "x*x=2"})
        self.assertEqual(status, 400)
        self.assertIn("error", json.loads(body))

    def test_non_object_body_rejected(self):
        status, _, _ = self.request("/api/settings", ["not", "an", "object"])
        self.assertEqual(status, 400)

    def test_static_path_traversal_not_served(self):
        status, _, _ = self.request("/../algebra_lab/storage.py")
        self.assertEqual(status, 404)

    def test_session_isolation(self):
        self.request("/api/exercise/start", {"task_id": "first"})
        stranger = urllib.request.build_opener()
        with stranger.open(self.base+"/api/exercise") as response:
            self.assertIsNone(json.load(response))
