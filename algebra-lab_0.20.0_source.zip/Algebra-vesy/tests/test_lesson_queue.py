import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from algebra_lab.storage import Store
from algebra_lab import lesson_queue as q

class QueueTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db.sqlite3')
        self.store.save_settings({'mobile_lessons_enabled':True});self.store.record('unlock','cups-1','practice',1,0,1)
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def test_idempotent_retries_and_one_pending_per_child(self):
        row=q.submit(self.store.db,'a'*32,'default','cups-3')
        self.assertEqual(q.submit(self.store.db,'a'*32,'default','cups-3'),row)
        q.submit(self.store.db,'b'*32,'default','cups-4')
        self.assertEqual(q.pending(self.store.db,'default')['id'],'b'*32)
        self.assertEqual(self.store.db.execute("SELECT state FROM mobile_lessons WHERE id=?",('a'*32,)).fetchone()[0],'superseded')
        with self.assertRaises(ValueError):q.submit(self.store.db,'a'*32,'default','cups-5')
    def test_gates_permissions_and_profile_isolation(self):
        other=self.store.create_profile('Саша')
        with self.assertRaises(ValueError):q.submit(self.store.db,'a'*32,other,'cups-3')
        q.submit(self.store.db,'b'*32,other,'cups-1')
        self.assertIsNone(q.pending(self.store.db,'default'))
        self.assertEqual(self.store.profile_id,'default')
        with self.assertRaises(ValueError):q.transition(self.store.db,'b'*32,'default','accepted')
        self.store.save_settings({'mobile_lessons_enabled':False})
        with self.assertRaises(PermissionError):q.submit(self.store.db,'c'*32,'default','cups-4')
    def test_expiry_cancellation_and_accept_revalidation(self):
        with patch('algebra_lab.lesson_queue.time.time',return_value=100):q.submit(self.store.db,'a'*32,'default','cups-3')
        with patch('algebra_lab.lesson_queue.time.time',return_value=100+q.TTL+1):
            self.assertIsNone(q.pending(self.store.db,'default'))
            self.assertEqual(q.latest(self.store.db,'default')['state'],'expired')
            with self.assertRaises(ValueError):q.transition(self.store.db,'a'*32,'default','accepted')
        q.submit(self.store.db,'b'*32,'default','cups-4');q.transition(self.store.db,'b'*32,'default','cancelled')
        self.assertEqual(q.latest(self.store.db,'default')['state'],'cancelled')
        q.submit(self.store.db,'c'*32,'default','cups-4');self.store.reset_progress()
        self.assertIsNone(q.pending(self.store.db,'default'))

    def test_restart_preserves_pending_and_cancelled_request_cannot_start(self):
        q.submit(self.store.db,'a'*32,'default','cups-3')
        path=Path(self.tmp.name)/'db.sqlite3';self.store.close();self.store=Store(path)
        self.assertEqual(q.pending(self.store.db,'default')['id'],'a'*32)
        q.transition(self.store.db,'a'*32,'default','cancelled')
        with self.assertRaises(ValueError):q.transition(self.store.db,'a'*32,'default','accepted')
        self.assertEqual(q.submit(self.store.db,'a'*32,'default','cups-3')['state'],'cancelled')
        self.assertIsNone(q.pending(self.store.db,'default'))
