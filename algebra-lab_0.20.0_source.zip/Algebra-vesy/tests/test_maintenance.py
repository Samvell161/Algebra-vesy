import sqlite3
import tempfile
import unittest
from pathlib import Path
from algebra_lab.storage import Store
from algebra_lab.maintenance import backup,restore

class BackupTests(unittest.TestCase):
    def test_snapshot_restore_and_rollback(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);store=Store(root/'live.db')
            try:
                store.bind('AA','1');backup(store,root/'copy.db')
                store.bind('BB','2');restore(store,root/'copy.db',root/'rollback.db')
                self.assertEqual(store.tags(),{'AA':'1'})
                previous=Store(root/'rollback.db')
                try:self.assertEqual(previous.tags(),{'AA':'1','BB':'2'})
                finally:previous.close()
                with self.assertRaises(ValueError):restore(store,root/'live.db',root/'rollback.db')
                (root/'bad.db').write_text('bad')
                with self.assertRaises(sqlite3.DatabaseError):restore(store,root/'bad.db',root/'rollback.db')
                self.assertEqual(store.tags(),{'AA':'1'})
            finally:store.close()

    def test_half_pair_restores_as_preview_without_committing_history(self):
        from algebra_lab.pending import save_pending,restore_pending
        from algebra_lab.service import Service,Session
        from algebra_lab.hardware import Reader
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'live.db');reader=Reader()
            try:
                service=Service(store,reader);session=Session();store.bind('AA','1')
                service.start(session,{'task_id':'cups-4'});service.begin_student(session)
                service.scan_cup(session,{'uid':'AA','side':'left','operation':'remove'})
                service.save_practice(session);save_pending(store,session)
                resumed=Session();self.assertTrue(service.restore_practice(resumed))
                self.assertTrue(restore_pending(service,resumed))
                self.assertTrue(service.cup_state(resumed)['pending'])
                self.assertEqual(len(resumed.history),1)
                service.scan_cup(resumed,{'uid':'AA','side':'right'})
                self.assertEqual(len(resumed.history),2)
            finally:store.close();reader.close()
