import unittest
from unittest.mock import patch, Mock

from algebra_lab.hardware import Reader
from algebra_lab.rc522 import CardReadError


class FakeLoop:
    def __init__(self, iterations):
        self.remaining = iterations

    def wait(self, timeout):
        self.remaining -= 1
        return self.remaining < 0


class FakeDriver:
    def __init__(self, readings):
        self.readings = iter(readings)
        self.recover = Mock()

    def read_id_no_block(self):
        reading = next(self.readings)
        if isinstance(reading, Exception):
            raise reading
        return reading


class ReaderTests(unittest.TestCase):
    def reader(self, readings):
        reader = Reader()
        reader.mode = "rc522"
        reader.driver = FakeDriver(readings)
        reader.stop_event = FakeLoop(len(readings))
        return reader

    def test_held_tag_emits_only_one_event(self):
        reader = self.reader([123, 123, 123, 123])
        reader._poll()
        self.assertEqual(reader.since(0), [{"sequence": 1, "uid": "7B"}])

    def test_tag_can_return_after_removal(self):
        reader = self.reader([123, 123, None, None, None, 123, 123])
        with patch("algebra_lab.hardware.time.monotonic", side_effect=[10, 10.7, 11.3]):
            reader._poll()
        self.assertEqual(len(reader.since(0)), 2)
        self.assertEqual(reader.since(1), [{"sequence": 2, "uid": "7B"}])

    def test_no_other_uid_until_confirmed_removal(self):
        reader = self.reader([123, 123, 456, 456])
        reader._poll()
        self.assertEqual([event["uid"] for event in reader.since(0)], ["7B"])

    def test_transient_rf_error_recovers_without_stopping(self):
        reader = self.reader([CardReadError("ErrorReg=0x08"), 123, 123])
        reader._poll()
        reader.driver.recover.assert_not_called()
        self.assertIsNone(reader.error)
        self.assertIsNone(reader.warning)
        self.assertEqual(len(reader.since(0)), 1)

    def test_glitches_do_not_duplicate_a_held_tag(self):
        reader = self.reader([123, 123, CardReadError("parity"), None, None, 123, 123])
        with patch("algebra_lab.hardware.time.monotonic", side_effect=[10, 10.4]):
            reader._poll()
        self.assertEqual(len(reader.since(0)), 1)

    def test_rf_error_interrupts_removal_confirmation(self):
        reader = self.reader([123, 123, None, CardReadError("collision"), None, None, 123, 123])
        with patch("algebra_lab.hardware.time.monotonic", side_effect=[10, 11, 11.4]):
            reader._poll()
        self.assertEqual(len(reader.since(0)), 1)

    def test_error_after_valid_uid_cannot_cancel_recognition(self):
        reader = self.reader([123, CardReadError("parity"), 123])
        reader._poll()
        self.assertEqual(reader.since(0), [{"sequence": 1, "uid": "7B"}])

    def test_different_samples_are_not_a_confirmed_uid(self):
        reader = self.reader([123, 456, 123, 456, 123, 123])
        reader._poll()
        self.assertEqual(reader.since(0), [{"sequence": 1, "uid": "7B"}])

    def test_persistent_rf_fault_stays_visible_and_keeps_retrying(self):
        reader = self.reader([CardReadError("parity")] * 3)
        reader._poll()
        self.assertEqual(reader.driver.recover.call_count, 1)
        self.assertIsNone(reader.error)
        self.assertIn("пока не прочитана", reader.status()["warning"])
        self.assertEqual(reader.since(0), [])

    def test_removal_starting_at_zero_can_rearm(self):
        reader = self.reader([123, 123, None, None, 456, 456])
        with patch("algebra_lab.hardware.time.monotonic", side_effect=[0, 1.3]):
            reader._poll()
        self.assertEqual([event["uid"] for event in reader.since(0)], ["7B", "1C8"])

    def test_two_second_removal_is_enough_at_slow_poll_rate(self):
        reader = self.reader([123, None, None, 123])
        with patch("algebra_lab.hardware.time.monotonic", side_effect=[.8, 1.6]):
            reader._poll()
        self.assertEqual(len(reader.since(0)), 2)

    def test_poll_is_slow_and_backoff_is_interruptible(self):
        reader = self.reader([CardReadError("protocol")] * 4 + [123])
        original_wait = reader.stop_event.wait
        delays = []
        def wait(delay):
            delays.append(delay)
            return original_wait(delay)
        reader.stop_event.wait = wait
        reader._poll()
        self.assertEqual(delays[0], .8)
        self.assertGreater(max(delays), 1.2)
        self.assertEqual(delays[-1], .8)
        self.assertEqual(len(reader.since(0)), 1)
        self.assertIsNone(reader.warning)
        self.assertEqual(reader.last_error, "protocol")

    def test_sparse_valid_uid_between_errors_is_recognized_once(self):
        reader = self.reader([CardReadError("parity"), 123, CardReadError("protocol"), 123])
        reader._poll()
        self.assertEqual(reader.since(0), [{'sequence': 1, 'uid': '7B'}])
        self.assertIsNone(reader.error)

    def test_driver_error_is_visible_not_false_readiness(self):
        reader = self.reader([OSError("SPI unavailable")])
        reader._poll()
        self.assertFalse(reader.status()["connected"])
        self.assertIn("OSError", reader.status()["error"])


class UIDProtocolTests(unittest.TestCase):
    def driver(self, responses):
        from algebra_lab.rc522 import RC522
        from unittest.mock import Mock
        reader = RC522.__new__(RC522)
        reader.transceive = Mock(side_effect=responses)
        reader.recover = Mock()
        return reader

    def test_legacy_uid_only_path_uses_reqa_and_anticollision_without_select_or_halt(self):
        frame = [0x12, 0x34, 0x56, 0x78, 0x08]
        reader = self.driver([[4, 0], frame])
        self.assertEqual(reader.read_id_no_block(), int.from_bytes(bytes(frame), 'big'))
        self.assertEqual([call.args for call in reader.transceive.call_args_list],
                         [([0x26], 7), ([0x93, 0x20], 0)])
        reader.recover.assert_not_called()

    def test_absent_card_is_not_uid_zero(self):
        self.assertIsNone(self.driver([None]).read_id_no_block())

    def test_corrupt_uid_does_not_register_a_tag(self):
        with self.assertRaises(OSError):
            self.driver([[4, 0], [1, 2, 3, 4, 0]]).read_id_no_block()

    def test_cascaded_uid(self):
        from algebra_lab.rc522 import crc_a
        reader = self.driver([[4, 0], [0x88, 1, 2, 3, 0x88], [4] + crc_a([4]),
                              [4, 5, 6, 7, 0], [0] + crc_a([0])])
        self.assertEqual(reader.read_id_no_block(), int.from_bytes(bytes(range(1, 8)), 'big'))

    def test_failed_connection_is_visible_and_can_switch_back(self):
        reader = Reader()
        with patch('algebra_lab.rc522.RC522', side_effect=OSError('SPI unavailable')):
            reader.configure('rc522')
            reader.thread.join(timeout=1)
        self.assertIn('SPI unavailable', reader.status()['error'])
        reader.configure('simulator')
        self.assertEqual(reader.mode, 'simulator')
        self.assertIsNone(reader.error)
        reader.close()


class RFErrorTests(unittest.TestCase):
    def test_collision_is_recoverable_and_reports_register_not_tag_count(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.read = Mock(side_effect=[0x30, 0x08])
        reader.write = Mock()
        with self.assertRaisesRegex(CardReadError, "ErrorReg=0x08"):
            reader.transceive([0x52], 7)
        self.assertEqual(reader.write.call_args.args, (0x01, 0))

    def test_timer_with_protocol_error_is_not_false_card_removal(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.read = Mock(side_effect=[0x03, 0x01])
        reader.write = Mock()
        with self.assertRaisesRegex(CardReadError, "ProtocolErr"):
            reader.transceive([0x26], 7)

    def test_clean_timer_timeout_means_no_card(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.read = Mock(side_effect=[0x01, 0x00])
        reader.write = Mock()
        self.assertIsNone(reader.transceive([0x26], 7))

    def test_spi_failure_is_not_misclassified_as_rf_fault(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.read = Mock(side_effect=OSError("SPI disconnected"))
        reader.write = Mock()
        with self.assertRaises(OSError) as caught:
            reader.transceive([0x52], 7)
        self.assertNotIsInstance(caught.exception, CardReadError)

    def test_recovery_restarts_field_and_clears_framing(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.read = Mock(return_value=0x83)
        reader.write = Mock()
        with patch("algebra_lab.rc522.time.sleep"):
            reader.recover()
        self.assertEqual([call.args for call in reader.write.call_args_list],
                         [(1, 0), (0x0d, 0), (0x0a, 0x80), (0x14, 0x80), (0x14, 0x83)])


class CompatibilityDriverTests(unittest.TestCase):
    def test_error_reports_phase_and_version(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.version = 0x92
        reader.transceive = Mock(side_effect=CardReadError("ProtocolErr (ErrorReg=0x01)"))
        with self.assertRaisesRegex(CardReadError, "REQA.*0x01.*0x92"):
            reader.exchange([0x26], 7, 'REQA', 16)

    def test_short_response_is_not_a_valid_atqa(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        reader.transceive = Mock(return_value=[4])
        with self.assertRaisesRegex(CardReadError, "8 бит вместо 16"):
            reader.exchange([0x26], 7, 'REQA', 16)

    def test_partial_final_byte_is_not_accepted_as_full_frame(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        def respond(data, bits):
            reader.received_bits = 12
            return [4, 0]
        reader.transceive = respond
        with self.assertRaisesRegex(CardReadError, "12 бит вместо 16"):
            reader.exchange([0x26], 7, 'REQA', 16)

    def test_start_send_cleared_before_reading_error_and_fifo(self):
        from algebra_lab.rc522 import RC522
        reader = RC522.__new__(RC522)
        operations = []
        values = {0x04: 0x30, 0x06: 0, 0x0a: 2, 0x0c: 0, 0x09: 4}
        reader.write = lambda reg, value: operations.append(('write', reg, value))
        def read(reg):
            operations.append(('read', reg))
            return values[reg]
        reader.read = read
        self.assertEqual(reader.transceive([0x26], 7), [4, 4])
        end = operations.index(('read', 0x04))
        self.assertEqual(operations[end + 1], ('write', 0x0d, 7))
        self.assertEqual(operations[end + 2], ('read', 0x06))


class UIDOnlyChip:
    """Register model of a tag/reader accepting the legacy UID-only exchange.

    It deliberately rejects SELECT so the end-to-end test catches restoring
    the extra exchange that the compatibility path must avoid.
    """
    def __init__(self):
        self.registers = {0x37: 0x92, 0x14: 0, 0x26: 0x48}
        self.tx, self.rx, self.commands = [], [], []
        self.present = True

    def read(self, reg):
        if reg == 0x0a:
            return len(self.rx)
        if reg == 0x09:
            return self.rx.pop(0)
        return self.registers.get(reg, 0)

    def write(self, reg, value):
        if reg == 0x04:
            self.registers[reg] = self.registers.get(reg, 0) & ~(value & 0x7f)
            return
        if reg == 0x0a and value & 0x80:
            self.tx, self.rx = [], []
            return
        if reg == 0x09:
            self.tx.append(value)
            return
        self.registers[reg] = value
        if reg == 0x0d and value & 0x80:
            self.commands.append(list(self.tx))
            self.registers[0x06] = 0
            self.registers[0x0c] = 0
            self.registers[0x04] = 0x30
            if not self.present:
                self.registers[0x04] = 1
            elif self.tx == [0x26] and value & 7 == 7:
                self.rx = [4, 0]
            elif self.tx == [0x93, 0x20] and value & 7 == 0:
                self.rx = [0x12, 0x34, 0x56, 0x78, 0x08]
            else:
                self.registers[0x06] = 1

    def xfer2(self, values):
        register = (values[0] & 0x7e) >> 1
        if values[0] & 0x80:
            return [0, self.read(register)]
        self.write(register, values[1])
        return [0, 0]


class RegisterPipelineTests(unittest.TestCase):
    def test_real_register_exchange_can_read_held_tag_without_select_and_no_duplicates(self):
        from algebra_lab.rc522 import RC522
        chip = UIDOnlyChip()
        driver = RC522.__new__(RC522)
        driver.read, driver.write = chip.read, chip.write
        driver.version = 0x92
        reader = Reader()
        reader.driver = driver
        reader.stop_event = FakeLoop(5)
        with patch('algebra_lab.rc522.time.sleep'):
            reader._poll()
        self.assertIsNone(reader.error)
        self.assertIsNone(reader.warning)
        self.assertEqual(reader.since(0), [{'sequence': 1, 'uid': '1234567808'}])
        self.assertEqual(chip.commands, [[0x26], [0x93, 0x20]] * 5)
        chip.present = False
        with patch('algebra_lab.rc522.time.sleep'):
            self.assertIsNone(driver.read_id_no_block())

    def test_initialization_uses_standard_gain_and_explicit_iso14443a_modes(self):
        import sys
        from types import ModuleType
        from algebra_lab.rc522 import RC522
        chip = UIDOnlyChip()
        spi = Mock()
        spi.xfer2.side_effect = chip.xfer2
        spidev = ModuleType('spidev')
        spidev.SpiDev = Mock(return_value=spi)
        gpio = ModuleType('RPi.GPIO')
        gpio.BCM, gpio.OUT, gpio.HIGH = 11, 0, 1
        gpio.setmode, gpio.setup, gpio.cleanup = Mock(), Mock(), Mock()
        rpi = ModuleType('RPi')
        rpi.GPIO = gpio
        with patch.dict(sys.modules, {'spidev': spidev, 'RPi': rpi, 'RPi.GPIO': gpio}):
            with patch('algebra_lab.rc522.time.sleep'):
                driver = RC522()
                self.assertEqual(driver.version, 0x92)
                self.assertEqual(chip.registers[0x26], 0x48)
                self.assertEqual(chip.registers[0x12], 0)
                self.assertEqual(chip.registers[0x13], 0)
                self.assertEqual(spi.max_speed_hz, 250000)
                self.assertEqual(driver.read_id_no_block(), int('1234567808', 16))
                driver.close()
        gpio.cleanup.assert_called_once_with(25)
