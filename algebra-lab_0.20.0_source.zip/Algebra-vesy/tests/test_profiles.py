import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from algebra_lab.storage import Store
from algebra_lab.maintenance import backup,restore
from algebra_lab.service import Service,Session
from algebra_lab.hardware import Reader
from algebra_lab.pending import save_pending,restore_pending

class ProfileTests(unittest.TestCase):
    def test_isolated_results_sessions_shared_tags_and_hardware_survive_reopen(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'data.db';store=Store(path);reader=Reader()
            try:
                store.bind('AA','1');store.save_settings({'name':'Маша','reader_mode':'rc522_dual'})
                store.record('old','cups-1','practice',1,0,1)
                service=Service(store,reader);session=Session()
                service.start(session,{'task_id':'cups-4'});service.begin_student(session)
                service.scan_cup(session,{'uid':'AA','side':'left','operation':'remove'})
                service.save_practice(session);save_pending(store,session)
                other=store.create_profile('Саша');store.select_profile(other)
                self.assertEqual(store.progress()['completed'],0)
                self.assertNotIn('practice_session',store.settings())
                self.assertEqual(store.settings()['reader_mode'],'rc522_dual')
                self.assertEqual(store.tags(),{'AA':'1'})
                store.record('new','cups-2','practice',1,0,2)
                store.save_settings({'motion':False})
                store.reset_progress();self.assertEqual(store.progress()['completed'],0)
                store.select_profile('default')
                self.assertEqual(store.progress()['completed'],1)
                self.assertNotEqual(store.settings().get('motion'),False)
                resumed=Session();self.assertTrue(service.restore_practice(resumed))
                self.assertTrue(restore_pending(service,resumed))
                store.select_profile(other);store.close();store=Store(path)
                self.assertEqual(store.profile_id,other)
                self.assertEqual(store.settings()['name'],'Саша')
                self.assertEqual(len(store.profiles()),2)
            finally:store.close();reader.close()

    def test_old_database_migrates_without_changing_results(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'old.db';db=sqlite3.connect(path)
            db.executescript('''CREATE TABLE attempts(id TEXT PRIMARY KEY,task_id TEXT,mode TEXT,steps INTEGER,hints INTEGER,stars INTEGER,seconds INTEGER,completed_at TEXT);
            CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT);CREATE TABLE tags(uid TEXT PRIMARY KEY,kind TEXT);
            INSERT INTO attempts VALUES ('old','cups-1','practice',1,0,3,20,'2026-01-01');''')
            db.execute('INSERT INTO settings VALUES (?,?)',('name',json.dumps('Маша')));db.commit();db.close()
            store=Store(path)
            try:
                self.assertEqual(store.profile_id,'default')
                self.assertEqual(store.profiles()[0]['name'],'Маша')
                self.assertEqual(store.progress()['stars'],3)
                store.select_profile(store.create_profile('Саша'))
                self.assertEqual(store.progress()['stars'],0)
            finally:store.close()

    def test_backup_restores_all_profiles_and_active_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);store=Store(root/'data.db')
            try:
                other=store.create_profile('Саша');store.select_profile(other)
                store.record('new','cups-2','practice',1,0,1);backup(store,root/'copy.db')
                store.select_profile('default');store.create_profile('Лена')
                restore(store,root/'copy.db',root/'rollback.db')
                self.assertEqual(len(store.profiles()),2)
                self.assertEqual(store.profile_id,other)
                self.assertEqual(store.progress()['completed'],1)
                with self.assertRaises(ValueError):store.create_profile('саша')
            finally:store.close()
