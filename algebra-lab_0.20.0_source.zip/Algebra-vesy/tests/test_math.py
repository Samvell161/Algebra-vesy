import unittest
from fractions import Fraction

from algebra_lab.math_engine import Equation, Linear, MathError, equation, number, parse
from algebra_lab.tasks import TASKS


class MathTests(unittest.TestCase):
    def test_implicit_multiplication_and_brackets(self):
        self.assertEqual(parse("2(x + 3) - 3x/2"), Linear(Fraction(1, 2), Fraction(6)))

    def test_unicode_and_signed_fractions(self):
        self.assertEqual(parse("−x + 3/2 − 0.5"), Linear(Fraction(-1), Fraction(1)))
        self.assertEqual(parse("2 × (x + 1) ÷ 4"), Linear(Fraction(1, 2), Fraction(1, 2)))

    def test_canonical_form_round_trip(self):
        for a in [Fraction(-3, 2), Fraction(-1), Fraction(0), Fraction(1), Fraction(7, 3)]:
            for b in [Fraction(-7, 2), Fraction(0), Fraction(4)]:
                with self.subTest(a=a, b=b):
                    linear = Linear(a, b)
                    self.assertEqual(parse(str(linear)), linear)

    def test_exact_fraction_solution(self):
        self.assertEqual(equation("2x - 1 = 6").solution(), {"kind": "one", "value": "7/2"})

    def test_all_and_no_solutions(self):
        self.assertEqual(equation("2(x+1) = 2x+2").solution()["kind"], "all")
        self.assertEqual(equation("x + 2 = x + 3").solution()["kind"], "none")

    def test_operations_preserve_solution_for_all_tasks(self):
        for task in TASKS:
            original = equation(task["equation"])
            for op, value in [("add", "-2x+3/2"), ("subtract", "2x-7"),
                              ("multiply", "-3/7"), ("divide", "5/3")]:
                with self.subTest(task=task["id"], op=op):
                    transformed = original.transform(op, value)
                    self.assertEqual(transformed.solution(), original.solution())
                    solution = Fraction(original.solution()["value"])
                    self.assertEqual(transformed.left.at(solution), transformed.right.at(solution))

    def test_prohibition_of_zero_operations(self):
        for op in ["divide", "multiply"]:
            with self.subTest(op=op), self.assertRaises(MathError):
                equation("x=2").transform(op, "0")

    def test_nonlinear_and_variable_divisor_rejected(self):
        for source in ["x*x", "x(x+1)", "1/x", "x/(x-1)", "2/0"]:
            with self.subTest(source=source), self.assertRaises(MathError):
                parse(source)

    def test_malformed_and_unsafe_input_rejected(self):
        for source in ["", "x+", "(x+1", "x)", "2..5", ".5", "x**2", "__import__('os')", "2 3", "y+1", "1e9"]:
            with self.subTest(source=source), self.assertRaises(MathError):
                parse(source)

    def test_resource_limits(self):
        for source in ["x"*161, "99999x", "10000*10000*x", "1/9999/9999"]:
            with self.subTest(source=source), self.assertRaises(MathError):
                parse(source)
        with self.assertRaises(MathError):
            number("1/0")
        for source in ["1e999999999", "9"*1000, "nan", "inf"]:
            with self.subTest(source=source[:20]), self.assertRaises(MathError):
                number(source)

    def test_isolated_on_either_side(self):
        self.assertTrue(equation("x = 4").isolated())
        self.assertTrue(equation("4 = x").isolated())
        self.assertFalse(equation("2x = 4").isolated())

    def test_equation_requires_one_equals(self):
        for source in ["x", "x=1=2", "=3"]:
            with self.subTest(source=source), self.assertRaises(MathError):
                equation(source)
