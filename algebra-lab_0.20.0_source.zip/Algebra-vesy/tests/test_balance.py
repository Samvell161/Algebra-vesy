"""Semantic balance direction, bounded animation, and persistent game rewards."""
import os
import unittest
from fractions import Fraction
from algebra_lab.math_engine import equation, Linear
from algebra_lab.balance_view import symbolic_tilt
from algebra_lab.learning import game_progress
try:
    import tkinter as tk
except ImportError:
    tk = None


class BalanceMeaningTests(unittest.TestCase):
    def test_uses_equivalence_not_number_of_blocks_as_fake_mass(self):
        base = equation('x+1=3')
        self.assertEqual(symbolic_tilt(base, base), 0)
        self.assertGreater(symbolic_tilt(base, equation('x=3')), 0)
        self.assertLess(symbolic_tilt(base, equation('x+1=2')), 0)
        self.assertEqual(symbolic_tilt(base, equation('x=2')), 0)

    def test_game_rewards_are_based_on_best_results_and_known_tasks(self):
        progress = {'best': {'cups-1': 3, 'cups-2': 3, 'unknown': 3},
                    'attempts': [{}] * 10, 'total_seconds': 120}
        stats = game_progress(progress)
        self.assertEqual((stats['xp'], stats['level'], stats['next_xp']), (60, 2, 60))
        self.assertEqual(stats['completed'], 2)
        self.assertEqual(stats['attempts'], 10)
        self.assertEqual(stats['seconds'], 120)
        progress['attempts'] *= 2
        self.assertEqual(game_progress(progress)['xp'], 60)


@unittest.skipUnless(tk and os.environ.get('DISPLAY'), 'Needs Tk and a display')
class BalanceCanvasTests(unittest.TestCase):
    def setUp(self):
        from algebra_lab.balance_view import BalanceCanvas
        self.root = tk.Tk()
        self.root.geometry('960x300')
        self.board = BalanceCanvas(self.root, Linear(Fraction(1), Fraction(1)), Linear(b=Fraction(2)), tilt=5)
        self.board.pack(fill='both', expand=True)
        self.root.update()

    def tearDown(self):
        self.root.destroy()

    def test_animation_is_finite_and_item_count_does_not_grow(self):
        count = len(self.board.find_all())
        self.board.after_cancel(self.board.timer)
        self.board.timer = None
        for index in range(self.board.FRAMES):
            self.board.animate()
            if self.board.timer is not None:
                self.board.after_cancel(self.board.timer)
                self.board.timer = None
        self.assertEqual(self.board.angle, 5)
        self.assertIsNone(self.board.timer)
        self.assertEqual(len(self.board.find_all()), count)
        self.assertLess(count, 150)
        self.assertGreater(self.board.pan_centers['right'][1], self.board.pan_centers['left'][1])

    def test_reduce_motion_is_instant_and_close_cancels_timer(self):
        from algebra_lab.balance_view import BalanceCanvas
        board = BalanceCanvas(self.root, Linear(1), Linear(0, 2), tilt=-5, motion=False)
        self.assertEqual(board.angle, -5)
        self.assertIsNone(board.timer)
        timer = self.board.timer
        self.board.destroy()
        self.assertIsNone(self.board.timer)
        if timer is not None:
            self.assertNotIn(timer, self.root.tk.call('after', 'info'))
        board.destroy()
