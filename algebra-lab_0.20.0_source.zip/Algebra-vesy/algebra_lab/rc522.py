"""Small UID-only ISO14443A reader: configurable SPI bus/CE and independent BCM reset. No pip packages."""
import time


def crc_a(data):
    crc = 0x6363
    for value in data:
        value ^= crc & 0xff
        value ^= (value << 4) & 0xff
        crc = ((crc >> 8) ^ (value << 8) ^ (value << 3) ^ (value >> 4)) & 0xffff
    return [crc & 0xff, crc >> 8]


class CardReadError(OSError):
    """A recoverable RF/protocol failure, distinct from a broken SPI connection."""


class RC522:
    def __init__(self, bus=0, device=0, rst=25):
        import spidev
        import RPi.GPIO as GPIO
        self.gpio, self.spi = GPIO, None
        self.bus, self.device, self.rst = bus, device, rst
        self.reset = False
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(rst, GPIO.OUT, initial=GPIO.HIGH)
            self.reset = True
            self.spi = spidev.SpiDev()
            self.spi.open(bus, device)
            self.spi.max_speed_hz = 250000
            self.spi.mode = 0
            self.write(0x01, 0x0f)
            time.sleep(0.05)
            self.version = self.read(0x37)
            if self.version in (0x00, 0xff):
                raise OSError('RC522 не отвечает (VersionReg 0x%02X). Проверьте 3,3 В, SPI%d CE%d и RST BCM%d.' % (self.version, bus, device, rst))
            for register, value in [(0x2a, 0x8d), (0x2b, 0x3e), (0x2d, 30), (0x2c, 0),
                                    (0x12, 0), (0x13, 0), (0x24, 0x26),
                                    (0x15, 0x40), (0x11, 0x3d)]:
                self.write(register, value)
            # Change only RxGain; preserve reserved bits of RFCfgReg.
            self.write(0x26, (self.read(0x26) & ~0x70) | 0x40)
            self.write(0x14, self.read(0x14) | 3)
            self.recover()
        except Exception:
            self.close()
            raise

    def write(self, register, value):
        self.spi.xfer2([(register << 1) & 0x7e, value])

    def read(self, register):
        return self.spi.xfer2([((register << 1) & 0x7e) | 0x80, 0])[1]

    def transceive(self, data, bits=0):
        self.write(0x01, 0)
        self.write(0x02, 0x77)
        self.write(0x04, 0x7f)
        self.write(0x0a, 0x80)
        for value in data:
            self.write(0x09, value)
        self.write(0x0d, bits)
        self.write(0x01, 0x0c)
        self.write(0x0d, bits | 0x80)
        deadline = time.monotonic() + 0.05
        try:
            while time.monotonic() < deadline:
                irq = self.read(0x04)
                if irq & 0x33:  # Rx/Idle, ErrIRQ, or timer; inspect ErrorReg first.
                    break
                time.sleep(0.001)
            else:
                raise OSError('RC522: нет ответа от контроллера SPI.')
            # Clear StartSend as soon as the exchange ends, before consuming FIFO.
            self.write(0x0d, bits)
            error = self.read(0x06)
            if error & 0xc0:
                raise OSError('RC522: ошибка контроллера (ErrorReg=0x%02X).' % error)
            if error & 0x1f:
                names = [name for flag, name in [(1, 'ProtocolErr'), (2, 'ParityErr'), (4, 'CRCErr'),
                                                   (8, 'CollErr'), (16, 'BufferOvfl')]
                         if error & flag]
                raise CardReadError('%s (ErrorReg=0x%02X).' % ('/'.join(names), error))
            if irq & 1 and not irq & 0x20:
                return None
            size = self.read(0x0a) & 0x7f
            if size > 64:
                raise OSError('RC522: переполнение FIFO.')
            last_bits = self.read(0x0c) & 7
            self.received_bits = (size - 1) * 8 + last_bits if last_bits and size else size * 8
            return [self.read(0x09) for _ in range(size)]
        finally:
            self.write(0x0d, bits)
            self.write(0x01, 0)

    def exchange(self, data, bits, stage, expected_bits):
        self.phase = stage
        self.received_bits = None
        try:
            result = self.transceive(data, bits)
            if result is not None:
                actual_bits = self.received_bits if self.received_bits is not None else len(result) * 8
                if actual_bits != expected_bits:
                    raise CardReadError('Длина ответа %s бит вместо %s.' % (actual_bits, expected_bits))
            return result
        except CardReadError as exc:
            version = getattr(self, 'version', None)
            suffix = ' VersionReg=0x%02X.' % version if version is not None else ''
            raise CardReadError(stage + ': ' + str(exc) + suffix) from None

    def read_id_no_block(self):
        # Keep the RF field stable for the common UID-only path. A field reset
        # is reserved for initialization and repeated faults, not every sample.
        if self.exchange([0x26], 7, 'REQA: запрос метки', 16) is None:
            return None
        uid = []
        for cascade in (0x93, 0x95, 0x97):
            stage = 'UID CL%d' % ((cascade - 0x93) // 2 + 1)
            frame = self.exchange([cascade, 0x20], 0, stage, 40)
            if frame is None or len(frame) != 5 or frame[0] ^ frame[1] ^ frame[2] ^ frame[3] != frame[4]:
                raise CardReadError(stage + ': не удалось подтвердить UID (BCC).')
            if cascade == 0x93 and frame[0] != 0x88:
                # Same four-byte UID + BCC representation and minimal exchange
                # as SimpleMFRC522.read_id_no_block. No SELECT/SAK/HALT needed.
                self.phase = 'UID прочитан (совместимый режим)'
                return int.from_bytes(bytes(frame), 'big')
            select = [cascade, 0x70] + frame
            sak = self.exchange(select + crc_a(select), 0, stage + ' SELECT', 24)
            if not sak or len(sak) != 3 or crc_a(sak[:1]) != sak[1:]:
                raise CardReadError(stage + ': не удалось подтвердить каскад UID (SAK).')
            uid.extend(frame[1:4] if frame[0] == 0x88 else frame[:4])
            if not sak[0] & 4:
                self.phase = 'UID прочитан (каскадный)'
                result = int.from_bytes(bytes(uid), 'big')
                # Cascaded SELECT leaves the card ACTIVE, unlike UID-only reads.
                self.recover()
                return result
        raise OSError('Неподдерживаемая длина UID.')

    def antenna(self, enabled):
        value = self.read(0x14)
        self.write(0x14, value | 3 if enabled else value & ~3)

    def recover(self):
        # Restart RF to restore IDLE before the next REQA. This never means
        # physical removal: the caller retains its presentation/dedup state.
        self.write(0x01, 0)
        self.write(0x0d, 0)
        self.write(0x0a, 0x80)
        antenna = self.read(0x14)
        self.write(0x14, antenna & ~3)
        time.sleep(0.01)
        self.write(0x14, antenna | 3)
        time.sleep(0.02)

    def close(self):
        if self.spi is not None:
            try:
                self.write(0x14, 0)
            except Exception:
                pass
            try:
                self.spi.close()
            except OSError:
                pass
            self.spi = None
        if self.reset:
            try:
                self.gpio.cleanup(self.rst)
            except RuntimeError:
                pass
            self.reset = False
