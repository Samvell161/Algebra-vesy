"""Offline tag lists: phone ISO14443A UIDs to the existing reader identifiers."""
import json
import re
from functools import reduce
from operator import xor

from .hardware import TAG_KINDS, normalize_uid

MAX_BYTES = 128 * 1024
MAX_TAGS = 1000


def phone_uid(source):
    if not isinstance(source, str) or len(source) > 100:
        raise ValueError('UID телефона должен быть текстом.')
    value = source.strip()
    if value.lower().startswith('0x'):
        value = value[2:]
    value = re.sub(r'[\s:\-]', '', value)
    if not re.fullmatch(r'[0-9a-fA-F]+', value) or len(value) not in (8, 14, 20):
        raise ValueError('Нужен UID из 4, 7 или 10 байт: например 12:34:56:78. Скопируйте UID, а не содержимое метки.')
    raw = bytes.fromhex(value)
    # SimpleMFRC522 and our 4-byte compatibility path include the BCC byte.
    if len(raw) == 4:
        raw += bytes([reduce(xor, raw)])
    return format(int.from_bytes(raw, 'big'), 'X')


def tag_kind(value):
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise ValueError('Значение метки должно быть x, −x, 1, −1, 2, −2 или командой.')
    kind = str(value).strip().replace('−', '-').lower()
    kind = {'+1': '1', '+2': '2', '+5': '5', '+x': 'x'}.get(kind, kind)
    if kind not in TAG_KINDS:
        raise ValueError('Неизвестное значение метки: ' + kind)
    return kind


def parse_tags(source):
    if not isinstance(source, str) or len(source.encode('utf-8')) > MAX_BYTES:
        raise ValueError('Файл меток должен быть не больше 128 КБ.')
    source = source.lstrip('\ufeff').strip()
    if not source:
        raise ValueError('Список меток пуст.')
    format_name = 'phone'
    if source[0] in '{[':
        try:
            data = json.loads(source)
        except (ValueError, RecursionError):
            raise ValueError('Не удалось прочитать JSON со списком меток.') from None
        if isinstance(data, dict) and 'tags' in data:
            format_name = data.get('format', 'phone')
            data = data['tags']
        if isinstance(data, dict):
            rows = list(data.items())
        elif isinstance(data, list):
            if not all(isinstance(row, dict) and set(row) >= {'uid', 'kind'} for row in data):
                raise ValueError('В каждой строке JSON нужны uid и kind.')
            rows = [(row['uid'], row['kind']) for row in data]
        else:
            raise ValueError('JSON должен содержать таблицу UID → значение.')
    else:
        rows = []
        for number, line in enumerate(source.splitlines(), 1):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = re.split(r'[;=,\t]', line)
            if len(parts) != 2:
                raise ValueError('Строка %d: используйте UID;значение.' % number)
            if parts[0].strip().lower() == 'uid':
                continue
            rows.append(parts)
    if format_name not in ('phone', 'reader'):
        raise ValueError('Формат UID должен быть phone или reader.')
    if not rows or len(rows) > MAX_TAGS:
        raise ValueError('Нужно от 1 до 1000 меток.')
    result = {}
    for position, (uid, kind) in enumerate(rows, 1):
        try:
            key = phone_uid(uid) if format_name == 'phone' else normalize_uid(uid)
            kind = tag_kind(kind)
        except ValueError as exc:
            raise ValueError('Метка %d: %s' % (position, exc)) from None
        if key in result and result[key] != kind:
            raise ValueError('Одна метка указана с разными значениями: ' + str(uid))
        result[key] = kind
    return result


def export_tags(tags):
    return json.dumps({'format': 'reader', 'tags': tags}, ensure_ascii=False, indent=2) + '\n'
