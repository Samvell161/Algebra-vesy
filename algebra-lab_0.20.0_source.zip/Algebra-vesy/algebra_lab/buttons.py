"""Optional active-low dry-contact inputs; no GUI calls in the worker."""
import threading
import time

PINS = {13: "add", 26: "remove"}  # BCM, physical header pins 33 and 37.


class Debouncer:
    def __init__(self, seconds=.06):
        self.seconds = seconds
        self.state = {pin: {"raw": None, "since": 0, "stable": None, "armed": False} for pin in PINS}

    def sample(self, levels, now):
        events = []
        for pin, state in self.state.items():
            value = bool(levels[pin])
            if value != state["raw"]:
                state["raw"], state["since"] = value, now
            if now - state["since"] >= self.seconds:
                if state["stable"] != value:
                    state["stable"] = value
                    if value:
                        state["armed"] = True
                    elif state["armed"]:
                        state["armed"] = False
                        events.append({"type": "button", "operation": PINS[pin], "pin": pin})
        if not any(levels.values()):
            # Pressing both has no special command; release both and choose one.
            for state in self.state.values():
                state["armed"] = False
            return []
        return events


class Buttons:
    def __init__(self, emit, enabled=False):
        self.emit, self.enabled, self.error = emit, False, None
        self.connected = False
        self.levels = {}
        self.stop = threading.Event()
        self.thread = None
        self.configure(enabled)

    def configure(self, enabled):
        self.close()
        if self.thread and self.thread.is_alive():
            raise OSError("Опрос кнопок ещё завершается.")
        self.enabled, self.error, self.connected = bool(enabled), None, False
        self.levels = {}
        self.stop = threading.Event()
        if self.enabled:
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()

    def _run(self):
        gpio, owned = None, []
        try:
            import RPi.GPIO as gpio
            gpio.setmode(gpio.BCM)
            for pin in PINS:
                gpio.setup(pin, gpio.IN, pull_up_down=gpio.PUD_UP)
                owned.append(pin)
            self.connected = True
            debounce = Debouncer()
            while not self.stop.wait(.025):
                self.levels = {pin: bool(gpio.input(pin)) for pin in PINS}
                for event in debounce.sample(self.levels, time.monotonic()):
                    self.emit(event)
        except Exception as exc:
            self.error = "Кнопки недоступны: " + str(exc)
        finally:
            self.connected = False
            if gpio and owned:
                gpio.cleanup(owned)

    def status(self):
        return {"enabled": self.enabled, "connected": self.connected, "error": self.error,
                "levels": self.levels.copy()}

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=.3)
