"""Lightweight interactive balance: bounded vector items and finite animations."""
import math
import tkinter as tk
from fractions import Fraction

BG, INK, PURPLE = '#eef0ff', '#233254', '#6451d8'
CYAN, GOLD, CORAL, TEAL = '#70c8f3', '#ffc454', '#ff827b', '#31a59c'


def symbolic_tilt(committed, preview):
    solution = committed.solution()
    if solution['kind'] != 'one':
        return 0
    value = Fraction(solution['value'])
    left, right = preview.left.at(value), preview.right.at(value)
    return 0 if left == right else (5 if right > left else -5)


class BalanceCanvas(tk.Canvas):
    FRAMES = 8
    FRAME_MS = 32

    def __init__(self, parent, left, right, selected=None, tilt=0, initial=0,
                 motion=True, won=False, height=230, on_select=None, font_family="DejaVu Sans"):
        super().__init__(parent, background=BG, highlightthickness=0, height=height)
        self.left, self.right = left, right
        self.font_family = font_family
        self.selected, self.won, self.on_select = selected, won, on_select
        self.target = max(-5, min(5, tilt))
        self.angle = initial if motion else self.target
        self.start_angle = self.angle
        self.frame, self.timer = 0, None
        self.items, self.buttons = {}, None
        self.bind('<Configure>', self.build)
        self.bind('<Button-1>', self.select)
        if motion and abs(self.target - self.angle) > .05:
            self.timer = self.after(self.FRAME_MS, self.animate)

    def attach_controls(self, left, right):
        self.buttons = (left, right)
        self.build()

    def select(self, event):
        if self.on_select:
            side = 'left' if event.x < self.winfo_width() / 2 else 'right'
            self.on_select(side)

    def blocks(self, expression):
        result = []
        for count, plus, minus in [(expression.a, 'x', '−x'), (expression.b, '+1', '−1')]:
            if count.denominator != 1 or abs(count) > 10:
                return [str(expression)]
            result.extend([plus if count > 0 else minus] * abs(int(count)))
        return result if len(result) <= 10 else [str(expression)]

    def build(self, event=None):
        self.delete('all')
        self.items = {}
        w, h = max(400, self.winfo_width()), max(130, self.winfo_height())
        self.cx, self.arm = w / 2, w * .285
        offset = self.arm * math.sin(math.radians(5))
        self.cy = max(h * .25, 45 + offset)
        self.hang = max(36, h - 42 - self.cy - offset)
        self.pan_width = min(w * .185, 185)
        self.create_oval(self.cx - 95, h - 22, self.cx + 95, h - 3, fill='#dbe1f5', outline='')
        self.create_polygon(self.cx, self.cy - 8, self.cx - 27, h - 23, self.cx + 27, h - 23,
                            fill=TEAL, outline='')
        self.create_polygon(self.cx, self.cy - 8, self.cx, h - 23, self.cx + 27, h - 23,
                            fill='#26877f', outline='')
        self.create_line(self.cx - 65, h - 20, self.cx + 65, h - 20, width=13, fill=PURPLE, capstyle='round')
        self.items['beam'] = self.create_line(0, 0, 0, 0, width=10, fill=PURPLE, capstyle='round')
        self.pan_centers = {}
        for side, expr, direction in [('left', self.left, -1), ('right', self.right, 1)]:
            x, y = self.cx + direction * self.arm, self.cy + self.hang
            self.pan_centers[side] = (x, y)
            tag = 'pan-' + side
            color = CYAN if side == 'left' else CORAL
            if side == self.selected:
                self.create_oval(x - self.pan_width - 5, y - 12, x + self.pan_width + 5, y + 36,
                                 outline=PURPLE, width=3, tags=tag)
            self.items[side + '-chains'] = [self.create_line(0, 0, 0, 0, fill='#6e7caa', width=2) for _ in range(2)]
            self.create_arc(x - self.pan_width, y - 10, x + self.pan_width, y + 30,
                            start=180, extent=180, fill=color, outline=PURPLE, width=2, tags=tag)
            self.create_line(x - self.pan_width, y + 10, x + self.pan_width, y + 10,
                             fill=PURPLE, width=4, capstyle='round', tags=tag)
            pieces = self.blocks(expr)
            if not pieces:
                self.create_text(x, y - 10, text='Пусто', fill='#64749a', font=(self.font_family, 12), tags=tag)
            for index, text in enumerate(pieces):
                count = min(5, len(pieces))
                row, col = index // 5, index % 5
                width = 51 if len(text) <= 2 else min(240, self.pan_width * 1.7)
                px = x + (col - (count - 1) / 2) * 57
                py = y + 8 - row * 48
                block_color = CORAL if '−' in text else (CYAN if 'x' in text else GOLD)
                self.create_rectangle(px - width / 2, py - 44, px + width / 2, py,
                                      fill=block_color, outline='#ffffff', width=2, tags=tag)
                self.create_line(px - width / 2 + 5, py - 39, px + width / 2 - 5, py - 39,
                                 fill='#ffffff', width=2, tags=tag)
                self.create_text(px, py - 20, text=text, fill=INK,
                                 font=(self.font_family, 21 if len(text) <= 2 else 14, 'bold'), tags=tag)
        self.create_oval(self.cx - 13, self.cy - 13, self.cx + 13, self.cy + 13,
                         fill=GOLD, outline='#ffffff', width=3)
        self.create_text(self.cx, self.cy, text='✓' if self.won else '•', fill=PURPLE, font=(self.font_family, 15, 'bold'))
        if self.won:
            for dx, dy in [(-40, 7), (40, 7), (0, 45)]:
                self.create_text(self.cx + dx, self.cy + dy, text='★', fill=GOLD, font=(self.font_family, 20))
        if self.buttons:
            for side, button in zip(('left', 'right'), self.buttons):
                x = self.pan_centers[side][0]
                self.create_window(x, 22, window=button, width=min(350, w * .40), height=43)
        else:
            for side, text in [('left', 'ЛЕВАЯ'), ('right', 'ПРАВАЯ')]:
                self.create_text(self.pan_centers[side][0], 17, text=text, fill=INK, font=(self.font_family, 11, 'bold'))
        self.pose()

    def pose(self):
        if not self.items:
            return
        radians = math.radians(self.angle)
        ends = []
        for side, direction in [('left', -1), ('right', 1)]:
            x = self.cx + direction * self.arm * math.cos(radians)
            y = self.cy + direction * self.arm * math.sin(radians)
            ends.extend([x, y])
            center = (x, y + self.hang)
            old = self.pan_centers[side]
            self.move('pan-' + side, center[0] - old[0], center[1] - old[1])
            self.pan_centers[side] = center
            for chain, edge in zip(self.items[side + '-chains'], [-1, 1]):
                self.coords(chain, x, y, center[0] + edge * self.pan_width, center[1] + 10)
        self.coords(self.items['beam'], *ends)

    def animate(self):
        self.timer = None
        self.frame += 1
        t = min(1, self.frame / self.FRAMES)
        eased = 1 - (1 - t) ** 3
        self.angle = self.start_angle + (self.target - self.start_angle) * eased
        self.pose()
        if t < 1:
            self.timer = self.after(self.FRAME_MS, self.animate)

    def destroy(self):
        if self.timer is not None:
            self.after_cancel(self.timer)
            self.timer = None
        super().destroy()
