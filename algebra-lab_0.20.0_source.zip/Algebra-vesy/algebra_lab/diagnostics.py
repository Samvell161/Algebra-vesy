"""Read-only boot/SPI inspection and bounded hardware check, without Tk windows."""
import json
import subprocess
import time
from pathlib import Path
from .hardware import Reader
from .buttons import Buttons


def boot_info(root=Path('/')):
    root = Path(root)
    candidates = [root/'boot/firmware/config.txt', root/'boot/config.txt']
    config = next((path for path in candidates if path.is_file()), None)
    overlay = next((path for path in [root/'boot/firmware/overlays/spi1-1cs.dtbo',
                                      root/'boot/overlays/spi1-1cs.dtbo'] if path.is_file()), None)
    return {"config": str(config) if config else None, "spi1_overlay": str(overlay) if overlay else None,
            "devices": sorted(str(path) for path in (root/'dev').glob('spidev*')),
            "spi1_line": "dtoverlay=spi1-1cs" if overlay else None}


def check(mode='rc522_dual', buttons=False, seconds=8):
    print(json.dumps(boot_info(), ensure_ascii=False, indent=2), flush=True)
    try:
        result = subprocess.run(['vcgencmd','get_throttled'], stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, universal_newlines=True, timeout=2)
        print(result.stdout.strip(), flush=True)
    except (OSError, subprocess.TimeoutExpired):
        print('vcgencmd недоступен; питание этим тестом не проверено.', flush=True)
    reader = Reader(mode)
    inputs = Buttons(reader.emit, buttons)
    sequence = 0
    try:
        deadline = time.monotonic() + min(30, max(1, seconds))
        print('Подносите по одной метке к каждой чаше; убирайте между чтениями. Для кнопок сначала отпустите обе.', flush=True)
        while time.monotonic() < deadline:
            time.sleep(.1)
            for event in reader.since(sequence):
                sequence = event['sequence']
                print(json.dumps(event, ensure_ascii=False), flush=True)
        print(json.dumps({'readers': reader.status(), 'buttons': inputs.status()}, ensure_ascii=False, indent=2), flush=True)
    finally:
        inputs.close()
        reader.close()
