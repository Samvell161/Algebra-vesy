'use strict';

const $ = (query, root = document) => root.querySelector(query);
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const paths = {
  arrow: 'M4 12h16m-6-6 6 6-6 6', play: 'm9 5 11 7-11 7Z',
  book: 'M4 4h6l2 2 2-2h6v15h-6l-2 2-2-2H4Zm8 2v15',
  lab: 'M9 3h6m-5 0v6l-6 10q-1 2 2 2h12q3 0 2-2L14 9V3M7 15h10',
  chart: 'M5 20V10m7 10V4m7 16v-7', check: 'm5 12 4 4L19 6',
  bulb: 'M9 19h6m-5 3h4M8 15a7 7 0 1 1 8 0l-1 1H9Z',
  undo: 'M8 4 3 9l5 5M3 9h11a6 6 0 0 1 0 12',
  clock: 'M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
  star: 'm12 3 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z',
  close: 'm6 6 12 12M6 18 18 6', settings: 'M12 8v8m-4-4h8M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0'
};
const icon = (name, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.arrow}"/></svg>`;
const state = {page:'home', data:null, filter:0, side:'left', hint:'', busy:false, eventSequence:0, lastUID:'', clockEnd:0, expiring:false, drafts:{}, keypadTarget:''};

async function api(path, data) {
  const response = await fetch(path, data === undefined ? {} : {method:'POST', headers:{'Content-Type':'application/json','X-Lab-Request':'1'}, body:JSON.stringify(data)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Не удалось выполнить запрос.');
  return result;
}
let toastTimer;
function toast(message, error = false) {
  const element = $('#toast');
  element.textContent = message;
  element.className = `visible ${error ? 'error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.className = '', 5500);
}
function settingsApply() {
  const prefs = state.data.settings;
  document.body.classList.toggle('no-motion', !prefs.motion);
  document.body.classList.toggle('high-contrast', prefs.contrast);
  $('#profile-name').textContent = prefs.name;
  $('.avatar').textContent = prefs.name[0].toUpperCase();
  const hw = state.data.hardware;
  $('#device-status').textContent = hw.mode === 'simulator' ? 'Симулятор · оборудование не требуется' : hw.connected ? 'RC522 · последовательная регистрация' : 'RC522 · нет подключения';
}
function starString(count) { return `<span class="stars" aria-label="${count} из 3 звёзд">${'★'.repeat(count)}<span>${'☆'.repeat(3-count)}</span></span>`; }
function nextTask() { return state.data.tasks.find(task => !state.data.progress.best[task.id]) || state.data.tasks[0]; }
function taskCard(task, index) {
  const best = state.data.progress.best[task.id] || 0;
  return `<button class="task-card ${best ? 'task-done' : ''}" data-action="start" data-id="${task.id}"><span class="task-top"><span class="task-number">${String(index+1).padStart(2,'0')}</span><span class="level">Уровень ${task.level}</span>${best ? icon('check') : icon('arrow')}</span><strong>${esc(task.title)}</strong><span class="task-equation">${esc(task.equation.replaceAll('*','·').replaceAll('-','−'))}</span><span class="task-bottom"><span>${icon('clock')}${task.minutes} мин</span>${best ? starString(best) : `<span>${esc(task.skill)}</span>`}</span></button>`;
}
function balance(left = 'x + 3', right = '7', tilt = 0, hero = false) {
  return `<svg class="balance ${hero ? 'hero-balance' : ''} tilt-${tilt < 0 ? 'left' : tilt > 0 ? 'right' : 'none'}" viewBox="0 0 600 290" role="img" aria-label="Весы: слева ${esc(left)}, справа ${esc(right)}">
    <defs><pattern id="dots" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="#97b3a3" opacity=".35"/></pattern></defs>
    <rect width="600" height="290" fill="url(#dots)"/>
    <ellipse cx="300" cy="270" rx="173" ry="10" fill="#1d5146" opacity=".07"/>
    <path d="M275 250 292 104h16l17 146" fill="#c1cec3"/><rect x="241" y="250" width="118" height="15" rx="7" fill="#205c50"/>
    <g class="beam"><rect x="115" y="91" width="370" height="12" rx="6" fill="#205c50"/><circle cx="300" cy="97" r="14" fill="#e9ab60"/><circle cx="300" cy="97" r="5" fill="#fff8e9"/>
      <path d="m134 103-66 100m66-100 66 100m266-100-66 100m66-100 66 100" stroke="#879c8d" stroke-width="3" fill="none"/>
      <path d="M60 204h148q-8 29-74 29t-74-29m332 0h148q-8 29-74 29t-74-29" fill="#205c50"/>
      <rect x="77" y="148" width="114" height="53" rx="10" fill="#e6b86b"/><rect x="409" y="148" width="114" height="53" rx="10" fill="#b7c8e5"/>
      <text x="134" y="183" text-anchor="middle" class="scale-label">${esc(left)}</text><text x="466" y="183" text-anchor="middle" class="scale-label">${esc(right)}</text>
    </g>
  </svg>`;
}
function home() {
  const {progress, settings} = state.data;
  const task = nextTask();
  return `<div class="page-heading"><div class="eyebrow"><span class="tiny-line"></span>ОТКРЫВАЙ. ПРОБУЙ. ПОНИМАЙ.</div><span class="session-note">Твоя маленькая научная лаборатория</span></div>
  <section class="hero">
    <div class="hero-copy"><span class="pill"><span class="status-dot"></span>Математика становится осязаемой</span><h1>Уравнения, которые<br>можно <em>потрогать.</em></h1><p>Собирай, уравновешивай, открывай закономерности.<br class="desktop-br"> Здесь каждый блок помогает понять алгебру.</p><div class="hero-actions"><button class="button primary" data-action="start" data-id="${task.id}">${progress.completed ? 'Продолжить практику' : 'Начать исследование'}${icon('arrow')}</button><a class="text-link" href="#lab">Свободный эксперимент ${icon('lab')}</a></div><div class="hero-proof"><span class="overlap-avatars"><i>x</i><i>+</i><i>=</i></span><span>Без страха ошибок.<br><strong>В своём темпе.</strong></span></div></div>
    <div class="hero-visual"><div class="visual-top"><span>ЭКСПЕРИМЕНТ № 001</span><span class="handwritten">всё начинается с баланса</span></div>${balance('x + 3','7',0,true)}<div class="visual-bottom"><span class="mini-block">x</span><span>Один неизвестный.<br><strong>Много открытий.</strong></span><span class="equation-pill">x + 3 = 7</span></div><span class="visual-spark">✳</span></div>
  </section>
  <section class="journey-row"><div class="journey-intro"><span class="icon-tile">${icon('book')}</span><div><strong>Привет, ${esc(settings.name)}!</strong><p>Немного практики — большое открытие.</p></div></div><div class="daily-goal"><div><strong>Цель: первые 3 задания</strong><span>${Math.min(3,progress.completed)} / 3</span></div><progress max="3" value="${Math.min(3,progress.completed)}" aria-label="Цель: первые три задания"></progress></div><a class="text-link" href="#progress">Мои достижения ${icon('arrow')}</a></section>
  <div class="section-heading"><div><span class="eyebrow">ШАГ ЗА ШАГОМ</span><h2>Маленькие шаги. Настоящие открытия.</h2></div><a class="text-link" href="#practice">Все задания ${icon('arrow')}</a></div>
  <div class="task-grid">${state.data.tasks.slice(0,3).map(taskCard).join('')}</div>
  <section class="explore-banner"><span class="explore-symbol">✳</span><div><strong>А что, если изменить одну чашу?</strong><p>Проверь свою идею в лаборатории. Здесь можно экспериментировать без ограничений по времени.</p></div><a class="button secondary" href="#lab">В лабораторию ${icon('arrow')}</a></section>`;
}
function practice() {
  const tasks = state.data.tasks.filter(task => !state.filter || task.level === state.filter);
  return `<div class="section-heading page-title"><div><span class="eyebrow">УЧИМСЯ НА ПРАКТИКЕ</span><h1>Каждое уравнение — открытие.</h1><p>Делай одинаковые действия с обеими частями и находи x.</p></div><button class="button challenge-button" data-action="challenge">${icon('clock')}Вызов на 3 минуты</button></div><div class="filter-row" role="group" aria-label="Уровень сложности">${[0,1,2,3,4].map(level => `<button class="filter ${state.filter === level ? 'selected' : ''}" data-action="filter" data-level="${level}" aria-pressed="${state.filter === level}">${level ? `Уровень ${level}` : 'Все задания'}</button>`).join('')}<span>${state.data.progress.completed} из ${state.data.tasks.length} пройдено</span></div><div class="task-grid practice-grid">${tasks.map(task => taskCard(task,state.data.tasks.indexOf(task))).join('')}</div>`;
}
function exercise() {
  const ex = state.data.exercise;
  if (!ex) return `<div class="empty-state">${icon('book')}<h1>Выберите первое задание</h1><a class="button primary" href="#practice">Перейти к практике ${icon('arrow')}</a></div>`;
  const done = ex.completed;
  const expired = ex.expired;
  const eq = ex.equation;
  return `<div class="exercise-top"><a class="text-link" href="#practice">← К заданиям</a><span class="pill">Уровень ${ex.task.level} · ${esc(ex.task.skill)}</span><span>${ex.mode === 'challenge' ? `${icon('clock')} <strong data-clock>${timeText(ex.remaining)}</strong>` : 'Практика без спешки'}</span></div>
  <div class="exercise-heading"><div><span class="eyebrow">ИССЛЕДОВАНИЕ ${String(state.data.tasks.findIndex(t=>t.id===ex.task.id)+1).padStart(2,'0')}</span><h1>${esc(ex.task.title)}</h1></div><button class="button secondary" data-action="restart">${icon('undo')}Заново</button></div>
  <div class="exercise-layout"><section class="equation-stage"><div class="stage-note"><span class="status-dot"></span>${done ? 'Решение найдено' : 'Применяй одно действие к обеим частям'}</div><div class="big-equation"><span>${esc(eq.left)}</span><b>=</b><span>${esc(eq.right)}</span></div>${balance(eq.left,eq.right)}<div class="stage-caption">Схема уравнения · не показание датчика массы</div>
  ${done ? `<div class="success-panel">${icon('check')}<div><strong>Отлично! x = ${esc(eq.solution.value.replace('-','−'))}</strong><p>Ответ проверен точной подстановкой.</p></div>${starString(ex.stars)}<button class="button primary" data-action="next">Дальше ${icon('arrow')}</button></div>` : expired ? `<div class="success-panel timeout"><div><strong>Время вышло</strong><p>Можно попробовать снова или решать без таймера.</p></div><button class="button primary" data-action="restart">Ещё раз</button><button class="button secondary" data-action="untimed">Без таймера</button></div>` : `<form id="answer-form" class="answer-form"><label for="answer">Уже знаешь ответ? <strong>x =</strong></label><input id="answer" name="answer" placeholder="например, 4" autocomplete="off" required aria-label="Значение x"><button class="button secondary" type="submit">Проверить ${icon('check')}</button></form>`}</section>
  <aside class="operations-panel"><h2>Сохраним равенство</h2><p>Что сделаем с обеими частями?</p><form id="operation-form"><div class="operation-grid">${[['add','+','Прибавить'],['subtract','−','Вычесть'],['multiply','×','Умножить'],['divide','÷','Разделить']].map(([value,symbol,label],i)=>`<label class="operation-choice"><input type="radio" name="operation" value="${value}" ${i===1?'checked':''} ${done||expired?'disabled':''}><span><b>${symbol}</b>${label}</span></label>`).join('')}</div><label class="field-label" for="operand">Число или выражение с x <small>Для × и ÷ — только число</small></label><input id="operand" name="value" placeholder="Например, 3 или x" required autocomplete="off" ${done||expired?'disabled':''}><button type="submit" class="button primary full" ${done||expired?'disabled':''}>Применить к обеим частям ${icon('arrow')}</button></form><div class="operation-extras"><button data-action="hint" ${done||expired?'disabled':''}>${icon('bulb')}Подсказка</button><button data-action="undo" ${done||expired||ex.history.length<2?'disabled':''}>${icon('undo')}Отменить</button></div>${state.hint ? `<div class="hint-box" role="status">${icon('bulb')}<p>${esc(state.hint)}</p></div>` : '<p class="hint-note">Подсказки помогают учиться.<br>Без подсказок — три звезды за задание.</p>'}</aside></div>
  <section class="history"><h2>Путь к решению <span>${ex.history.length-1} шагов</span></h2><ol>${ex.history.map((step,i)=>`<li><span class="history-index">${i}</span><span>${esc(step.label)}</span><strong>${esc(step.left)} = ${esc(step.right)}</strong></li>`).join('')}</ol></section>`;
}
function lab() {
  const lab = state.data.lab, hardware = state.data.hardware;
  const sim = hardware.mode === 'simulator';
  return `<div class="section-heading page-title"><div><span class="eyebrow">ПРОВЕРЯЙ СВОИ ГИПОТЕЗЫ</span><h1>Твоя лаборатория.</h1><p>${sim ? 'Добавляй виртуальные блоки по одному. Экспериментируй с обеими чашами.' : 'Поднеси одну метку к RC522, убери её и перенеси блок на выбранную чашу.'}</p></div><button class="button secondary" data-action="clear-lab">Очистить чаши ${icon('undo')}</button></div>
  <div class="lab-layout"><section class="lab-stage"><div class="lab-state"><span class="pill">${sim ? 'СИМУЛЯТОР БЛОКОВ' : 'RC522 · ОДНА МЕТКА ЗА РАЗ'}</span><span class="balance-status ${lab.balanced?'is-balanced':''}">${lab.balanced ? 'Равенство при выбранном x' : 'Значения отличаются'}</span></div><div class="lab-equation">${esc(lab.equation.left)} <b>=</b> ${esc(lab.equation.right)}</div>${balance(lab.equation.left,lab.equation.right,lab.tilt)}<div class="trays">${['left','right'].map(side=>`<section class="tray ${state.side===side?'active-tray':''}"><button class="tray-select" data-action="side" data-side="${side}" aria-pressed="${state.side===side}">${side==='left'?'Левая':'Правая'} чаша <span>${state.side===side?'Выбрана для регистрации':'Выбрать'}</span></button><div class="tray-blocks">${lab.blocks[side].length ? lab.blocks[side].map(block=>`<button class="physical-block ${block.kind.includes('x')?'variable':'constant'}" data-action="remove-block" data-uid="${esc(block.uid)}" aria-label="Удалить блок ${esc(state.data.blocks[block.kind].label)} ${esc(block.uid)}" title="${esc(block.uid)} · удалить">${esc(state.data.blocks[block.kind].label)}<small>×</small></button>`).join('') : '<span class="tray-empty">Пока без блоков</span>'}</div></section>`).join('')}</div><form id="x-form" class="answer-form"><label for="lab-x">Посмотрим при <strong>x =</strong></label><input id="lab-x" name="value" value="${esc(lab.x)}" required aria-label="Пробное значение x"><button class="button secondary" type="submit">Подставить</button><span class="substitution">${lab.left_value} ${lab.balanced?'=':'≠'} ${lab.right_value}</span></form><p class="stage-caption">Наклон показывает сравнение выражений при выбранном x. Это не измерение массы.</p></section>
  <aside class="operations-panel"><h2>${sim?'Палитра блоков':'Регистрация блоков'}</h2><p>Добавляем на <strong>${state.side==='left'?'левую':'правую'} чашу</strong></p>${sim?`<div class="block-palette">${Object.entries(state.data.blocks).map(([kind,block])=>`<button class="palette-block ${kind.includes('x')?'variable':'constant'}" data-action="sim-block" data-kind="${kind}"><b>${esc(block.label)}</b><span>Добавить</span></button>`).join('')}</div>`:`<div class="reader-notice">${icon('lab')}<strong>${hardware.connected?'Считыватель готов':'Считыватель недоступен'}</strong><p>${esc(hardware.error || 'Выбери чашу и поднеси один блок. Повторное чтение не добавляет его второй раз.')}</p></div>`}<div class="registration-note">${icon('bulb')}<p>Блоки регистрируются по одному. Чтобы перенести блок, сначала удали его с текущей чаши.</p></div><button class="button secondary full" data-action="tags">Настроить RFID-метки ${icon('settings')}</button><div class="lab-solution"><span class="eyebrow">МАТЕМАТИЧЕСКИЙ ВЫВОД</span><strong>${solutionText(lab.equation.solution)}</strong><p>HX711 не подключён. Масса не используется для проверки уравнения.</p></div></aside></div>
  <section class="custom-equation"><div><h2>Проверь своё уравнение</h2><p>Линейные выражения, скобки и точные дроби.</p></div><form id="custom-form"><label class="sr-only" for="custom-equation">Своё уравнение</label><input name="equation" id="custom-equation" placeholder="2(x + 3) = 16" required><button class="button primary" type="submit">Исследовать ${icon('arrow')}</button></form><div id="custom-result" role="status"></div></section>`;
}
function solutionText(solution) { return solution.kind==='one' ? `Равенство при x = ${esc(solution.value.replace('-','−'))}` : solution.kind==='all' ? 'Равенство при любом x' : 'Уравнение не имеет решений'; }
function progressPage() {
  const {progress,tasks} = state.data;
  const achievements = [
    ['Первое открытие','Реши первое уравнение',progress.completed>=1,'✦'],
    ['В ритме науки','Пройди 3 разных задания',progress.completed>=3,'↗'],
    ['Без подсказок','Получи три звезды за задание',Object.values(progress.best).includes(3),'★'],
    ['Мастер равновесия',`Пройди все ${tasks.length} заданий`,progress.completed>=tasks.length,'⚖']
  ];
  return `<div class="section-heading page-title"><div><span class="eyebrow">КАЖДЫЙ ШАГ ИМЕЕТ ЗНАЧЕНИЕ</span><h1>Твои открытия в цифрах.</h1><p>Прогресс хранится на этом устройстве. Можно вернуться в любой момент.</p></div><a class="button primary" href="#practice">Продолжить ${icon('arrow')}</a></div><div class="stats-grid"><div><span>Пройдено заданий</span><strong>${progress.completed}<small> / ${tasks.length}</small></strong><progress max="${tasks.length}" value="${progress.completed}" aria-label="Пройдено заданий"></progress></div><div><span>Звёзды за лучшие решения</span><strong>${progress.stars}<small> / ${tasks.length*3} ★</small></strong></div><div><span>Успешных решений</span><strong>${progress.attempts.length}</strong></div><div><span>Время успешных попыток</span><strong>${Math.floor(progress.total_seconds/60)}<small> мин</small></strong></div></div><div class="section-heading"><h2>Коллекция достижений</h2><span>${achievements.filter(a=>a[2]).length} / 4 открыто</span></div><div class="achievement-grid">${achievements.map(([name,description,unlocked,symbol])=>`<div class="achievement ${unlocked?'unlocked':''}"><span class="achievement-symbol">${symbol}</span><strong>${name}</strong><p>${description}</p><span class="achievement-label">${unlocked?'Получено ✓':'Пока впереди'}</span></div>`).join('')}</div><section class="history"><h2>Последние решения</h2>${progress.attempts.length ? `<ol>${progress.attempts.slice(0,15).map(attempt=>`<li><span class="history-index">${icon('check')}</span><span><strong>${esc(tasks.find(t=>t.id===attempt.task_id)?.title || attempt.task_id)}</strong><small>${attempt.mode==='challenge'?'Вызов':'Практика'} · ${attempt.steps} шагов · ${attempt.hints} подсказок · ${timeText(attempt.seconds)}</small></span>${starString(attempt.stars)}<span>${new Date(attempt.completed_at).toLocaleDateString('ru-RU')}</span></li>`).join('')}</ol>` : '<div class="empty-history">Здесь появится история твоих решений. Начни с первого уравнения — x + 3 = 7.</div>'}</section>`;
}
function timeText(seconds) { return `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`; }
function render() {
  if (!state.data) return;
  document.body.dataset.page=state.page;
  settingsApply();
  const renderers = {home,practice,exercise,lab,progress:progressPage};
  $('#app').innerHTML = (renderers[state.page] || home)();
  // A scan or queued request must not erase an answer being typed on the touchscreen.
  for (const id of ['lab-x','custom-equation','operand','answer']) {
    if ($('#'+id) && Object.hasOwn(state.drafts,id)) $('#'+id).value=state.drafts[id];
    const input = $('#'+id);
    if (input) {
      const wrap=document.createElement('span');
      wrap.className='input-wrap';
      input.replaceWith(wrap);
      wrap.append(input);
      const key=document.createElement('button');
      key.type='button';
      key.className='keypad-toggle';
      key.dataset.action='keypad';
      key.dataset.target=id;
      key.setAttribute('aria-label',`Экранная клавиатура: ${input.getAttribute('aria-label') || input.placeholder}`);
      key.textContent='⌨';
      key.disabled=input.disabled;
      wrap.append(key);
    }
  }
  if (state.drafts.operation && $(`#operation-form [value="${state.drafts.operation}"]`)) $(`#operation-form [value="${state.drafts.operation}"]`).checked=true;
  document.querySelectorAll('nav a').forEach(a => {
    const active = a.dataset.page === (state.page==='exercise'?'practice':state.page);
    a.classList.toggle('active',active);
    if (active) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
  });
  document.title = `${({home:'Главная',practice:'Практика',exercise:'Решение',lab:'Лаборатория',progress:'Мой прогресс'})[state.page] || 'Главная'} · Алгебра LAB`;
}
function route() {
  state.page = location.hash.slice(1) || 'home';
  render();
  window.scrollTo(0,0);
}
function showModal(html) {
  const modal = $('#modal');
  $('#modal-content').innerHTML = `<button class="modal-close" data-action="close-modal" aria-label="Закрыть">${icon('close')}</button>${html}`;
  if (!modal.open) modal.showModal();
}
function helpModal() {
  showModal(`<span class="eyebrow">ЛАБОРАТОРИЯ РАВНОВЕСИЯ</span><h2>Здесь всё можно понять.</h2><div class="help-step"><b>01</b><div><h3>Равенство — это баланс</h3><p>Левая и правая части имеют одинаковое значение при решении уравнения. Блок x — неизвестное число, которое предстоит найти.</p></div></div><div class="help-step"><b>02</b><div><h3>Одно действие — две стороны</h3><p>Прибавляй или вычитай одно и то же выражение с обеих сторон. Умножать и делить можно на одно и то же ненулевое число. Попробуй x + 3 = 7: вычти 3 с обеих сторон.</p></div></div><div class="help-step"><b>03</b><div><h3>Физические блоки — по одному</h3><p>Выбери чашу, поднеси одну метку к RC522 и убери её из зоны чтения. Программа ведёт реестр блоков, а не считывает всю чашу. При снятии или переносе блока обнови реестр кнопкой на экране.</p></div></div><p class="notice">Наклон в лаборатории вычисляется по выражениям при выбранном x. HX711 — отдельный измерительный модуль; он не определяет правильность решения.</p><button class="button primary full" data-action="help-try">Попробовать в лаборатории ${icon('arrow')}</button>`);
}
function settingsModal() {
  const prefs = state.data.settings, hw = state.data.hardware;
  showModal(`<span class="eyebrow">ТВОЯ ЛАБОРАТОРИЯ</span><h2>Настроим под тебя</h2><form id="settings-form"><label class="field-label" for="learner-name">Как тебя называть?</label><input id="learner-name" name="name" value="${esc(prefs.name)}" maxlength="32" required><label class="toggle-row"><span><strong>Анимация интерфейса</strong><small>Плавные переходы и движение весов</small></span><input type="checkbox" name="motion" ${prefs.motion?'checked':''}></label><label class="toggle-row"><span><strong>Повышенный контраст</strong><small>Более заметные границы и текст</small></span><input type="checkbox" name="contrast" ${prefs.contrast?'checked':''}></label><button class="button primary full" type="submit">Сохранить настройки ${icon('check')}</button></form><hr><div class="device-line"><span><strong>Оборудование</strong><small>${hw.mode==='simulator'?'Симулятор включён':hw.connected?'RC522 подключён':'RC522 недоступен'} · HX711 не настроен</small></span><button class="button secondary" data-action="tags">RFID-метки</button></div>${hw.error?`<p class="notice">${esc(hw.error)}</p>`:''}<p class="privacy-note">Один локальный профиль. Имя, результаты и метки хранятся только на этом устройстве, без облачной отправки.</p><button class="danger-link" data-action="reset-confirm">Сбросить учебный прогресс</button>`);
}
function tagsModal() {
  const tags = state.data.tags;
  showModal(`<span class="eyebrow">ПОСЛЕДОВАТЕЛЬНАЯ РЕГИСТРАЦИЯ</span><h2>Паспорт RFID-блоков</h2><p>Свяжи UID с математическим блоком. Держи в зоне RC522 только одну метку.</p><p id="last-uid" class="notice">${state.lastUID ? `Последняя метка: ${esc(state.lastUID)}` : 'Метка появится здесь после чтения RC522. В симуляторе UID можно ввести вручную.'}</p><form id="tag-form"><label class="field-label" for="tag-uid">UID метки</label><input name="uid" id="tag-uid" value="${esc(state.lastUID)}" placeholder="Например, A1:B2:C3:D4" maxlength="64" required><label class="field-label" for="tag-kind">Значение блока</label><select name="kind" id="tag-kind">${Object.entries(state.data.blocks).map(([key,block])=>`<option value="${key}">${esc(block.label)}</option>`).join('')}</select><button class="button primary full" type="submit">Сохранить метку ${icon('check')}</button></form><div class="tag-list">${Object.entries(tags).map(([uid,kind])=>`<div><code>${esc(uid)}</code><strong>${esc(state.data.blocks[kind]?.label)}</strong><button data-action="unbind" data-uid="${esc(uid)}" aria-label="Удалить привязку ${esc(uid)}">${icon('close')}</button></div>`).join('') || '<p>Пока нет зарегистрированных меток.</p>'}</div><p class="privacy-note">UID идентифицирует блок, но не доказывает его наличие на чаше. Изменения реестра выполняются явно.</p>`);
}
function keypadModal(target) {
  const input=$('#'+target);
  if(!input) return;
  state.keypadTarget=target;
  const expression=target==='operand'||target==='custom-equation';
  const keys=expression ? ['7','8','9','+','−','4','5','6','×','÷','1','2','3','(',')','0','.','x','/','='] : ['7','8','9','4','5','6','1','2','3','−','0','/','.'];
  showModal(`<span class="eyebrow">СЕНСОРНЫЙ ВВОД</span><h2>${target==='custom-equation'?'Своё уравнение':'Число или выражение'}</h2><label class="sr-only" for="keypad-value">Ввод</label><input id="keypad-value" value="${esc(input.value)}" autocomplete="off"><div class="math-keypad ${expression?'expression-keys':'number-keys'}">${keys.map(key=>`<button data-action="keypad-key" data-key="${esc(key)}">${esc(key)}</button>`).join('')}</div><div class="keypad-tools"><button class="button secondary" data-action="keypad-clear">Очистить</button><button class="button secondary" data-action="keypad-back">⌫ Удалить</button></div><button class="button primary full" data-action="keypad-apply">Готово ${icon('check')}</button>`);
  $('#keypad-value').focus();
  $('#keypad-value').setSelectionRange(input.value.length,input.value.length);
}
async function updateExercise(ex) {
  state.data.exercise = ex;
  if (ex.mode==='challenge') state.clockEnd = Date.now()+ex.remaining*1000;
  if (ex.completed) state.data.progress = (await api('/api/bootstrap')).progress;
  if (location.hash !== '#exercise') location.hash = 'exercise'; else render();
}
async function startTask(id, mode='practice') {
  state.hint = '';
  delete state.drafts.operand;
  delete state.drafts.answer;
  delete state.drafts.operation;
  await updateExercise(await api('/api/exercise/start',{task_id:id,mode}));
}
let actionQueue = Promise.resolve();
function enqueue(work) {
  actionQueue = actionQueue.then(async () => {
    state.busy = true;
    try { await work(); }
    catch (error) { toast(error.message, true); }
    finally { state.busy = false; }
  });
}
document.addEventListener('click', event => {
  const button = event.target.closest('[data-action]');
  if (!button || button.disabled || !state.data) return;
  const action = button.dataset.action;
  enqueue(async () => {
    if (action==='start') await startTask(button.dataset.id);
    if (action==='challenge') await startTask(nextTask().id,'challenge');
    if (action==='filter') { state.filter=Number(button.dataset.level); render(); }
    if (action==='restart') await startTask(state.data.exercise.task.id,state.data.exercise.mode);
    if (action==='untimed') await startTask(state.data.exercise.task.id);
    if (action==='next') { const i=state.data.tasks.findIndex(t=>t.id===state.data.exercise.task.id); await startTask(state.data.tasks[(i+1)%state.data.tasks.length].id,state.data.exercise.mode); }
    if (action==='hint') { const result=await api('/api/exercise/hint',{}); state.hint=result.text; state.data.exercise.hints=result.hints; render(); }
    if (action==='undo') { state.hint=''; await updateExercise(await api('/api/exercise/undo',{})); }
    if (action==='side') { state.side=button.dataset.side; render(); }
    if (action==='sim-block') { state.data.lab=await api('/api/lab/simulate',{side:state.side,kind:button.dataset.kind}); render(); }
    if (action==='remove-block') { state.data.lab=await api('/api/lab/remove',{uid:button.dataset.uid}); render(); }
    if (action==='clear-lab') { state.data.lab=await api('/api/lab/clear',{}); render(); toast('Реестр чаш очищен. Уберите и физические блоки, если они использовались.'); }
    if (action==='help') helpModal();
    if (action==='settings') settingsModal();
    if (action==='tags') tagsModal();
    if (action==='keypad') keypadModal(button.dataset.target);
    if (action==='keypad-key') {
      const input=$('#keypad-value');
      const key=({'−':'-','×':'*','÷':'/'})[button.dataset.key] || button.dataset.key;
      input.setRangeText(key,input.selectionStart,input.selectionEnd,'end');
      input.focus();
    }
    if (action==='keypad-clear') { $('#keypad-value').value=''; $('#keypad-value').focus(); }
    if (action==='keypad-back') {
      const input=$('#keypad-value'), start=input.selectionStart, end=input.selectionEnd;
      input.setRangeText('',start===end?Math.max(0,start-1):start,end,'end'); input.focus();
    }
    if (action==='keypad-apply') {
      const input=$('#'+state.keypadTarget), value=$('#keypad-value').value;
      if(input) { input.value=value; state.drafts[state.keypadTarget]=value; }
      $('#modal').close();
      input?.focus({preventScroll:true});
    }
    if (action==='close-modal') $('#modal').close();
    if (action==='help-try') { $('#modal').close(); location.hash='lab'; }
    if (action==='unbind') { state.data.tags=await api('/api/tags/remove',{uid:button.dataset.uid}); tagsModal(); }
    if (action==='reset-confirm') showModal(`<span class="eyebrow">СБРОС ПРОГРЕССА</span><h2>Начать с чистого листа?</h2><p>История решений, звёзды и достижения будут удалены. Имя, настройки и RFID-метки сохранятся.</p><div class="modal-actions"><button class="button secondary" data-action="settings">Отмена</button><button class="button danger" data-action="reset-progress">Удалить прогресс</button></div>`);
    if (action==='reset-progress') { state.data.progress=await api('/api/progress/reset',{confirm:'RESET'}); $('#modal').close(); render(); toast('Учебный прогресс сброшен.'); }
  });
});
document.addEventListener('submit', event => {
  event.preventDefault();
  const form=event.target, data=Object.fromEntries(new FormData(form));
  const prefs = form.id==='settings-form' ? {name:data.name,motion:form.elements.motion.checked,contrast:form.elements.contrast.checked} : null;
  enqueue(async () => {
    if (form.id==='operation-form') { state.hint=''; await updateExercise(await api('/api/exercise/transform',data)); }
    if (form.id==='answer-form') { const result=await api('/api/exercise/answer',data); if(result.correct) await updateExercise(result.exercise); else toast(result.message,true); }
    if (form.id==='x-form') { state.data.lab=await api('/api/lab/x',data); render(); }
    if (form.id==='custom-form') { const result=await api('/api/equation/check',data); $('#custom-result').innerHTML=`<strong>${esc(result.left)} = ${esc(result.right)}</strong><span>${solutionText(result.solution)}</span>`; }
    if (form.id==='settings-form') { state.data.settings=await api('/api/settings',prefs); $('#modal').close(); render(); toast('Настройки сохранены.'); }
    if (form.id==='tag-form') { state.data.tags=await api('/api/tags/bind',data); tagsModal(); toast('Метка сохранена.'); }
  });
});
document.addEventListener('input', event => {
  if (['lab-x','custom-equation','operand','answer'].includes(event.target.id)) state.drafts[event.target.id]=event.target.value;
  if (event.target.name==='operation') state.drafts.operation=event.target.value;
});
window.addEventListener('hashchange',route);
$('#modal').addEventListener('click',event=>{if(event.target===$('#modal')) $('#modal').close();});
setInterval(async()=>{
  const ex=state.data?.exercise;
  if(state.page!=='exercise'||!ex||ex.mode!=='challenge'||ex.completed||ex.expired) return;
  const remaining=Math.max(0,Math.ceil((state.clockEnd-Date.now())/1000));
  if($('[data-clock]')) $('[data-clock]').textContent=timeText(remaining);
  if(!remaining&&!state.expiring) {
    state.expiring=true;
    try { state.data.exercise=await api('/api/exercise'); render(); } catch(error) { toast(error.message,true); }
    finally { state.expiring=false; }
  }
},500);
setInterval(async()=>{
  if(!state.data||state.data.hardware.mode!=='rc522'||state.busy) return;
  try {
    const result=await api(`/api/hardware/events?after=${state.eventSequence}`);
    state.data.hardware=result.hardware;
    settingsApply();
    for(const event of result.events) {
      state.eventSequence=event.sequence;
      state.lastUID=event.uid;
      if($('#modal').open&&$('#tag-form')) { $('#tag-uid').value=event.uid; $('#last-uid').textContent=`Последняя метка: ${event.uid}`; }
      else if(state.page==='lab'&&!$('#modal').open) {
        try { state.data.lab=await api('/api/lab/scan',{uid:event.uid,side:state.side}); render(); toast('Блок зарегистрирован. Уберите метку из зоны чтения.'); }
        catch(error) { toast(error.message,true); }
      } else toast(`Считана метка ${event.uid}. Для регистрации откройте лабораторию.`);
    }
  } catch(error) { toast('Нет связи с локальным сервером. Проверьте его запуск.',true); }
},900);
async function init() {
  try { state.data=await api('/api/bootstrap'); state.eventSequence=state.data.hardware.sequence; if(state.data.exercise?.mode==='challenge') state.clockEnd=Date.now()+state.data.exercise.remaining*1000; route(); }
  catch(error) { $('#app').innerHTML='<div class="empty-state"><h1>Не удалось открыть лабораторию</h1><p>Проверьте локальный сервер и обновите страницу.</p><button class="button primary" id="retry">Повторить</button></div>'; $('#retry').addEventListener('click',init); }
}
init();
