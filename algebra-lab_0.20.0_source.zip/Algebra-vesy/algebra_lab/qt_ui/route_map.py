"""Six touch stops on a cached illustrated trail; no periodic drawing or DB reads."""
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap, QLinearGradient
from PyQt6.QtWidgets import QWidget,QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QLabel
from ..adventure import ADVENTURE_TASKS,LANDS,QUIZZES,level_open,land_open,quiz_open

TITLES=['Начало','Числа побольше','Зеркальные весы','Два x']
PALETTES=[('#f5fbed','#d6ebcd','#9ec39d'),('#fff7df','#f1dcb0','#cdb185'),
          ('#eef9f8','#cce4df','#93bbb5'),('#fff1e4','#eed4c4','#cdaea2')]

class Trail(QWidget):
    def __init__(self,chapter,best,current,choose,parent=None):
        super().__init__(parent)
        self.chapter,self.best,self.current=chapter,dict(best),current
        self.nodes={};self.labels=[];self.cache=None;self.cache_size=None
        self.setMinimumHeight(260)
        for i,task in enumerate(ADVENTURE_TASKS[chapter*6:chapter*6+6]):
            number=chapter*6+i+1;done=task['id'] in best
            button=QPushButton(str(number),self);button.setFixedSize(72,72)
            button.setObjectName('route-'+task['id'])
            button.setEnabled(level_open(best,task['id']))
            color='#40a68c' if done else '#4d9eb5' if button.isEnabled() else '#c5cec4'
            light,shade=('#81e7c6','#117c72') if done else ('#a4dbe5','#346b82') if button.isEnabled() else ('#edf0f5','#a3abba')
            border='#ffc94c' if task['id']==current else '#ffffff'
            button.setStyleSheet('QPushButton {min-width:0;min-height:0;padding:0;border-radius:36px;'
                'border:4px solid '+border+';border-bottom:6px solid '+shade+';'
                'background:qradialgradient(cx:0.35,cy:0.25,radius:0.95,fx:0.3,fy:0.2,stop:0 '+light+',stop:0.55 '+color+',stop:1 '+shade+');color:white;font-size:25px;font-weight:bold;}'
                'QPushButton:hover {border-color:#ffc94c;} QPushButton:pressed {background:#347f83;}'
                'QPushButton:disabled {color:#71778a;} QPushButton:focus {border-color:#ffc94c;}')
            button.setAccessibleName('Уровень %d. %s. %s'%(number,task['title'], 'Пройден' if done else 'Доступен' if button.isEnabled() else 'Закрыт'))
            button.setToolTip(task['title']+' · '+task['equation'])
            button.clicked.connect(lambda checked=False,key=task['id']:choose(key))
            self.nodes[task['id']]=button
            equation=QLabel(task['equation'],self);equation.setAlignment(Qt.AlignmentFlag.AlignCenter)
            equation.setStyleSheet('background:#ffffff;color:#302755;border-radius:9px;font-size:17px;font-weight:bold;')
            status=QLabel('★'*best[task['id']] if done else 'Можно играть' if button.isEnabled() else 'Закрыто',self)
            status.setAlignment(Qt.AlignmentFlag.AlignCenter)
            status.setStyleSheet('background:transparent;color:'+('#846014' if done else '#5d5670')+';font-size:14px;')
            self.labels.append((equation,status))

    def points(self):
        return [QPointF(self.width()*(.095+i*.162),self.height()*(.57 if i%2==0 else .23)) for i in range(6)]

    def resizeEvent(self,event):
        for point,button,labels in zip(self.points(),self.nodes.values(),self.labels):
            x,y=round(point.x()),round(point.y())
            button.move(x-36,y-36)
            labels[0].setGeometry(x-65,y+41,130,30)
            labels[1].setGeometry(x-65,y+73,130,23)
        self.cache_size=None
        super().resizeEvent(event)

    def paintEvent(self,event):
        key=(self.width(),self.height(),self.devicePixelRatioF())
        if key!=self.cache_size:
            w,h=self.width(),self.height();ratio=self.devicePixelRatioF()
            self.cache=QPixmap(round(w*ratio),round(h*ratio));self.cache.setDevicePixelRatio(ratio)
            self.cache.fill(Qt.GlobalColor.transparent)
            p=QPainter(self.cache);p.setRenderHint(QPainter.RenderHint.Antialiasing)
            sky,ground,hill=PALETTES[self.chapter]
            fill=QLinearGradient(0,0,0,h);fill.setColorAt(0,QColor(sky));fill.setColorAt(1,QColor(ground))
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(fill);p.drawRoundedRect(QRectF(0,0,w,h),22,22)
            # Quiet landscape ornaments stay below the interactive route.
            p.setBrush(QColor(hill))
            landscape=QPainterPath(QPointF(0,h*.93));landscape.cubicTo(w*.25,h*.70,w*.38,h,w*.62,h*.89);landscape.cubicTo(w*.82,h*.75,w*.91,h*.91,w,h*.82);landscape.lineTo(w,h);landscape.lineTo(0,h);landscape.closeSubpath();p.drawPath(landscape)
            if self.chapter in (0,2):
                for x,y,size in [(w*.045,h*.82,18),(w*.45,h*.87,20),(w*.94,h*.9,16)]:
                    p.setPen(QPen(QColor('#73897d'),3));p.drawLine(QPointF(x,y),QPointF(x,y+17))
                    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#76ad97' if self.chapter==0 else '#92b9cb'))
                    tree=QPainterPath(QPointF(x,y-size));tree.lineTo(x-size*.65,y+8);tree.lineTo(x+size*.65,y+8);tree.closeSubpath();p.drawPath(tree)
            else:
                for x,y in [(w*.05,h*.8),(w*.45,h*.85),(w*.94,h*.86)]:
                    p.setPen(QPen(QColor(hill),3));p.setBrush(QColor('#fff7d8'))
                    p.drawEllipse(QPointF(x,y),5,5)
            pts=self.points()
            for i,(a,b) in enumerate(zip(pts,pts[1:])):
                path=QPainterPath(a);mid=(a.x()+b.x())/2
                path.cubicTo(mid,a.y(),mid,b.y(),b.x(),b.y())
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(QColor('#ffffff'),24,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
                complete=ADVENTURE_TASKS[self.chapter*6+i]['id'] in self.best
                p.setPen(QPen(QColor('#8ec9b3' if complete else '#d9c49b'),15,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
                p.setPen(QPen(QColor('#ffffff'),2,Qt.PenStyle.DotLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
            p.end();self.cache_size=key
        painter=QPainter(self);painter.drawPixmap(0,0,self.cache);painter.end()

class RouteMap(QDialog):
    def __init__(self,best,current,chapter=0,parent=None):
        super().__init__(parent)
        self.setWindowTitle('Карта приключения');self.resize(980,560)
        self.best=dict(best);self.current=current;self.chosen_task=None;self.chosen_quiz=None
        layout=QVBoxLayout(self);layout.setContentsMargins(16,12,16,12);layout.setSpacing(8)
        heading=QHBoxLayout();layout.addLayout(heading)
        title=QLabel('Карта приключения');title.setStyleSheet('font-size:25px;font-weight:bold;');heading.addWidget(title)
        heading.addStretch();heading.addWidget(QLabel('%d / 24 пройдено'%sum(t['id'] in best for t in ADVENTURE_TASKS)))
        tabs=QHBoxLayout();layout.addLayout(tabs);self.tabs=[]
        for i,name in enumerate(TITLES):
            b=QPushButton('%d · %s'%(i+1,name));b.setCheckable(True)
            b.setEnabled(land_open(best,i) or any(t['id'] in best for t in ADVENTURE_TASKS[i*6:i*6+6]))
            b.clicked.connect(lambda checked=False,index=i:self.select_chapter(index));tabs.addWidget(b);self.tabs.append(b)
        self.subtitle=QLabel();self.subtitle.setWordWrap(True);self.subtitle.setStyleSheet('font-size:17px;');layout.addWidget(self.subtitle)
        self.scene_layout=QVBoxLayout();layout.addLayout(self.scene_layout,1);self.trail=None
        footer=QHBoxLayout();layout.addLayout(footer)
        self.quiz_button=QPushButton('Квиз главы →');self.quiz_button.clicked.connect(self.choose_quiz);footer.addWidget(self.quiz_button)
        legend=QLabel('Бирюзовый — пройдено · Синий — доступно · Серый — закрыто');legend.setWordWrap(True);legend.setStyleSheet('font-size:14px;');footer.addWidget(legend,1)
        close=QPushButton('Закрыть');close.clicked.connect(self.reject);footer.addWidget(close)
        if not self.tabs[chapter].isEnabled():chapter=0
        self.select_chapter(chapter)

    def select_chapter(self,index):
        if not self.tabs[index].isEnabled():return
        self.chapter=index
        for i,b in enumerate(self.tabs):b.setChecked(i==index)
        self.subtitle.setText(LANDS[index][0]+' · '+LANDS[index][1])
        if self.trail is not None:
            self.scene_layout.removeWidget(self.trail);self.trail.hide();self.trail.deleteLater()
        self.trail=Trail(index,self.best,self.current,self.choose_task,self);self.scene_layout.addWidget(self.trail)
        self.quiz_button.setEnabled(quiz_open(self.best,index))

    def choose_task(self,key):
        if level_open(self.best,key):self.chosen_task=key;self.accept()

    def choose_quiz(self):
        if quiz_open(self.best,self.chapter):
            self.chosen_quiz=QUIZZES[self.chapter]['id'];self.accept()
