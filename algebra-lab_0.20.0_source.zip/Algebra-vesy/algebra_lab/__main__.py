import argparse
import json
import logging
import secrets
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from . import __version__

from .hardware import Reader
from .service import Service, Session
from .storage import Store

STATIC = Path(__file__).parent / "static"


class Application(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, store, reader):
        self.service = Service(store, reader)
        self.sessions = {}
        self.sessions_lock = threading.RLock()
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    server_version = "AlgebraLAB/0.1"

    def log_message(self, fmt, *args):
        logging.info(fmt, *args)

    def send(self, status, content, content_type="application/json; charset=utf-8", cookie=None):
        if content_type.startswith("application/json"):
            content = json.dumps(content, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        if cookie:
            self.send_header("Set-Cookie", f"lab_session={cookie}; HttpOnly; SameSite=Strict; Path=/")
        self.end_headers()
        self.wfile.write(content)

    def session(self):
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get("Cookie", ""))
        except Exception:
            pass
        sid = cookies["lab_session"].value if "lab_session" in cookies else ""
        with self.server.sessions_lock:
            if sid not in self.server.sessions:
                if len(self.server.sessions) >= 128:
                    self.server.sessions.pop(next(iter(self.server.sessions)))
                sid = secrets.token_hex(24)
                self.server.sessions[sid] = (Session(), threading.RLock())
            return sid, self.server.sessions[sid]

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/health":
            return self.send(200, {"status": "ok", "version": __version__, "hardware": self.server.service.reader.status()})
        if path.startswith("/api/"):
            sid, (session, lock) = self.session()
            with lock:
                if path == "/api/bootstrap":
                    result = self.server.service.bootstrap(session)
                elif path == "/api/exercise":
                    result = self.server.service.exercise(session)
                elif path == "/api/hardware/events":
                    try:
                        after = int(parse_qs(urlsplit(self.path).query).get("after", ["0"])[0])
                    except ValueError:
                        return self.send(400, {"error": "Некорректный номер события."})
                    result = {"events": self.server.service.reader.since(after), "hardware": self.server.service.reader.status()}
                else:
                    return self.send(404, {"error": "Маршрут не найден."})
            return self.send(200, result, cookie=sid)
        files = {"/": ("index.html", "text/html; charset=utf-8"),
                 "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                 "/style.css": ("style.css", "text/css; charset=utf-8"),
                 "/favicon.svg": ("favicon.svg", "image/svg+xml")}
        if path not in files:
            return self.send(404, {"error": "Страница не найдена."})
        name, mime = files[path]
        return self.send(200, (STATIC / name).read_bytes(), mime)

    def do_POST(self):
        if self.headers.get("X-Lab-Request") != "1" or self.headers.get_content_type() != "application/json":
            return self.send(403, {"error": "Запрос должен исходить из интерфейса приложения."})
        origin = self.headers.get("Origin")
        if origin and urlsplit(origin).netloc != self.headers.get("Host"):
            return self.send(403, {"error": "Запрос с другого сайта запрещён."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8192:
                return self.send(413, {"error": "Недопустимый размер запроса."})
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError("Ожидается JSON-объект.")
            sid, (session, lock) = self.session()
            with lock:
                result = self.server.service.dispatch(urlsplit(self.path).path, session, data)
            self.send(200, result, cookie=sid)
        except LookupError:
            self.send(404, {"error": "Маршрут не найден."})
        except (ValueError, TypeError, OverflowError) as exc:
            self.send(400, {"error": str(exc) or "Проверьте введённые данные."})


def main():
    parser = argparse.ArgumentParser(description="Алгебра LAB — локальный образовательный тренажёр")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--data-dir", type=Path, default=Path(".local"))
    parser.add_argument("--reader", choices=["simulator", "rc522"], default="simulator")
    args = parser.parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    store, reader = Store(args.data_dir / "algebra.sqlite3"), Reader(args.reader)
    server = Application((args.host, args.port), store, reader)
    logging.info("Алгебра LAB: http://%s:%s; режим %s", args.host, args.port, args.reader)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        reader.close()
        store.close()


if __name__ == "__main__":
    main()
