"""Validated, idempotent next-lesson proposals. Never changes the active lesson."""
import sqlite3
import time
from datetime import datetime,timezone
from .adventure import ADVENTURE_TASKS,ADVENTURE_IDS,level_open,LANDS
from .tasks import BY_ID

TTL=6*60*60
STATES=('pending','accepted','declined','cancelled','superseded','expired')

def initialize(db):
    db.execute('''CREATE TABLE IF NOT EXISTS mobile_lessons (
        id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, task_id TEXT NOT NULL,
        state TEXT NOT NULL CHECK(state IN ('pending','accepted','declined','cancelled','superseded','expired')),
        created_at REAL NOT NULL, updated_at REAL NOT NULL, expires_at REAL NOT NULL)''')
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS one_mobile_lesson ON mobile_lessons(profile_id) WHERE state='pending'")
    db.execute('CREATE INDEX IF NOT EXISTS mobile_lesson_history ON mobile_lessons(profile_id,created_at DESC)')


def best_for(db,profile):
    return {row[0]:row[1] for row in db.execute('SELECT task_id,MAX(stars) FROM attempts WHERE profile_id=? GROUP BY task_id',(profile,))}


def _profile(db,key):
    if not isinstance(key,str) or not db.execute('SELECT 1 FROM profiles WHERE id=?',(key,)).fetchone():raise ValueError('Профиль не найден.')


def allowed(db):
    import json
    row=db.execute("SELECT value FROM settings WHERE key='mobile_lessons_enabled'").fetchone()
    return bool(row and json.loads(row[0]) is True)


def catalog(db,profile):
    _profile(db,profile);best=best_for(db,profile)
    return {'profile_id':profile,'can_propose':allowed(db),'lessons':[
        {'id':t['id'],'title':t['title'],'equation':t['equation'],'chapter':LANDS[i//6][0],
         'available':level_open(best,t['id']),'stars':best.get(t['id'],0)} for i,t in enumerate(ADVENTURE_TASKS)]}


def public(row,now=None):
    if row is None:return None
    now=time.time() if now is None else now
    result=dict(row)
    if result['state']=='pending' and result['expires_at']<=now:result['state']='expired'
    for key in ('created_at','updated_at','expires_at'):
        result[key]=datetime.fromtimestamp(result[key],timezone.utc).isoformat()
    task=BY_ID.get(row['task_id'],{})
    result.update(title=task.get('title',row['task_id']),equation=task.get('equation',''))
    return result


def latest(db,profile):
    return public(db.execute('SELECT * FROM mobile_lessons WHERE profile_id=? ORDER BY created_at DESC LIMIT 1',(profile,)).fetchone())


def expire(db):
    now=time.time()
    db.execute("UPDATE mobile_lessons SET state='expired',updated_at=? WHERE state='pending' AND expires_at<=?",(now,now))


def submit(db,request_id,profile,task):
    if not isinstance(request_id,str) or len(request_id)!=32 or any(c not in '0123456789abcdef' for c in request_id):raise ValueError('Неверный идентификатор предложения.')
    if not isinstance(task,str) or task not in ADVENTURE_IDS:raise ValueError('Задание не найдено.')
    with db:
        db.execute('BEGIN IMMEDIATE');_profile(db,profile);expire(db)
        old=db.execute('SELECT * FROM mobile_lessons WHERE id=?',(request_id,)).fetchone()
        if old:
            if old['profile_id']!=profile or old['task_id']!=task:raise ValueError('Этот идентификатор уже использован для другого задания.')
            return public(old)
        if not allowed(db):raise PermissionError('На Raspberry Pi выключены предложения уроков.')
        if not level_open(best_for(db,profile),task):raise ValueError('Этот уровень пока закрыт для ребёнка.')
        now=time.time()
        db.execute("UPDATE mobile_lessons SET state='superseded',updated_at=? WHERE profile_id=? AND state='pending'",(now,profile))
        db.execute('INSERT INTO mobile_lessons VALUES (?,?,?,?,?,?,?)',(request_id,profile,task,'pending',now,now,now+TTL))
        db.execute("DELETE FROM mobile_lessons WHERE state!='pending' AND id NOT IN (SELECT id FROM mobile_lessons ORDER BY created_at DESC LIMIT 200)")
        return public(db.execute('SELECT * FROM mobile_lessons WHERE id=?',(request_id,)).fetchone())


def pending(db,profile):
    row=db.execute("SELECT * FROM mobile_lessons WHERE profile_id=? AND state='pending' ORDER BY created_at DESC LIMIT 1",(profile,)).fetchone()
    if row and row['expires_at']>time.time():return dict(row)
    return None


def transition(db,request_id,profile,state):
    if state not in ('accepted','declined','cancelled'):raise ValueError('Недопустимое действие.')
    if not isinstance(request_id,str) or not isinstance(profile,str):raise ValueError('Неверный идентификатор предложения или профиля.')
    with db:
        db.execute('BEGIN IMMEDIATE');expire(db)
        row=db.execute('SELECT * FROM mobile_lessons WHERE id=? AND profile_id=?',(request_id,profile)).fetchone()
        if row is None:raise ValueError('Предложение не найдено.')
        if row['state']==state:return public(row)
        if row['state']!='pending':raise ValueError('Предложение уже обработано или истекло.')
        if state=='accepted':
            if not allowed(db):raise PermissionError('Предложения отключены.')
            if not level_open(best_for(db,profile),row['task_id']):raise ValueError('Уровень больше не доступен.')
        db.execute('UPDATE mobile_lessons SET state=?,updated_at=? WHERE id=?',(state,time.time(),request_id))
        return public(db.execute('SELECT * FROM mobile_lessons WHERE id=?',(request_id,)).fetchone())


def cancel_all(db):
    with db:db.execute("UPDATE mobile_lessons SET state='cancelled',updated_at=? WHERE state='pending'",(time.time(),))
