TASKS = [
    {"id": "first", "title": "Первое равновесие", "level": 1, "equation": "x + 3 = 7", "skill": "Сложение и вычитание", "minutes": 2},
    {"id": "missing", "title": "Найди неизвестное", "level": 1, "equation": "x - 5 = 4", "skill": "Сложение и вычитание", "minutes": 2},
    {"id": "negative", "title": "Ниже нуля", "level": 1, "equation": "x + 6 = 2", "skill": "Отрицательные числа", "minutes": 2},
    {"id": "twins", "title": "Два одинаковых блока", "level": 2, "equation": "2x = 10", "skill": "Умножение и деление", "minutes": 3},
    {"id": "double", "title": "Два шага к ответу", "level": 2, "equation": "3x + 2 = 14", "skill": "Умножение и деление", "minutes": 3},
    {"id": "fraction", "title": "Делим поровну", "level": 2, "equation": "2x - 1 = 6", "skill": "Дроби", "minutes": 3},
    {"id": "both", "title": "X на обеих чашах", "level": 3, "equation": "3x + 2 = x + 10", "skill": "Переменная с двух сторон", "minutes": 4},
    {"id": "brackets", "title": "Открываем скобки", "level": 3, "equation": "2(x + 3) = 16", "skill": "Скобки", "minutes": 4},
    {"id": "reverse", "title": "С другой стороны", "level": 3, "equation": "12 = 2x + 4", "skill": "Переменная с двух сторон", "minutes": 4},
    {"id": "minus", "title": "Минус перед X", "level": 3, "equation": "5 - 2x = 11", "skill": "Отрицательные числа", "minutes": 4},
    {"id": "halves", "title": "Половина секрета", "level": 4, "equation": "x/2 + 3 = 8", "skill": "Дроби", "minutes": 5},
    {"id": "final", "title": "Мастер равновесия", "level": 4, "equation": "4(x - 2) = 2x + 6", "skill": "Скобки", "minutes": 5},
]

TASKS += [
    {"id": "zero", "title": "Нулевая отметка", "level": 1, "equation": "x + 8 = 8", "skill": "Сложение и вычитание", "minutes": 2},
    {"id": "winter", "title": "Холодный старт", "level": 1, "equation": "x - 3 = -9", "skill": "Отрицательные числа", "minutes": 2},
    {"id": "cargo", "title": "Секретный груз", "level": 1, "equation": "12 + x = 19", "skill": "Сложение и вычитание", "minutes": 2},
    {"id": "triple", "title": "Тройной запас", "level": 2, "equation": "3x - 6 = 15", "skill": "Умножение и деление", "minutes": 3},
    {"id": "mirror", "title": "Зеркальный блок", "level": 2, "equation": "-x + 4 = 9", "skill": "Отрицательные числа", "minutes": 3},
    {"id": "quarter", "title": "Четверть пути", "level": 2, "equation": "4x + 3 = 10", "skill": "Дроби", "minutes": 3},
    {"id": "bridge", "title": "Мост между чашами", "level": 3, "equation": "5x - 4 = 2x + 11", "skill": "Переменная с двух сторон", "minutes": 4},
    {"id": "boxes", "title": "Коробки с секретом", "level": 3, "equation": "3(x - 2) = x + 8", "skill": "Скобки", "minutes": 4},
    {"id": "third", "title": "Треть открытия", "level": 4, "equation": "x/3 - 2 = 5", "skill": "Дроби", "minutes": 5},
    {"id": "orbit", "title": "Дробная орбита", "level": 4, "equation": "3x/2 + 1 = 7", "skill": "Дроби", "minutes": 5},
    {"id": "signal", "title": "Обратный сигнал", "level": 4, "equation": "2 - (x + 3) = 2x + 5", "skill": "Скобки", "minutes": 5},
    {"id": "summit", "title": "Вершина экспедиции", "level": 4, "equation": "(x + 1)/2 = (x - 2)/3", "skill": "Дроби", "minutes": 5},
]
TASKS.sort(key=lambda task: task["level"])
BY_ID = {task["id"]: task for task in TASKS}


# Separate introductory path: legacy task IDs and equations stay unchanged.
STARTER_TASKS = [
    {"id": "cups-1", "title": "Убери по одной", "level": 1, "equation": "x + 1 = 2", "skill": "Одинаковое действие с чашами", "minutes": 2},
    {"id": "cups-2", "title": "Спрятанное число", "level": 1, "equation": "x + 1 = 3", "skill": "Одинаковое действие с чашами", "minutes": 2},
    {"id": "cups-3", "title": "Две единицы", "level": 1, "equation": "x + 2 = 3", "skill": "По одному блоку", "minutes": 3},
    {"id": "cups-4", "title": "Ещё одна пара", "level": 1, "equation": "x + 2 = 4", "skill": "По одному блоку", "minutes": 3},
    {"id": "cups-5", "title": "Верни единицу", "level": 1, "equation": "x - 1 = 1", "skill": "Прибавление к обеим чашам", "minutes": 3},
    {"id": "cups-6", "title": "Три маленьких шага", "level": 1, "equation": "x + 3 = 5", "skill": "По одному блоку", "minutes": 4},
]
PLAY_TASKS = STARTER_TASKS + TASKS
BY_ID.update({task['id']: task for task in STARTER_TASKS})
STARTER_IDS = {task['id'] for task in STARTER_TASKS}
