"""Keep an unconfirmed cup preview separate from the equivalent-step history."""
def save_pending(store,session):
    actions=session.cup_actions
    value=None
    if session.cup_play and not session.completed and len(actions)==1:
        value={'task':session.task_id,'attempt':session.attempt,'action':actions[0]}
    store.save_settings({'pending_cup':value})


def restore_pending(service,session):
    saved=service.store.settings().get('pending_cup')
    if not isinstance(saved,dict) or saved.get('task')!=session.task_id or saved.get('attempt')!=session.attempt:return False
    action=saved.get('action',{})
    if not isinstance(action,dict) or action.get('side') not in ('left','right') or action.get('operation') not in ('add','remove'):return False
    uid=next((uid for uid,kind in service.store.tags().items() if kind==action.get('kind')),None)
    if uid is None:return False
    try:
        service.scan_cup(session,{'uid':uid,'side':action['side'],'operation':action['operation']})
    except ValueError:return False
    session.cup_operation=action['operation']
    return True
