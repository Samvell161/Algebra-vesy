"""Exact, bounded linear algebra. Never evaluates Python or floating point input."""

import re
from dataclasses import dataclass
from fractions import Fraction


class MathError(ValueError):
    pass


def number(value):
    source = str(value).strip().replace("−", "-")
    if len(source) > 64 or not re.fullmatch(r"[+-]?\d+(?:\.\d+)?(?:/\d+)?", source):
        raise MathError("Введите число или дробь, например 3/2.")
    try:
        result = Fraction(source)
    except (ValueError, ZeroDivisionError):
        raise MathError("Введите число или дробь, например 3/2.") from None
    if abs(result) > 10000 or result.denominator > 10000:
        raise MathError("Используйте числа до 10 000 и знаменатели до 10 000.")
    return result


def fmt(value):
    return str(value).replace("-", "−")


@dataclass(frozen=True)
class Linear:
    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    def __add__(self, other):
        return Linear(self.a + other.a, self.b + other.b)

    def scale(self, factor):
        return Linear(self.a * factor, self.b * factor)

    def at(self, x):
        return self.a * x + self.b

    def __str__(self):
        parts = []
        if self.a:
            parts.append("x" if self.a == 1 else "−x" if self.a == -1 else fmt(self.a) + "x")
        if self.b:
            if parts:
                parts.append((" + " if self.b > 0 else " − ") + fmt(abs(self.b)))
            else:
                parts.append(fmt(self.b))
        return "".join(parts) or "0"


class Parser:
    def __init__(self, source):
        if not isinstance(source, str) or not source.strip() or len(source) > 160:
            raise MathError("Введите выражение длиной до 160 символов.")
        source = source.replace("−", "-").replace("×", "*").replace("·", "*").replace("÷", "/")
        if re.search(r"[^0-9xX+*/().\s-]", source):
            raise MathError("Допустимы числа, x, скобки и знаки + − × ÷.")
        self.tokens = re.findall(r"\d+(?:\.\d+)?|[xX+*/()-]", source)
        # Reject stray decimal points rather than silently dropping them.
        if "".join(self.tokens).lower() != re.sub(r"\s", "", source).lower():
            raise MathError("Проверьте запись числа.")
        self.index = 0

    def peek(self):
        return self.tokens[self.index] if self.index < len(self.tokens) else None

    def pop(self):
        token = self.peek()
        self.index += 1
        return token

    def expression(self):
        result = self.term()
        while self.peek() in ("+", "-"):
            op = self.pop()
            result = result + self.term().scale(1 if op == "+" else -1)
        return result

    def term(self):
        result = self.atom()
        while self.peek() in ("*", "/", "x", "X", "("):
            op = self.pop() if self.peek() in ("*", "/") else "*"
            other = self.atom()
            if op == "/":
                if other.a:
                    raise MathError("Деление на выражение с x пока не поддерживается.")
                if not other.b:
                    raise MathError("На ноль делить нельзя.")
                result = result.scale(1 / other.b)
            else:
                if result.a and other.a:
                    raise MathError("Этот тренажёр работает с линейными уравнениями, без x².")
                result = result.scale(other.b) if not other.a else other.scale(result.b)
            self.check(result)
        return result

    def atom(self):
        token = self.pop()
        if token in ("+", "-"):
            return self.atom().scale(1 if token == "+" else -1)
        if token == "(":
            result = self.expression()
            if self.pop() != ")":
                raise MathError("Не хватает закрывающей скобки.")
            return result
        if token and token.lower() == "x":
            return Linear(Fraction(1))
        if token and re.fullmatch(r"\d+(?:\.\d+)?", token):
            return Linear(b=number(token))
        raise MathError("Проверьте выражение: ожидается число, x или скобка.")

    @staticmethod
    def check(result):
        if any(abs(v) > 1000000 or v.denominator > 1000000 for v in (result.a, result.b)):
            raise MathError("Выражение слишком большое для учебного режима.")


def parse(source):
    parser = Parser(source)
    try:
        result = parser.expression()
    except RecursionError:
        raise MathError("Слишком много вложенных скобок.") from None
    if parser.peek() is not None:
        raise MathError("Проверьте знаки и скобки в выражении.")
    parser.check(result)
    return result


@dataclass(frozen=True)
class Equation:
    left: Linear
    right: Linear

    def solution(self):
        a = self.left.a - self.right.a
        b = self.right.b - self.left.b
        if not a:
            return {"kind": "all" if not b else "none", "value": None}
        return {"kind": "one", "value": str(b / a)}

    def isolated(self):
        return ((self.left.a == 1 and self.left.b == 0 and self.right.a == 0)
                or (self.right.a == 1 and self.right.b == 0 and self.left.a == 0))

    def transform(self, op, value):
        if op in ("add", "subtract"):
            term = parse(value).scale(1 if op == "add" else -1)
            result = Equation(self.left + term, self.right + term)
        elif op in ("multiply", "divide"):
            factor = number(value)
            if not factor:
                raise MathError("Ноль не подходит: делить на него нельзя, а умножение потеряет решение.")
            if op == "divide":
                factor = 1 / factor
            result = Equation(self.left.scale(factor), self.right.scale(factor))
        else:
            raise MathError("Неизвестное действие.")
        Parser.check(result.left)
        Parser.check(result.right)
        return result

    def json(self):
        return {"left": str(self.left), "right": str(self.right), "solution": self.solution(),
                "isolated": self.isolated()}


def equation(source):
    if not isinstance(source, str) or source.count("=") != 1:
        raise MathError("Уравнение должно содержать один знак =.")
    left, right = source.split("=")
    return Equation(parse(left), parse(right))
