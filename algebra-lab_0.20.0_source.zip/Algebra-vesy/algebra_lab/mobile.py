"""Opt-in, read-only LAN progress API and UDP discovery. Standard library only."""
import hashlib
import json
import os
import secrets
import socket
import sqlite3
import threading
import time
import uuid
from datetime import date,datetime,timedelta,timezone
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from .adventure import ADVENTURE_TASKS,QUIZZES,LANDS
from .tasks import TASKS,BY_ID
from . import lesson_queue
from urllib.parse import urlsplit,parse_qs

HTTP_PORT=8765
DISCOVERY_PORT=8766
SERVICE='algebra-lab-progress'
KNOWN={t['id'] for t in ADVENTURE_TASKS+TASKS+QUIZZES}


def snapshot(path,device_id):
    """Read all profiles in one transaction, without touching the active child."""
    db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True,timeout=.3)
    db.row_factory=sqlite3.Row
    try:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        result=[];cutoff=(datetime.now(timezone.utc)-timedelta(days=31)).isoformat()
        for profile in db.execute('SELECT id,name FROM profiles ORDER BY rowid LIMIT 20'):
            key=profile['id']
            best={r['task_id']:max(0,min(3,r['stars'])) for r in db.execute('SELECT task_id,MAX(stars) stars FROM attempts WHERE profile_id=? GROUP BY task_id',(key,)) if r['task_id'] in KNOWN}
            total=db.execute('SELECT COUNT(*) attempts,COALESCE(SUM(seconds),0) seconds,COALESCE(SUM(hints),0) hints,MAX(completed_at) last_activity FROM attempts WHERE profile_id=?',(key,)).fetchone()
            daily=[dict(r) for r in db.execute("SELECT date(completed_at,'localtime') day,COUNT(*) count FROM attempts WHERE profile_id=? AND completed_at>=? GROUP BY day ORDER BY day",(key,cutoff))]
            recent=[]
            for row in db.execute('SELECT task_id,mode,stars,hints,seconds,completed_at FROM attempts WHERE profile_id=? ORDER BY completed_at DESC LIMIT 20',(key,)):
                item=dict(row);item['title']=BY_ID.get(row['task_id'],{}).get('title',row['task_id']);recent.append(item)
            xp=sum(best.values())*10
            result.append({'id':key,'name':profile['name'],'completed':len(best),'total':len(KNOWN),'xp':xp,'level':1+xp//60,
                           **dict(total),'daily':daily,'recent':recent,
                           'lesson_request':lesson_queue.latest(db,key),
                           'chapters':[{'name':LANDS[i][0],'completed':sum(t['id'] in best for t in ADVENTURE_TASKS[i*6:i*6+6]),'total':6} for i in range(4)]})
        return {'schema':1,'device_id':device_id,'today':date.today().isoformat(),'profiles':result,'capabilities':['lesson_proposals']}
    finally:db.close()


class ProgressHub:
    def __init__(self,data,host='0.0.0.0',port=HTTP_PORT,discovery_port=DISCOVERY_PORT):
        self.data=Path(data);self.host=host;self.port=port;self.discovery_port=discovery_port
        self.path=self.data/'mobile-access.json';self.lock=threading.RLock()
        self.server=None;self.udp=None;self.thread=None;self.udp_thread=None
        self.stop_event=threading.Event();self.error=None;self.running=False
        self.code=None;self.code_deadline=0;self.attempts={}
        self.credentials=None;self.address=""
        self.requests_changed=threading.Event();self.requests_changed.set()

    def _write(self):
        temp=self.path.with_suffix('.tmp')
        with temp.open('w',encoding='utf8') as stream:
            os.chmod(temp,0o600);json.dump(self.credentials,stream)
        os.replace(temp,self.path)

    def _load(self):
        if self.path.exists():
            if self.path.stat().st_size>16384:raise ValueError('Слишком большой файл доступа.')
            self.credentials=json.loads(self.path.read_text())
            if not isinstance(self.credentials.get('device_id'),str) or not isinstance(self.credentials.get('tokens'),list) or not all(isinstance(t,str) and t.isascii() for t in self.credentials.get('tokens',[])):raise ValueError('Некорректный файл доступа к телефону.')
        else:
            self.credentials={'device_id':uuid.uuid4().hex,'tokens':[]};self._write()

    def start(self):
        if self.thread and self.thread.is_alive():
            if self.stop_event.is_set():raise OSError("Служба ещё завершается. Повторите включение через секунду.")
            return
        self.error=None;self.stop_event=threading.Event()
        self.thread=threading.Thread(target=self._serve,daemon=True);self.thread.start()

    def _serve(self):
        try:
            with self.lock:self._load()
            hub=self
            class Handler(BaseHTTPRequestHandler):
                def log_message(self,*args):pass
                def setup(self):
                    self.request.settimeout(.6);super().setup()
                def reply(self,status,value=None,etag=None):
                    body=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode() if value is not None else b''
                    self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
                    self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
                    self.send_header('Connection','close')
                    if etag:self.send_header('ETag',etag)
                    self.end_headers()
                    if body:self.wfile.write(body)
                def authenticated(self):
                    header=self.headers.get('Authorization','')
                    token=header[7:] if header.startswith('Bearer ') and header.isascii() else ''
                    with hub.lock:return any(secrets.compare_digest(token,item) for item in hub.credentials['tokens'])
                def body(self):
                    size=int(self.headers.get('Content-Length','0'))
                    if not 0<size<=1024:raise ValueError()
                    value=json.loads(self.rfile.read(size))
                    if not isinstance(value,dict):raise ValueError()
                    return value
                def do_GET(self):
                    parsed=urlsplit(self.path)
                    if parsed.path=='/v1/info':self.reply(200,hub.info());return
                    if parsed.path not in ('/v1/progress','/v1/lessons'):self.reply(404,{'error':'not_found'});return
                    if not self.authenticated():self.reply(401,{'error':'pair_required'});return
                    try:
                        if parsed.path=='/v1/lessons':
                            profile=parse_qs(parsed.query).get('profile',[''])[0]
                            with hub.database() as db:value=lesson_queue.catalog(db,profile)
                        else:value=snapshot(hub.data/'algebra.sqlite3',hub.credentials['device_id'])
                        body=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
                        etag='"'+hashlib.sha256(body).hexdigest()+'"'
                        if self.headers.get('If-None-Match')==etag:self.reply(304,etag=etag)
                        else:self.reply(200,value,etag)
                    except ValueError:self.reply(400,{'error':'invalid_profile'})
                    except sqlite3.Error:self.reply(503,{'error':'database_busy'})
                def do_POST(self):
                    if self.path not in ('/v1/pair','/v1/lesson-requests','/v1/lesson-requests/cancel'):
                        self.reply(404,{'error':'not_found'});return
                    if self.path!='/v1/pair' and not self.authenticated():self.reply(401,{'error':'pair_required'});return
                    try:value=self.body()
                    except (ValueError,AttributeError):self.reply(400,{'error':'invalid_request'});return
                    if self.path=='/v1/pair':
                        code=value.get('code')
                        if not isinstance(code,str) or len(code)!=6 or not code.isascii() or not code.isdecimal():self.reply(400,{'error':'invalid_request'});return
                        status,response=hub.pair(code,self.client_address[0]);self.reply(status,response);return
                    try:
                        with hub.database() as db:
                            if self.path=='/v1/lesson-requests':result=lesson_queue.submit(db,value.get('id'),value.get('profile_id'),value.get('task_id'))
                            else:result=lesson_queue.transition(db,value.get('id'),value.get('profile_id'),'cancelled')
                        hub.requests_changed.set();self.reply(200,{'request':result})
                    except PermissionError:self.reply(403,{'error':'proposals_disabled'})
                    except (ValueError,TypeError):self.reply(409,{'error':'invalid_or_unavailable_lesson'})
                    except sqlite3.Error:self.reply(503,{'error':'database_busy'})
            self.server=HTTPServer((self.host,self.port),Handler)
            self.port=self.server.server_address[1]
            self.udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            self.udp.bind((self.host,self.discovery_port));self.discovery_port=self.udp.getsockname()[1];self.udp.settimeout(1)
            try:
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
                    route.connect(("192.0.2.1",9));self.address=route.getsockname()[0]
            except OSError:self.address=""
            self.running=True
            self.udp_thread=threading.Thread(target=self._discover,daemon=True);self.udp_thread.start()
            while not self.stop_event.is_set():
                self.server.timeout=1;self.server.handle_request()
        except (OSError,ValueError) as exc:self.error=str(exc)
        finally:
            self.running=False
            if self.udp:self.udp.close()
            if self.server:self.server.server_close()

    def database(self):
        import contextlib
        @contextlib.contextmanager
        def connection():
            db=sqlite3.connect(self.data/'algebra.sqlite3',timeout=.3)
            db.row_factory=sqlite3.Row
            try:yield db
            finally:db.close()
        return connection()

    def info(self):
        return {'service':SERVICE,'schema':1,'device_id':self.credentials['device_id'],'name':'Алгебра LAB · '+socket.gethostname(),'port':self.port,'capabilities':['lesson_proposals']}

    def _discover(self):
        while not self.stop_event.is_set():
            try:
                data,addr=self.udp.recvfrom(1024);request=json.loads(data)
                if request.get('service')!=SERVICE or request.get('schema')!=1:continue
                nonce=request.get('nonce')
                if not isinstance(nonce,str) or len(nonce)>64:continue
                self.udp.sendto(json.dumps({**self.info(),'nonce':nonce}).encode(),addr)
            except socket.timeout:continue
            except (OSError,ValueError,AttributeError):
                if self.stop_event.is_set():break

    def new_code(self):
        with self.lock:
            if not self.running:raise ValueError("Сначала дождитесь запуска доступа к телефону.")
            self.code='%06d'%secrets.randbelow(1000000);self.code_deadline=time.monotonic()+300
            return self.code

    def pair(self,code,address):
        with self.lock:
            now=time.monotonic();self.attempts={ip:entry for ip,entry in self.attempts.items() if now-entry[0]<60}
            previous=self.attempts.get(address,(now,0))
            if previous[1]>=5 or len(self.attempts)>64:return 429,{'error':'try_later'}
            self.attempts[address]=(previous[0],previous[1]+1)
            if self.code is None or now>self.code_deadline or not secrets.compare_digest(code,self.code):return 403,{'error':'wrong_or_expired_code'}
            token=secrets.token_urlsafe(32)
            self.credentials['tokens']=(self.credentials['tokens']+[token])[-8:];self._write()
            self.code=None;self.code_deadline=0
            return 200,{**self.info(),'token':token}

    def revoke(self):
        with self.lock:
            if self.credentials:
                self.credentials['tokens']=[];self._write()
            self.code=None;self.code_deadline=0

    def status(self):
        with self.lock:
            return {'running':self.running,'error':self.error,'port':self.port,'address':self.address,
                    'code':self.code if time.monotonic()<self.code_deadline else None,
                    'phones':len(self.credentials['tokens']) if self.credentials else 0}

    def close(self):
        with self.lock:self.code=None;self.code_deadline=0
        self.stop_event.set()
        # Wake blocked network listeners so disabling sharing remains responsive.
        address='127.0.0.1' if self.host=='0.0.0.0' else self.host
        if self.running:
            try:
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as wake:
                    wake.sendto(b'{}',(address,self.discovery_port))
                with socket.create_connection((address,self.port),timeout=.15):pass
            except OSError:pass
        if self.thread:self.thread.join(timeout=1.5)
        if self.udp_thread:self.udp_thread.join(timeout=.4)
