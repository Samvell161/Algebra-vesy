"""On-demand SQLite snapshots and bounded local diagnostics."""
import logging
from logging.handlers import RotatingFileHandler
import sqlite3
import json
from pathlib import Path


def diagnostic_logger(directory):
    logger=logging.getLogger('algebra-lab.hardware.'+str(Path(directory).resolve()))
    if not logger.handlers:
        handler=RotatingFileHandler(Path(directory)/'hardware.log',maxBytes=128*1024,backupCount=2,encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
        logger.addHandler(handler);logger.setLevel(logging.INFO);logger.propagate=False
    return logger


def backup(store,path):
    path=Path(path)
    current=store.db.execute('PRAGMA database_list').fetchone()[2]
    if path.resolve()==Path(current).resolve():raise ValueError('Выберите другой файл для резервной копии.')
    # SQLite backup API produces a consistent snapshot, including committed WAL data.
    with store.lock:
        target=sqlite3.connect(path)
        try:store.db.backup(target)
        finally:target.close()
    return path


def restore(store,path,rollback):
    path=Path(path)
    current=Path(store.db.execute("PRAGMA database_list").fetchone()[2]).resolve()
    if path.resolve() in (current,Path(rollback).resolve()):raise ValueError("Выберите отдельный файл резервной копии.")
    if path.stat().st_size>32*1024*1024:raise ValueError('Резервная копия больше 32 МБ.')
    source=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
    try:
        if source.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Копия повреждена.')
        for table,columns in [('solution_paths','attempt_id,task_id,data'),('tags','uid,kind'),('settings','key,value'),('attempts','id,task_id,mode,steps,hints,stars,seconds,completed_at')]:
            source.execute('SELECT '+columns+' FROM '+table+' LIMIT 0')
        for key,value in source.execute("SELECT key,value FROM settings"):
            json.loads(value)
        backup(store,rollback)
        with store.lock:
            source.backup(store.db)
            store.initialize_profiles()
    finally:source.close()
