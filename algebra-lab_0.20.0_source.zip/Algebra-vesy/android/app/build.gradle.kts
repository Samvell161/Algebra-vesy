plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ru.algebralab.progress"
    compileSdk = 35
    buildToolsVersion = "35.0.0"
    defaultConfig {
        applicationId = "ru.algebralab.progress"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

android {
    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all {
            it.systemProperty("algebra.screenshots",rootProject.file("../artifacts/android-1.2.0").absolutePath)
            for (key in listOf("http.proxyHost","http.proxyPort","https.proxyHost","https.proxyPort","http.proxyUser","http.proxyPassword","https.proxyUser","https.proxyPassword","javax.net.ssl.trustStore","user.home")) {
                System.getProperty(key)?.let { value -> it.systemProperty(key,value) }
            }
        }
    }
}
dependencies {
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}
