package ru.algebralab.progress

import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.materialswitch.MaterialSwitch
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.animation.ValueAnimator
import android.text.TextUtils
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.*
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

private fun shortDay(value:String):String=runCatching {LocalDate.parse(value).format(DateTimeFormatter.ofPattern("dd.MM"))}.getOrDefault(value)

class MainActivity : AppCompatActivity() {
    private val purple get() = getColor(R.color.lab_primary)
    private val ink get() = getColor(R.color.lab_ink)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("trainer", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var navigation: BottomNavigationView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var connectionBadge: TextView
    private lateinit var spinner: CircularProgressIndicator
    private var connectionSummary: TextView? = null
    private var online = false
    private var tab = 0
    private var range = 14
    private var active = false
    private var busy = false
    private var data: JSONObject? = null
    private var selected = ""
    private var etag = ""
    private val poll = object : Runnable { override fun run() { if (active) { if (!busy && prefs.getString("token", "").orEmpty().isNotEmpty()) refresh() else schedule() } } }
    data class Endpoint(val host:String, val port:Int, val id:String, val name:String) { val base get()="http://$host:$port" }
    data class Response(val status:Int, val text:String, val etag:String)
    class ApiRejected(message:String):IOException(message)
    class PairRequired: IOException("Доступ отозван. Найдите тренажёр и подключитесь снова.")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected = prefs.getString("selected", "").orEmpty()
        range = prefs.getInt("range",14).takeIf { it in listOf(7,14,30) } ?: 14
        data = runCatching { JSONObject(prefs.getString("snapshot", "").orEmpty()) }.getOrNull()
        tab = prefs.getInt("tab",if(data==null)2 else if(selected.isEmpty())0 else 1).coerceIn(0,2)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(getColor(R.color.lab_background)); fitsSystemWindows=true }
        val toolbar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=android.view.Gravity.CENTER_VERTICAL;setPadding(dp(20),dp(14),dp(14),dp(6)) }
        val brand=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        brand.addView(text("Алгебра LAB",24,true));brand.addView(text("Дневник занятий",13).apply {setTextColor(getColor(R.color.lab_muted))})
        toolbar.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        spinner=CircularProgressIndicator(this).apply {isIndeterminate=true;indicatorSize=dp(20);trackThickness=dp(2);visibility=View.GONE}
        toolbar.addView(spinner,LinearLayout.LayoutParams(dp(24),dp(24)))
        connectionBadge=text("",12,true).apply {setPadding(dp(10),dp(6),dp(10),dp(6));background=shape(getColor(R.color.lab_surface_soft),12)}
        toolbar.addView(connectionBadge)
        root.addView(toolbar)
        status=text("",13).apply {setTextColor(getColor(R.color.lab_muted));setPadding(dp(20),dp(6),dp(20),dp(10));maxLines=3}
        root.addView(status)
        swipe=SwipeRefreshLayout(this).apply {setColorSchemeColors(purple,getColor(R.color.lab_secondary))}
        scroll=ScrollView(this).apply {isFillViewport=true;clipToPadding=false}
        content=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(24))}
        scroll.addView(content);swipe.addView(scroll)
        swipe.setOnRefreshListener {if(endpoint()==null){swipe.isRefreshing=false;search()}else refresh()}
        root.addView(swipe,LinearLayout.LayoutParams(-1,0,1f))
        navigation=BottomNavigationView(this).apply {
            setBackgroundColor(getColor(R.color.lab_surface));labelVisibilityMode=com.google.android.material.navigation.NavigationBarView.LABEL_VISIBILITY_LABELED
            menu.add(0,1,0,"Дети").setIcon(R.drawable.ic_people)
            menu.add(0,2,1,"Прогресс").setIcon(R.drawable.ic_chart)
            menu.add(0,3,2,"Тренажёр").setIcon(R.drawable.ic_device)
            menu.findItem(tab+1).isChecked=true
            setOnItemSelectedListener { item ->
                val next=item.itemId-1
                if(tab!=next){tab=next;prefs.edit().putInt("tab",tab).apply();render(false);reveal()}
                true
            }
        }
        root.addView(navigation,LinearLayout.LayoutParams(-1,-2));setContentView(root)
        onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true){
            override fun handleOnBackPressed(){
                if(tab!=0){tab=0;prefs.edit().putInt("tab",0).apply();navigation.menu.findItem(1).isChecked=true;render(false)}
                else {isEnabled=false;onBackPressedDispatcher.onBackPressed()}
            }
        })
        render(false)
        status.text=if(data==null) "Подключите телефон и Raspberry Pi к одной Wi-Fi сети. Интернет и QR-код не нужны." else "Сохранённые данные. Последнее обновление: ${lastSync()}"
        syncChrome()
    }
    override fun onResume() { super.onResume();active=true;main.removeCallbacks(poll);main.post(poll) }
    override fun onPause() { content.animate().cancel();content.alpha=1f;active=false;main.removeCallbacks(poll);super.onPause() }
    override fun onDestroy() { main.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy() }
    private fun schedule() { main.removeCallbacks(poll);if(active && prefs.getString("token", "").orEmpty().isNotEmpty())main.postDelayed(poll,25_000) }
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()
    private fun text(value:String,size:Int=17,bold:Boolean=false)=TextView(this).apply { text=value;textSize=size.toFloat();setTextColor(ink);if(bold)setTypeface(typeface,Typeface.BOLD) }
    private fun shape(color:Int,radius:Int)=GradientDrawable().apply {setColor(color);cornerRadius=dp(radius).toFloat()}
    private fun button(value:String,iconRes:Int=0,filled:Boolean=true,click:()->Unit)=MaterialButton(this).apply {
        text=value;isAllCaps=false;textSize=15f;minHeight=dp(52);cornerRadius=dp(16)
        setTextColor(getColor(if(filled)R.color.lab_on_primary else R.color.lab_ink))
        backgroundTintList=ColorStateList.valueOf(getColor(if(filled)R.color.lab_primary else R.color.lab_surface_soft))
        if(iconRes!=0){setIconResource(iconRes);iconSize=dp(19);iconTint=ColorStateList.valueOf(currentTextColor)}
        setOnClickListener {click()}
    }
    private fun selectionChip():Chip = Chip(this).apply {
        chipBackgroundColor=ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked),intArrayOf()),intArrayOf(getColor(R.color.lab_primary_container),getColor(R.color.lab_surface_soft)))
        chipStrokeWidth=0f;setTextColor(getColor(R.color.lab_ink));setEnsureMinTouchTargetSize(true)
    }
    private fun card(hero:Boolean=false):LinearLayout {
        val shell=MaterialCardView(this).apply {
            radius=dp(24).toFloat();cardElevation=0f;strokeWidth=if(hero)0 else dp(1)
            strokeColor=getColor(R.color.lab_outline);setCardBackgroundColor(getColor(R.color.lab_surface));clipToOutline=true
        }
        val body=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18))}
        if(hero)body.background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(102,77,185),Color.rgb(58,48,113))).apply {cornerRadius=dp(24).toFloat()}
        shell.addView(body);content.addView(shell,LinearLayout.LayoutParams(-1,-2).apply {bottomMargin=dp(14)})
        return body
    }
    private fun gap(parent:LinearLayout,height:Int=10){parent.addView(View(this),LinearLayout.LayoutParams(1,dp(height)))}
    private fun caption(value:String)=text(value,14).apply {setTextColor(getColor(R.color.lab_muted))}
    private fun title(value:String,subtitle:String="") {
        content.addView(text(value,28,true));if(subtitle.isNotEmpty())content.addView(caption(subtitle));gap(content,16)
    }
    private fun reveal(){if(prefs.getBoolean("animations",true)&&ValueAnimator.areAnimatorsEnabled()){content.alpha=.65f;content.animate().alpha(1f).setDuration(140).start()}}
    private fun syncChrome(){
        spinner.visibility=if(busy)View.VISIBLE else View.GONE
        connectionBadge.text=when {busy->"Обновление";online->"● В сети";data!=null->"● Сохранено";else->"○ Нет связи"}
        connectionBadge.setTextColor(getColor(if(online)R.color.lab_secondary else R.color.lab_muted))
        if(!busy)swipe.isRefreshing=false
        connectionSummary?.text=trainerSummary()
    }
    private fun trainerSummary():String {
        val ep=endpoint()?:return "Тренажёр ещё не подключён. Найдите его в общей Wi-Fi сети."
        return "${ep.name}\n${ep.host}:${ep.port}\nПоследнее обновление: ${lastSync()}"
    }
    private fun wifi():Network {
        val cm=getSystemService(ConnectivityManager::class.java)
        return cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true }
            ?: throw IOException("Подключите телефон к той же Wi-Fi сети, что и тренажёр.")
    }
    private fun endpoint():Endpoint? {
        val host=prefs.getString("host", "").orEmpty();val id=prefs.getString("device", "").orEmpty()
        return if(host.isEmpty()||id.isEmpty()) null else Endpoint(host,prefs.getInt("port",8765),id,prefs.getString("name","Алгебра LAB").orEmpty())
    }
    private fun <T> launch(message:String,work:()->T,success:(T)->Unit) {
        if(busy)return
        busy=true;status.text=message;syncChrome()
        worker.execute {
            val result=runCatching(work)
            main.post {
                if(isDestroyed||isFinishing)return@post
                busy=false
                if(active) result.fold(success) { error ->
                    if(error !is ApiRejected)online=false
                    if(error is PairRequired){prefs.edit().remove("token").apply();etag=""}
                    val message=when(error) {is SocketTimeoutException->"Тренажёр не ответил. Проверьте Wi-Fi.";is ConnectException->"Нет связи с тренажёром. Включите доступ на Raspberry Pi.";is SocketException->"Соединение прервано. Проверьте Wi-Fi.";else->error.message ?: "Нет связи с тренажёром"}
                    status.text="$message\n"+if(data!=null)"Сохранённые результаты доступны. Обновлено: ${lastSync()}" else "Попробуйте поиск ещё раз или укажите адрес." }
                syncChrome();schedule()
            }
        }
    }
    private fun request(ep:Endpoint,path:String,token:String="",body:JSONObject?=null,tag:String=""):Response {
        val connection=wifi().openConnection(URL(ep.base+path)) as HttpURLConnection
        connection.connectTimeout=4000;connection.readTimeout=5000;connection.useCaches=false
        if(token.isNotEmpty())connection.setRequestProperty("Authorization","Bearer $token")
        if(tag.isNotEmpty())connection.setRequestProperty("If-None-Match",tag)
        try {
            if(body!=null) { connection.requestMethod="POST";connection.doOutput=true;connection.setRequestProperty("Content-Type","application/json");connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) } }
            val code=connection.responseCode
            if(code==401)throw PairRequired()
            if(path.startsWith("/v1/lesson") && code !in listOf(200,304))throw ApiRejected(when(code){
                404->"Для предложений уроков обновите Raspberry Pi до 0.16.0."
                403->"На Raspberry Pi разрешите предложения уроков в разделе доступа к Android."
                409->"Предложение уже обработано или уровень недоступен. Обновите прогресс."
                503->"Тренажёр занят. Повторите отправку чуть позже."
                else->"Не удалось передать предложение: ответ $code."
            })
            if(code!=200 && code!=304)throw IOException(when(code) {401->"Доступ отозван. Найдите тренажёр и подключитесь снова.";403->"Код неверный или истёк. Получите новый код на Raspberry Pi.";429->"Слишком много попыток. Подождите минуту.";503->"Тренажёр занят. Попробуйте обновить чуть позже.";else->"Тренажёр ответил ошибкой $code."})
            val bytes=if(code==304)byteArrayOf() else connection.inputStream.use { input ->
                val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(4096)
                while(true) { val n=input.read(buffer);if(n<0)break;out.write(buffer,0,n);if(out.size()>2*1024*1024)throw IOException("Ответ слишком большой.") };out.toByteArray()
            }
            return Response(code,String(bytes,Charsets.UTF_8),connection.getHeaderField("ETag").orEmpty())
        } finally { connection.disconnect() }
    }
    private fun endpointFrom(json:JSONObject,host:String):Endpoint {
        if(json.optString("service")!="algebra-lab-progress" || json.optInt("schema")!=1)throw IOException("Это другой сервис.")
        val port=json.optInt("port");val id=json.optString("device_id")
        if(port !in 1..65535 || !id.matches(Regex("[a-f0-9]{32}")))throw IOException("Неверный ответ тренажёра.")
        return Endpoint(host,port,id,json.optString("name","Алгебра LAB").take(80))
    }
    private fun discover():List<Endpoint> {
        val network=wifi();val nonce=UUID.randomUUID().toString();val found=linkedMapOf<String,Endpoint>()
        DatagramSocket().use { socket ->
            network.bindSocket(socket);socket.broadcast=true;socket.soTimeout=250
            val targets=mutableSetOf("255.255.255.255")
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { iface -> iface.interfaceAddresses.forEach { address -> address.broadcast?.hostAddress?.let { targets.add(it) } } }
            val payload=JSONObject().put("service","algebra-lab-progress").put("schema",1).put("nonce",nonce).toString().toByteArray()
            for(host in targets)runCatching { socket.send(DatagramPacket(payload,payload.size,InetAddress.getByName(host),8766)) }
            val deadline=System.nanoTime()+4_000_000_000L
            while(System.nanoTime()<deadline && !Thread.currentThread().isInterrupted) {
                try {
                    val packet=DatagramPacket(ByteArray(2048),2048);socket.receive(packet)
                    val json=JSONObject(String(packet.data,0,packet.length,Charsets.UTF_8))
                    if(json.optString("nonce")==nonce) { val ep=endpointFrom(json,packet.address.hostAddress.orEmpty());found[ep.id]=ep }
                } catch(_:SocketTimeoutException) {} catch(_:org.json.JSONException) {} catch(_:IOException) {}
            }
        }
        return found.values.toList()
    }
    private fun search() {
        launch("Ищем тренажёр в Wi-Fi…",{discover()}) { found ->
            if(found.isEmpty()) {
                MaterialAlertDialogBuilder(this).setTitle("Тренажёр не найден").setMessage("Включите доступ в разделе взрослого на Raspberry Pi. В гостевой Wi-Fi сети поиск может быть ограничен; можно указать адрес с экрана тренажёра.")
                    .setPositiveButton("Указать адрес") { _,_->manualAddress() }.setNegativeButton("Закрыть",null).show()
            } else if(found.size==1) select(found[0])
            else MaterialAlertDialogBuilder(this).setTitle("Выберите тренажёр").setItems(found.map { "${it.name}\n${it.host}" }.toTypedArray()) { _,i->select(found[i]) }.show()
        }
    }
    private fun manualAddress() {
        val input=TextInputEditText(this).apply {inputType=InputType.TYPE_CLASS_TEXT;isSingleLine=true}
        val field=TextInputLayout(this).apply {hint="192.168.1.10:8765";boxBackgroundMode=TextInputLayout.BOX_BACKGROUND_OUTLINE;addView(input);setPadding(dp(20),dp(8),dp(20),0)}
        MaterialAlertDialogBuilder(this).setTitle("Адрес тренажёра").setView(field).setPositiveButton("Найти") { _,_->
            val parts=input.text.toString().trim().split(":");val host=parts[0];val port=parts.getOrNull(1)?.toIntOrNull()?:8765
            if(parts.size>2 || port !in 1..65535 || !host.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}")) || host.split('.').any { it.toInt() !in 0..255 }) { status.text="Укажите IPv4-адрес, например 192.168.1.10:8765";return@setPositiveButton }
            launch("Проверяем адрес…",{endpointFrom(JSONObject(request(Endpoint(host,port,"",""),"/v1/info").text),host)}) { select(it) }
        }.setNegativeButton("Отмена",null).show()
    }
    private fun select(ep:Endpoint) {
        val remembered=endpoint()
        if(remembered?.id==ep.id && prefs.getString("token", "").orEmpty().isNotEmpty()) { remember(ep);refresh();return }
        pair(ep)
    }
    private fun pair(ep:Endpoint) {
        val input=TextInputEditText(this).apply {inputType=InputType.TYPE_CLASS_NUMBER;filters=arrayOf(InputFilter.LengthFilter(6));isSingleLine=true;textSize=26f;importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO}
        val field=TextInputLayout(this).apply {hint="Код из 6 цифр";boxBackgroundMode=TextInputLayout.BOX_BACKGROUND_OUTLINE;addView(input);setPadding(dp(20),dp(8),dp(20),0)}
        MaterialAlertDialogBuilder(this).setTitle(ep.name).setMessage("На Raspberry Pi: Для взрослого → Прогресс на Android → Получить новый код. Введите его здесь один раз.")
            .setView(field).setPositiveButton("Подключить") { _,_->
                val code=input.text.toString()
                if(!code.matches(Regex("\\d{6}"))) {status.text="Нужен код из 6 цифр.";return@setPositiveButton}
                launch("Подключаем телефон…",{JSONObject(request(ep,"/v1/pair",body=JSONObject().put("code",code)).text)}) { json ->
                    remember(ep);prefs.edit().putString("token",json.getString("token")).apply();etag="";refresh()
                }
            }.setNegativeButton("Отмена",null).show()
    }
    private fun remember(ep:Endpoint) {
        if(prefs.getString("device","")!=ep.id) {
            data=null;selected="";etag=""
            prefs.edit().remove("snapshot").remove("last_sync").remove("selected").apply();render(false)
        }
        prefs.edit().putString("host",ep.host).putInt("port",ep.port).putString("device",ep.id).putString("name",ep.name).apply() }
    private fun refresh() {
        val ep=endpoint()?:return
        val token=prefs.getString("token", "").orEmpty();if(token.isEmpty()) {pair(ep);return}
        launch("Обновляем прогресс…",{request(ep,"/v1/progress",token=token,tag=etag)}) { response ->
            if(response.status==200) {
                val incoming=JSONObject(response.text)
                if(incoming.optInt("schema")!=1 || incoming.optString("device_id")!=ep.id) {status.text="Ответ другого устройства. Выполните поиск заново.";return@launch}
                val prepared=preparedProposal()
                val profiles=incoming.optJSONArray("profiles")?:JSONArray()
                for(i in 0 until profiles.length())if(profiles.getJSONObject(i).optJSONObject("lesson_request")?.optString("id")==prepared?.optString("id") && prepared!=null)prefs.edit().remove("proposal_retry").apply()
                val changed=data?.toString()!=incoming.toString();data=incoming
                prefs.edit().putString("snapshot",incoming.toString()).apply();etag=response.etag
                if(changed)render(true)
            }
            online=true
            prefs.edit().putLong("last_sync",System.currentTimeMillis()).apply()
            status.text="${ep.name}\nОбновлено: ${lastSync()} · автообновление 25 с"
        }
    }
    private fun lastSync():String { val timestamp=prefs.getLong("last_sync",0);return if(timestamp==0L)"ещё не обновлялось" else SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(timestamp)) }
    private fun stamp(raw:String):String=runCatching { SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(OffsetDateTime.parse(raw).toInstant().toEpochMilli())) }.getOrDefault("—")
    private fun openProfile(id:String) {
        selected=id;tab=1;prefs.edit().putString("selected",id).putInt("tab",1).apply()
        navigation.menu.findItem(2).isChecked=true;render(false);reveal()
    }
    private fun avatar(profile:JSONObject,size:Int=52):TextView {
        val name=profile.optString("name","?")
        val initial=if(name.isNotEmpty())String(Character.toChars(name.codePointAt(0))).uppercase() else "?"
        val backgrounds=intArrayOf(0xffe9e0ff.toInt(),0xffcef1e7.toInt(),0xffffedc7.toInt(),0xffddecff.toInt())
        val index=(profile.optString("id").hashCode() and Int.MAX_VALUE)%backgrounds.size
        return text(initial,24,true).apply {gravity=android.view.Gravity.CENTER;setTextColor(Color.rgb(65,49,111));background=GradientDrawable().apply {shape=GradientDrawable.OVAL;setColor(backgrounds[index])};layoutParams=LinearLayout.LayoutParams(dp(size),dp(size))}
    }
    private fun metric(parent:LinearLayout,value:String,label:String,light:Boolean=false){
        val box=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        box.addView(text(value,25,true).apply {if(light)setTextColor(Color.WHITE)})
        box.addView(text(label,13).apply {setTextColor(if(light)Color.rgb(222,211,250)else getColor(R.color.lab_muted))})
        parent.addView(box,LinearLayout.LayoutParams(0,-2,1f))
    }
    private fun render(preserveScroll:Boolean) {
        val previous=if(preserveScroll)scroll.scrollY else 0;scroll.isFocusableInTouchMode=true;scroll.requestFocus();content.removeAllViews();connectionSummary=null
        val profiles=data?.optJSONArray("profiles")?:JSONArray()
        when(tab){
            0->children(profiles)
            1->{
                if(profiles.length()==0)emptyProgress() else {
                    val profile=(0 until profiles.length()).map {profiles.getJSONObject(it)}.firstOrNull {it.optString("id")==selected}?:profiles.getJSONObject(0)
                    selected=profile.optString("id");progress(profile,profiles)
                }
            }
            else->trainer()
        }
        scroll.post {scroll.scrollTo(0,previous)}
    }
    private fun emptyProgress(){
        title("Прогресс появится здесь","Подключите тренажёр и проведите первое занятие.")
        val box=card();box.addView(text("Один тренажёр — несколько детей",22,true));gap(box)
        box.addView(caption("У каждого ребёнка свой путь. Результаты сохраняются на телефоне и доступны даже без связи."));gap(box)
        box.addView(button("Найти тренажёр",R.drawable.ic_wifi){search()})
    }
    private fun children(profiles:JSONArray){
        title("Как идут занятия?","Все дети и их маленькие открытия")
        if(profiles.length()==0){emptyProgress();return}
        var attempts=0;for(i in 0 until profiles.length())attempts+=profiles.getJSONObject(i).optInt("attempts")
        val hero=card(true);hero.addView(text("Каждый шаг имеет значение",22,true).apply {setTextColor(Color.WHITE)});gap(hero,16)
        val overview=LinearLayout(this);metric(overview,profiles.length().toString(),"профилей",true);metric(overview,attempts.toString(),"успешных решений",true);hero.addView(overview)
        content.addView(text("Дети",20,true));gap(content,10)
        for(i in 0 until profiles.length()){
            val profile=profiles.getJSONObject(i);val body=card();val row=LinearLayout(this).apply {gravity=android.view.Gravity.CENTER_VERTICAL}
            row.addView(avatar(profile));val info=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(8),0)}
            info.addView(text(profile.optString("name"),21,true));info.addView(caption("Уровень ${profile.optInt("level")} · ${profile.optInt("xp")} XP"))
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(ImageView(this).apply {setImageResource(R.drawable.ic_arrow);imageTintList=ColorStateList.valueOf(purple)},LinearLayout.LayoutParams(dp(24),dp(24)))
            body.addView(row);gap(body,14)
            val track=LinearProgressIndicator(this).apply {max=profile.optInt("total",52).coerceAtLeast(1);progress=profile.optInt("completed");setIndicatorColor(getColor(R.color.lab_secondary));trackCornerRadius=dp(4);trackThickness=dp(6)}
            body.addView(track,LinearLayout.LayoutParams(-1,dp(10)));gap(body,8)
            body.addView(caption("Освоено ${profile.optInt("completed")} из ${profile.optInt("total")} · ${stamp(profile.optString("last_activity"))}"))
            body.isClickable=true;body.isFocusable=true;body.contentDescription="Открыть прогресс ${profile.optString("name")}"
            body.setOnClickListener {openProfile(profile.optString("id"))}
        }
    }
    private fun progress(p:JSONObject,profiles:JSONArray){
        content.addView(text("Прогресс",26,true));gap(content,8)
        val selector=HorizontalScrollView(this).apply {isHorizontalScrollBarEnabled=false}
        val chips=ChipGroup(this).apply {isSingleLine=true;isSingleSelection=true}
        for(i in 0 until profiles.length()){
            val child=profiles.getJSONObject(i);chips.addView(selectionChip().apply {text=child.optString("name");isCheckable=true;isChecked=child.optString("id")==selected;isCheckedIconVisible=false;maxWidth=dp(180);ellipsize=TextUtils.TruncateAt.END;setOnClickListener {openProfile(child.optString("id"))}})
        }
        selector.addView(chips);content.addView(selector);gap(content,12)
        val hero=card(true);val top=LinearLayout(this).apply {gravity=android.view.Gravity.CENTER_VERTICAL}
        top.addView(avatar(p,56));val names=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,0,0)}
        names.addView(text(p.optString("name"),27,true).apply {setTextColor(Color.WHITE)})
        names.addView(text("Уровень ${p.optInt("level")} · ${p.optInt("xp")} XP",16).apply {setTextColor(Color.rgb(231,222,251))});top.addView(names);hero.addView(top);gap(hero,18)
        hero.addView(LinearProgressIndicator(this).apply {max=60;progress=p.optInt("xp")%60;setIndicatorColor(Color.rgb(255,209,101));trackColor=Color.rgb(116,97,165);trackThickness=dp(7);trackCornerRadius=dp(4)},LinearLayout.LayoutParams(-1,dp(10)))
        gap(hero,6);hero.addView(text("До следующего уровня: ${60-p.optInt("xp")%60} XP",13).apply {setTextColor(Color.rgb(231,222,251))})
        hero.addView(button("Предложить урок на Pi",R.drawable.ic_device,false){chooseLesson(p)})
        proposalCard(p)
        val chart=card();chart.addView(text("Успешные решения по дням",20,true));gap(chart,8)
        val periods=ChipGroup(this).apply {isSingleSelection=true}
        for(days in listOf(7,14,30))periods.addView(selectionChip().apply {text="$days дней";isCheckable=true;isChecked=days==range;isCheckedIconVisible=false;setOnClickListener {range=days;prefs.edit().putInt("range",days).apply();render(true)}})
        chart.addView(periods)
        val counts=mutableMapOf<String,Int>();val days=p.optJSONArray("daily")?:JSONArray()
        for(i in 0 until days.length()){val row=days.getJSONObject(i);counts[row.optString("day")]=row.optInt("count")}
        val today=runCatching {LocalDate.parse(data?.optString("today"))}.getOrDefault(LocalDate.now())
        val values=(range-1 downTo 0).map {today.minusDays(it.toLong()).let {day->day.toString() to (counts[day.toString()]?:0)}}
        val selectedDay=caption("Коснитесь столбца, чтобы посмотреть день")
        chart.addView(Bars(this,values){day,count->selectedDay.text="${shortDay(day)} · завершённых заданий: $count"},LinearLayout.LayoutParams(-1,dp(180)))
        chart.addView(selectedDay);chart.addView(caption("Повторы учитываются · даты по времени тренажёра"))
        val summary=card();val metrics=LinearLayout(this)
        metric(metrics,p.optInt("completed").toString(),"освоено заданий");metric(metrics,p.optInt("attempts").toString(),"успешных попыток");metric(metrics,(p.optInt("seconds")/60).toString(),"минут практики");summary.addView(metrics)
        val chapters=card();chapters.addView(text("Освоение глав",20,true));gap(chapters)
        val list=p.optJSONArray("chapters")?:JSONArray()
        for(i in 0 until list.length()){
            val chapter=list.getJSONObject(i);val row=LinearLayout(this)
            row.addView(text(chapter.optString("name"),16,true),LinearLayout.LayoutParams(0,-2,1f));row.addView(caption("${chapter.optInt("completed")}/${chapter.optInt("total")}"));chapters.addView(row)
            chapters.addView(LinearProgressIndicator(this).apply {max=chapter.optInt("total",6);progress=chapter.optInt("completed");trackThickness=dp(6);trackCornerRadius=dp(4);setIndicatorColor(getColor(R.color.lab_secondary))},LinearLayout.LayoutParams(-1,dp(14)));gap(chapters,12)
        }
        val history=card();history.addView(text("Последние завершённые задания",20,true));gap(history)
        val recent=p.optJSONArray("recent")?:JSONArray()
        if(recent.length()==0)history.addView(caption("Здесь появятся первые решения."))
        for(i in 0 until recent.length()){
            val row=recent.getJSONObject(i);history.addView(text(row.optString("title"),17,true))
            history.addView(text("★".repeat(row.optInt("stars").coerceIn(0,3)),16).apply {setTextColor(getColor(R.color.lab_warning))})
            history.addView(caption("${stamp(row.optString("completed_at"))} · ${row.optInt("seconds")} с · подсказок: ${row.optInt("hints")}"));gap(history,14)
        }
        history.addView(caption("Всего подсказок в завершённых заданиях: ${p.optInt("hints")}"))
    }
    private fun requestStatus(state:String):String=when(state){
        "pending"->"Ожидает на тренажёре";"accepted"->"Принято на тренажёре";"declined"->"Ребёнок отклонил";"cancelled"->"Отменено";"superseded"->"Заменено другим уроком";"expired"->"Время предложения истекло";else->"Статус уточняется"
    }
    private fun preparedProposal():JSONObject?=runCatching{JSONObject(prefs.getString("proposal_retry","").orEmpty())}.getOrNull()?.takeIf {it.optString("device_id")==endpoint()?.id}
    private fun proposalCard(profile:JSONObject){
        val proposal=profile.optJSONObject("lesson_request")
        val retry=preparedProposal()?.takeIf {it.optString("profile_id")==profile.optString("id")}
        if(proposal==null && retry==null)return
        val box=card();box.addView(text("Следующее занятие",20,true));gap(box)
        if(proposal!=null){
            box.addView(text(proposal.optString("title"),18,true));box.addView(caption(proposal.optString("equation")))
            val state=proposal.optString("state");gap(box,6)
            box.addView(text(requestStatus(state),16,true).apply{setTextColor(getColor(if(state=="accepted")R.color.lab_secondary else R.color.lab_primary))})
            if(state=="pending"){
                box.addView(caption("Pi предложит этот урок после текущего задания. Ребёнок сможет открыть его или отклонить."))
                box.addView(button("Отменить предложение",filled=false){cancelProposal(profile,proposal)})
            }
        }
        if(retry!=null){
            box.addView(caption("Отправка не подтверждена. Повтор безопасно проверит тот же запрос без дубликата."))
            box.addView(button("Повторить отправку"){sendProposal(retry)})
        }
    }
    private fun chooseLesson(profile:JSONObject){
        val ep=endpoint()?:return search()
        val key=profile.optString("id");val token=prefs.getString("token","").orEmpty()
        launch("Получаем доступные уроки…",{JSONObject(request(ep,"/v1/lessons?profile="+URLEncoder.encode(key,"UTF-8"),token).text)}) { catalog->
            if(!catalog.optBoolean("can_propose")){
                MaterialAlertDialogBuilder(this).setTitle("Разрешите предложения на Pi").setMessage("В разделе взрослого на Raspberry Pi откройте доступ к Android и нажмите «Разрешить предложения уроков с телефона». Чтение прогресса продолжает работать как раньше.").setPositiveButton("Понятно",null).show()
                return@launch
            }
            val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0)}
            val note=caption("Для ${profile.optString("name")}. Текущее решение не прервётся. Серые уровни пока закрыты.");panel.addView(note)
            val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            panel.addView(ScrollView(this).apply{addView(rows)},LinearLayout.LayoutParams(-1,dp((resources.configuration.screenHeightDp-240).coerceIn(120,380))))
            val dialog=MaterialAlertDialogBuilder(this).setTitle("Следующий урок").setView(panel).setNegativeButton("Отмена",null).create()
            val lessons=catalog.optJSONArray("lessons")?:JSONArray();var chapter=""
            for(i in 0 until lessons.length()){
                val lesson=lessons.getJSONObject(i)
                if(lesson.optString("chapter")!=chapter){chapter=lesson.optString("chapter");gap(rows);rows.addView(text(chapter,17,true))}
                rows.addView(button("${i+1}. ${lesson.optString("title")}\n${lesson.optString("equation")}",filled=false){
                    dialog.dismiss()
                    MaterialAlertDialogBuilder(this).setTitle("Предложить урок?").setMessage("${profile.optString("name")}: ${lesson.optString("equation")}\n\nПосле завершения текущего задания Pi покажет предложение. Оно заменит прежний ожидающий урок этого ребёнка.")
                        .setPositiveButton("Отправить"){_,_->
                            val payload=JSONObject().put("id",UUID.randomUUID().toString().replace("-","")).put("profile_id",key).put("task_id",lesson.optString("id")).put("device_id",ep.id)
                            prefs.edit().putString("proposal_retry",payload.toString()).apply();sendProposal(payload)
                        }.setNegativeButton("Отмена",null).show()
                }.apply {isEnabled=lesson.optBoolean("available");textAlignment=View.TEXT_ALIGNMENT_VIEW_START;minHeight=dp(64)})
            }
            dialog.show()
        }
    }
    private fun applyProposal(profileId:String,proposal:JSONObject){
        val profiles=data?.optJSONArray("profiles")?:return
        for(i in 0 until profiles.length()){
            val profile=profiles.getJSONObject(i)
            if(profile.optString("id")==profileId){
                val current=profile.optJSONObject("lesson_request")
                if(current==null || current.optString("created_at")<=proposal.optString("created_at"))profile.put("lesson_request",proposal)
            }
        }
        prefs.edit().putString("snapshot",data.toString()).apply();etag="";render(true)
    }
    private fun sendProposal(payload:JSONObject){
        val ep=endpoint()?:return
        if(payload.optString("device_id")!=ep.id){status.text="Предложение относится к другому тренажёру.";return}
        render(false)
        if(busy){status.text="Дождитесь обновления, затем нажмите «Повторить отправку». Предложение сохранено.";return}
        val body=JSONObject().put("id",payload.optString("id")).put("profile_id",payload.optString("profile_id")).put("task_id",payload.optString("task_id"))
        launch("Передаём следующий урок…",{JSONObject(request(ep,"/v1/lesson-requests",prefs.getString("token","").orEmpty(),body).text)}) { result->
            val saved=preparedProposal()
            if(saved?.optString("id")==payload.optString("id"))prefs.edit().remove("proposal_retry").apply()
            val proposal=result.getJSONObject("request");applyProposal(payload.optString("profile_id"),proposal)
            status.text=requestStatus(proposal.optString("state"));refresh()
        }
    }
    private fun cancelProposal(profile:JSONObject,proposal:JSONObject){
        val ep=endpoint()?:return
        val body=JSONObject().put("id",proposal.optString("id")).put("profile_id",profile.optString("id"))
        launch("Отменяем предложение…",{JSONObject(request(ep,"/v1/lesson-requests/cancel",prefs.getString("token","").orEmpty(),body).text)}) {result->
            applyProposal(profile.optString("id"),result.getJSONObject("request"));refresh()
        }
    }
    private fun trainer(){
        title("Ваш тренажёр","Подключение и синхронизация")
        val box=card(true);box.addView(text(if(endpoint()==null)"Подключим Алгебра LAB" else "Тренажёр рядом",24,true).apply {setTextColor(Color.WHITE)})
        gap(box);box.addView(text("Одна Wi-Fi сеть. Без камеры, QR-кода и облачного аккаунта.",16).apply {setTextColor(Color.rgb(231,222,251))})
        val connection=card();connection.addView(text("Подключение",20,true));gap(connection)
        connectionSummary=caption(trainerSummary());connection.addView(connectionSummary);gap(connection)
        connection.addView(button("Найти тренажёр",R.drawable.ic_wifi){search()})
        connection.addView(button("Обновить сейчас",R.drawable.ic_refresh,false){if(endpoint()==null)search() else refresh()})
        connection.addView(button("Указать адрес вручную",filled=false){manualAddress()})
        val help=card();help.addView(text("Как подключиться",20,true));gap(help)
        help.addView(caption("1. На Raspberry Pi откройте раздел взрослого и включите доступ к Android.\n\n2. Получите шестизначный код и найдите тренажёр с телефона.\n\n3. Введите код один раз — приложение запомнит устройство."))
        gap(help);help.addView(caption("Результаты обновляются каждые 25 секунд, пока приложение открыто. Без связи остаётся сохранённая копия."))
        val appearance=card();appearance.addView(text("Оформление",20,true));gap(appearance)
        appearance.addView(caption("Светлая или тёмная тема выбирается по настройке телефона."))
        appearance.addView(MaterialSwitch(this).apply {text="Короткие анимации";isChecked=prefs.getBoolean("animations",true);setOnCheckedChangeListener {_,enabled->prefs.edit().putBoolean("animations",enabled).apply();if(!enabled){content.animate().cancel();content.alpha=1f}}})
    }
}

private class Bars(context:Context,private val values:List<Pair<String,Int>>,private val select:(String,Int)->Unit):View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val density=resources.displayMetrics.density
    private var selected=-1
    init {isClickable=true;isFocusable=true;contentDescription="Диаграмма за ${values.size} дней. Используйте касание или действия вперёд и назад для выбора дня."}
    private fun choose(index:Int){selected=index.coerceIn(values.indices);select(values[selected].first,values[selected].second);contentDescription="${values[selected].first}: завершённых заданий ${values[selected].second}";invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_SELECTED)}
    override fun performClick():Boolean {super.performClick();return true}
    override fun onTouchEvent(event:android.view.MotionEvent):Boolean {
        if(event.action==android.view.MotionEvent.ACTION_UP){val step=(width-48*density)/values.size;choose(((event.x-24*density)/step).toInt());performClick();return true}
        return true
    }
    override fun onInitializeAccessibilityNodeInfo(info:AccessibilityNodeInfo){super.onInitializeAccessibilityNodeInfo(info);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD)}
    override fun performAccessibilityAction(action:Int,args:Bundle?):Boolean {
        if(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD){choose(if(selected<0)0 else selected+1);return true}
        if(action==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD){choose(if(selected<0)0 else selected-1);return true}
        return super.performAccessibilityAction(action,args)
    }
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        val left=24*density;val bottom=height-26*density;val top=24*density;val step=(width-left*2)/values.size
        val max=(values.maxOfOrNull {it.second}?:0).coerceAtLeast(1)
        paint.textSize=11*resources.displayMetrics.scaledDensity;paint.textAlign=Paint.Align.CENTER
        for(i in 0..2){val y=bottom-(bottom-top)*i/2;paint.color=context.getColor(R.color.lab_outline);paint.strokeWidth=density;canvas.drawLine(left,y,width-left,y,paint)}
        values.forEachIndexed {i,pair->
            val x=left+i*step;val h=(bottom-top)*pair.second/max
            paint.color=context.getColor(if(i==selected)R.color.lab_secondary else R.color.lab_primary)
            val radius=minOf(6*density,step*.25f)
            canvas.drawRoundRect(x+step*.18f,bottom-h,x+step*.82f,bottom,radius,radius,paint)
            if(pair.second>0 && (values.size<=14 || i==selected)){paint.color=context.getColor(R.color.lab_ink);canvas.drawText(pair.second.toString(),x+step/2,bottom-h-7*density,paint)}
            if(i==0||i==values.lastIndex||i==values.size/2){paint.color=context.getColor(R.color.lab_muted);canvas.drawText(shortDay(pair.first),x+step/2,bottom+20*density,paint)}
        }
        if(values.all {it.second==0}){paint.color=context.getColor(R.color.lab_muted);paint.textSize=14*resources.displayMetrics.scaledDensity;canvas.drawText("Пока нет завершённых заданий",width/2f,height/2f,paint)}
    }
}
