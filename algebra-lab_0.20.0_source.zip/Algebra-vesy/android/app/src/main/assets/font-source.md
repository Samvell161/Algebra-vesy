# Algebra Rounded

Static Cyrillic/Latin subsets derived from Google Fonts Nunito (wght 400 / 700), renamed Algebra Rounded. Distributed under the included SIL Open Font License 1.1 (OFL.txt).

Source: https://raw.githubusercontent.com/google/fonts/main/ofl/nunito/Nunito%5Bwght%5D.ttf
Source SHA-256: bb55a5ca5c2042335b3991af27c4d0705d0ef41cac6164ac737fd8f2a1e85207
Retrieved 2026-10-30 over verified HTTPS. Source license copyright retained in OFL.txt and font name records.
Build used fontTools instancer for weights 400/700, then subset to Latin, Cyrillic, punctuation and available symbols. Renamed family, full name and PostScript name. No runtime fontTools dependency.
