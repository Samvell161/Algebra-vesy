package ru.algebralab.progress

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34],qualifiers="w360dp-h780dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DesignTest {
    @Before fun seed() {
        val profiles=JSONArray()
        for((index,name) in listOf("Маша","Саша").withIndex()){
            val days=JSONArray()
            for((offset,count) in listOf(2,1,0,3,2,4,2).withIndex())days.put(JSONObject().put("day",java.time.LocalDate.parse("2026-11-04").minusDays((6-offset).toLong()).toString()).put("count",count))
            val chapters=JSONArray()
            for((i,title) in listOf("Первые открытия","Числа побольше","Зеркальные весы","X с двух сторон").withIndex())chapters.put(JSONObject().put("name",title).put("total",6).put("completed",if(i==0)6 else if(i==1)2-index else 0))
            val recent=JSONArray().put(JSONObject().put("title","Четыре единицы").put("stars",3).put("hints",0).put("seconds",84).put("completed_at","2026-11-04T12:00:00+00:00"))
            profiles.put(JSONObject().put("id",if(index==0)"default" else "sasha").put("name",name).put("completed",8-index).put("total",52).put("xp",210-index*90).put("level",4-index)
                .put("attempts",14-index*5).put("seconds",840-index*120).put("hints",2).put("last_activity","2026-11-04T12:00:00+00:00").put("daily",days).put("chapters",chapters).put("recent",recent))
        }
        val snapshot=JSONObject().put("schema",1).put("device_id","test").put("today","2026-11-04").put("profiles",profiles)
        RuntimeEnvironment.getApplication().getSharedPreferences("trainer",Context.MODE_PRIVATE).edit().clear().putString("snapshot",snapshot.toString()).putLong("last_sync",java.time.Instant.parse("2026-11-04T12:00:00Z").toEpochMilli()).putBoolean("animations",false).commit()
    }
    private fun views(view:View):List<View> = listOf(view)+if(view is ViewGroup)(0 until view.childCount).flatMap {views(view.getChildAt(it))} else emptyList()
    private fun capture(activity:MainActivity,name:String){
        org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(500))
        val root=activity.window.decorView
        root.forceLayout()
        root.measure(View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(2340,View.MeasureSpec.EXACTLY));root.layout(0,0,1080,2340)
        val bitmap=Bitmap.createBitmap(1080,2340,Bitmap.Config.ARGB_8888);root.draw(Canvas(bitmap))
        val path=File(System.getProperty("algebra.screenshots"),name+".png");path.parentFile!!.mkdirs();path.outputStream().use {bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}

        assertTrue(path.length()>5000)
    }
    @Test @Config(sdk=[34],qualifiers="w360dp-h780dp-night-xxhdpi")
    fun darkThemeRenders(){
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
        try {assertEquals(0xff15141d.toInt(),controller.get().getColor(R.color.lab_background));capture(controller.get(),"children-dark")}finally {controller.pause().stop().destroy()}
    }
    @Test fun navigationRangeAndScreens(){
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
        try{
            val activity=controller.get();capture(activity,"children")
            val name=views(activity.window.decorView).filterIsInstance<TextView>().first {it.text.toString()=="Маша"}
            generateSequence(name as View?) {it.parent as? View}.first {it.isClickable}.performClick()
            capture(activity,"progress")
            val bars=views(activity.window.decorView).first {it.javaClass.simpleName=="Bars"}
            val density=activity.resources.displayMetrics.density
            val x=24*density+(bars.width-48*density)/14*12.5f
            val now=android.os.SystemClock.uptimeMillis()
            bars.dispatchTouchEvent(android.view.MotionEvent.obtain(now,now,android.view.MotionEvent.ACTION_DOWN,x,bars.height/2f,0))
            bars.dispatchTouchEvent(android.view.MotionEvent.obtain(now,now+10,android.view.MotionEvent.ACTION_UP,x,bars.height/2f,0))
            assertTrue(views(activity.window.decorView).filterIsInstance<TextView>().any {it.text.toString()=="03.11 · завершённых заданий: 4"})
            capture(activity,"progress-selected")
            val range=views(activity.window.decorView).filterIsInstance<TextView>().first {it.text.toString()=="30 дней"}
            range.performClick()
            assertEquals(30,activity.getSharedPreferences("trainer",Context.MODE_PRIVATE).getInt("range",0))
            val nav=views(activity.window.decorView).filterIsInstance<BottomNavigationView>().first()
            nav.selectedItemId=3;capture(activity,"trainer")
            assertTrue(views(activity.window.decorView).filterIsInstance<TextView>().any {it.text.toString()=="Найти тренажёр"})
            activity.onBackPressedDispatcher.onBackPressed()
            assertEquals(1,nav.selectedItemId)
        }finally{controller.pause().stop().destroy()}
    }
}
