package ru.algebralab.progress

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class MainActivityTest {
    @Before fun clear() { RuntimeEnvironment.getApplication().getSharedPreferences("trainer",Context.MODE_PRIVATE).edit().clear().commit() }
    private fun labels(view:View):List<TextView> {
        val result=mutableListOf<TextView>()
        if(view is TextView)result.add(view)
        if(view is ViewGroup)for(i in 0 until view.childCount)result.addAll(labels(view.getChildAt(i)))
        return result
    }
    @Test fun firstLaunchNeedsNoInternetAndOffersDiscovery() {
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
        try {
            val texts=labels(controller.get().window.decorView).map {it.text.toString()}
            assertTrue(texts.contains("Найти тренажёр"))
            assertTrue(texts.contains("Обновить сейчас"))
            assertTrue(texts.any {it.contains("QR-код не нужны")})
        } finally {controller.pause().stop().destroy()}
    }
    @Test fun cachedProfilesOpenDetailAndChartWithoutTrainer() {
        val profile=JSONObject().put("id","default").put("name","Маша").put("completed",2).put("total",52).put("xp",60).put("level",2)
            .put("attempts",2).put("seconds",90).put("hints",1).put("last_activity","2026-11-04T12:00:00+00:00")
            .put("daily",JSONArray().put(JSONObject().put("day","2026-11-04").put("count",2)))
            .put("chapters",JSONArray().put(JSONObject().put("name","Первые открытия").put("completed",2).put("total",6))).put("recent",JSONArray())
        val snapshot=JSONObject().put("schema",1).put("device_id","demo").put("today","2026-11-04").put("profiles",JSONArray().put(profile))
        RuntimeEnvironment.getApplication().getSharedPreferences("trainer",Context.MODE_PRIVATE).edit().putString("snapshot",snapshot.toString()).putLong("last_sync",1000).commit()
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
        try {
            val activity=controller.get()
            val name=labels(activity.window.decorView).first {it.text.toString()=="Маша"}
            generateSequence(name as View?) { it.parent as? View }.first {it.isClickable}.performClick()
            val texts=labels(activity.window.decorView).map {it.text.toString()}
            assertTrue(texts.contains("Успешные решения по дням"))
            assertTrue(texts.any {it.contains("60 XP")})
            assertTrue(texts.contains("Освоение глав"))
            assertTrue(texts.any {it.contains("Сохранённые данные")})
        } finally {controller.pause().stop().destroy()}
    }
    @Test fun pendingLessonAndUnconfirmedRetrySurviveOfflineRecreation() {
        val proposal=JSONObject().put("id","a".repeat(32)).put("title","Первые весы").put("equation","x = 2").put("state","pending")
        val profile=JSONObject().put("id","default").put("name","Маша").put("lesson_request",proposal)
        val snapshot=JSONObject().put("schema",1).put("device_id","demo").put("profiles",JSONArray().put(profile))
        val retry=JSONObject().put("id","b".repeat(32)).put("profile_id","default").put("task_id","cups-1").put("device_id","demo")
        val prefs=RuntimeEnvironment.getApplication().getSharedPreferences("trainer",Context.MODE_PRIVATE)
        prefs.edit().putString("snapshot",snapshot.toString()).putString("selected","default").putInt("tab",1)
            .putString("device","demo").putString("host","192.0.2.1").putString("proposal_retry",retry.toString()).commit()
        repeat(2) {
            val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
            try {
                val texts=labels(controller.get().window.decorView).map {it.text.toString()}
                assertTrue(texts.contains("Ожидает на тренажёре"))
                assertTrue(texts.contains("Отменить предложение"))
                assertTrue(texts.contains("Повторить отправку"))
                assertEquals(retry.toString(),prefs.getString("proposal_retry",""))
            } finally {controller.pause().stop().destroy()}
        }
    }
}
