"""Optional browser acceptance checks against a temporary isolated server/database."""
import argparse
import shutil
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from algebra_lab.__main__ import Application
from algebra_lab.hardware import Reader
from algebra_lab.storage import Store


def main():
    from playwright.sync_api import sync_playwright, expect

    parser = argparse.ArgumentParser()
    parser.add_argument("--chromium", default=shutil.which("chromium") or shutil.which("chromium-browser"))
    parser.add_argument("--screenshots", type=Path)
    args = parser.parse_args()
    if args.screenshots:
        args.screenshots.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temp:
        store, reader = Store(Path(temp)/"browser.sqlite3"), Reader()
        server = Application(("127.0.0.1", 0), store, reader)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=args.chromium, args=["--no-sandbox"])
                page = browser.new_page(viewport={"width":1024,"height":600}, device_scale_factor=1)
                errors = []
                http_errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                page.on("console", lambda message: errors.append(message.text) if message.type=="error" and '400 (Bad Request)' not in message.text else None)
                page.on("response", lambda response: http_errors.append((response.url.split(server_url)[-1],response.status)) if response.status>=400 else None)
                server_url = f"http://127.0.0.1:{server.server_port}"
                page.goto(f"http://127.0.0.1:{server.server_port}")
                expect(page.get_by_role("heading",name="Уравнения, которые можно потрогать.")).to_be_visible()
                if args.screenshots:
                    page.screenshot(path=str(args.screenshots/"home-1024.png"), full_page=True)
                page.get_by_role("button",name="Начать исследование").click()
                expect(page.get_by_role("heading",name="Первое равновесие")).to_be_visible()
                if args.screenshots:
                    page.screenshot(path=str(args.screenshots/"exercise-1024.png"), full_page=True)
                page.locator('#operand').fill('0')
                page.locator('#operation-form button[type=submit]').click()
                expect(page.locator('#toast')).to_contain_text('ничего не меняет')
                page.locator('[data-action=keypad][data-target=operand]').click()
                page.get_by_role('button',name='Очистить',exact=True).click()
                page.locator('[data-action=keypad-key][data-key="3"]').click()
                page.get_by_role('button',name='Готово',exact=True).click()
                expect(page.locator('#operand')).to_have_value('3')
                page.locator('#operation-form button[type=submit]').click()
                expect(page.locator('.success-panel')).to_contain_text('x = 4')
                expect(page.locator('.success-panel .stars')).to_have_attribute('aria-label','3 из 3 звёзд')
                page.get_by_role('button',name='Дальше').click()
                page.get_by_role('button',name='Подсказка',exact=True).click()
                expect(page.locator('.hint-box')).to_be_visible()
                page.locator('#answer').fill('9')
                page.locator('#answer-form button[type=submit]').click()
                expect(page.locator('.success-panel')).to_contain_text('x = 9')
                expect(page.locator('.success-panel .stars')).to_have_attribute('aria-label','2 из 3 звёзд')
                page.get_by_role('link',name='Мой прогресс',exact=True).click()
                expect(page.locator('.stats-grid > div').first).to_contain_text('2 / 24')
                page.reload()
                expect(page.locator('.stats-grid > div').first).to_contain_text('2 / 24')
                page.get_by_role('link',name='Практика',exact=True).click()
                page.locator('[data-action=start][data-id=double]').click()
                page.locator('#operand').fill('2')
                page.locator('#operation-form button[type=submit]').click()
                expect(page.locator('.big-equation')).to_have_text('3x=12')
                page.get_by_role('button',name='Отменить',exact=True).click()
                expect(page.locator('.big-equation')).to_have_text('3x + 2=14')
                page.get_by_role('link',name='Лаборатория',exact=True).click()
                page.locator('[data-action=sim-block][data-kind=x]').click()
                page.locator('[data-action=sim-block][data-kind="1"]').click()
                page.locator('[data-action=side][data-side=right]').click()
                page.locator('[data-action=sim-block][data-kind="5"]').click()
                page.locator('#lab-x').fill('4')
                page.get_by_role('button',name='Подставить',exact=True).click()
                expect(page.locator('.balance-status')).to_contain_text('Равенство при выбранном x')
                expect(page.locator('.substitution')).to_have_text('5 = 5')
                if args.screenshots:
                    page.screenshot(path=str(args.screenshots/"lab-1024.png"), full_page=True)
                page.locator('.physical-block').first.click()
                expect(page.locator('.physical-block')).to_have_count(2)
                page.get_by_role('button',name='Очистить чаши').click()
                expect(page.locator('.physical-block')).to_have_count(0)
                page.locator('#custom-equation').fill('x+1=x+2')
                page.get_by_role('button',name='Исследовать',exact=True).click()
                expect(page.locator('#custom-result')).to_contain_text('не имеет решений')
                page.get_by_role('button',name='Настройки профиля').click()
                page.locator('#learner-name').fill('Саша')
                page.locator('[name=motion]').uncheck()
                page.get_by_role('button',name='Сохранить настройки').click()
                expect(page.locator('#profile-name')).to_have_text('Саша')
                page.get_by_role('button',name='Настроить RFID-метки').click()
                page.locator('#tag-uid').fill('AA:BB')
                page.get_by_role('button',name='Сохранить метку').click()
                expect(page.locator('.tag-list')).to_contain_text('AA:BB')
                page.get_by_role('button',name='Удалить привязку AA:BB').click()
                expect(page.locator('.tag-list')).to_contain_text('Пока нет')
                page.get_by_role('button',name='Закрыть',exact=True).click()
                page.get_by_role('link',name='Практика',exact=True).click()
                page.get_by_role('button',name='Уровень 4',exact=True).click()
                expect(page.locator('.task-card')).to_have_count(6)
                page.get_by_role('button',name='Вызов на 3 минуты').click()
                expect(page.locator('[data-clock]')).to_be_visible()
                # Validate every viewport for navigation, overflow, and usable forms.
                for width,height in [(1024,600),(800,480),(390,844)]:
                    page.set_viewport_size({"width":width,"height":height})
                    for route in ['home','practice','exercise','lab','progress']:
                        page.goto(f"http://127.0.0.1:{server.server_port}/#{route}")
                        expect(page.locator('main h1')).to_be_visible()
                        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), (width,route,'horizontal overflow')
                page.get_by_role('button',name='Как это работает').click()
                expect(page.get_by_role('heading',name='Здесь всё можно понять.')).to_be_visible()
                page.get_by_role('button',name='Попробовать в лаборатории').click()
                expect(page.locator('.lab-stage')).to_be_visible()
                page.get_by_role('button',name='Настройки профиля').click()
                page.get_by_role('button',name='Сбросить учебный прогресс').click()
                page.get_by_role('button',name='Удалить прогресс',exact=True).click()
                page.get_by_role('link',name='Мой прогресс',exact=True).click()
                expect(page.locator('.stats-grid > div').first).to_contain_text('0 / 24')
                assert http_errors == [('/api/exercise/transform',400)], http_errors
                assert not errors, errors
                browser.close()
                print('PASS: browser flow, undo, persistence, RFID bindings, challenge, help, reset, and 15 viewport/page checks; no unexpected browser/network errors. One expected validation HTTP 400.')
        finally:
            server.shutdown()
            server.server_close()
            thread.join()
            reader.close()
            store.close()


if __name__=='__main__':
    main()
