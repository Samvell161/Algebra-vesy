"""Verify the packaged Tk return button, lock release and Qt restoration."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    subprocess.run(['dpkg-deb','-x',sys.argv[1],str(root)],check=True)
    payload=root/'usr/share/algebra-lab';sys.path.insert(0,str(payload))
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.app import Window
    app=QApplication([])
    profile=root/'profile';profile.mkdir()
    w=Window(profile);w.start('cups-4');w.store.bind('AA','1');w.operation('remove')
    w.scan({'uid':'AA','source':'left'});w.scan({'uid':'AA','source':'right'})
    original=w.condition.text();current=w.session.current;w.close()
    code='''
import sys,json,fcntl
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from algebra_lab import desktop
original_init=desktop.Desktop.__init__
def init(self,*args,**kwargs):
    original_init(self,*args,**kwargs)
    self.root.after(150,lambda:self.controls['return-child'].invoke())
desktop.Desktop.__init__=init
def restart(executable,command):
    with (Path(sys.argv[2])/'desktop.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    Path(sys.argv[3]).write_text(json.dumps(command))
desktop.os.execv=restart
assert desktop.main(['--data-dir',sys.argv[2],'--windowed'])==0
'''
    note=root/'command.json';env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':97'))
    result=subprocess.run(['/usr/bin/python3','-c',code,str(payload),str(profile),str(note)],env=env,capture_output=True,text=True,timeout=15)
    assert result.returncode==0,(result.stdout,result.stderr)
    command=json.loads(note.read_text())
    assert command[1]==str(payload/'launcher.py')
    assert '--legacy' not in command and '--windowed' in command
    assert command[command.index('--data-dir')+1]==str(profile)
    w=Window(profile)
    assert w.session.task_id=='cups-4' and w.session.current==current
    assert w.condition.text()==original
    w.close()
    print('PASS: packaged return button saves steps, releases profile lock, launches Qt command and restores original condition/current solution')
