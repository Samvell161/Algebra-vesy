"""Record the actual Qt workspace, with simulated UID input, to an animated GIF.

Development only: requires PyQt6, QtAwesome and Pillow. No runtime dependency.
"""
import argparse
import io
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PIL import Image
from PyQt6.QtCore import QBuffer,QIODevice
from PyQt6.QtGui import QFontDatabase
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication
from algebra_lab.qt_ui.app import Window

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True)
app=QApplication([])
for path in (ROOT/'packaging/fonts').glob('*.ttf'):QFontDatabase.addApplicationFont(str(path))
app.setStyleSheet((ROOT/'algebra_lab/qt_ui/theme.qss').read_text())
frames=[]
with tempfile.TemporaryDirectory() as tmp:
    window=Window(Path(tmp));window.start('cups-4');window.show();app.processEvents()
    def capture(count):
        for _ in range(count):
            QTest.qWait(50)
            buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            window.grab().save(buffer,'PNG')
            frames.append(Image.open(io.BytesIO(bytes(buffer.data()))).convert('RGB').quantize(colors=160))
    try:
        window.store.bind('BB','2');window.operation('remove');capture(12)
        window.reader.emit({'uid':'BB','source':'left'});window.poll();capture(22)
        window.reader.emit({'uid':'BB','source':'right'});window.poll();capture(22)
        window.answer.setCurrentIndex(1);window.check();capture(26)
    finally:window.close()
frames[0].save(args.output,save_all=True,append_images=frames[1:],duration=50,loop=0,optimize=True)
print('Recorded actual Qt widgets:',args.output,args.output.stat().st_size,'bytes')
