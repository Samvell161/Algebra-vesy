"""Run with QT_QPA_PLATFORM=offscreen and the Qt dependencies installed."""
import unittest
try:
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.balance import Balance
except ImportError:
    QApplication = None

@unittest.skipUnless(QApplication, 'Qt development dependencies required')
class QtBalanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_cached_render_and_both_tilts_keep_chain_anchors_inside_board(self):
        board = Balance();board.resize(992,203);board.show()
        board.set_motion(False)
        for tilt in [-5,0,5]:
            board.set_blocks(['x','1','1'],['1']*4,tilt)
            self.app.processEvents()
            self.assertFalse(board.grab().isNull())
            self.assertEqual(len(board.attachments),4)
            for start,end in board.attachments:
                self.assertLess(start.y(),end.y())
                for point in (start,end):
                    self.assertTrue(0 <= point.x() <= board.width())
                    self.assertTrue(0 <= point.y() <= board.height())
            cached = board._cache.cacheKey()
            board.grab()
            self.assertEqual(board._cache.cacheKey(),cached)
        board.set_blocks(['x'],['1','1'],0);self.app.processEvents()
        self.assertNotEqual(board._cache.cacheKey(),cached)
        board.close()

    def test_animation_finishes_and_idle_frame_reuses_static_scene(self):
        from PyQt6.QtTest import QTest
        board=Balance();board.resize(992,211);board.show()
        try:
            board.set_blocks(['x','1','1'],['1']*4);self.app.processEvents()
            stage=board._stage.cacheKey()
            board.set_blocks(['x'],['1']*4,5)
            self.assertTrue(board.is_animating)
            self.assertEqual(board.tilt,5)  # Logical target is immediate.
            QTest.qWait(board.DURATION+100);board.grab()
            self.assertFalse(board.is_animating)
            self.assertEqual(board._angle,5)
            self.assertEqual(board._stage.cacheKey(),stage)
            frame=board._cache.cacheKey()
            QTest.qWait(90);board.grab()
            self.assertEqual(board._cache.cacheKey(),frame)
            self.assertLessEqual(len(board._sprites),64)
        finally:board.close()

    def test_background_clock_moves_in_isolation_and_pauses_with_motion_or_visibility(self):
        from PyQt6.QtTest import QTest
        board=Balance();board.resize(992,361);board.show()
        try:
            board.set_blocks(['x'],['1','1']);self.app.processEvents();board.grab()
            self.assertTrue(board.clock.is_running)
            room,scene=board._stage.cacheKey(),board._cache.cacheKey()
            first=board.clock.grab().toImage()
            QTest.qWait(350)
            self.assertNotEqual(first,board.clock.grab().toImage())
            self.assertEqual(board._stage.cacheKey(),room)
            self.assertEqual(board._cache.cacheKey(),scene)
            self.assertFalse(board.is_animating)
            board.set_ambient(False);frozen=board.clock.grab().toImage()
            self.assertFalse(board.clock.is_running)
            QTest.qWait(250)
            self.assertEqual(frozen,board.clock.grab().toImage())
            board.set_ambient(True);self.assertTrue(board.clock.is_running)
            board.hide();self.assertFalse(board.clock.is_running)
            board.show();self.assertTrue(board.clock.is_running)
            board.set_motion(False);self.assertFalse(board.clock.is_running)
        finally:board.close()

    def test_clock_is_occluded_by_balance_even_if_placed_behind_pivot(self):
        board=Balance();board.resize(996,361);board.set_motion(False);board.show()
        try:
            board.set_blocks(['x'],['1','1']);self.app.processEvents()
            scale,_,_,_,clearance=board._geometry()
            cx=board.width()//2;cy=round(max(40,clearance+18)*scale)
            board.clock.setGeometry(cx-29,cy-18,58,83)
            self.app.processEvents();visible=board.grab().toImage()
            x,y=cx+3,cy+10
            foreground=board._cache.toImage().pixelColor(x,y)
            self.assertEqual(foreground.alpha(),255)
            self.assertEqual(visible.pixelColor(x,y),foreground)
            board.clock.setGeometry(-100,-100,58,83)
            self.app.processEvents();hidden=board.grab().toImage()
            self.assertNotEqual(visible,hidden)
            self.assertEqual(visible.pixelColor(x,y),hidden.pixelColor(x,y))
        finally:board.close()

    def test_disabling_motion_or_hiding_stops_all_visual_timers(self):
        board=Balance();board.resize(992,211);board.show()
        try:
            board.set_blocks(['x'],['1']);board.set_blocks(['x'],['1','1'],5)
            board.celebrate();self.assertTrue(board.is_animating)
            board.set_motion(False)
            self.assertFalse(board.is_animating);self.assertEqual(board._angle,5)
            board.celebrate();self.assertFalse(board.is_animating)
            board.set_blocks(['x'],['1'],0)
            self.assertFalse(board.is_animating);self.assertEqual(board._angle,0)
            board.set_motion(True);board.set_blocks(['x'],[], -5)
            self.assertTrue(board.is_animating)
            board.hide();self.assertFalse(board.is_animating)
            board.set_blocks(['x'],['2'],5)
            self.assertFalse(board.is_animating);self.assertEqual(board._angle,5)
        finally:board.close()

    def test_rapid_retargeting_preserves_latest_values_and_small_screen_anchors(self):
        from PyQt6.QtTest import QTest
        board=Balance();board.resize(992,211);board.show()
        try:
            board.set_blocks(['x','1'],['2'],0)
            board.set_blocks(['x','1','2'],['2'], -5)
            QTest.qWait(45)
            board.set_blocks(['x','1','2'],['2','2'],0)
            board.set_blocks(['−x','−1'],['1/2'],5)
            QTest.qWait(board.DURATION+100)
            self.assertEqual((board.left,board.right,board._angle),(['−x','−1'],['1/2'],5))
            self.assertFalse(board.is_animating)
            for size in [(400,120),(992,148),(992,211),(2000,420)]:
                board.resize(*size);self.app.processEvents();board.grab()
                self.assertEqual(len(board.attachments),4)
                for start,end in board.attachments:
                    self.assertLess(start.y(),end.y())
                    for point in (start,end):
                        self.assertTrue(0<=point.x()<=board.width())
                        self.assertTrue(0<=point.y()<=board.height())
        finally:board.close()
