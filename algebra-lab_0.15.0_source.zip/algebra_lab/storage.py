import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone


class Store:
    SHARED_SETTINGS = {"reader_mode", "buttons_enabled", "fullscreen", "mobile_enabled"}

    def __init__(self, path):
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS attempts (
                id TEXT PRIMARY KEY, task_id TEXT NOT NULL, mode TEXT NOT NULL,
                steps INTEGER NOT NULL, hints INTEGER NOT NULL, stars INTEGER NOT NULL,
                seconds INTEGER NOT NULL, completed_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS solution_paths (
                attempt_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, data TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tags (uid TEXT PRIMARY KEY, kind TEXT NOT NULL);
        """)
        self.db.commit()
        self.initialize_profiles()

    def initialize_profiles(self):
        # Existing attempts and settings remain the first child's data.
        with self.lock, self.db:
            columns={row[1] for row in self.db.execute('PRAGMA table_info(attempts)')}
            if 'profile_id' not in columns:
                self.db.execute("ALTER TABLE attempts ADD COLUMN profile_id TEXT NOT NULL DEFAULT 'default'")
            self.db.execute('CREATE INDEX IF NOT EXISTS attempts_by_profile ON attempts(profile_id,completed_at DESC)')
            self.db.execute("CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, name TEXT NOT NULL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS profile_settings (profile_id TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(profile_id,key))")
            row=self.db.execute("SELECT value FROM settings WHERE key='name'").fetchone()
            name=json.loads(row[0]) if row else 'Исследователь'
            if not isinstance(name,str) or not name.strip():name='Исследователь'
            self.db.execute("INSERT OR IGNORE INTO profiles VALUES ('default',?)",(name,))
            selected=self.db.execute("SELECT value FROM settings WHERE key='active_profile'").fetchone()
            selected=json.loads(selected[0]) if selected else 'default'
            if not isinstance(selected,str):selected='default'
            self.profile_id=selected if self.db.execute('SELECT 1 FROM profiles WHERE id=?',(selected,)).fetchone() else 'default'

    def profiles(self):
        with self.lock:
            return [dict(row) for row in self.db.execute('SELECT id,name FROM profiles ORDER BY rowid')]

    def create_profile(self, name):
        name=str(name).strip()
        if not name or len(name)>24:raise ValueError('Имя: от 1 до 24 символов.')
        key=uuid.uuid4().hex
        with self.lock, self.db:
            if any(p['name'].casefold()==name.casefold() for p in self.profiles()):raise ValueError('Такое имя уже есть. Выберите другое.')
            if self.db.execute('SELECT count(*) FROM profiles').fetchone()[0]>=20:raise ValueError('Доступно до 20 профилей.')
            self.db.execute('INSERT INTO profiles VALUES (?,?)',(key,name))
        return key

    def select_profile(self, key):
        with self.lock, self.db:
            if not self.db.execute('SELECT 1 FROM profiles WHERE id=?',(key,)).fetchone():raise ValueError('Профиль не найден.')
            self.db.execute("INSERT OR REPLACE INTO settings VALUES ('active_profile',?)",(json.dumps(key),))
            self.profile_id=key

    def record(self, attempt, task_id, mode, steps, hints, seconds, solution=None):
        stars = max(1, 3 - min(2, hints))
        with self.lock, self.db:
            self.db.execute("INSERT OR IGNORE INTO attempts (id,task_id,mode,steps,hints,stars,seconds,completed_at,profile_id) VALUES (?,?,?,?,?,?,?,?,?)",
                            (attempt, task_id, mode, steps, hints, stars, seconds,
                             datetime.now(timezone.utc).isoformat(), self.profile_id))
            if solution is not None:
                self.db.execute("INSERT OR IGNORE INTO solution_paths VALUES (?,?,?)",
                                (attempt, task_id, json.dumps(solution, ensure_ascii=False)))
        return stars

    def progress(self):
        with self.lock:
            rows = [dict(row) for row in self.db.execute("SELECT * FROM attempts WHERE profile_id=? ORDER BY completed_at DESC",(self.profile_id,))]
        best = {}
        for row in rows:
            best[row["task_id"]] = max(best.get(row["task_id"], 0), row["stars"])
        return {"attempts": rows, "best": best, "completed": len(best), "stars": sum(best.values()),
                "total_seconds": sum(row["seconds"] for row in rows)}

    def solutions(self):
        with self.lock:
            return [{"attempt_id": row["attempt_id"], "task_id": row["task_id"],
                     "completed_at": row["completed_at"], "data": json.loads(row["data"])}
                    for row in self.db.execute("""SELECT p.*, a.completed_at FROM solution_paths p
                        JOIN attempts a ON a.id=p.attempt_id WHERE a.profile_id=? ORDER BY a.completed_at DESC LIMIT 30""",(self.profile_id,))]

    def settings(self):
        result = {"name": "Исследователь", "motion": True, "contrast": False}
        with self.lock:
            rows={row["key"]: json.loads(row["value"]) for row in self.db.execute("SELECT * FROM settings")}
            if self.profile_id == 'default':
                result.update(rows)
            else:
                result.update({k:v for k,v in rows.items() if k in self.SHARED_SETTINGS})
                result.update({row['key']:json.loads(row['value']) for row in self.db.execute('SELECT key,value FROM profile_settings WHERE profile_id=?',(self.profile_id,))})
                result['name']=self.db.execute('SELECT name FROM profiles WHERE id=?',(self.profile_id,)).fetchone()[0]
        return result

    def save_settings(self, values):
        with self.lock, self.db:
            for key, value in values.items():
                if key in self.SHARED_SETTINGS or self.profile_id == 'default':
                    self.db.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, json.dumps(value)))
                else:
                    self.db.execute('INSERT OR REPLACE INTO profile_settings VALUES (?,?,?)',(self.profile_id,key,json.dumps(value)))
                if key=='name':self.db.execute('UPDATE profiles SET name=? WHERE id=?',(str(value),self.profile_id))

    def tags(self):
        with self.lock:
            return {r["uid"]: r["kind"] for r in self.db.execute("SELECT * FROM tags")}

    def bind(self, uid, kind):
        with self.lock, self.db:
            self.db.execute("INSERT OR REPLACE INTO tags VALUES (?,?)", (uid, kind))

    def bind_many(self, tags):
        # One transaction: a failed import must not leave half the list applied.
        with self.lock, self.db:
            self.db.executemany("INSERT OR REPLACE INTO tags VALUES (?,?)", list(tags.items()))

    def unbind(self, uid):
        with self.lock, self.db:
            self.db.execute("DELETE FROM tags WHERE uid=?", (uid,))

    def reset_progress(self):
        with self.lock, self.db:
            self.db.execute("DELETE FROM solution_paths WHERE attempt_id IN (SELECT id FROM attempts WHERE profile_id=?)",(self.profile_id,))
            self.db.execute("DELETE FROM attempts WHERE profile_id=?",(self.profile_id,))

    def checkpoint(self, value):
        self.save_settings({"practice_session": value})

    def close(self):
        self.db.close()
