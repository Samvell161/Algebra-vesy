package ru.algebralab.progress

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.*
import java.time.LocalDate
import java.time.OffsetDateTime
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val purple = Color.rgb(57,49,126)
    private val ink = Color.rgb(40,34,74)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("trainer", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private var active = false
    private var busy = false
    private var data: JSONObject? = null
    private var selected = ""
    private var etag = ""
    private val poll = object : Runnable { override fun run() { if (active) { if (!busy && prefs.getString("token", "").orEmpty().isNotEmpty()) refresh() else schedule() } } }
    data class Endpoint(val host:String, val port:Int, val id:String, val name:String) { val base get()="http://$host:$port" }
    data class Response(val status:Int, val text:String, val etag:String)
    class PairRequired: IOException("Доступ отозван. Найдите тренажёр и подключитесь снова.")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected = prefs.getString("selected", "").orEmpty()
        data = runCatching { JSONObject(prefs.getString("snapshot", "").orEmpty()) }.getOrNull()
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(248,247,252)); fitsSystemWindows=true }
        val header = text("Алгебра LAB · Прогресс",22,true).apply { setTextColor(Color.WHITE); setBackgroundColor(purple); setPadding(dp(18),dp(18),dp(18),dp(18)) }
        root.addView(header)
        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(dp(10),dp(8),dp(10),0) }
        actions.addView(button("Найти тренажёр") { search() },LinearLayout.LayoutParams(0,dp(52),1f))
        actions.addView(button("Обновить сейчас") { if (endpoint()==null) search() else refresh() },LinearLayout.LayoutParams(0,dp(52),1f))
        root.addView(actions)
        status=text("",14).apply { setPadding(dp(16),dp(10),dp(16),dp(10)) };root.addView(status)
        scroll=ScrollView(this); content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),0,dp(16),dp(20)) };scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        render(false)
        status.text=if(data==null) "Подключите телефон и Raspberry Pi к одной Wi-Fi сети. Интернет и QR-код не нужны." else "Сохранённые данные. Последнее обновление: ${lastSync()}"
    }
    override fun onResume() { super.onResume();active=true;main.removeCallbacks(poll);main.post(poll) }
    override fun onPause() { active=false;main.removeCallbacks(poll);super.onPause() }
    override fun onDestroy() { main.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy() }
    private fun schedule() { main.removeCallbacks(poll);if(active && prefs.getString("token", "").orEmpty().isNotEmpty())main.postDelayed(poll,25_000) }
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()
    private fun text(value:String,size:Int=17,bold:Boolean=false)=TextView(this).apply { text=value;textSize=size.toFloat();setTextColor(ink);if(bold)setTypeface(typeface,Typeface.BOLD) }
    private fun button(value:String,click:()->Unit)=Button(this).apply { text=value;isAllCaps=false;textSize=14f;minHeight=dp(48);setTextColor(purple);setOnClickListener { click() } }
    private fun card():LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14))
        background=GradientDrawable().apply { setColor(Color.WHITE);cornerRadius=dp(18).toFloat() }
        content.addView(this,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(12) })
    }
    private fun wifi():Network {
        val cm=getSystemService(ConnectivityManager::class.java)
        return cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true }
            ?: throw IOException("Подключите телефон к той же Wi-Fi сети, что и тренажёр.")
    }
    private fun endpoint():Endpoint? {
        val host=prefs.getString("host", "").orEmpty();val id=prefs.getString("device", "").orEmpty()
        return if(host.isEmpty()||id.isEmpty()) null else Endpoint(host,prefs.getInt("port",8765),id,prefs.getString("name","Алгебра LAB").orEmpty())
    }
    private fun <T> launch(message:String,work:()->T,success:(T)->Unit) {
        if(busy)return
        busy=true;status.text=message
        worker.execute {
            val result=runCatching(work)
            main.post {
                if(isDestroyed||isFinishing)return@post
                busy=false
                if(active) result.fold(success) { error ->
                    if(error is PairRequired){prefs.edit().remove("token").apply();etag=""}
                    val message=when(error) {is SocketTimeoutException->"Тренажёр не ответил. Проверьте Wi-Fi.";is ConnectException->"Нет связи с тренажёром. Включите доступ на Raspberry Pi.";is SocketException->"Соединение прервано. Проверьте Wi-Fi.";else->error.message ?: "Нет связи с тренажёром"}
                    status.text="$message\n"+if(data!=null)"Сохранённые результаты доступны. Обновлено: ${lastSync()}" else "Попробуйте поиск ещё раз или укажите адрес." }
                schedule()
            }
        }
    }
    private fun request(ep:Endpoint,path:String,token:String="",body:JSONObject?=null,tag:String=""):Response {
        val connection=wifi().openConnection(URL(ep.base+path)) as HttpURLConnection
        connection.connectTimeout=4000;connection.readTimeout=5000;connection.useCaches=false
        if(token.isNotEmpty())connection.setRequestProperty("Authorization","Bearer $token")
        if(tag.isNotEmpty())connection.setRequestProperty("If-None-Match",tag)
        try {
            if(body!=null) { connection.requestMethod="POST";connection.doOutput=true;connection.setRequestProperty("Content-Type","application/json");connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) } }
            val code=connection.responseCode
            if(code==401)throw PairRequired()
            if(code!=200 && code!=304)throw IOException(when(code) {401->"Доступ отозван. Найдите тренажёр и подключитесь снова.";403->"Код неверный или истёк. Получите новый код на Raspberry Pi.";429->"Слишком много попыток. Подождите минуту.";503->"Тренажёр занят. Попробуйте обновить чуть позже.";else->"Тренажёр ответил ошибкой $code."})
            val bytes=if(code==304)byteArrayOf() else connection.inputStream.use { input ->
                val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(4096)
                while(true) { val n=input.read(buffer);if(n<0)break;out.write(buffer,0,n);if(out.size()>2*1024*1024)throw IOException("Ответ слишком большой.") };out.toByteArray()
            }
            return Response(code,String(bytes,Charsets.UTF_8),connection.getHeaderField("ETag").orEmpty())
        } finally { connection.disconnect() }
    }
    private fun endpointFrom(json:JSONObject,host:String):Endpoint {
        if(json.optString("service")!="algebra-lab-progress" || json.optInt("schema")!=1)throw IOException("Это другой сервис.")
        val port=json.optInt("port");val id=json.optString("device_id")
        if(port !in 1..65535 || !id.matches(Regex("[a-f0-9]{32}")))throw IOException("Неверный ответ тренажёра.")
        return Endpoint(host,port,id,json.optString("name","Алгебра LAB").take(80))
    }
    private fun discover():List<Endpoint> {
        val network=wifi();val nonce=UUID.randomUUID().toString();val found=linkedMapOf<String,Endpoint>()
        DatagramSocket().use { socket ->
            network.bindSocket(socket);socket.broadcast=true;socket.soTimeout=250
            val targets=mutableSetOf("255.255.255.255")
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { iface -> iface.interfaceAddresses.forEach { address -> address.broadcast?.hostAddress?.let { targets.add(it) } } }
            val payload=JSONObject().put("service","algebra-lab-progress").put("schema",1).put("nonce",nonce).toString().toByteArray()
            for(host in targets)runCatching { socket.send(DatagramPacket(payload,payload.size,InetAddress.getByName(host),8766)) }
            val deadline=System.nanoTime()+4_000_000_000L
            while(System.nanoTime()<deadline && !Thread.currentThread().isInterrupted) {
                try {
                    val packet=DatagramPacket(ByteArray(2048),2048);socket.receive(packet)
                    val json=JSONObject(String(packet.data,0,packet.length,Charsets.UTF_8))
                    if(json.optString("nonce")==nonce) { val ep=endpointFrom(json,packet.address.hostAddress.orEmpty());found[ep.id]=ep }
                } catch(_:SocketTimeoutException) {} catch(_:org.json.JSONException) {} catch(_:IOException) {}
            }
        }
        return found.values.toList()
    }
    private fun search() {
        launch("Ищем тренажёр в Wi-Fi…",{discover()}) { found ->
            if(found.isEmpty()) {
                AlertDialog.Builder(this).setTitle("Тренажёр не найден").setMessage("Включите доступ в разделе взрослого на Raspberry Pi. В гостевой Wi-Fi сети поиск может быть ограничен; можно указать адрес с экрана тренажёра.")
                    .setPositiveButton("Указать адрес") { _,_->manualAddress() }.setNegativeButton("Закрыть",null).show()
            } else if(found.size==1) select(found[0])
            else AlertDialog.Builder(this).setTitle("Выберите тренажёр").setItems(found.map { "${it.name}\n${it.host}" }.toTypedArray()) { _,i->select(found[i]) }.show()
        }
    }
    private fun manualAddress() {
        val input=EditText(this).apply { hint="192.168.1.10:8765";inputType=InputType.TYPE_CLASS_TEXT;isSingleLine=true }
        AlertDialog.Builder(this).setTitle("Адрес тренажёра").setView(input).setPositiveButton("Найти") { _,_->
            val parts=input.text.toString().trim().split(":");val host=parts[0];val port=parts.getOrNull(1)?.toIntOrNull()?:8765
            if(parts.size>2 || port !in 1..65535 || !host.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}")) || host.split('.').any { it.toInt() !in 0..255 }) { status.text="Укажите IPv4-адрес, например 192.168.1.10:8765";return@setPositiveButton }
            launch("Проверяем адрес…",{endpointFrom(JSONObject(request(Endpoint(host,port,"",""),"/v1/info").text),host)}) { select(it) }
        }.setNegativeButton("Отмена",null).show()
    }
    private fun select(ep:Endpoint) {
        val remembered=endpoint()
        if(remembered?.id==ep.id && prefs.getString("token", "").orEmpty().isNotEmpty()) { remember(ep);refresh();return }
        pair(ep)
    }
    private fun pair(ep:Endpoint) {
        val input=EditText(this).apply { inputType=InputType.TYPE_CLASS_NUMBER;filters=arrayOf(InputFilter.LengthFilter(6));isSingleLine=true;hint="Код из 6 цифр" }
        AlertDialog.Builder(this).setTitle(ep.name).setMessage("На Raspberry Pi: Для взрослого → Прогресс на Android → Получить новый код. Введите его здесь один раз.")
            .setView(input).setPositiveButton("Подключить") { _,_->
                val code=input.text.toString()
                if(!code.matches(Regex("\\d{6}"))) {status.text="Нужен код из 6 цифр.";return@setPositiveButton}
                launch("Подключаем телефон…",{JSONObject(request(ep,"/v1/pair",body=JSONObject().put("code",code)).text)}) { json ->
                    remember(ep);prefs.edit().putString("token",json.getString("token")).apply();etag="";refresh()
                }
            }.setNegativeButton("Отмена",null).show()
    }
    private fun remember(ep:Endpoint) {
        if(prefs.getString("device","")!=ep.id) {
            data=null;selected="";etag=""
            prefs.edit().remove("snapshot").remove("last_sync").remove("selected").apply();render(false)
        }
        prefs.edit().putString("host",ep.host).putInt("port",ep.port).putString("device",ep.id).putString("name",ep.name).apply() }
    private fun refresh() {
        val ep=endpoint()?:return
        val token=prefs.getString("token", "").orEmpty();if(token.isEmpty()) {pair(ep);return}
        launch("Обновляем прогресс…",{request(ep,"/v1/progress",token=token,tag=etag)}) { response ->
            if(response.status==200) {
                val incoming=JSONObject(response.text)
                if(incoming.optInt("schema")!=1 || incoming.optString("device_id")!=ep.id) {status.text="Ответ другого устройства. Выполните поиск заново.";return@launch}
                val changed=data?.toString()!=incoming.toString();data=incoming
                prefs.edit().putString("snapshot",incoming.toString()).apply();etag=response.etag
                if(changed)render(true)
            }
            prefs.edit().putLong("last_sync",System.currentTimeMillis()).apply()
            status.text="${ep.name}\nОбновлено: ${lastSync()} · автообновление 25 с"
        }
    }
    private fun lastSync():String { val timestamp=prefs.getLong("last_sync",0);return if(timestamp==0L)"ещё не обновлялось" else SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(timestamp)) }
    private fun stamp(raw:String):String=runCatching { SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(OffsetDateTime.parse(raw).toInstant().toEpochMilli())) }.getOrDefault("—")
    private fun render(preserveScroll:Boolean) {
        val previous=if(preserveScroll)scroll.scrollY else 0;content.removeAllViews()
        val profiles=data?.optJSONArray("profiles")?:JSONArray()
        if(profiles.length()==0) { card().addView(text(if(data==null)"Найдите тренажёр, чтобы увидеть результаты детей." else "Профилей пока нет."));return }
        var profile:JSONObject?=null
        for(i in 0 until profiles.length()) { val p=profiles.getJSONObject(i);if(p.optString("id")==selected)profile=p }
        if(profile==null) {
            content.addView(text("Дети",24,true))
            for(i in 0 until profiles.length()) {
                val p=profiles.getJSONObject(i);val item=card()
                item.addView(text(p.optString("name"),22,true));item.addView(text("Освоено ${p.optInt("completed")} / ${p.optInt("total")} · ${p.optInt("xp")} XP"))
                item.addView(text("Последнее занятие: ${stamp(p.optString("last_activity"))}",14))
                item.isClickable=true;item.isFocusable=true;item.contentDescription="Открыть прогресс ${p.optString("name")}";item.setOnClickListener { selected=p.optString("id");prefs.edit().putString("selected",selected).apply();render(false) }
            }
        } else {
            val p=profile
            content.addView(button("← Все дети") {selected="";prefs.edit().putString("selected","").apply();render(false)})
            val summary=card();summary.addView(text(p.optString("name"),26,true))
            summary.addView(text("Уровень ${p.optInt("level")} · ${p.optInt("xp")} XP",21,true))
            summary.addView(text("Освоено заданий: ${p.optInt("completed")} / ${p.optInt("total")}"))
            summary.addView(text("Успешных попыток: ${p.optInt("attempts")} · Время: ${p.optInt("seconds")/60} мин"))
            summary.addView(text("Подсказок в завершённых заданиях: ${p.optInt("hints")}",15))
            val chart=card();chart.addView(text("Успешные решения по дням",20,true));chart.addView(text("Последние 14 дней по времени тренажёра",13))
            val counts=mutableMapOf<String,Int>();val days=p.optJSONArray("daily")?:JSONArray()
            for(i in 0 until days.length()) { val row=days.getJSONObject(i);counts[row.optString("day")]=row.optInt("count") }
            val today=runCatching { LocalDate.parse(data?.optString("today")) }.getOrDefault(LocalDate.now())
            val values=(13 downTo 0).map { today.minusDays(it.toLong()).let { day->day.toString() to (counts[day.toString()]?:0) } }
            chart.addView(Bars(this,values),LinearLayout.LayoutParams(-1,dp(190)))
            val chapters=card();chapters.addView(text("Освоение глав",20,true));val list=p.optJSONArray("chapters")?:JSONArray()
            for(i in 0 until list.length()) {
                val chapter=list.getJSONObject(i);chapters.addView(text("${chapter.optString("name")} · ${chapter.optInt("completed")}/${chapter.optInt("total")}",16))
                chapters.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=chapter.optInt("total");progress=chapter.optInt("completed");progressTintList=ColorStateList.valueOf(Color.rgb(32,163,141)) },LinearLayout.LayoutParams(-1,dp(22)))
            }
            val history=card();history.addView(text("Последние завершённые задания",20,true));val recent=p.optJSONArray("recent")?:JSONArray()
            if(recent.length()==0)history.addView(text("Пока нет завершённых заданий."))
            for(i in 0 until recent.length()) {
                val row=recent.getJSONObject(i);history.addView(text("${row.optString("title")}  ${"★".repeat(row.optInt("stars").coerceIn(0,3))}",17,true))
                history.addView(text("${stamp(row.optString("completed_at"))} · ${row.optInt("seconds")} с · подсказок: ${row.optInt("hints")}",13).apply { setPadding(0,0,0,dp(12)) })
            }
        }
        scroll.post {scroll.scrollTo(0,previous)}
    }
}

private class Bars(context:Context,private val values:List<Pair<String,Int>>):View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val density=resources.displayMetrics.density
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        val left=10*density;val bottom=height-26*density;val top=24*density;val step=(width-left*2)/values.size
        paint.strokeWidth=1*density;paint.color=Color.rgb(221,219,235);canvas.drawLine(left,bottom,width-left,bottom,paint)
        val max=(values.maxOfOrNull {it.second}?:0).coerceAtLeast(1)
        paint.textSize=11*resources.displayMetrics.scaledDensity;paint.textAlign=Paint.Align.CENTER
        values.forEachIndexed { i,pair ->
            val x=left+i*step;val h=(bottom-top)*pair.second/max
            paint.color=Color.rgb(100,81,216);canvas.drawRoundRect(x+step*.16f,bottom-h,x+step*.84f,bottom,4*density,4*density,paint)
            if(pair.second>0){paint.color=Color.rgb(57,49,126);canvas.drawText(pair.second.toString(),x+step/2,bottom-h-5*density,paint)}
            if(i%3==0||i==values.lastIndex){paint.color=Color.rgb(99,94,120);canvas.drawText(pair.first.takeLast(5).replace('-','.'),x+step/2,bottom+18*density,paint)}
        }
        if(values.all {it.second==0}) {paint.color=Color.rgb(99,94,120);paint.textSize=14*resources.displayMetrics.scaledDensity;canvas.drawText("Пока нет завершённых заданий",width/2f,height/2f,paint)}
    }
}
