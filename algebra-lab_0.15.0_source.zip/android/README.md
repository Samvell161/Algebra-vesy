# Алгебра · Прогресс — Android

Нативное приложение Kotlin / Android Views. Android 8.0+, без браузера, Google Play Services, аккаунтов или облака. Runtime-зависимость — Kotlin stdlib; диаграмма Canvas и стандартные Android-виджеты. Сеть только в рабочем потоке; обновление открытого приложения раз в 25 секунд. Данные сохраняются локально.

## Сборка

Нужны JDK 17, Gradle 8.10.2, Android SDK platform 35 и build-tools 35.0.0. Укажите JAVA_HOME, ANDROID_HOME; при необходимости GRADLE_BIN. Из корня репозитория:

```bash
python3 scripts/build_android.py
```

Скрипт выполняет assembleRelease и Robolectric-тесты, затем подписывает APK. Результат — dist/algebra-progress_1.0.0.apk. Android local.properties формируется автоматически и не коммитится.

Приватный ключ и пароль находятся в .local/android-signing; не публикуйте их. Сохраните эту папку в защищённом месте для будущих обновлений APK с той же подписью. Скрипт не требует Play Store. Нельзя заменить уже установленное приложение APK с другим ключом без удаления старой установки.

Для разработки можно использовать `gradle -p android assembleDebug testDebugUnitTest`.

## Протокол

UDP broadcast 8766: запрос JSON service=algebra-lab-progress, schema=1, nonce=<строка>. Ответ содержит тот же nonce, название, device_id и HTTP-порт. Личные результаты в обнаружении не передаются. HTTP 8765: GET /v1/info, POST /v1/pair {code: шестизначная строка}, GET /v1/progress с Authorization: Bearer <token>. ETag/If-None-Match поддерживают ответ 304.

Ни камера, ни NFC, ни доступ к местоположению не используются. Автопоиск может блокироваться гостевой сетью; предусмотрен ввод IPv4-адреса вручную. Подробная пользовательская инструкция — ../docs/mobile.md.
