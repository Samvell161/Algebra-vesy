#!/usr/bin/env python3
"""Build/test a small native APK and sign it with a persistent local key."""
import argparse
import os
from pathlib import Path
import secrets
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--skip-tests',action='store_true')
args=parser.parse_args()
env=dict(os.environ)
local=ROOT/'.local/android-tools'
if not env.get('JAVA_HOME') and (local/'jdk').exists():env['JAVA_HOME']=str(next((local/'jdk').iterdir()))
if not env.get('ANDROID_HOME') and (local/'platform').exists():env['ANDROID_HOME']=str(local/'platform')
if not env.get('ANDROID_HOME'):raise SystemExit('Set ANDROID_HOME to an installed Android SDK (platform 35, build-tools 35.0.0).')
sdk=Path(env['ANDROID_HOME'])
(ROOT/'android/local.properties').write_text('sdk.dir='+str(sdk)+'\n')
env.setdefault('ANDROID_USER_HOME',str(local/'android-home'))
env.setdefault('GRADLE_USER_HOME',str(ROOT/'.local/gradle'))
user_home=local/'java-home';user_home.mkdir(parents=True,exist_ok=True)
env.setdefault('GRADLE_OPTS','-Duser.home='+str(user_home))
gradle=env.get('GRADLE_BIN') or shutil.which('gradle') or str(local/'gradle/gradle-8.10.2/bin/gradle')
tasks=['assembleRelease']+([] if args.skip_tests else ['testDebugUnitTest'])
subprocess.run([gradle,'-p',str(ROOT/'android'),*tasks,'--no-daemon','--max-workers=2'],env=env,check=True)
keys=ROOT/'.local/android-signing';keys.mkdir(parents=True,exist_ok=True);keys.chmod(0o700)
password=keys/'password';keystore=keys/'algebra-lab.jks'
if not password.exists():password.write_text(secrets.token_urlsafe(32)+'\n');password.chmod(0o600)
java_bin=Path(env.get('JAVA_HOME','/usr'))/'bin'
if not keystore.exists():
    subprocess.run([str(java_bin/'keytool'),'-genkeypair','-keystore',str(keystore),'-storetype','JKS','-alias','algebra-lab','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=Algebra LAB, O=Algebra LAB','-storepass:file',str(password),'-keypass:file',str(password)],env=env,check=True)
    keystore.chmod(0o600)
output=ROOT/'dist/algebra-progress_1.0.0.apk';output.parent.mkdir(exist_ok=True)
signer=sdk/'build-tools/35.0.0/apksigner'
subprocess.run([str(signer),'sign','--ks',str(keystore),'--ks-key-alias','algebra-lab','--ks-pass','file:'+str(password),'--out',str(output),str(ROOT/'android/app/build/outputs/apk/release/app-release-unsigned.apk')],env=env,check=True)
subprocess.run([str(signer),'verify','--verbose',str(output)],env=env,check=True)
import hashlib
output.with_suffix('.apk.sha256').write_text(hashlib.sha256(output.read_bytes()).hexdigest()+'  '+output.name+'\n')
print('Signed APK:',output,output.stat().st_size,'bytes')
