"""Validate an extracted .deb, exercise its actual GUI payload, and measure Linux RSS.

Run with a graphical DISPLAY and Python/Tk. Installation as root is not required.
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    parser.add_argument("--screenshots", type=Path)
    args = parser.parse_args()
    package = args.package.resolve()
    if args.screenshots:
        args.screenshots = args.screenshots.resolve()
        args.screenshots.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="algebra-verify-") as temp:
        temp = Path(temp)
        extracted, metadata = temp / "root", temp / "metadata"
        subprocess.run(["dpkg-deb", "-x", str(package), str(extracted)], check=True)
        subprocess.run(["dpkg-deb", "-e", str(package), str(metadata)], check=True)
        for line in (metadata / "md5sums").read_text().splitlines():
            expected, path = line.split("  ", 1)
            assert hashlib.md5((extracted / path).read_bytes()).hexdigest() == expected, path
        payload = extracted / "usr/share/algebra-lab"
        assert not (payload / "algebra_lab/static").exists()
        assert not (payload / "algebra_lab/__main__.py").exists()
        launcher = payload / "launcher.py"
        result = subprocess.run([sys.executable, str(launcher), "--help"], cwd=str(temp), capture_output=True, text=True, check=True)
        assert "--fullscreen" in result.stdout
        subprocess.run(["sh", "-n", str(extracted / "usr/bin/algebra-lab")], check=True)
        # Verify installed launcher startup independently of checkout and shell working directory.
        data = temp / "cli-data"
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        process = subprocess.Popen([sys.executable, str(launcher), "--data-dir", str(data)], cwd=str(temp), env=env)
        try:
            for _ in range(50):
                if process.poll() is not None:
                    raise AssertionError("Packaged GUI exited during startup")
                if (data / "algebra.sqlite3").exists():
                    break
                time.sleep(.1)
            else:
                raise AssertionError("Packaged GUI did not create its database")
            duplicate = subprocess.run([sys.executable, str(launcher), "--data-dir", str(data)], cwd=str(temp), env=env, capture_output=True, text=True, timeout=5)
            assert duplicate.returncode == 1 and "уже запущена" in duplicate.stderr
        finally:
            process.terminate()
            process.wait(timeout=5)
        # Imports come from the extracted payload, not the source checkout.
        sys.path.insert(0, str(payload))
        import resource
        import tkinter as tk
        from algebra_lab.desktop import Desktop
        from algebra_lab.hardware import Reader
        from algebra_lab.storage import Store
        root = tk.Tk()
        store = Store(temp / "smoke.sqlite3")
        store.save_settings({"simple_ui": False})
        app = Desktop(root, store, Reader())
        root.update()
        app.controls["start"].invoke()
        app.operand.set("3")
        app.controls["transform"].invoke()
        root.update()
        assert app.session.completed and app.store.progress()["stars"] == 3
        app.navigate("lab")
        app.controls["block-x"].invoke()
        app.controls["block-1"].invoke()
        app.controls["side-right"].invoke()
        app.controls["block-5"].invoke()
        app.x_value.set("4")
        app.controls["substitute"].invoke()
        root.update()
        assert app.service.lab(app.session)["balanced"]
        from algebra_lab.learning import daily_task, progress_csv
        app.navigate("home")
        app.controls["chapter-4"].invoke()
        app.controls["lesson"].invoke()
        app.controls["lesson-try"].invoke()
        assert app.service.exercise(app.session)["task"]["level"] == 4
        app.navigate("home")
        app.controls["daily"].invoke()
        assert app.session.task_id == daily_task()["id"]
        assert "Первое равновесие" in progress_csv(app.store.progress())
        for page in ["home", "practice", "exercise", "lab", "progress"] * 5:
            app.navigate(page)
            root.update()
        app.tags()
        app.tag_waiting = True
        app.receive_tag("AA:BB")
        app.receive_tag("CC:DD")
        assert app.tag_uid.get() == "AA:BB"
        app.controls["tag-kind--2"].invoke()
        app.controls["bind-tag"].invoke()
        root.update()
        assert app.store.tags()["AA:BB"] == "-2"
        assert "Сохранено" in app.tag_message.get()
        app.dialog.destroy()
        # Feed reader events into the actual packaged GUI, without real GPIO.
        app.reader.mode = "rc522"
        app.store.bind("F1", "1")
        app.store.bind("F2", "apply")
        app.start("first")
        def present(uid):
            app.reader.sequence += 1
            app.reader.events.append({"sequence": app.reader.sequence, "uid": uid})
            root.after_cancel(app.timer_id)
            app.tick()
            root.update()
        present("F1")
        assert app.session.completed
        assert "answer" not in app.controls and "transform" not in app.controls
        present("F1")
        assert app.session.task_id != "first" and not app.session.completed
        app.store.save_settings({"rfid_style": "independent"})
        app.start("first")
        for uid in ["F1", "F1", "F1", "F2"]:
            present(uid)
        assert app.session.completed and app.session.current.solution()["value"] == "4"
        app.store.save_settings({"rfid_style": "cups"})
        app.start("cups-1")
        present("F1")
        assert not app.session.completed and app.session.cup_side == "right"
        assert str(app.service.cup_state(app.session)["preview"].left) == "x"
        assert str(app.session.current.left) == "x + 1"
        present("F1")
        assert app.session.completed and app.session.current.solution()["value"] == "1"
        app.store.save_settings({"simple_ui": True})
        app.navigate("home")
        root.update()
        assert not app.navigation["progress"].winfo_ismapped()
        assert "daily" not in app.controls
        app.phone_tag()
        app.controls["phone-uid"].insert(0, "12:34:56:78")
        app.controls["save-phone-tag"].invoke()
        root.update()
        assert app.store.tags()["1234567808"] == "1"
        app.dialog.destroy()
        from algebra_lab.tag_import import parse_tags, export_tags
        app.preview_tag_import(parse_tags("AABBCCDD;2"))
        assert "AABBCCDD00" not in app.store.tags()
        app.controls["confirm-tag-import"].invoke()
        root.update()
        assert app.store.tags()["AABBCCDD00"] == "2"
        assert parse_tags(export_tags(app.store.tags())) == app.store.tags()
        app.dialog.destroy()
        app.start("cups-1")
        present("1234567808")
        assert not app.session.completed
        assert "cup-unit" not in app.controls
        assert "reader-details" not in app.controls
        present("1234567808")
        assert app.session.cup_phase == "answer" and not app.session.completed
        present("1234567808")
        assert app.session.completed
        from algebra_lab.learning import game_progress
        from algebra_lab.balance_view import BalanceCanvas
        before_xp = game_progress(app.store.progress())["xp"]
        app.start("cups-2")
        def settle_balance():
            end = time.monotonic() + 1.5
            root.update()
            while app.balance_widget.timer is not None and time.monotonic() < end:
                root.update()
                time.sleep(.005)
            assert app.balance_widget.timer is None, (app.balance_widget.frame, app.balance_widget.angle, app.balance_widget.target)
        app.controls["cup-op-remove"].invoke()
        app.controls["cup-left"].invoke()
        present("1234567808")
        settle_balance()
        assert app.balance_widget.angle == 5 and app.balance_widget.timer is None, (app.balance_widget.angle, app.balance_widget.target, app.session.task_id)
        assert len(app.balance_widget.find_all()) < 150
        app.controls["cup-right"].invoke()
        present("1234567808")
        settle_balance()
        assert not app.session.completed and app.session.cup_phase == "answer"
        present("AABBCCDD00")
        assert app.balance_widget.angle == 0 and app.balance_widget.timer is None
        assert game_progress(app.store.progress())["xp"] == before_xp + 30
        app.lesson_map()
        assert not app.controls["map-cups-3"].instate(["disabled"])
        app.dialog.destroy()
        from algebra_lab.adventure import ADVENTURE_TASKS, QUIZZES
        for task in ADVENTURE_TASKS[:18]:
            app.store.record("unlock-" + task["id"], task["id"], "practice", 1, 0, 1)
        app.lesson_map(3)
        assert app.controls["map-duet-1"].winfo_exists()
        app.controls["map-duet-1"].invoke()
        root.update()
        app.store.bind("F3", "x")
        for uid in ["F3", "1234567808"]:
            app.controls["cup-op-remove"].invoke()
            app.controls["cup-left"].invoke()
            present(uid)
            app.controls["cup-right"].invoke()
            present(uid)
        assert app.session.cup_phase == "answer" and not app.session.completed
        app.controls["student-answer-3"].invoke()
        app.controls["student-check"].invoke()
        assert app.session.completed
        app.open_quiz("quiz-1")
        for question in QUIZZES[0]["questions"]:
            app.controls["quiz-choice-" + str(question[2])].invoke()
            app.controls["quiz-next"].invoke()
            root.update()
        assert app.quiz_state["completed"]
        assert "quiz-1" in app.store.progress()["best"]
        # Hardware source/button routing through actual extracted GUI payload.
        app.store.bind("F4", "2")
        app.start("cups-4")
        app.reader.mode = "rc522_dual"
        app.reader.emit({"type": "button", "operation": "remove", "pin": 26})
        app.reader.emit({"uid": "F4", "source": "right"})
        app.reader.emit({"uid": "F4", "source": "left"})
        app.tick()
        root.update()
        assert app.session.cup_phase == "answer" and not app.session.completed
        app.controls["student-answer-2"].invoke()
        app.reader.emit({"uid": "F3", "source": "right"})
        app.tick()
        root.update()
        assert app.session.completed
        paths = app.store.solutions()
        assert paths[0]["data"]["check"] == {"x": "2", "left": "4", "right": "4"}
        assert paths[0]["data"]["steps"][1]["actions"][0]["side"] == "right"
        app.saved_solutions()
        app.controls["saved-solution-0"].invoke()
        root.update()
        app.dialog.destroy()
        app.store.save_settings({"simple_ui": False})
        app.reader.mode = "simulator"
        assert not app.errors, app.errors
        report = {"package_bytes": package.stat().st_size,
                  "payload_bytes": sum(p.stat().st_size for p in extracted.rglob("*") if p.is_file() and p.suffix != ".pyc"),
                  "gui_peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  "platform": sys.platform, "python": sys.version.split()[0], "font_family": app.ui_font,
                  "note": "Linux x86_64 / virtual X11; not a measurement on Raspberry Pi B+. RSS excludes X server and OS.",
                  "checks": ["package file checksums", "launcher", "single instance", "solving", "progress", "lab", "chapters", "lesson", "daily task", "CSV", "25 page transitions", "tag capture freeze", "touch binding and persistence", "RFID guided solving and next task", "RFID independent solving without typed answers", "separate left/right previews and paired commit", "simple child interface", "phone UID conversion and real exercise event", "file import preview and backup roundtrip", "finite balance animation and semantic tilt", "XP and lesson map unlock", "student choices and explicit final answer", "24-level chapter map", "x-block operation in final chapter", "touch quiz completion and saved score", "dual source and GPIO button event routing", "saved solution path with original-answer proof"]}
        if args.screenshots:
            # Optional capture libraries are imported after the RSS measurement.
            from PIL import ImageGrab
            for page in ["home", "exercise", "lab"]:
                if page == "exercise":
                    app.start("first")
                else:
                    app.navigate(page)
                root.update()
                ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / ("native-" + page + ".png")))
            app.tags("AA:BB")
            app.controls["tag-kind--2"].invoke()
            app.controls["bind-tag"].invoke()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "tag-binding.png"))
            app.dialog.destroy()
            app.reader.mode = "rc522"
            app.store.save_settings({"rfid_style": "guided"})
            app.start("double")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "physical-guided.png"))
            app.handle_physical_scan("F1")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "physical-after-scan.png"))
            app.store.save_settings({"rfid_style": "independent"})
            app.start("first")
            present("F1")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "physical-independent.png"))
            app.tags("F2")
            app.controls["tag-commands"].invoke()
            app.controls["tag-kind-apply"].invoke()
            app.controls["bind-tag"].invoke()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "command-binding.png"))
            app.dialog.destroy()
            app.store.save_settings({"rfid_style": "cups"})
            app.start("cups-1")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "cups-before.png"))
            present("F1")
            settle_balance()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "cups-left-done.png"))
            present("F1")
            settle_balance()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "cups-solved.png"))
            app.store.save_settings({"simple_ui": True})
            app.navigate("home")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "simple-home.png"))
            app.start("cups-1")
            present("1234567808")
            settle_balance()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "simple-cups.png"))
            app.lesson_map()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "lesson-map.png"))
            app.dialog.destroy()
            app.child_statistics()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "child-statistics.png"))
            app.dialog.destroy()
            app.start("cups-3")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "student-choose.png"))
            app.controls["cup-op-remove"].invoke()
            app.controls["cup-left"].invoke()
            present("AABBCCDD00")
            settle_balance()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "student-other-side.png"))
            app.controls["cup-right"].invoke()
            present("AABBCCDD00")
            settle_balance()
            assert app.session.cup_phase == "answer" and not app.session.completed
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "student-answer.png"))
            app.select_student_answer(1)
            app.store.bind("F3", "x")
            present("F3")
            settle_balance()
            assert app.session.completed
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "student-success.png"))
            app.lesson_map(3)
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "adventure-map.png"))
            app.dialog.destroy()
            app.start("duet-1")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "adventure-x.png"))
            app.open_quiz("quiz-1")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "quiz-question.png"))
            app.controls["quiz-choice-0"].invoke()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "quiz-feedback.png"))
            app.phone_tag()
            app.controls["phone-uid"].insert(0, "12:34:56:78")
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "phone-tag.png"))
            app.dialog.destroy()
            app.store.save_settings({"simple_ui": True, "rfid_style": "cups"})
            app.reader.mode = "rc522_dual"
            app.start("cups-4")
            app.reader.emit({"type": "button", "operation": "remove", "pin": 26})
            app.reader.emit({"uid": "F4", "source": "left"})
            app.tick()
            root.update()
            for _ in range(18):
                time.sleep(.02)
                root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "dual-first-side.png"))
            app.reader.emit({"uid": "F4", "source": "right"})
            app.tick()
            root.update()
            app.controls["student-answer-2"].invoke()
            app.controls["student-check"].invoke()
            app.history()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "solution-history.png"))
            app.dialog.destroy()
            app.reader_details()
            root.update()
            ImageGrab.grab(xdisplay=os.environ.get("DISPLAY")).save(str(args.screenshots / "hardware-settings.png"))
            (args.screenshots / "native-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        assert not app.errors, app.errors
        app.close()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        print("PASS: extracted package functional checks. No system installation performed.")


if __name__ == "__main__":
    main()
