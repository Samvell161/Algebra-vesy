"""Exercise the extracted Qt payload; no physical GPIO required."""
import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('package',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    subprocess.run(['dpkg-deb','-x',str(args.package),str(root)],check=True)
    payload=root/'usr/share/algebra-lab'
    sys.path.insert(0,str(payload))
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QFontDatabase
    from algebra_lab.qt_ui.app import Window
    app=QApplication([])
    for font in (root/'usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):
        assert QFontDatabase.addApplicationFont(str(font))>=0
    app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
    data=root/'profile';data.mkdir()
    w=Window(data);w.start('cups-4');w.show();app.processEvents()
    assert w.size().width()==1024 and w.height()<=600
    w.grab().save(str(args.output/'game.png'))
    w.store.bind('AA','2');w.operation('remove')
    w.reader.emit({'uid':'AA','source':'left'});w.poll();app.processEvents()
    assert w.board.tilt!=0
    w.grab().save(str(args.output/'left-changed.png'))
    w.reader.emit({'uid':'AA','source':'right'});w.poll();app.processEvents()
    assert w.session.cup_phase=='answer' and not w.session.completed
    assert w.height()<=600
    w.session.cup_guess=2;w.check();assert w.session.completed
    assert w.store.solutions()
    w.close()
print('PASS: extracted Qt UI at 1024x600, fonts, chain rendering, RFID paired step, explicit answer and saved history')
