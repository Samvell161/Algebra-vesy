"""Measure real rasterised ink contrast inside the front faces of simple blocks."""
from PyQt6.QtGui import QVector3D

def luminance(color):
    def linear(v):
        v/=255
        return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
    return .2126*linear(color.red())+.7152*linear(color.green())+.0722*linear(color.blue())

def measure_symbols(surface):
    frame=surface.grabFramebuffer();nodes,labels=surface._nodes();records=[]
    for key,model,finish,casts in nodes:
        label=labels.get(id(model))
        if label is None or label[0] not in ('x','1','2'):continue
        corners=[surface.vp.map(model.map(QVector3D(x,-.1802,z))) for x in (-.17,.17) for z in (-.20,.20)]
        xs=[round((p.x()+1)*frame.width()/2) for p in corners];ys=[round((1-p.y())*frame.height()/2) for p in corners]
        left,right=max(0,min(xs)),min(frame.width()-1,max(xs));top,bottom=max(0,min(ys)),min(frame.height()-1,max(ys))
        values=sorted(luminance(frame.pixelColor(x,y)) for y in range(top,bottom+1) for x in range(left,right+1))
        background=sum(values[-max(1,len(values)//5):])/max(1,len(values)//5)
        ink=sum(values[:10])/min(10,len(values))
        centre=model.map(QVector3D(0,0,0))
        records.append({'symbol':label[0],'side':'left' if centre.x()<0 else 'right',
                        'contrast':(background+.05)/(ink+.05),'background':background,
                        'dark_pixels':sum(v<background/2.7 for v in values),'roi':[left,top,right,bottom]})
    return records
