"""Small, cached world-space contact atlas and a quiet ambient blink.

Red stores worktop occlusion (XY), green stores rear-wall occlusion (XZ),
and blue stores a feathered window-light projection (XY).
The atlas modulates lighting on 3D receivers; it is not a room background.
"""
import math
from dataclasses import dataclass
from functools import lru_cache

ATLAS_WIDTH=512
ATLAS_HEIGHT=256
FLOOR_BOUNDS=(-8.0,8.0,-3.2,3.9)
WALL_BOUNDS=(-8.0,8.0,0.0,6.0)

@dataclass(frozen=True)
class Contact:
    plane:str
    x:float
    y:float
    half_x:float
    half_y:float
    softness:float
    strength:float
    ellipse:bool=False

def _smooth(low,high,value):
    t=max(0.0,min(1.0,(value-low)/(high-low)))
    return t*t*(3-2*t)

def window_light(x,y):
    """Feathered arched aperture, projected into the left worktop's XY plane."""
    dx,dy=x+2.75,y-1.2
    u=(.98*dx+.20*dy)/2.15;v=(-.20*dx+.98*dy)/1.10
    edge=max(abs(v)-1.0,(u-.90)*1.2)
    if u<-.35:edge=max(edge,math.hypot((u+.35)/.75,v)-1.0)
    pool=1.0-_smooth(-.18,.18,edge)
    frame=1-.12*math.exp(-((u-.08)/.065)**2)-.09*math.exp(-(v/.08)**2)
    return max(0.0,min(1.0,pool*frame))

@lru_cache(maxsize=4)
def bake_contacts(contacts,width=ATLAS_WIDTH,height=ATLAS_HEIGHT):
    pixels=bytearray(b'\0\0\0\xff'*(width*height))
    x0,x1,y0,y1=FLOOR_BOUNDS
    for py in range(height):
        y=y0+(py+.5)/height*(y1-y0)
        for px in range(width):
            x=x0+(px+.5)/width*(x1-x0)
            pixels[(py*width+px)*4+2]=round(255*window_light(x,y))
    for c in contacts:
        bounds=FLOOR_BOUNDS if c.plane=='floor' else WALL_BOUNDS
        x0,x1,y0,y1=bounds;channel=0 if c.plane=='floor' else 1
        margin=c.softness*3.0
        left=max(0,int((c.x-c.half_x-margin-x0)/(x1-x0)*width))
        right=min(width,int((c.x+c.half_x+margin-x0)/(x1-x0)*width)+1)
        bottom=max(0,int((c.y-c.half_y-margin-y0)/(y1-y0)*height))
        top=min(height,int((c.y+c.half_y+margin-y0)/(y1-y0)*height)+1)
        for py in range(bottom,top):
            y=y0+(py+.5)/height*(y1-y0)
            for px in range(left,right):
                x=x0+(px+.5)/width*(x1-x0)
                if c.ellipse:
                    distance=max(0.0,math.hypot((x-c.x)/c.half_x,(y-c.y)/c.half_y)-1)*min(c.half_x,c.half_y)
                    distance2=distance*distance
                else:
                    dx=max(0.0,abs(x-c.x)-c.half_x);dy=max(0.0,abs(y-c.y)-c.half_y)
                    distance2=dx*dx+dy*dy
                value=round(255*c.strength*math.exp(-distance2/(c.softness*c.softness)))
                index=(py*width+px)*4+channel
                pixels[index]=max(pixels[index],min(255,value))
    return bytes(pixels)

def owl_openness(seconds):
    phase=seconds%9.0
    if not 6.0<phase<6.32:return 1.0
    return max(.04,1-math.sin(math.pi*(phase-6.0)/.32)**2)
