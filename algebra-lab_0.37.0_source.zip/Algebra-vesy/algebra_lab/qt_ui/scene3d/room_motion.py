"""Bounded, slow room movement; no mesh rebuilds or simulation state."""
import math
from dataclasses import dataclass

@dataclass(frozen=True)
class RoomPose:
    clouds:tuple
    robot_x:float
    robot_bob:float
    feet:tuple
    owl_angle:float
    pendulum:float

def room_pose(seconds):
    t=max(0.0,seconds)
    stride=math.sin(t*math.tau/1.6)
    # The robot stays on its own small patch between the globe and paper boat.
    # Feet lift alternately; the planted foot remains at worktop height.
    walk=math.sin(t*math.tau/12)
    glance=(t%15)/3.2
    owl=5*math.sin(math.pi*glance)**2*math.sin(math.tau*glance) if glance<1 else 0.0
    return RoomPose((.24*math.sin(t*math.tau/32),.18*math.sin(t*math.tau/43)),
                    .12*walk,.009*stride*stride,
                    (.045*max(0.0,stride),.045*max(0.0,-stride)),
                    owl,8*math.sin(t*math.tau/2.4))
