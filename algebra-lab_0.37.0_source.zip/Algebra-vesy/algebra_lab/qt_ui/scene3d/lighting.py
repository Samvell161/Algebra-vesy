"""Shared world-space light positions, matching the visible room fixtures."""
import math

WINDOW_DIRECTION=(-5.0,2.5,7.5)
LAMP_POSITION=(6.95,2.67,2.88)
# The shade is rotated -20 degrees around X, then 48 around Y.
LAMP_ROTATION=(-20,48,0)
LAMP_DIRECTION=(-math.sin(math.radians(48))*math.cos(math.radians(20)),
                -math.sin(math.radians(20)),
                -math.cos(math.radians(48))*math.cos(math.radians(20)))
CLOCK_POSITION=(-4.25,3.10,2.90)
