"""Qt child workspace sharing the established model, database and reader queue."""
import argparse
import fcntl
import os
import sys
import sqlite3
import time
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFontDatabase, QFont, QFontMetrics
from PyQt6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,
 QPushButton,QDialog,QScrollArea,QMessageBox,QComboBox,QFileDialog,QInputDialog)
import qtawesome as qta
from .balance import Balance as SoftwareBalance
from .real_balance import RealBalance as Balance
from .button_shadow import install_button_shadows
from .route_map import RouteMap
from .balance_motion import tilt_for_difference
from ..service import Service, Session
from ..storage import Store
from ..hardware import Reader
from ..buttons import Buttons
from ..adventure import ADVENTURE_TASKS, LANDS, QUIZZES, QUIZ_BY_ID, level_open, quiz_open, next_level
from ..learning import game_progress
from ..math_engine import Linear, equation, fmt
from ..maintenance import backup, restore, diagnostic_logger
from ..pending import save_pending, restore_pending
from ..presentation import SCRIPT, stage
from ..mobile import ProgressHub
from .. import lesson_queue

@lru_cache(maxsize=32)
def icon(name,color='#285e64'):
    return qta.icon(name,color=color)

def pieces(value):
    result=[]
    for count,label in [(value.a,'x'),(value.b,'1')]:
        if count.denominator != 1 or abs(count)>9:return [str(value)]
        result += [('−' if count<0 else '')+label]*abs(int(count))
    return result if len(result)<=5 else [str(value)]

class Window(QMainWindow):
    def __init__(self, data, reader_mode=None, software_view=False):
        super().__init__()
        install_button_shadows()
        self.data=data
        self.log=diagnostic_logger(data)
        self.last_hardware=None
        self.demonstration=False
        self.saved_workspace=None
        self.preflight=None
        self.remote_request=None
        self.remote_dirty=True
        self._visual_key=None
        self._visual_completed=False
        self.store=Store(data/'algebra.sqlite3')
        prefs=self.store.settings()
        self.mobile=ProgressHub(data)
        if prefs.get("mobile_enabled",False):self.mobile.start()
        self.reader=Reader(reader_mode or prefs.get('reader_mode','simulator'))
        self.buttons=Buttons(self.reader.emit,prefs.get('buttons_enabled',False))
        self.service=Service(self.store,self.reader);self.session=Session()
        self.service.restore_practice(self.session)
        pending=restore_pending(self.service,self.session)
        self.pending_offer=pending
        self.seq=self.reader.sequence;self.legacy=False;self.closed=False
        self.setWindowTitle('Алгебра LAB');self.resize(1024,600)
        root=QWidget();root.setObjectName('workspace');self.setCentralWidget(root)
        layout=QVBoxLayout(root);layout.setContentsMargins(10,6,10,6);layout.setSpacing(6)
        header_widget=QWidget();header_widget.setObjectName('header')
        header=QHBoxLayout(header_widget);header.setContentsMargins(8,0,6,2);header.setSpacing(7);layout.addWidget(header_widget)
        condition_card=QWidget();condition_card.setObjectName('conditionCard')
        condition_rows=QVBoxLayout(condition_card);condition_rows.setContentsMargins(8,0,8,0);condition_rows.setSpacing(0)
        caption=QLabel('УСЛОВИЕ');caption.setObjectName('conditionCaption');condition_rows.addWidget(caption)
        self.condition=QLabel();self.condition.setObjectName('equation');self.condition.setFont(QFont('Algebra Rounded',22,QFont.Weight.Bold));condition_rows.addWidget(self.condition)
        header.addWidget(condition_card)
        brand=QLabel('Алгебра LAB');brand.setObjectName('title');header.addWidget(brand)
        self.heading=QLabel();self.heading.setObjectName('heading');self.heading.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.heading.setWordWrap(True);header.addWidget(self.heading,1)
        self.xp=QLabel();header.addWidget(self.xp)
        self.profile_button=self.button(header,'Кто играет?',self.choose_profile);self.profile_button.setMaximumWidth(136)
        self.button(header,'Для взрослого',self.adult,'fa5s.cog')
        board_class=SoftwareBalance if software_view or os.environ.get('ALGEBRA_VIEW')=='software' else Balance
        self.board=board_class();self.board.set_motion(prefs.get('motion',True));self.board.set_ambient(prefs.get('ambient_motion',True));layout.addWidget(self.board,1)
        if getattr(self.board,'is_3d',False):self.board.set_quality(prefs.get('graphics_quality'));self.board.set_lamp(prefs.get('room_lamp',True))
        if getattr(self.board,'surface',None) is not None:self.board.surface.failed.connect(self.report_graphics_error)
        scene_layout=QVBoxLayout(self.board);scene_layout.setContentsMargins(10,0,10,4);scene_layout.addStretch(1)
        sides=QHBoxLayout();sides.setSpacing(7);scene_layout.addLayout(sides)
        self.left=self.button(sides,'Левая чаша',lambda:self.side('left'));sides.addStretch(1)
        self.remove=self.button(sides,'− Убрать',lambda:self.operation('remove'))
        self.add=self.button(sides,'+ Добавить',lambda:self.operation('add'))
        for button in [self.remove,self.add]:button.setCheckable(True);button.setMaximumWidth(152)
        sides.addStretch(1);self.right=self.button(sides,'Правая чаша',lambda:self.side('right'))
        self.left.setObjectName('leftCup');self.right.setObjectName('rightCup')
        self.answers=QWidget();answerrow=QHBoxLayout(self.answers);answerrow.setContentsMargins(0,0,0,0)
        self.answer=QComboBox();self.answer.setMinimumHeight(46);self.answer.addItems([str(i) for i in range(1,10)]);self.answer.setCurrentIndex(-1)
        self.answer.currentIndexChanged.connect(self.select_answer);answerrow.addWidget(QLabel('Сколько скрывает x?'));answerrow.addWidget(self.answer)
        self.button(answerrow,'Проверить',self.check);layout.addWidget(self.answers)
        self.remote_bar=QWidget();self.remote_bar.setObjectName('remoteOffer')
        self.remote_bar.setStyleSheet('QWidget#remoteOffer {background:#eee7ff;border-radius:12px;}')
        remote_row=QHBoxLayout(self.remote_bar);remote_row.setContentsMargins(8,4,8,4)
        self.remote_label=QLabel();self.remote_label.setWordWrap(True);self.remote_label.setStyleSheet('font-size:16px;');remote_row.addWidget(self.remote_label,1)
        for text,action in [('Открыть',lambda:self.respond_remote('accepted')),('Отклонить',lambda:self.respond_remote('declined'))]:
            button=self.button(remote_row,text,action);button.setStyleSheet('QPushButton {min-height:34px;padding:4px 12px;font-size:16px;}')
        layout.addWidget(self.remote_bar);self.remote_bar.hide()
        self.feedback=QLabel();self.feedback.setWordWrap(True);self.feedback.setMinimumHeight(40);self.feedback.setObjectName('hint');layout.addWidget(self.feedback)
        footer=QHBoxLayout();layout.addLayout(footer)
        self.undo_button=self.button(footer,'Отменить',self.undo,'fa5s.undo');self.undo_button.setObjectName('undo')
        self.button(footer,'Карта',self.map,'fa5s.map').setObjectName('mapButton');self.button(footer,'Мой путь',self.history).setObjectName('historyButton')
        self.next_button=self.button(footer,'Дальше',self.next)
        self.next_button.setObjectName('nextButton')
        self.hint_button=self.button(footer,'Подсказка',self.hint,'fa5s.lightbulb');self.hint_button.setObjectName('help')
        self.timer=QTimer(self);self.timer.timeout.connect(self.poll);self.timer.start(150)
        if not self.session.current:self.start(next_level(self.store.progress()['best'])['id'])
        else:
            if self.session.task_id not in {t['id'] for t in ADVENTURE_TASKS}:
                self.feedback.setText('Незавершённое дополнительное задание доступно в прежнем интерфейсе.')
            elif not self.session.cup_play:self.service.begin_student(self.session)
            self.refresh()
        if self.pending_offer:QTimer.singleShot(0,self.offer_pending)

    def report_graphics_error(self,message):self.log.error('3D %s',message)

    def offer_pending(self):
        if self.closed:return
        if QMessageBox.question(self,"Незавершённый ход","Продолжить действие на одной чаше? «Нет» отменит только незавершённую пару.")==QMessageBox.StandardButton.No:
            self.service.begin_student(self.session);self.refresh()

    def button(self,row,text,fn,ico=None):
        b=QPushButton(text)
        if ico:b.setIcon(icon(ico))
        b.clicked.connect(lambda checked=False:self.run(fn));row.addWidget(b);return b
    def run(self,fn):
        try:fn()
        except (ValueError,OSError,sqlite3.Error) as exc:self.feedback.setText(str(exc))
    def start(self,task):
        self.service.start(self.session,{'task_id':task});self.service.begin_student(self.session)
        self.feedback.setText('Выбери действие и поднеси метку к нужной чаше.');self.refresh()
    def next(self):
        if self.demonstration:return
        self.start(next_level(self.store.progress()['best'],self.session.task_id)['id'])
    def operation(self,op):
        if self.service.cup_state(self.session)['pending']:raise ValueError('Повтори действие на второй чаше или нажми «Отменить».')
        if self.session.completed or self.session.cup_phase!='choose':return
        if self.service.student_stage(self.session)=='demo':return
        self.session.cup_operation=op;self.refresh()
    def side(self,side):self.session.cup_side=side;self.refresh()
    def select_answer(self,index):self.session.cup_guess=index+1 if index>=0 else None
    def check(self):
        if self.session.cup_guess is None:raise ValueError('Выбери число для ответа.')
        self.feedback.setText(self.service.student_answer(self.session,self.session.cup_guess)['message']);self.refresh()
    def undo(self):
        if self.service.cup_state(self.session)['pending']:self.service.begin_student(self.session)
        else:self.service.undo(self.session)
        self.feedback.setText('Ход отменён.');self.refresh()
    def hint(self):self.feedback.setText(self.service.student_hint(self.session)['text']);self.refresh()
    def refresh(self):
        self.remote_dirty=True
        if self.demonstration or (self.remote_request and self.remote_request["profile_id"]!=self.store.profile_id):
            self.remote_request=None;self.remote_bar.hide()
        ex=self.service.exercise(self.session)
        if not ex:return
        stats=game_progress(self.store.progress());self.xp.setText('ПОКАЗ' if self.demonstration else '★ XP '+str(stats['xp']))
        profile_name='Завершить показ' if self.demonstration else self.store.settings()['name']
        self.profile_button.setToolTip(profile_name)
        self.profile_button.setText(QFontMetrics(self.profile_button.font()).elidedText(profile_name,Qt.TextElideMode.ElideRight,108))
        state=self.service.cup_state(self.session);preview=state['preview']
        cue='Верно! Можно идти дальше' if self.session.completed else 'Покажи, чему равен x' if self.session.cup_phase=='answer' else 'Повтори на другой чаше' if state['pending'] else 'Освободи x'
        self.heading.setText(ex['task']['title']+'\n'+cue)
        self.condition.setText(ex['task']['equation'])
        self.condition.setToolTip('Исходное уравнение этого задания')
        result=equation(ex['task']['equation']).solution()
        value=Fraction(result["value"]) if result["kind"]=="one" else 0
        diff=preview.right.at(value)-preview.left.at(value)
        visual_prefs=self.store.settings()
        self.board.set_motion(visual_prefs.get('motion',True));self.board.set_ambient(visual_prefs.get('ambient_motion',True))
        if getattr(self.board,'is_3d',False):self.board.set_quality(visual_prefs.get('graphics_quality'));self.board.set_lamp(visual_prefs.get('room_lamp',True))
        self.board.set_blocks(pieces(preview.left),pieces(preview.right),tilt_for_difference(diff))
        visual_key=(self.store.profile_id,id(self.session),self.session.task_id)
        if visual_key==self._visual_key and self.session.completed and not self._visual_completed:
            self.board.celebrate()
        self._visual_key=visual_key;self._visual_completed=self.session.completed
        choose=not self.session.completed and self.session.cup_phase=='choose'
        for b,op in [(self.remove,'remove'),(self.add,'add')]:
            b.setChecked(self.session.cup_operation==op);b.setEnabled(choose and not state['pending'] and self.service.student_stage(self.session)!='demo')
        for b,side in [(self.left,'left'),(self.right,'right')]:
            b.setCheckable(True);b.setChecked(self.session.cup_side==side);b.setEnabled(choose)
        self.answers.setVisible(not self.session.completed and self.session.cup_phase=='answer')
        self.answer.blockSignals(True);self.answer.setCurrentIndex((self.session.cup_guess or 0)-1);self.answer.blockSignals(False)
        self.next_button.setEnabled(self.session.completed and not self.demonstration);self.hint_button.setEnabled(not self.session.completed)
        self.undo_button.setEnabled(not self.session.completed and (state['pending'] or len(self.session.history)>1))
        self.service.save_practice(self.session)
        save_pending(self.store,self.session)
        if self.demonstration:
            index=stage(self.session,state["pending"])
            self.heading.setText("Показ для жюри · %d/5\n" % (index+1)+SCRIPT[index][0].split(" · ",1)[1])
            self.feedback.setText(SCRIPT[index][1])
    def poll(self):
        state=self.reader.status()
        errors=str((state.get('error'),state.get('warning'),state.get('channels'),self.buttons.error))
        if errors!=self.last_hardware:
            self.log.info('state %s',errors);self.last_hardware=errors
            for side,button,label in [('left',self.left,'Левая чаша'),('right',self.right,'Правая чаша')]:
                channel=state.get('channels',{}).get(side,state)
                status=('нет связи' if channel.get('error') else 'повтори чтение' if channel.get('warning') else 'убери метку' if channel.get('present_uid') else 'готова' if channel.get('connected') else 'экран' if self.reader.mode=='simulator' else 'подключение')
                button.setText(label+' · '+status)
        for e in self.reader.since(self.seq):
            self.seq=e['sequence']
            if self.preflight is not None:
                key=e.get('source','reader') if e.get('type')!='button' else e['operation']
                self.preflight[key]=self.preflight.get(key,0)+1
                self.preflight_note.setText(str(self.preflight)+'\nПоследнее событие: '+str(e)+'\nНазначение метки: '+str(self.store.tags().get(e.get('uid'), 'не назначена') if 'uid' in e else e.get('operation')))
            if QApplication.activeModalWidget():continue
            if e.get('type')=='button':self.run(lambda e=e:self.operation(e['operation']))
            else:self.run(lambda e=e:self.scan(e))
        self.run(self.check_remote)
    def check_remote(self):
        if self.demonstration or not self.mobile.running:
            self.remote_bar.hide();return
        if QApplication.activeModalWidget():return
        changed=self.mobile.requests_changed.is_set()
        expired=bool(self.remote_request and self.remote_request['expires_at']<=time.time())
        if not self.remote_dirty and not changed and not expired:return
        self.mobile.requests_changed.clear();self.remote_dirty=False
        self.remote_request=lesson_queue.pending(self.store.db,self.store.profile_id)
        visible=bool(self.remote_request and self.session.completed and lesson_queue.allowed(self.store.db))
        self.remote_bar.setVisible(visible)
        if visible:
            task=next(t for t in ADVENTURE_TASKS if t['id']==self.remote_request['task_id'])
            self.remote_label.setText('С телефона: '+task['title']+' · '+task['equation'])

    def respond_remote(self,state):
        if self.demonstration or not self.session.completed:raise ValueError('Сначала заверши текущий пример.')
        if not self.remote_request:raise ValueError('Предложение больше не доступно.')
        try:
            with self.store.lock:
                value=lesson_queue.transition(self.store.db,self.remote_request['id'],self.store.profile_id,state)
            self.remote_request=None;self.remote_bar.hide()
            if state=='accepted':self.start(value['task_id'])
            else:self.feedback.setText('Предложение отклонено. Можно выбрать другой урок на карте.')
        finally:self.remote_dirty=True

    def scan(self,event):
        if self.demonstration and self.session.completed:return
        result=self.service.scan_cup(self.session,event);self.feedback.setText(result['message']);self.refresh()
    def dialog(self,title):
        d=QDialog(self);d.setObjectName('labDialog');d.setWindowTitle(title);d.resize(800,520)
        outer=QVBoxLayout(d);outer.setContentsMargins(18,14,18,14);outer.setSpacing(10)
        heading=QLabel(title);heading.setObjectName('dialogTitle');heading.setWordWrap(True);outer.addWidget(heading)
        scroll=QScrollArea();scroll.setWidgetResizable(True);body=QWidget();rows=QVBoxLayout(body);scroll.setWidget(body);outer.addWidget(scroll)
        self.button(outer,'Закрыть',d.accept)
        return d,rows
    def map(self):
        if self.demonstration:
            self.show_script();return
        from ..adventure import land_index
        dialog=RouteMap(self.store.progress()['best'],self.session.task_id,land_index(self.session.task_id),self,motion=self.store.settings().get('motion',True))
        result=dialog.exec();task,quiz=dialog.chosen_task,dialog.chosen_quiz
        dialog.deleteLater()
        if result==QDialog.DialogCode.Accepted:
            if task:self.start(task)
            elif quiz:self.quiz(quiz)
    def quiz(self,key):
        state=self.service.start_quiz(key)
        while not state['completed']:
            d,rows=self.dialog(QUIZ_BY_ID[key]['title']);q=QUIZ_BY_ID[key]['questions'][state['index']]
            label=QLabel(q[0]);label.setWordWrap(True);rows.addWidget(label);feedback=QLabel();feedback.setWordWrap(True)
            buttons=[]
            def choose(index):
                self.service.quiz_answer(state,index);feedback.setText(state['feedback'])
                for b in buttons:b.setEnabled(not state['answered'])
                forward.setEnabled(state['answered'])
            for i,text in enumerate(q[1]):buttons.append(self.button(rows,text,lambda i=i:choose(i)))
            rows.addWidget(feedback);forward=self.button(rows,'Дальше',lambda:(self.service.quiz_next(state),d.done(2)));forward.setEnabled(False)
            if d.exec()!=2:return
        self.feedback.setText('Квиз завершён! Результат сохранён.');self.refresh()
    def history(self):
        d,rows=self.dialog('Мой путь решения')
        for step in self.session.history:
            label=QLabel(step['label']+'\n'+step['left']+' = '+step['right']);label.setWordWrap(True);rows.addWidget(label)
        rule=QLabel('Одинаковые действия с обеих сторон сохраняют равенство.')
        rule.setWordWrap(True);rows.addWidget(rule)
        if self.session.completed:
            original=equation(self.service.exercise(self.session)['task']['equation'])
            solution=original.solution()
            if solution['kind']=='one':
                value=Fraction(solution['value'])
                proof=QLabel('Проверка в исходном условии: при x = '+fmt(value)+' получаем '+fmt(original.left.at(value))+' = '+fmt(original.right.at(value))+'.')
                proof.setWordWrap(True);rows.addWidget(proof)
        d.exec()
    def adult(self):
        if self.demonstration:
            self.show_script();return
        d,rows=self.dialog('Для взрослого')
        self.button(rows,'Кто играет? · Профили детей',lambda:(d.accept(),self.choose_profile()))
        self.button(rows,'Показ для жюри · 2–3 минуты',lambda:(d.accept(),self.begin_demo()))
        self.button(rows,'Прогресс на Android · доступ по Wi-Fi',self.mobile_access)
        self.button(rows,'Оформление · анимации',self.visual_settings)
        self.button(rows,'Состояние оборудования / проверка перед занятием',self.hardware_check)
        self.button(rows,'Сохранить резервную копию',self.make_backup)
        self.button(rows,'Восстановить резервную копию',self.load_backup)
        self.button(rows,'Сохранить журнал диагностики',self.export_log)
        self.button(rows,'Настройки и дополнительные режимы прежнего интерфейса',lambda:(d.accept(),self.open_legacy()))
        rows.addWidget(QLabel('Резервное копирование и проверки запускаются по запросу.'))
        d.exec()
    def open_legacy(self):
        self.legacy=True;self.close()
    def visual_settings(self):
        d,rows=self.dialog('Оформление и движение')
        note=QLabel('Можно выключить движение и тёплый светильник. Дневной свет остаётся. «Детальнее» улучшает материалы и тени; «Плавнее» уменьшает нагрузку.')
        note.setWordWrap(True);rows.addWidget(note)
        if getattr(self.board,'is_3d',False):
            info=self.board.surface.info if self.board.surface is not None else {}
            graphics=QLabel('Настоящая 3D-сцена · OpenGL\n'+info.get('renderer','Инициализация графики…'))
            graphics.setWordWrap(True);rows.addWidget(graphics)
            from .scene3d.quality import PROFILES,quality
            quality_buttons={}
            quality_row=QHBoxLayout();rows.addLayout(quality_row)
            def choose_quality(key):
                self.store.save_settings({'graphics_quality':key});self.board.set_quality(key)
                for name,b in quality_buttons.items():b.setChecked(name==key)
            current=quality(self.store.settings().get('graphics_quality')).key
            for key,profile in PROFILES.items():
                b=self.button(quality_row,profile.title,lambda checked=False,k=key:choose_quality(k))
                b.setCheckable(True);b.setChecked(key==current);quality_buttons[key]=b
        def toggle():
            enabled=not self.store.settings().get('motion',True)
            self.store.save_settings({'motion':enabled});self.board.set_motion(enabled)
            update()
        button=self.button(rows,'',toggle);button.setCheckable(True)
        def toggle_ambient():
            enabled=not self.store.settings().get('ambient_motion',True)
            self.store.save_settings({'ambient_motion':enabled});self.board.set_ambient(enabled);update()
        ambient_row=QHBoxLayout();rows.addLayout(ambient_row)
        ambient=self.button(ambient_row,'',toggle_ambient);ambient.setCheckable(True)
        lamp_button=None
        if getattr(self.board,'is_3d',False):
            def toggle_lamp():
                enabled=not self.store.settings().get('room_lamp',True)
                self.store.save_settings({'room_lamp':enabled});self.board.set_lamp(enabled);update()
            lamp_button=self.button(ambient_row,'',toggle_lamp);lamp_button.setCheckable(True)
        def update():
            if lamp_button is not None:
                enabled=self.store.settings().get('room_lamp',True)
                lamp_button.setChecked(enabled);lamp_button.setText('Светильник: '+('включён' if enabled else 'выключен'))
            enabled=self.store.settings().get('motion',True)
            button.setChecked(enabled);button.setText('Анимации: '+('включены' if enabled else 'выключены'))
            background=self.store.settings().get('ambient_motion',True)
            ambient.setChecked(background)
            ambient.setText(('Живой фон: '+('включён' if background else 'выключен')) if getattr(self.board,'is_3d',False) else ('Фоновые часы: '+('включены' if background else 'выключены')))
        update();d.exec()
    def mobile_access(self):
        d,rows=self.dialog('Прогресс на телефоне')
        intro=QLabel('Подключите телефон и тренажёр к одной Wi-Fi сети. В Android нажмите «Найти тренажёр». Для первого подключения введите код с этого экрана. Камера и QR-код не нужны.')
        intro.setWordWrap(True);rows.addWidget(intro)
        code_label=QLabel('Сначала включите доступ');code_label.setStyleSheet('font-size:30px;font-weight:bold;');rows.addWidget(code_label)
        note=QLabel();note.setWordWrap(True);rows.addWidget(note)
        def enable():
            self.mobile.start();self.store.save_settings({'mobile_enabled':True})
        def disable():
            self.mobile.close();self.store.save_settings({'mobile_enabled':False})
        self.button(rows,'Включить доступ',enable)
        code_button=self.button(rows,'Получить новый код (5 минут)',self.mobile.new_code)
        self.button(rows,'Отключить доступ',disable)
        self.button(rows,'Отозвать подключения телефонов',self.mobile.revoke)
        def proposals(enabled):
            self.store.save_settings({'mobile_lessons_enabled':enabled})
            if not enabled:lesson_queue.cancel_all(self.store.db)
            self.remote_dirty=True;self.mobile.requests_changed.set()
        self.button(rows,'Разрешить предложения уроков с телефона',lambda:proposals(True))
        self.button(rows,'Выключить предложения уроков',lambda:proposals(False))
        timer=QTimer(d)
        def update():
            state=self.mobile.status()
            text=('Доступ включён' if state['running'] else 'Доступ выключен / подключение…')
            if state['error']:text+='\nОшибка: '+state['error']
            text+='\nАдрес: '+(state['address'] or 'определяется при поиске')+':'+str(state['port'])
            code_label.setText(state['code'] or ('Получите новый код' if state['running'] else 'Сначала включите доступ'))
            code_button.setEnabled(state['running'])
            text+='\nПодключённых телефонов: '+str(state['phones'])
            text+='\nПредложения уроков: '+('включены' if self.store.settings().get('mobile_lessons_enabled',False) else 'выключены')
            text+='\nПосле подключения приложение запоминает устройство и обновляется каждые 25 секунд, пока открыто.'
            if note.text()!=text:note.setText(text)
        timer.timeout.connect(update);update();timer.start(1000)
        try:d.exec()
        finally:timer.stop()

    def hardware_check(self):
        d,rows=self.dialog('Проверка оборудования')
        note=QLabel();note.setWordWrap(True);rows.addWidget(note)
        self.preflight={};self.preflight_note=QLabel('Поднесите известную метку к каждой чаше и нажмите обе кнопки. Действия не меняют уравнение.')
        self.preflight_note.setWordWrap(True);rows.addWidget(self.preflight_note)
        timer=QTimer(d)
        def update():
            state=self.reader.status()
            text=str(state)+'\nКнопки: '+str(self.buttons.status())
            if note.text()!=text:note.setText(text)
        timer.timeout.connect(update);update();timer.start(700)
        try:d.exec()
        finally:timer.stop();self.preflight=None
    def make_backup(self):
        name,_=QFileDialog.getSaveFileName(self,'Сохранить резервную копию','algebra-backup.sqlite3','SQLite (*.sqlite3)')
        if name:
            self.service.save_practice(self.session);save_pending(self.store,self.session);backup(self.store,name)
            QMessageBox.information(self,'Резервная копия','Сохранены все профили детей, метки, настройки и прогресс.')
    def load_backup(self):
        name,_=QFileDialog.getOpenFileName(self,'Выбрать резервную копию','','SQLite (*.sqlite3)')
        if name and QMessageBox.question(self,'Восстановление','Заменить все профили детей, метки, настройки и прогресс выбранной копией? Текущая база будет сохранена в before-restore.sqlite3.')==QMessageBox.StandardButton.Yes:
            restore(self.store,name,self.data/'before-restore.sqlite3')
            if self.store.settings().get('mobile_enabled',False):self.mobile.start()
            else:self.mobile.close()
            self.session=Session()
            if not self.service.restore_practice(self.session):self.start(next_level(self.store.progress()['best'])['id'])
            pending=restore_pending(self.service,self.session)
            self.refresh()
            if pending:QTimer.singleShot(0,self.offer_pending)
    def export_log(self):
        import shutil
        name,_=QFileDialog.getSaveFileName(self,'Сохранить журнал','hardware.log','Log (*.log)')
        if name:
            for handler in self.log.handlers:handler.flush()
            source=self.data/'hardware.log'
            if Path(name).resolve()!=source.resolve():shutil.copyfile(source,name)
    def choose_profile(self):
        if self.demonstration:
            self.end_demo();return
        d,rows=self.dialog('Кто играет?')
        note=QLabel('У каждого ребёнка свои уровни, XP и незавершённый пример. Метки общие.')
        note.setWordWrap(True);rows.addWidget(note)
        for profile in self.store.profiles():
            label=('✓ ' if profile['id']==self.store.profile_id else '')+profile['name']
            self.button(rows,label,lambda key=profile['id']:(self.switch_profile(key),d.accept()))
        def create():
            name,ok=QInputDialog.getText(d,'Новый ребёнок','Имя или прозвище (до 24 символов):')
            if ok:
                key=self.store.create_profile(name)
                self.switch_profile(key);d.accept()
        self.button(rows,'+ Добавить ребёнка',create)
        d.exec()

    def switch_profile(self,key):
        if self.demonstration:raise ValueError('Сначала завершите показ.')
        self.service.save_practice(self.session);save_pending(self.store,self.session)
        self.store.select_profile(key)
        self.session=Session()
        if not self.service.restore_practice(self.session):
            self.start(next_level(self.store.progress()['best'])['id'])
        else:
            pending=restore_pending(self.service,self.session)
            self.refresh()
            if pending:QTimer.singleShot(0,self.offer_pending)
        self.seq=self.reader.sequence
        self.feedback.setText('Играет '+self.store.settings()['name']+'. Выбери свой ход.')

    def begin_demo(self):
        if self.demonstration:return
        self.service.save_practice(self.session);save_pending(self.store,self.session)
        self.demo_started=time.monotonic()
        self.saved_workspace=(self.store,self.service,self.session,self.feedback.text())
        tags=self.store.tags()
        visual_prefs=self.store.settings()
        self.store=Store(':memory:')
        self.store.bind_many(tags)
        self.store.save_settings({'motion':visual_prefs.get('motion',True),'ambient_motion':visual_prefs.get('ambient_motion',True),'graphics_quality':visual_prefs.get('graphics_quality'),'room_lamp':visual_prefs.get('room_lamp',True)})
        self.service=Service(self.store,self.reader);self.session=Session()
        self.demonstration=True;self.seq=self.reader.sequence
        self.start('cups-4')
        self.show_script()

    def show_script(self):
        d,rows=self.dialog('Показ для жюри · управление остаётся у человека')
        note=QLabel('Демонстрация не меняет прогресс ребёнка. Нужна назначенная метка +1 или +2. Закройте эту памятку и выполняйте действия на весах.')
        note.setWordWrap(True);rows.addWidget(note)
        for title,text in SCRIPT:
            label=QLabel(title+'\n'+text);label.setWordWrap(True);rows.addWidget(label)
        self.button(rows,'Завершить показ и вернуться к ребёнку',lambda:(d.accept(),self.end_demo()))
        d.exec()

    def end_demo(self,refresh=True):
        if not self.demonstration:return
        self.store.close()
        elapsed=time.monotonic()-self.demo_started
        self.store,self.service,self.session,feedback=self.saved_workspace
        self.session.started+=elapsed
        self.saved_workspace=None;self.demonstration=False
        self.seq=self.reader.sequence
        if refresh:
            self.feedback.setText(feedback);self.refresh()

    def closeEvent(self,event):
        if not self.closed:
            if self.demonstration:self.end_demo(refresh=False)
            self.closed=True;self.timer.stop();self.board.stop_animation();self.board.clock.stop();self.service.save_practice(self.session);save_pending(self.store,self.session);self.buttons.close();self.reader.close();self.mobile.close();self.store.close()
            if hasattr(self.board,'shutdown'):self.board.shutdown()
            for handler in self.log.handlers[:]:
                handler.close();self.log.removeHandler(handler)
        event.accept()

def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,default=Path(os.environ.get('XDG_DATA_HOME',str(Path.home()/'.local/share')))/'algebra-lab');parser.add_argument('--windowed',action='store_true');parser.add_argument('--fullscreen',action='store_true');parser.add_argument('--reader',choices=['simulator','rc522','rc522_dual'])
    parser.add_argument('--software-view',action='store_true',help='Прежний совместимый вид, без настоящего 3D')
    parser.add_argument('--check-3d',action='store_true',help='Проверить контекст, шейдеры и 3D-сцену без учебных данных')
    args=parser.parse_args(argv)
    if args.check_3d:
        from .scene3d.diagnostics import run
        return run()
    args.data_dir.mkdir(parents=True,exist_ok=True)
    with (args.data_dir/'desktop.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:print('Алгебра LAB уже запущена.',file=sys.stderr);return 1
        app=QApplication(sys.argv[:1])
        for folder in [Path('/usr/share/fonts/truetype/algebra-lab'),Path(__file__).parents[2]/'packaging/fonts']:
            for path in folder.glob('AlgebraRounded-*.ttf'):QFontDatabase.addApplicationFont(str(path))
        app.setStyleSheet(Path(__file__).with_name('theme.qss').read_text())
        w=Window(args.data_dir,args.reader,args.software_view)
        if args.windowed:w.show()
        else:w.showFullScreen()
        result=app.exec()
        if not w.closed:w.close()
        legacy=w.legacy
        from PyQt6 import sip
        from .gui_lifecycle import release_gui_caches
        sip.delete(w)
        del w
        icon.cache_clear();release_gui_caches()
        sip.delete(app)
        del app
        import gc
        gc.collect()
    if legacy:
        os.execv(sys.executable,[sys.executable,str(Path(__file__).parents[2]/'launcher.py'),'--legacy','--data-dir',str(args.data_dir)])
    return result


if __name__ == "__main__":
    raise SystemExit(main())
