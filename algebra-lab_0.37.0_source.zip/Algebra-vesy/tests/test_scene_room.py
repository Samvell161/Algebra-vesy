"""The fixed camera must show separate props around a clear balance workspace."""
import itertools
import math
import unittest
from algebra_lab.qt_ui.scene3d.model import build_workshop,ARM,PIVOT,HERO_SCALE
from algebra_lab.qt_ui.scene3d.lighting import LAMP_POSITION,LAMP_DIRECTION
from algebra_lab.qt_ui.balance_motion import ANGLE_STOP

CO=math.cos(math.radians(12));SI=math.sin(math.radians(12))
def projected(bounds):
    lo,hi=bounds
    return ((lo[0],lo[2]*CO+lo[1]*SI),(hi[0],hi[2]*CO+hi[1]*SI))

class RoomLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.scene=build_workshop(True)

    def test_room_contains_distinct_assemblies_with_a_bounded_geometry_budget(self):
        for name in ['window','globe','robot','plant','boat','pencils','rings','shape-toys','mini-map','lamp','clock','garland','owl']:
            self.assertIn(name,self.scene.room_bounds)
        self.assertGreaterEqual(len(self.scene.room_bounds),22)
        self.assertLess(sum(m.vertex_count for m in self.scene.static.values()),220000)
        self.assertLessEqual(len(self.scene.static),8)

    def test_actual_prop_silhouettes_have_clear_space_between_them(self):
        for (a,aa),(b,bb) in itertools.combinations(self.scene.room_bounds.items(),2):
            lo,hi=projected(aa);other_lo,other_hi=projected(bb)
            overlaps=[min(hi[i],other_hi[i])-max(lo[i],other_lo[i]) for i in range(2)]
            self.assertLessEqual(min(overlaps),.015,(a,b,overlaps))

    def test_background_stays_outside_pan_sweep_and_level_beam(self):
        for name,bounds in self.scene.room_bounds.items():
            lo,hi=projected(bounds)
            for left,right in [(-3.81,-.97),(.97,3.81)]:
                if min(hi[0],right)>max(lo[0],left) and hi[1]>.50:
                    self.assertGreater(lo[1],3.76,name)
            for left,right in [(-4.04,-3.80),(3.80,4.04)]:
                if min(hi[0],right)>max(lo[0],left):
                    self.assertTrue(hi[1]<.6 or lo[1]>2.35,(name,lo,hi))
            left,right=max(-ARM*HERO_SCALE,lo[0]),min(ARM*HERO_SCALE,hi[0])
            if left<right:
                excursion=max(abs(left),abs(right))*math.tan(math.radians(ANGLE_STOP))
                lower=(PIVOT*HERO_SCALE-excursion-.15*HERO_SCALE)*CO-.15*HERO_SCALE*SI
                upper=(PIVOT*HERO_SCALE+excursion+.15*HERO_SCALE)*CO+.15*HERO_SCALE*SI
                self.assertTrue(hi[1]<lower or lo[1]>upper,(name,lo,hi,lower,upper))

    def test_spotlight_origin_is_inside_its_visible_bulb(self):
        lo,hi=self.scene.parts['lamp-bulb'].bounds()
        for p,a,b in zip(LAMP_POSITION,lo,hi):
            self.assertLess(a,p);self.assertGreater(b,p)
            self.assertAlmostEqual((a+b)/2,p,places=5)
        self.assertAlmostEqual(sum(v*v for v in LAMP_DIRECTION),1)
        self.assertTrue(all(v<0 for v in LAMP_DIRECTION))
