"""Decor remains in its own space, with neutral resting poses and no state."""
import math
import unittest
from algebra_lab.qt_ui.scene3d.room_motion import room_pose
from algebra_lab.qt_ui.scene3d.model import build_workshop

class RoomMotionTests(unittest.TestCase):
    def test_neutral_pose_and_bounded_long_running_motion(self):
        neutral=room_pose(0)
        self.assertEqual(neutral.clouds,(0,0));self.assertEqual(neutral.feet,(0,0))
        self.assertEqual(neutral.robot_x,0);self.assertEqual(neutral.owl_angle,0)
        self.assertEqual(neutral.pendulum,0)
        for i in range(1500):
            pose=room_pose(i*.137)
            values=[*pose.clouds,pose.robot_x,pose.robot_bob,*pose.feet,pose.owl_angle,pose.pendulum]
            self.assertTrue(all(math.isfinite(v) for v in values))
            self.assertLessEqual(abs(pose.robot_x),.12)
            self.assertLessEqual(abs(pose.clouds[0]),.24)
            self.assertLessEqual(abs(pose.clouds[1]),.18)
            self.assertLessEqual(abs(pose.owl_angle),5)
            self.assertLessEqual(abs(pose.pendulum),8)
            self.assertEqual(min(pose.feet),0)
            self.assertTrue(all(0<=v<=.045 for v in pose.feet))

    def test_robot_route_stays_between_globe_and_boat(self):
        scene=build_workshop(False)
        lo,hi=scene.room_bounds['robot']
        self.assertGreater(lo[0]-.12,scene.room_bounds['globe'][1][0])
        self.assertLess(hi[0]+.12,scene.room_bounds['boat'][0][0])
        moving=[k for k in scene.parts if k.startswith('room-robot-')]
        self.assertEqual(len(moving),7)
        self.assertEqual(len([k for k in scene.parts if k.startswith('room-owl-head-')]),2)
        self.assertLess(sum(m.vertex_count for m in scene.static.values())+sum(m.vertex_count for m in scene.parts.values()),550000)

    def test_slow_clouds_and_robot_have_continuous_positions(self):
        for frame in range(900):
            a,b=[room_pose(t/30) for t in [frame,frame+1]]
            self.assertLess(abs(a.robot_x-b.robot_x),.003)
            self.assertLess(max(abs(x-y) for x,y in zip(a.clouds,b.clouds)),.003)
            self.assertLess(abs(a.owl_angle-b.owl_angle),.7)
