"""Hardware defaults, bounded detail geometry and durable preferences."""
import tempfile
import unittest
from pathlib import Path
from algebra_lab.qt_ui.scene3d.quality import quality,default_quality,PROFILES
from algebra_lab.qt_ui.scene3d.model import build_workshop
from algebra_lab.storage import Store

class GraphicsBudgetTests(unittest.TestCase):
    def test_pi_defaults_and_unknown_preferences_are_valid(self):
        for model in ['Raspberry Pi 3 Model B Plus Rev 1.3','Raspberry Pi Zero 2 W Rev 1.0']:
            self.assertEqual(default_quality(model),'smooth')
        for model in ['Raspberry Pi 4 Model B Rev 1.5','Raspberry Pi 5 Model B Rev 1.0']:
            self.assertEqual(default_quality(model),'detail')
        self.assertIn(quality('old-value').key,PROFILES)

    def test_graphics_budgets_are_bounded_and_smooth_is_cheaper(self):
        low,high=quality('smooth'),quality('detail')
        self.assertLess(low.shadow,high.shadow)
        self.assertLess(low.frame_width,high.frame_width)
        self.assertGreater(low.ambient_ms,high.ambient_ms)
        self.assertEqual(high.shadow,2048)
        self.assertFalse(low.detailed);self.assertTrue(high.detailed)
        self.assertGreater(high.supersample,low.supersample);self.assertLessEqual(high.supersample,1.5)

    def test_detailed_geometry_preserves_contacts_and_stays_batched(self):
        low,high=build_workshop(False),build_workshop(True)
        for key in ['block','xblock','negative','bowl-0','bowl-1']:
            for a,b in zip(low.parts[key].bounds(),high.parts[key].bounds()):
                for x,y in zip(a,b):self.assertAlmostEqual(x,y,places=4)
        self.assertGreater(high.parts['chains'].vertex_count,low.parts['chains'].vertex_count)
        self.assertIn('base-fastener',high.names);self.assertIn('shelf-bracket',high.names)
        self.assertLessEqual(len(high.static),8)
        self.assertLess(sum(m.vertex_count for m in high.static.values())+sum(m.vertex_count for m in high.parts.values()),550000)

    def test_quality_persists_without_changing_existing_tags_or_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'algebra.sqlite3';store=Store(path)
            store.bind('A1','1');tags=store.tags();progress=store.progress()
            store.save_settings({'graphics_quality':'smooth','room_lamp':False});store.close()
            store=Store(path)
            try:
                self.assertEqual(store.settings()['graphics_quality'],'smooth')
                self.assertFalse(store.settings()['room_lamp'])
                self.assertEqual(store.tags(),tags);self.assertEqual(store.progress(),progress)
            finally:store.close()
