"""Record the actual extracted DEB with one, two and six-unit imbalances.

Development only: Qt and Pillow. Simulated RFID input, disposable progress.
Frame timestamps preserve the captured timing; this is not a Pi benchmark.
"""
import argparse
import io
import subprocess
import sys
import tempfile
from pathlib import Path
from PIL import Image

parser=argparse.ArgumentParser()
parser.add_argument('package',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
frames=[];timestamps=[]
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    subprocess.run(['dpkg-deb','-x',str(args.package),str(root)],check=True)
    payload=root/'usr/share/algebra-lab';sys.path.insert(0,str(payload))
    from PyQt6.QtCore import QBuffer,QIODevice,QElapsedTimer
    from PyQt6.QtGui import QFontDatabase
    from PyQt6.QtTest import QTest
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.app import Window
    app=QApplication([])
    for font in (root/'usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):
        assert QFontDatabase.addApplicationFont(str(font))>=0
    app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
    data=root/'profile';data.mkdir()
    window=Window(data);window.start('cups-4');window.show();app.processEvents()
    clock=QElapsedTimer();clock.start()
    def capture(seconds):
        for _ in range(round(seconds*25)):
            QTest.qWait(max(1,round((len(frames)+1)*1000/25)-clock.elapsed()))
            buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            window.grab().save(buffer,'PNG')
            frames.append(Image.open(io.BytesIO(bytes(buffer.data()))).convert('RGB'))
            timestamps.append(clock.elapsed())
    try:
        for uid,kind in [('B1','1'),('A2','2'),('CC','x')]:window.store.bind(uid,kind)
        capture(.6)
        window.operation('add');window.scan({'uid':'B1','source':'left'});capture(1.6)
        assert abs(window.board.tilt+1.8)<1e-9
        window.grab().save(str(args.output/'one-unit.png'))
        window.undo();capture(1.4)
        window.operation('add');window.scan({'uid':'A2','source':'left'});capture(1.6)
        assert window.board.tilt==-3
        window.grab().save(str(args.output/'two-units.png'))
        window.scan({'uid':'A2','source':'right'});capture(1.4)
        window.start('duet-5');capture(1.4)
        window.operation('remove');window.scan({'uid':'CC','source':'left'});capture(1.6)
        assert window.board.tilt==5.4
        window.grab().save(str(args.output/'strong-tilt.png'))
        window.scan({'uid':'CC','source':'right'});capture(1.4)
        assert window.board.tilt==0
    finally:window.close()
frames=[frame.quantize(colors=192) for frame in frames]
durations=[max(10,b-a) for a,b in zip(timestamps,timestamps[1:])]+[40]
target=args.output/'physics-animation.gif'
frames[0].save(target,save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True)
print('PASS: actual extracted package, imbalances 1/2/6, return to balance;',target.stat().st_size,'bytes')
