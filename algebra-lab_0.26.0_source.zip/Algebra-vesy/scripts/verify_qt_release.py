"""Exercise the extracted Qt payload; no physical GPIO required."""
import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('package',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    subprocess.run(['dpkg-deb','-x',str(args.package),str(root)],check=True)
    payload=root/'usr/share/algebra-lab'
    sys.path.insert(0,str(payload))
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtGui import QFontDatabase,QFontInfo,QRawFont
    from PyQt6.QtTest import QTest
    from algebra_lab.qt_ui.app import Window
    from algebra_lab.qt_ui.workshop import BACKGROUND,background_texture
    app=QApplication([])
    for font in (root/'usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):
        assert QFontDatabase.addApplicationFont(str(font))>=0
    app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
    data=root/'profile';data.mkdir()
    w=Window(data);w.start('cups-4');w.show();app.processEvents()
    for label in [w.heading,w.condition]:
        assert QFontInfo(label.font()).family()=='Algebra Rounded'
        assert QFontInfo(label.font()).styleName()=='Bold'
        raw=QRawFont.fromFont(label.font())
        assert all(raw.supportsCharacter(char) for char in 'ЁёЖДя0123456789x−=+×÷½')
    assert BACKGROUND.is_file() and payload in BACKGROUND.parents
    assert not background_texture().isNull(), 'Packaged offline workshop artwork must decode'
    assert background_texture.cache_info().misses==1
    assert w.size().width()==1024 and w.height()<=600
    assert w.board.height()>=340
    for button in w.centralWidget().findChildren(QPushButton):
        if button.isVisible():
            assert button.height()>=44 and button.width()>=44,button.text()
            assert button.graphicsEffect() is not None,button.text()
    assert w.board.clock.is_running
    clock=w.board.clock.grab().toImage();room=w.board._stage.cacheKey()
    QTest.qWait(350)
    assert w.board.clock.grab().toImage()!=clock
    assert w.board._stage.cacheKey()==room
    w.grab().save(str(args.output/'game.png'))
    w.store.bind('B1','1');w.operation('add')
    w.reader.emit({'uid':'B1','source':'left'});w.poll();app.processEvents()
    assert abs(w.board.tilt+1.8)<1e-9
    QTest.qWait(w.board.DURATION+100)
    w.grab().save(str(args.output/'one-unit.png'))
    w.undo();QTest.qWait(w.board.DURATION+100)
    w.store.bind('AA','2');w.operation('add')
    w.reader.emit({'uid':'AA','source':'left'});w.poll();app.processEvents()
    assert abs(w.board.tilt+3)<1e-9
    QTest.qWait(w.board.DURATION+100)
    bodies=w.board._cups[0].bodies
    assert len(bodies)==5 and any(b.row==1 for b in bodies)
    assert all(abs(b.y-w.board._cups[0].support(b)[0])<.01 for b in bodies)
    w.grab().save(str(args.output/'stacked.png'))
    w.undo();QTest.qWait(w.board.DURATION+100)
    w.operation('remove')
    w.reader.emit({'uid':'AA','source':'left'});w.poll();app.processEvents()
    assert w.board.tilt!=0
    assert w.board.is_animating
    QTest.qWait(w.board.DURATION+100)
    assert not w.board.is_animating and w.board._angle==w.board.tilt
    w.grab().save(str(args.output/'left-changed.png'))
    w.reader.emit({'uid':'AA','source':'right'});w.poll();app.processEvents()
    assert w.session.cup_phase=='answer' and not w.session.completed
    assert w.height()<=600
    assert w.board.height()>=280
    QTest.qWait(w.board.DURATION+100)
    w.grab().save(str(args.output/'answer.png'))
    w.session.cup_guess=2;w.check();assert w.session.completed
    assert w.board.is_animating
    QTest.qWait(140);w.grab().save(str(args.output/'success.png'))
    QTest.qWait(w.board.CELEBRATION_DURATION+100)
    assert not w.board.is_animating
    assert w.store.solutions()
    from unittest.mock import patch
    from algebra_lab import lesson_queue
    w.store.save_settings({'mobile_lessons_enabled':True})
    lesson_queue.submit(w.store.db,'a'*32,w.store.profile_id,'cups-1')
    with patch.object(w.mobile,'running',True):
        w.check_remote();app.processEvents()
        assert not w.remote_bar.isHidden()
        assert w.height()<=600 and w.remote_bar.geometry().bottom()<w.height()
        w.grab().save(str(args.output/'phone-lesson.png'))
        w.respond_remote('accepted')
        assert w.session.task_id=='cups-1' and not w.session.completed
    from algebra_lab.qt_ui.route_map import RouteMap
    from algebra_lab.qt_ui.map_backdrop import texture as map_texture
    assert not map_texture().isNull(), 'Packaged offline map diorama must decode'
    route=RouteMap(w.store.progress()['best'],w.session.task_id,parent=w,motion=True)
    route.show();app.processEvents()
    assert route.trail.is_animating
    geometry={key:button.geometry() for key,button in route.trail.nodes.items()}
    QTest.qWait(140)
    assert 0<route.trail._reveal<1
    route.grab().save(str(args.output/'map-opening.png'))
    QTest.qWait(1100)
    assert route.trail._reveal==1
    assert geometry=={key:button.geometry() for key,button in route.trail.nodes.items()}
    route.grab().save(str(args.output/'map.png'))
    route.close();assert not route.trail.is_animating
    w.close()
    assert not w.board.clock.is_running
    # Simulate a damaged local installation only inside the extracted temp directory.
    BACKGROUND.unlink();background_texture.cache_clear()
    (payload/'algebra_lab/qt_ui/assets/adventure-diorama.png').unlink();map_texture.cache_clear()
    fallback=Window(data);fallback.show();app.processEvents()
    try:
        assert not fallback.board.grab().isNull()
        assert fallback.condition.text()==fallback.service.exercise(fallback.session)['task']['equation']
        assert fallback.left.isVisible() and fallback.right.isVisible()
        fallback.grab().save(str(args.output/'fallback.png'))
        # Match the application lifecycle: dialogs belong to their main window.
        damaged_map=RouteMap({},'cups-1',parent=fallback,motion=False)
        try:
            damaged_map.show();app.processEvents()
            assert not damaged_map.grab().isNull()
            assert not damaged_map.trail.is_animating
        finally:damaged_map.close()
    finally:fallback.close()
print('PASS: extracted Qt UI at 1024x600, background clock, gravity/contact/stacking, shadows, offline art/fallback, RFID paired step, explicit answer, history and Android proposal')
