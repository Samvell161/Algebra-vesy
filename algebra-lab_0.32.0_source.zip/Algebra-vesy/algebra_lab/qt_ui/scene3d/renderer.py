"""OpenGL 2.1 / GLES 2 renderer: fixed frontal projection, depth, normals and shadow map.

Uses standard PyOpenGL and Qt's OpenGL widget. Geometry is uploaded once;
the room never comes from an image. Only block lettering uses small textures.
"""
import ctypes
import math
import os
import weakref
from array import array
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from PyQt6.QtCore import Qt,QTimer,pyqtSignal
from PyQt6.QtGui import QMatrix4x4,QVector3D,QImage,QPainter,QFont,QColor
from PyQt6.QtOpenGL import QOpenGLWindow
from .gl_api import GL,compileShader
from .model import build_workshop,PIVOT,ARM,RIM,RADIUS,CLOCK
from .quality import quality

_executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='algebra-mesh')
_futures={}

VERTEX='''
attribute vec3 a_position;
attribute vec3 a_normal;
attribute vec3 a_color;
uniform mat4 u_model;
uniform mat4 u_vp;
uniform mat4 u_light;
uniform mat3 u_normal;
uniform vec2 u_label_size;
varying vec3 v_world;
varying vec3 v_normal;
varying vec3 v_color;
varying vec4 v_shadow;
varying vec3 v_label;
void main(){
    vec4 world=u_model*vec4(a_position,1.0);
    v_world=world.xyz;v_normal=normalize(u_normal*a_normal);v_color=a_color;
    v_shadow=u_light*world;gl_Position=u_vp*world;
    v_label=vec3(a_position.x/u_label_size.x+.5,a_position.z/u_label_size.y+.5,-a_normal.y);
}
'''
FRAGMENT='''
uniform sampler2D u_shadow;
uniform vec3 u_eye;
uniform vec4 u_finish;
uniform float u_alpha;
uniform float u_shadows;
uniform float u_labelled;
uniform float u_shadow_texel;
#if DETAIL_MODE
uniform vec4 u_contacts[12];
#endif
uniform sampler2D u_label;
varying vec3 v_world;
varying vec3 v_normal;
varying vec3 v_color;
varying vec4 v_shadow;
varying vec3 v_label;
float unpackDepth(vec4 v){return dot(v.rg,vec2(1.0,1.0/255.0));}
float visibility(vec3 n,vec3 light){
    vec3 q=v_shadow.xyz/v_shadow.w*.5+.5;
    if(q.x<.002||q.x>.998||q.y<.002||q.y>.998||q.z<0.0||q.z>1.0)return 1.0;
    float bias=max(.00145,.0032*(1.0-max(0.0,dot(n,light))));
    float sum=0.0;
#if DETAIL_MODE
    for(int i=0;i<3;i++)for(int j=0;j<3;j++){
        vec2 offset=(vec2(float(i),float(j))-1.0)*u_shadow_texel*1.7;
#else
    for(int i=0;i<2;i++)for(int j=0;j<2;j++){
        vec2 offset=(vec2(float(i),float(j))-.5)*u_shadow_texel*1.5;
#endif
        float depth=unpackDepth(texture2D(u_shadow,q.xy+offset));
        sum+=q.z-bias<=depth?1.0:.28;
    }
#if DETAIL_MODE
    return mix(1.0,sum/9.0,u_shadows);
#else
    return mix(1.0,sum*.25,u_shadows);
#endif
}
void main(){
    vec3 n=normalize(v_normal),l=normalize(vec3(-5.0,-7.0,9.0));
    vec3 eye=normalize(u_eye-v_world),halfway=normalize(eye+l);
    float vis=visibility(n,l),diff=max(0.0,dot(n,l));
    float grain=1.0;
    if(u_finish.z>.5){
        float rings=sin(v_world.x*32.0+sin(v_world.y*1.9)*2.0+sin(v_world.x*3.0)*.7);
        grain=.97+.025*rings;
    }
    vec3 base=pow(v_color,vec3(2.2))*grain;
    if(u_labelled>.5){
        vec4 printColor=texture2D(u_label,v_label.xy);
        base=mix(base,pow(printColor.rgb,vec3(2.2)),printColor.a*step(.98,v_label.z));
    }
    vec3 ambient=mix(vec3(.26,.23,.18),vec3(.52,.58,.57),n.z*.5+.5);
    float spec=pow(max(0.0,dot(n,halfway)),u_finish.x)*u_finish.y*vis;
#if DETAIL_MODE
    // GGX microfacets: enamel, brushed metal and wood keep distinct roughness.
    float roughness=clamp(sqrt(2.0/(u_finish.x+2.0)),.16,.75);
    float a2=roughness*roughness; a2*=a2;
    float nh=max(0.0,dot(n,halfway)),nv=max(.025,dot(n,eye));
    float d=nh*nh*(a2-1.0)+1.0;
    float distribution=a2/(3.141593*d*d);
    float k=(roughness+1.0)*(roughness+1.0)/8.0;
    float geometry=(nv/(nv*(1.0-k)+k))*(diff/(diff*(1.0-k)+k));
    vec3 f0=mix(vec3(.04),base,step(.35,u_finish.y)*.75);
    vec3 fresnel=f0+(1.0-f0)*pow(1.0-max(0.0,dot(halfway,eye)),5.0);
    vec3 glossy=distribution*geometry*fresnel/max(.08,4.0*nv*diff);
    float occlusion=1.0;
    for(int i=0;i<12;i++){
        vec3 delta=u_contacts[i].xyz-v_world;
        float distance2=max(.0001,dot(delta,delta));
        float facing=max(0.0,dot(n,delta)*inversesqrt(distance2));
        float solidAngle=min(.85,u_contacts[i].w*u_contacts[i].w/distance2);
        occlusion*=1.0-.55*facing*solidAngle;
    }
    // Broad, cool reflection from the window, without an environment image.
    vec3 reflection=reflect(-eye,n);
    float windowLight=pow(max(0.0,dot(reflection,normalize(vec3(-.65,-.2,.7)))),12.0);
    vec3 lit=base*(ambient*max(.42,occlusion)+vec3(1.03,.94,.79)*diff*vis)
        +vec3(1.0,.94,.82)*glossy*diff*vis*.7
        +vec3(.70,.83,.88)*windowLight*fresnel*.32;
#else
    vec3 lit=base*(ambient+vec3(1.03,.94,.79)*diff*vis)+vec3(1.0,.94,.82)*spec;
#endif
    lit=mix(lit,base*1.12,u_finish.w);
    vec3 mapped=(lit*(2.51*lit+.03))/(lit*(2.43*lit+.59)+.14);
    gl_FragColor=vec4(pow(clamp(mapped,0.0,1.0),vec3(1.0/2.2)),u_alpha);
}
'''
DEPTH_VERTEX='''attribute vec3 a_position;uniform mat4 u_mvp;void main(){gl_Position=u_mvp*vec4(a_position,1.0);}'''
DEPTH_FRAGMENT='''void main(){float d=min(gl_FragCoord.z,.99999);vec2 e=fract(vec2(1.0,255.0)*d);e.x-=e.y/255.0;gl_FragColor=vec4(e,0.0,1.0);}'''
POST_VERTEX='''attribute vec3 a_position;varying vec2 v_uv;void main(){v_uv=a_position.xy*.5+.5;gl_Position=vec4(a_position,1.0);}'''
POST_FRAGMENT='''
uniform sampler2D u_scene;uniform vec2 u_texel;varying vec2 v_uv;
void main(){
    vec3 nw=texture2D(u_scene,v_uv+vec2(-1.0,1.0)*u_texel).rgb;
    vec3 ne=texture2D(u_scene,v_uv+vec2(1.0,1.0)*u_texel).rgb;
    vec3 sw=texture2D(u_scene,v_uv+vec2(-1.0,-1.0)*u_texel).rgb;
    vec3 se=texture2D(u_scene,v_uv+vec2(1.0,-1.0)*u_texel).rgb;
    vec3 mid=texture2D(u_scene,v_uv).rgb,luma=vec3(.299,.587,.114);
    float a=dot(nw,luma),b=dot(ne,luma),c=dot(sw,luma),d=dot(se,luma),m=dot(mid,luma);
    float low=min(m,min(min(a,b),min(c,d))),high=max(m,max(max(a,b),max(c,d)));
    if(high-low<max(.035,high*.08)){gl_FragColor=vec4(mid,1.0);return;}
    vec2 dir=vec2(-((a+b)-(c+d)),(a+c)-(b+d));
    float reduce=max((a+b+c+d)*.03125,.0078125);
    dir=clamp(dir/(min(abs(dir.x),abs(dir.y))+reduce),vec2(-6.0),vec2(6.0))*u_texel;
    vec3 first=.5*(texture2D(u_scene,v_uv-dir/6.0).rgb+texture2D(u_scene,v_uv+dir/6.0).rgb);
    vec3 second=first*.5+.25*(texture2D(u_scene,v_uv-dir*.5).rgb+texture2D(u_scene,v_uv+dir*.5).rgb);
    float lum=dot(second,luma);gl_FragColor=vec4(lum<low||lum>high?first:second,1.0);
}
'''

FINISH={'matte':(28,.06,0,0),'wood':(24,.06,1,0),'metal':(75,.42,0,0),
        'enamel':(52,.22,0,0),'emissive':(8,0,0,1)}

def matrix(position=(0,0,0),rotation=(0,0,0),scale=(1,1,1)):
    m=QMatrix4x4();m.translate(*position)
    for a,axis in zip(rotation,[(1,0,0),(0,1,0),(0,0,1)]):
        if a:m.rotate(a,*axis)
    if isinstance(scale,(int,float)):m.scale(scale)
    else:m.scale(*scale)
    return m

class SceneSurface(QOpenGLWindow):
    ready=pyqtSignal()
    failed=pyqtSignal(str)

    def __init__(self,board):
        super().__init__();self.owner=weakref.proxy(board)
        self.buffers={};self.textures=OrderedDict();self.programs=[];self.scene=None
        self.error=None;self.info={};self.initialized=False;self._dead=False
        self.frames=0;self.shadow_frames=0;self._shadow_key=None;self._press=None
        self.shadows_enabled=True
        self.scene_size=None;self.scene_fbo=self.scene_texture=self.scene_depth=0
        self.setTitle('Трёхмерная мастерская')
        self.quality=quality();self._pending_scene=None;self._applied_quality=None
        self.shadow_size=0
        self._select_mesh(self.quality)
        self._loading=QTimer(self);self._loading.setInterval(40);self._loading.timeout.connect(self._poll_mesh)
        self._loading.start()

    def _select_mesh(self,profile):
        if profile.key not in _futures:
            _futures[profile.key]=_executor.submit(build_workshop,profile.detailed)
        self._mesh_future=_futures[profile.key]

    def set_quality(self,key):
        profile=quality(key)
        if profile==self.quality:return
        self.quality=profile;self._pending_scene=None;self._select_mesh(profile)
        self._loading.start();self.update()

    def _apply_quality(self):
        if self._pending_scene is None:return
        if self._applied_quality==self.quality.key:
            self._pending_scene=None;return
        # paintGL owns the context. No GL allocations happen in button handlers.
        if self.buffers:
            GL.glDeleteBuffers(len(self.buffers),[value[0] for value in self.buffers.values()])
            self.buffers.clear()
        self.scene=self._pending_scene;self._pending_scene=None
        if self._applied_quality is not None:GL.glDeleteProgram(self.main_program);self.programs.remove(self.main_program);self.locations.pop(self.main_program,None)
        self.main_program=self._program(VERTEX,'#define DETAIL_MODE '+str(int(self.quality.detailed))+'\n'+FRAGMENT)
        self.locations[self.main_program]={}
        self._resize_shadow(self.quality.shadow)
        self._applied_quality=self.quality.key;self._shadow_key=None
        self.info.update(quality=self.quality.key,shadow_size=self.shadow_size,
                         contact_shading=self.quality.detailed)

    def _poll_mesh(self):
        if not self._mesh_future.done():return
        self._loading.stop()
        try:self._pending_scene=self._mesh_future.result()
        except Exception as exc:self._fail('Не удалось построить модели: '+str(exc));return
        self.update()

    def _fail(self,text):
        self.error=text;self.failed.emit(text)

    def _program(self,vertex,fragment):
        prefix='#version 100\nprecision highp float;\n' if self.context().isOpenGLES() else '#version 120\n'
        shaders=[]
        try:
            shaders=[compileShader(prefix+vertex,GL.GL_VERTEX_SHADER),compileShader(prefix+fragment,GL.GL_FRAGMENT_SHADER)]
            program=GL.glCreateProgram()
            for shader in shaders:GL.glAttachShader(program,shader)
            for i,name in enumerate(['a_position','a_normal','a_color','a_uv']):GL.glBindAttribLocation(program,i,name)
            GL.glLinkProgram(program)
            if not GL.glGetProgramiv(program,GL.GL_LINK_STATUS):raise RuntimeError(GL.glGetProgramInfoLog(program).decode())
            self.programs.append(program);return program
        finally:
            for shader in shaders:GL.glDeleteShader(shader)

    def initializeGL(self):
        try:
            self._drain_qt_errors()
            self.context().aboutToBeDestroyed.connect(self.cleanup,Qt.ConnectionType.DirectConnection)
            self.info={key:GL.glGetString(value).decode() for key,value in [('version',GL.GL_VERSION),('renderer',GL.GL_RENDERER),('vendor',GL.GL_VENDOR),('glsl',GL.GL_SHADING_LANGUAGE_VERSION)]}
            self.info['api']='OpenGL ES' if self.context().isOpenGLES() else 'OpenGL'
            self.info['samples']=self.context().format().samples()
            self.info['depth_bits']=self.context().format().depthBufferSize()
            self.main_program=0
            self.depth_program=self._program(DEPTH_VERTEX,DEPTH_FRAGMENT)
            self.post_program=self._program(POST_VERTEX,POST_FRAGMENT)
            self.locations={p:{} for p in self.programs}
            self._make_shadow()
            self.light=QMatrix4x4();self.light.ortho(-8.5,8.5,-7,7,1,30)
            view=QMatrix4x4();view.lookAt(QVector3D(-5,-6,10),QVector3D(0,1,1),QVector3D(0,0,1));self.light=self.light*view
            GL.glEnable(GL.GL_DEPTH_TEST);GL.glEnable(GL.GL_CULL_FACE);GL.glCullFace(GL.GL_BACK)
            GL.glDisable(GL.GL_DITHER)
            self.initialized=True
        except Exception as exc:self._fail('OpenGL: '+str(exc))

    def _make_shadow(self):
        self.shadow_texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,self.shadow_texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,1024,1024,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
        for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_NEAREST),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_NEAREST),
                            (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
        self.shadow_fbo=int(GL.glGenFramebuffers(1));GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.shadow_fbo)
        GL.glFramebufferTexture2D(GL.GL_FRAMEBUFFER,GL.GL_COLOR_ATTACHMENT0,GL.GL_TEXTURE_2D,self.shadow_texture,0)
        self.shadow_depth=int(GL.glGenRenderbuffers(1));GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.shadow_depth)
        GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,1024,1024)
        GL.glFramebufferRenderbuffer(GL.GL_FRAMEBUFFER,GL.GL_DEPTH_ATTACHMENT,GL.GL_RENDERBUFFER,self.shadow_depth)
        if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Карта теней недоступна')
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.defaultFramebufferObject())

    def _resize_shadow(self,size):
        if self.shadow_size==size:return
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D,self.shadow_texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,size,size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
        GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.shadow_depth)
        GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,size,size)
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.shadow_fbo)
        if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Недоступен выбранный размер теней')
        self.shadow_size=size

    def _frame_target(self):
        ratio=self.devicePixelRatioF();width=max(1,round(self.width()*ratio));height=max(1,round(self.height()*ratio))
        profile=quality(self._applied_quality)
        scale=min(1,profile.frame_width/width,profile.frame_height/height);size=(max(1,round(width*scale)),max(1,round(height*scale)))
        if self.scene_size!=size:
            if self.scene_fbo:
                GL.glDeleteTextures([self.scene_texture]);GL.glDeleteRenderbuffers(1,[self.scene_depth]);GL.glDeleteFramebuffers(1,[self.scene_fbo])
            self.scene_texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,self.scene_texture)
            GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,*size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
            for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_LINEAR),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_LINEAR),
                                (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
            self.scene_fbo=int(GL.glGenFramebuffers(1));GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.scene_fbo)
            GL.glFramebufferTexture2D(GL.GL_FRAMEBUFFER,GL.GL_COLOR_ATTACHMENT0,GL.GL_TEXTURE_2D,self.scene_texture,0)
            self.scene_depth=int(GL.glGenRenderbuffers(1));GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.scene_depth)
            GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,*size)
            GL.glFramebufferRenderbuffer(GL.GL_FRAMEBUFFER,GL.GL_DEPTH_ATTACHMENT,GL.GL_RENDERBUFFER,self.scene_depth)
            if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Недоступен 3D-буфер кадра')
            self.scene_size=size
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.scene_fbo);GL.glViewport(0,0,*size)

    def _finish_frame(self):
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.defaultFramebufferObject())
        ratio=self.devicePixelRatioF();GL.glViewport(0,0,round(self.width()*ratio),round(self.height()*ratio))
        GL.glDisable(GL.GL_DEPTH_TEST);GL.glDisable(GL.GL_CULL_FACE)
        p=self.post_program;GL.glUseProgram(p)
        GL.glBindTexture(GL.GL_TEXTURE_2D,self.scene_texture);GL.glUniform1i(self.location(p,'u_scene'),0)
        GL.glUniform2f(self.location(p,'u_texel'),1/self.scene_size[0],1/self.scene_size[1])
        if 'screen-quad' not in self.buffers:self._buffer('screen-quad',array('f',[-1,-1,0,1,-1,0,1,1,0,-1,-1,0,1,1,0,-1,1,0]),3)
        self.draw('screen-quad',p)
        GL.glEnable(GL.GL_DEPTH_TEST);GL.glEnable(GL.GL_CULL_FACE)

    def location(self,p,name):
        if name not in self.locations[p]:self.locations[p][name]=GL.glGetUniformLocation(p,name)
        return self.locations[p][name]
    def mat4(self,p,name,m):GL.glUniformMatrix4fv(self.location(p,name),1,False,(ctypes.c_float*16)(*m.data()))

    def mesh(self,key):
        if key in self.buffers:return self.buffers[key]
        data=self.scene.static[key[7:]].data if key.startswith('static:') else self.scene.parts[key].data
        return self._buffer(key,data,9)

    def _buffer(self,key,data,stride):
        handle=int(GL.glGenBuffers(1));GL.glBindBuffer(GL.GL_ARRAY_BUFFER,handle)
        GL.glBufferData(GL.GL_ARRAY_BUFFER,len(data)*4,data.tobytes(),GL.GL_STATIC_DRAW)
        self.buffers[key]=(handle,len(data)//stride,stride);return self.buffers[key]

    def draw(self,key,program):
        handle,count,stride=self.mesh(key);GL.glBindBuffer(GL.GL_ARRAY_BUFFER,handle)
        GL.glEnableVertexAttribArray(0);GL.glVertexAttribPointer(0,3,GL.GL_FLOAT,False,stride*4,ctypes.c_void_p(0))
        if program==self.main_program:
            for i,offset in [(1,12),(2,24)]:
                GL.glEnableVertexAttribArray(i);GL.glVertexAttribPointer(i,3,GL.GL_FLOAT,False,stride*4,ctypes.c_void_p(offset))
        GL.glDrawArrays(GL.GL_TRIANGLES,0,count)
        for i in range(4):GL.glDisableVertexAttribArray(i)

    def _nodes(self):
        board=self.owner;angle=math.radians(board._angle);nodes=[];labels={}
        for finish in self.scene.static:nodes.append(('static:'+finish,QMatrix4x4(),finish,True))
        for index,(key,(x,y,z)) in enumerate(self.scene.ambient_nodes):
            phase=board.clock._phase
            nodes.append((key,matrix((x+math.sin(phase*.18+index)*.20,y,z+math.sin(phase*.24+index)*.02)),'matte',False))
        nodes.append(('beam',matrix((0,0,PIVOT),(0,board._angle,0)),'metal',True))
        nodes.append(('pivot',matrix((0,-.13,PIVOT),(90,0,0)),'metal',True))
        nodes.append(('pivot-inlay',matrix((0,-.246,PIVOT),(90,0,0)),'enamel',False))
        for index,(direction,cup) in enumerate(zip((-1,1),board._cups)):
            x=direction*ARM*math.cos(angle);z=RIM-direction*ARM*math.sin(angle)
            nodes.extend([(f'bowl-{index}',matrix((x,0,z)),'enamel',True),('bowl-rim',matrix((x,0,z)),'metal',True),
                          ('chains',matrix((x,0,z)),'metal',True),('hook',matrix((x,0,PIVOT-direction*ARM*math.sin(angle)-.10),(90,0,0)),'metal',True)])
            for body in cup.bodies:
                if body.removing and body.age>.27:continue
                key='xblock' if 'x' in body.label else 'negative' if body.label.startswith(('−','-')) else 'block'
                wide=body.width>60
                scale=(body.width/220 if wide else body.width/52,1,1)
                # Model origin is the physical centre of the bottom edge.
                transform=matrix((x+body.x/100,body.depth/100,z-body.y/100),(body.pitch,body.roll,0),scale)
                centre=QMatrix4x4(transform);centre.translate(0,0,.29)
                nodes.append((key+('-wide' if wide else ''),centre,'matte',True))
                labels[id(centre)]=(body.label,2.2 if wide else .52)
        clock=board.clock;t=clock._time
        sec=t.second()+t.msec()/1000;minute=t.minute()+sec/60;hour=t.hour()%12+minute/60
        for key,rotation in [('hour-hand',hour*30),('minute-hand',minute*6),('second-hand',sec*6)]:
            nodes.append((key,matrix((CLOCK[0],CLOCK[1]-.115,CLOCK[2]),(0,rotation,0)),'matte',False))
        nodes.append(('pendulum',matrix((CLOCK[0],CLOCK[1]-.03,CLOCK[2]-.14),(0,math.sin(clock._phase*math.pi)*12,0)),'metal',False))
        if board._celebration.isValid():
            t=min(1,board._celebration.elapsed()/board.CELEBRATION_DURATION)
            for i in range(12):
                a=i*math.tau/12;distance=.3+.9*t
                position=(math.cos(a)*distance,-.35-(i%3)*.1,2.15+math.sin(a)*distance*.6+.15*t)
                nodes.append((['star-gold','star-mint','star-peach'][i%3],matrix(position,(90,i*18+t*140,0),max(.02,1-t)),'metal',False))
        return nodes,labels

    def _camera(self):
        # A fixed, centred parallel view keeps both pans equally sized. The
        # small elevation exposes their interiors without a sideways perspective.
        elevation=math.radians(12);target=QVector3D(0,.15,1.97)
        eye=target+QVector3D(0,-math.cos(elevation)*12,math.sin(elevation)*12)
        view=QMatrix4x4();view.lookAt(eye,target,QVector3D(0,0,1))
        half_height=2.17;aspect=max(.25,self.width()/max(1,self.height()))
        projection=QMatrix4x4();projection.ortho(-half_height*aspect,half_height*aspect,-half_height,half_height,1,35)
        self.eye=eye;self.vp=projection*view
        self.info.update(projection='orthographic',view='fixed-front')

    def paintGL(self):
        if self._dead:return
        try:
            self._drain_qt_errors()
            GL.glClearColor(.965,.937,.87,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
            if self.error or not self.initialized:return
            self._apply_quality()
            if self.scene is None:return
            if not self.buffers:
                for key in self.scene.static:self.mesh('static:'+key)
                for key in self.scene.parts:self.mesh(key)
            nodes,labels=self._nodes();self._camera()
            shadow_key=(self.owner._angle,tuple((b.x,b.y,b.depth,b.roll,b.pitch,b.age if b.removing else 0,b.label) for c in self.owner._cups for b in c.bodies))
            if shadow_key!=self._shadow_key:
                GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.shadow_fbo);GL.glViewport(0,0,self.shadow_size,self.shadow_size)
                GL.glClearColor(1,1,1,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
                GL.glUseProgram(self.depth_program)
                for key,model,finish,casts in nodes:
                    if casts:self.mat4(self.depth_program,'u_mvp',self.light*model);self.draw(key,self.depth_program)
                self._shadow_key=shadow_key;self.shadow_frames+=1
            self._frame_target()
            GL.glClearColor(.965,.937,.87,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
            p=self.main_program;GL.glUseProgram(p)
            self.mat4(p,'u_vp',self.vp);self.mat4(p,'u_light',self.light)
            GL.glUniform3f(self.location(p,'u_eye'),self.eye.x(),self.eye.y(),self.eye.z())
            GL.glUniform1f(self.location(p,'u_alpha'),1);GL.glUniform1f(self.location(p,'u_shadows'),float(self.shadows_enabled))
            GL.glActiveTexture(GL.GL_TEXTURE0);GL.glBindTexture(GL.GL_TEXTURE_2D,self.shadow_texture);GL.glUniform1i(self.location(p,'u_shadow'),0)
            GL.glUniform1f(self.location(p,'u_shadow_texel'),1/self.shadow_size)
            if quality(self._applied_quality).detailed:
                contacts=[(0,.1,.22,.52)]
                for key,model,finish,casts in nodes:
                    if id(model) in labels:
                        centre=model.map(QVector3D(0,0,0))
                        contacts.append((centre.x(),centre.y(),centre.z(),.24))
                contacts=(contacts+[(0,0,0,0)]*12)[:12]
                GL.glUniform4fv(self.location(p,'u_contacts[0]'),12,(ctypes.c_float*48)(*(v for c in contacts for v in c)))
            GL.glUniform1i(self.location(p,'u_label'),1);GL.glUniform2f(self.location(p,'u_label_size'),1,1)
            for key,model,finish,casts in nodes:
                label=labels.get(id(model))
                GL.glUniform1f(self.location(p,'u_labelled'),float(label is not None))
                if label is not None:
                    text,width=label
                    GL.glActiveTexture(GL.GL_TEXTURE1);GL.glBindTexture(GL.GL_TEXTURE_2D,self._label(text,width))
                    GL.glUniform2f(self.location(p,'u_label_size'),width,.58)
                self.mat4(p,'u_model',model)
                GL.glUniformMatrix3fv(self.location(p,'u_normal'),1,False,(ctypes.c_float*9)(*model.normalMatrix().data()))
                GL.glUniform4f(self.location(p,'u_finish'),*FINISH[finish]);self.draw(key,p)
            GL.glActiveTexture(GL.GL_TEXTURE0)
            self._finish_frame()
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER,0);GL.glUseProgram(0)
            self.frames+=1
            if self.frames==1:self.ready.emit()
        except Exception as exc:self._fail('Ошибка 3D-отрисовки: '+str(exc))

    def _drain_qt_errors(self):
        # Qt owns the context between callbacks. Do not attribute a stale Qt
        # state error (e.g. unsupported sRGB on ES 2) to our next GL operation.
        # Errors from our own calls remain checked by the binding.
        for _ in range(8):
            error=GL.glGetError()
            if error==GL.GL_NO_ERROR:return
            self.info.setdefault('qt_entry_errors',[])
            if int(error) not in self.info['qt_entry_errors']:self.info['qt_entry_errors'].append(int(error))

    def _label(self,text,width):
        key=(text,width)
        if key in self.textures:self.textures.move_to_end(key);return self.textures[key]
        image_width=512 if width>1 else 128
        image=QImage(image_width,128,QImage.Format.Format_RGBA8888);image.fill(Qt.GlobalColor.transparent)
        painter=QPainter(image);painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        font=QFont('Algebra Rounded');font.setBold(True);font.setPixelSize(104)
        painter.setFont(font)
        while painter.fontMetrics().horizontalAdvance(text)>image_width-12 and font.pixelSize()>20:
            font.setPixelSize(font.pixelSize()-2);painter.setFont(font)
        painter.setPen(QColor('#34564d') if 'x' in text else QColor('#5f4d32'))
        painter.drawText(image.rect(),int(Qt.AlignmentFlag.AlignCenter),text);painter.end()
        image=image.mirrored(False,True);data=image.bits().asstring(image.sizeInBytes())
        texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,image_width,128,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,data)
        GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
        for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_LINEAR_MIPMAP_LINEAR),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_LINEAR),
                            (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
        self.textures[key]=texture
        while len(self.textures)>64:
            _,old=self.textures.popitem(last=False);GL.glDeleteTextures([old])
        return texture

    def cleanup(self):
        if self._dead:return
        self._dead=True;self._loading.stop()
        context=self.context()
        if context is not None:
            try:context.aboutToBeDestroyed.disconnect(self.cleanup)
            except (TypeError,RuntimeError):pass
        if not self.initialized:return
        self.makeCurrent()
        try:
            GL.glFinish()
            if self.buffers:GL.glDeleteBuffers(len(self.buffers),[item[0] for item in self.buffers.values()])
            for texture in self.textures.values():GL.glDeleteTextures([texture])
            GL.glDeleteTextures([self.shadow_texture]);GL.glDeleteRenderbuffers(1,[self.shadow_depth]);GL.glDeleteFramebuffers(1,[self.shadow_fbo])
            if self.scene_fbo:
                GL.glDeleteTextures([self.scene_texture]);GL.glDeleteRenderbuffers(1,[self.scene_depth]);GL.glDeleteFramebuffers(1,[self.scene_fbo])
            for program in self.programs:GL.glDeleteProgram(program)
            self.buffers.clear();self.textures.clear()
            GL.glFinish()
        except Exception as exc:self.info['cleanup_error']=str(exc)
        finally:self.doneCurrent()
