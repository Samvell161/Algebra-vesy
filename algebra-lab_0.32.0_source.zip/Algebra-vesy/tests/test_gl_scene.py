"""Opt in with ALGEBRA_TEST_GL=1, DISPLAY and the xcb Qt platform.

This exercises the real OpenGL/GLES renderer, not the compatible software view.
"""
import os
import sys
import tempfile
import unittest
from pathlib import Path
if os.environ.get('ALGEBRA_NO_NUMPY')=='1':sys.modules['numpy']=None
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtGui import QFontDatabase
    from PyQt6.QtTest import QTest
    from algebra_lab.qt_ui.app import Window
except ImportError:QApplication=None

@unittest.skipUnless(QApplication and os.environ.get('ALGEBRA_TEST_GL')=='1','An actual GL display is required')
class RealGLTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        root=Path(__file__).resolve().parents[1]
        for font in (root/'packaging/fonts').glob('AlgebraRounded*.ttf'):QFontDatabase.addApplicationFont(str(font))
        cls.app.setStyleSheet((root/'algebra_lab/qt_ui/theme.qss').read_text())

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.w=Window(Path(self.tmp.name));self.w.start('cups-4');self.w.show()
        self.surface=self.w.board.surface
        self.wait_for(lambda:self.surface.frames>0 or self.w.board.graphics_error)
        self.assertIsNone(self.w.board.graphics_error)
        QTest.qWait(80)

    def tearDown(self):
        from PyQt6 import sip
        if not sip.isdeleted(self.w):self.w.close();sip.delete(self.w)
        self.surface=None;self.w=None
        import gc
        gc.collect()
        self.tmp.cleanup()

    @classmethod
    def tearDownClass(cls):
        from algebra_lab.qt_ui.app import icon
        from algebra_lab.qt_ui.gui_lifecycle import release_gui_caches
        icon.cache_clear();release_gui_caches()

    def wait_for(self,predicate):
        for _ in range(200):
            if predicate():return
            QTest.qWait(50)
        self.fail('3D scene did not become ready')

    def frame(self):
        count=self.surface.frames;self.surface.update();self.wait_for(lambda:self.surface.frames>count)
        return self.surface.grabFramebuffer()

    def test_real_gl_context_depth_buffers_offline_geometry_and_no_numpy(self):
        from algebra_lab.qt_ui.scene3d.gl_api import GL
        from algebra_lab.qt_ui.workshop import background_texture
        import OpenGL
        self.assertTrue(self.surface.isValid())
        self.assertIn('PyOpenGL-3.1.9-',OpenGL.__file__)
        self.assertEqual(background_texture.cache_info().misses,0)
        self.assertTrue(self.surface.vp.isAffine())
        self.surface.makeCurrent()
        try:self.assertTrue(GL.glIsEnabled(GL.GL_DEPTH_TEST))
        finally:self.surface.doneCurrent()
        image=self.frame();colors={image.pixelColor(x,y).name() for x in range(0,image.width(),12) for y in range(0,image.height(),12)}
        self.assertGreater(len(colors),80)
        self.assertGreater(self.surface.shadow_frames,0)
        self.assertGreater(sum(m.vertex_count for m in self.surface.scene.static.values()),10000)

    def test_fixed_front_camera_preserves_parallel_scale_and_ignores_drag(self):
        from PyQt6.QtCore import Qt,QPoint
        from PyQt6.QtGui import QVector3D,QMatrix4x4
        self.w.board.set_ambient(False);initial=self.frame();handles=dict(self.surface.buffers)
        shadow_frames=self.surface.shadow_frames;projection=QMatrix4x4(self.surface.vp)
        self.assertAlmostEqual(self.surface.eye.x(),0)
        self.assertTrue(projection.isAffine())
        # Equal widths at different depths, and a level, symmetrical beam.
        widths=[]
        for depth in [-1,0,3]:
            a,b=[projection.map(QVector3D(x,depth,1.5)) for x in [-1,1]]
            widths.append(b.x()-a.x())
        self.assertAlmostEqual(min(widths),max(widths),places=6)
        left,right=[projection.map(QVector3D(x,0,3.25)) for x in [-2.35,2.35]]
        self.assertAlmostEqual(left.y(),right.y(),places=6)
        self.assertAlmostEqual(left.x(),-right.x(),places=6)
        QTest.mousePress(self.surface,Qt.MouseButton.LeftButton,pos=QPoint(120,100))
        QTest.mouseMove(self.surface,QPoint(270,155),delay=30)
        QTest.mouseRelease(self.surface,Qt.MouseButton.LeftButton,pos=QPoint(270,155))
        other=self.frame()
        self.assertEqual(projection,self.surface.vp);self.assertEqual(initial,other)
        self.assertEqual(handles,self.surface.buffers);self.assertEqual(shadow_frames,self.surface.shadow_frames)
        self.assertFalse(any(b.text()=='Ракурс' for b in self.w.board.findChildren(QPushButton)))

    def test_real_shadows_and_clock_reuse_static_geometry(self):
        self.w.board.set_ambient(False);shadows=self.frame()
        self.surface.shadows_enabled=False;unshadowed=self.frame()
        self.assertNotEqual(shadows,unshadowed)
        self.surface.shadows_enabled=True;self.w.board.set_ambient(True)
        buffers=dict(self.surface.buffers);shadow_frames=self.surface.shadow_frames
        QTest.qWait(350)
        self.assertEqual(buffers,self.surface.buffers)
        self.assertEqual(shadow_frames,self.surface.shadow_frames)
        self.w.board.hide();self.assertFalse(self.w.board.clock.is_running)

    def test_rfid_equation_touch_targets_contacts_and_motion_setting_in_real_window(self):
        w=self.w;original=w.condition.text()
        for button in w.centralWidget().findChildren(QPushButton):
            if button.isVisible():self.assertGreaterEqual(min(button.width(),button.height()),44,button.text())
        self.assertLess(w.board.container.geometry().bottom(),w.left.geometry().top())
        w.store.bind('A1','1');w.operation('add');w.reader.emit({'uid':'A1','source':'left'});w.poll()
        self.assertAlmostEqual(w.board.tilt,-1.8)
        self.assertEqual(w.condition.text(),original)
        QTest.qWait(w.board.DURATION+150)
        self.assertFalse(w.board.is_animating)
        for cup in w.board._cups:
            for body in cup.bodies:self.assertAlmostEqual(body.y,cup.support(body)[0],places=5)
        w.reader.emit({'uid':'A1','source':'right'});w.poll();self.assertEqual(w.board.tilt,0)
        w.board.set_motion(False);self.assertFalse(w.board.clock.is_running);self.assertFalse(w.board.is_animating)
        self.assertEqual(w.condition.text(),original)

    def test_quality_switch_rebuilds_only_geometry_and_preserves_lesson_and_labels(self):
        w=self.w;surface=self.surface;w.board.set_ambient(False)
        original=w.condition.text();progress=w.store.progress();tags=w.store.tags()
        w.board.set_quality('detail');self.wait_for(lambda:surface._applied_quality=='detail')
        high=self.frame();high_vertices=surface.scene.parts['chains'].vertex_count
        self.assertEqual(surface.shadow_size,2048)
        self.assertTrue(surface.info['contact_shading'])
        textures=dict(surface.textures)
        w.board.set_quality('smooth');self.wait_for(lambda:surface._applied_quality=='smooth')
        low=self.frame()
        self.assertEqual(surface.shadow_size,1024)
        self.assertFalse(surface.info['contact_shading'])
        self.assertLess(surface.scene.parts['chains'].vertex_count,high_vertices)
        self.assertNotEqual(high,low);self.assertEqual(dict(surface.textures),textures)
        self.assertEqual(w.condition.text(),original);self.assertEqual(w.store.progress(),progress);self.assertEqual(w.store.tags(),tags)
        # Several quick requests must not install a stale model or shader.
        for key in ['detail','smooth','detail','smooth','detail']:w.board.set_quality(key)
        self.wait_for(lambda:surface._applied_quality=='detail');self.frame()
        self.assertEqual(surface.shadow_size,2048)
        self.assertEqual(surface.scene.parts['chains'].vertex_count,high_vertices)
        w.board.set_motion(False);self.assertFalse(w.board.clock.is_running)
        w.board.set_quality('smooth');self.wait_for(lambda:surface._applied_quality=='smooth')
        self.assertFalse(w.board.clock.is_running);self.assertFalse(w.board.is_animating)

    def test_quality_dialog_persists_touch_selection_and_returns_to_real_scene(self):
        from PyQt6.QtCore import QTimer
        w=self.w;seen=[]
        def choose():
            dialog=QApplication.activeModalWidget();self.assertIsNotNone(dialog)
            buttons=dialog.findChildren(QPushButton)
            selection=next(b for b in buttons if b.text().startswith('Плавнее'))
            self.assertGreaterEqual(selection.height(),44);selection.click()
            seen.append(w.store.settings()['graphics_quality']);dialog.accept()
        QTimer.singleShot(150,choose);w.visual_settings()
        self.assertEqual(seen,['smooth'])
        self.wait_for(lambda:self.surface._applied_quality=='smooth')
        self.assertTrue(self.surface.isValid());self.assertFalse(w.closed)
        self.assertEqual(w.board.clock._timer.interval(),160)
        w.refresh();self.assertEqual(w.store.settings()['graphics_quality'],'smooth')

    def test_shader_failure_leaves_native_controls_responsive(self):
        from unittest.mock import patch
        from algebra_lab.qt_ui.scene3d.renderer import SceneSurface
        self.w.close()
        with patch.object(SceneSurface,'_program',side_effect=RuntimeError('test shader failure')):
            data=Path(self.tmp.name)/'failure';data.mkdir()
            other=Window(data);other.start('cups-4');other.show()
            try:
                self.wait_for(lambda:bool(other.board.graphics_error))
                self.assertIn('test shader failure',other.board.graphics_error)
                self.assertFalse(other.board.container.isVisible())
                self.assertTrue(other.left.isEnabled())
                other.operation('add');self.assertEqual(other.session.cup_operation,'add')
            finally:
                from PyQt6 import sip
                other.close();sip.delete(other)
