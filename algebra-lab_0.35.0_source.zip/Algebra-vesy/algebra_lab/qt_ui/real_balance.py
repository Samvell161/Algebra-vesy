"""Native touch container and controller for the genuine 3D workshop."""
import math
import os
import platform
from PyQt6.QtCore import Qt,QTimer
from PyQt6.QtGui import QSurfaceFormat,QPainter,QColor
from PyQt6.QtWidgets import QApplication,QWidget,QLabel,QPushButton
from .balance import Balance
from .workshop_clock import WorkshopClock
from .scene3d.physics import CupMotion3D


class SceneClock(WorkshopClock):
    def _tick(self):
        from PyQt6.QtCore import QTime
        if QApplication.activeModalWidget() is not None:return
        from .scene3d.room_light import owl_openness
        now=QTime.currentTime();phase=self._elapsed.elapsed()/1000
        key=(now.hour(),now.minute(),round(owl_openness(phase),3))
        if key==getattr(self,'_last_ambient_frame',None):return
        self._last_ambient_frame=key;self._time=now;self._phase=phase
        if getattr(self._owner,'surface',None) is not None:self._owner.surface.update()



class RealBalance(Balance):
    """Same lesson/control contract; rendering and contacts use an XYZ scene."""
    is_3d=True
    CONTROL_HEIGHT=52

    def __init__(self,parent=None):
        super().__init__(parent,cup_factory=CupMotion3D,clock_factory=SceneClock)
        self._timer.setInterval(33)
        self._context_check=QTimer(self);self._context_check.setSingleShot(True)
        self._context_check.timeout.connect(self._check_context)
        self.surface=None;self.container=None;self.graphics_error=None;self._scene_loaded=False
        self.status=QLabel('Строю трёхмерную мастерскую…',self)
        self.status.setWordWrap(True);self.status.setStyleSheet('background:#fff5df;color:#47685f;border-radius:12px;padding:12px;font-size:18px;')
        try:
            from .scene3d.renderer import SceneSurface
            self.surface=SceneSurface(self)
            fmt=QSurfaceFormat();gles=os.environ.get('ALGEBRA_GL_API')=='gles' or platform.machine().lower().startswith(('arm','aarch'))
            fmt.setRenderableType(QSurfaceFormat.RenderableType.OpenGLES if gles else QSurfaceFormat.RenderableType.OpenGL)
            fmt.setVersion(2,0 if gles else 1);fmt.setDepthBufferSize(24);fmt.setSamples(2)
            self.surface.setFormat(fmt);self.surface.ready.connect(self._scene_ready,Qt.ConnectionType.QueuedConnection);self.surface.failed.connect(self._graphics_failed,Qt.ConnectionType.QueuedConnection)
            self.container=QWidget.createWindowContainer(self.surface,self)
            self.container.setAccessibleName('Трёхмерная мастерская')
        except ImportError as exc:self._graphics_failed('Не установлена 3D-библиотека: '+str(exc))
        self.setAccessibleName('Алгебраические весы · настоящая 3D-сцена')

    def set_ambient(self,enabled):
        previous=getattr(self,'_ambient',True)
        super().set_ambient(enabled)
        if previous!=bool(enabled):self._invalidate()

    def set_lamp(self,enabled):
        if self.surface is not None:
            enabled=bool(enabled)
            if self.surface.lamp_enabled!=enabled:
                self.surface.lamp_enabled=enabled;self._invalidate()

    def set_quality(self,key):
        from .scene3d.quality import quality
        profile=quality(key)
        self.clock._timer.setInterval(profile.ambient_ms)
        if self.surface is not None:self.surface.set_quality(profile.key)

    def _graphics_failed(self,message):
        self.graphics_error=message
        if self.container is not None:self.container.hide()
        self.status.setText(message+'\nПроверьте драйвер OpenGL и зависимости приложения. Совместимый вид можно запустить с --software-view.')
        self._layout_surface();self.status.show();self.status.raise_()

    def _scene_ready(self):
        self._scene_loaded=True;self.status.hide();self._layout_surface()
        for button in self.findChildren(QPushButton):button.update()
        self.update()

    def _geometry(self):return 1.,1000.,360.,235.,235*math.sin(math.radians(10))

    def _invalidate(self):
        if getattr(self,'surface',None) is not None:self.surface.update()
        self.update()

    def _layout_surface(self):
        loading=48 if not self._scene_loaded and not self.graphics_error else 0
        if self.container is not None:self.container.setGeometry(0,0,self.width(),max(40,self.height()-self.CONTROL_HEIGHT-loading))
        if self.graphics_error:self.status.setGeometry(18,30,max(100,self.width()-36),160)
        else:self.status.setGeometry(14,self.height()-self.CONTROL_HEIGHT-loading,max(100,self.width()-28),44)

    def resizeEvent(self,event):
        self._layout_surface();QWidget.resizeEvent(self,event)

    def paintEvent(self,event):
        painter=QPainter(self);painter.fillRect(self.rect(),QColor('#f6eddb'));painter.end()

    def showEvent(self,event):
        super().showEvent(event)
        self._context_check.start(1200)

    def hideEvent(self,event):
        self._context_check.stop();super().hideEvent(event)

    def _check_context(self):
        if self.isVisible() and self.surface is not None and not self.surface.isValid():
            self._graphics_failed('Не удалось создать контекст OpenGL 2.1 / OpenGL ES 2.0.')

    def shutdown(self):
        self._context_check.stop()
        self.stop_animation();self.clock.stop()
        surface=self.surface
        if surface is not None:surface.cleanup()
        if self.container is not None:
            from PyQt6 import sip
            container=self.container;self.container=None
            # Release the native GL window while QApplication and its display
            # connection still exist, before interpreter/module teardown.
            sip.delete(container)
        self.surface=None
