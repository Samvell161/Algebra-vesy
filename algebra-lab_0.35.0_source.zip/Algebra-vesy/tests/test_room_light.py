"""Contact fields are soft, world anchored and shareable between GL profiles."""
import unittest
from algebra_lab.qt_ui.scene3d.room_light import Contact,bake_contacts,owl_openness,FLOOR_BOUNDS,WALL_BOUNDS

class ContactLightingTests(unittest.TestCase):
    def sample(self,data,plane,x,y,w=512,h=256):
        x0,x1,y0,y1=FLOOR_BOUNDS if plane=='floor' else WALL_BOUNDS
        px=min(w-1,max(0,int((x-x0)/(x1-x0)*w)));py=min(h-1,max(0,int((y-y0)/(y1-y0)*h)))
        return data[(py*w+px)*4+(0 if plane=='floor' else 1)]

    def test_ground_contact_has_a_soft_falloff_instead_of_a_hard_disc(self):
        data=bake_contacts((Contact('floor',0,0,.18,.18,.16,.40,True),))
        values=[self.sample(data,'floor',x,0) for x in [0,.16,.23,.31,.42,.62]]
        self.assertGreater(values[0],90);self.assertLess(values[-1],2)
        self.assertEqual(values,sorted(values,reverse=True))
        self.assertGreater(len(set(values)),4)

    def test_wall_and_ground_channels_are_independent(self):
        data=bake_contacts((Contact('wall',.65,1.29,.29,.045,.12,.28),))
        self.assertGreater(self.sample(data,'wall',.65,1.29),60)
        self.assertEqual(self.sample(data,'floor',.65,1.29),0)
        self.assertEqual(self.sample(data,'wall',-4,4),0)

    def test_unchanged_contacts_reuse_the_bake_and_clamp_strength(self):
        contacts=(Contact('floor',1,1,.05,.05,.1,.5),)
        a=bake_contacts(contacts);b=bake_contacts(contacts)
        self.assertIs(a,b);self.assertEqual(len(a),512*256*4)
        self.assertLessEqual(max(a[0::4]),128)

    def test_one_brief_blink_leaves_long_quiet_intervals(self):
        self.assertEqual(owl_openness(0),1);self.assertEqual(owl_openness(5.9),1)
        self.assertLess(owl_openness(6.16),.05);self.assertEqual(owl_openness(6.4),1)
        self.assertEqual(owl_openness(8.9),1)
        self.assertAlmostEqual(owl_openness(6.08),owl_openness(6.24),places=5)
