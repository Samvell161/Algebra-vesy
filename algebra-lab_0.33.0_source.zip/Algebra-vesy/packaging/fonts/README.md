# Algebra Rounded — Raspberry Pi UI, 0.26+

The active UI family is a readable sans serif derived from Google Fonts **Nunito**, with static Regular (400) and Bold (700) faces. Derivatives are named **Algebra Rounded**, include Cyrillic, digits and mathematical symbols, and are bundled locally as `AlgebraRounded-Regular.ttf` and `AlgebraRounded-Bold.ttf`. The plain body text uses Regular; buttons, headings and block labels use Bold. No font download or fontTools dependency is needed at runtime. Android keeps its existing typography.

Source: https://raw.githubusercontent.com/google/fonts/main/ofl/nunito/Nunito%5Bwght%5D.ttf
Source SHA-256: bb55a5ca5c2042335b3991af27c4d0705d0ef41cac6164ac737fd8f2a1e85207
Retrieved 2026-10-30 over verified HTTPS. Original source: `Nunito-source.ttf`. Copyright 2014 The Nunito Project Authors. License: SIL Open Font License 1.1, retained in `OFL.txt` and the font name records. The Pi DEB ships these two static TTF files and the Nunito OFL notice.

Regenerate with `python3 scripts/build_fonts.py` (development-only fontTools). The script preserves hinting, shaping and kerning, sets the derivative family names, and checks Cyrillic including Ё/ё and classroom operators. The extracted DEB check verifies the actual selected Qt font and glyph coverage.

## Former family, retained in source

Versions 0.23–0.25 used **Algebra Compass**, derived from Google Fonts Comfortaa, weights Medium (500) and Bold (700). Comfortaa reserves its name, so the derivative was renamed. Source: https://raw.githubusercontent.com/google/fonts/main/ofl/comfortaa/Comfortaa%5Bwght%5D.ttf
Source SHA-256: 0fc3f45dc48b614db9c39181502544b37217ecbf8bee2fb35886992bc96c5bd3
Retrieved 2026-11-05. `Comfortaa-source.ttf`, `AlgebraCompass-*.ttf` and `Comfortaa-OFL.txt` remain in source history; they are not installed by 0.26. Regenerate with `python3 scripts/build_fonts.py --family compass`.
