import math
import unittest
from algebra_lab.qt_ui.scene3d.physics import CupMotion3D,DEPTH
from algebra_lab.qt_ui.cube_motion import inner_depth,DEPTH_SCALE

class WorldContactTests(unittest.TestCase):
    def test_four_bottom_corners_respect_radial_bowl_in_xyz(self):
        cup=CupMotion3D();cup.target(['x','1','1','1'],True)
        for frame in range(160):
            cup.step(1/120,pan_acceleration=math.sin(frame/15)*300,lateral_acceleration=math.cos(frame/20)*120)
            for body in cup.bodies:
                for x,y,delta_z in cup.bottom_corners(body):
                    floor=inner_depth(math.hypot(x,y),cup.radius)/DEPTH_SCALE
                    self.assertLessEqual(body.y-delta_z,floor+1e-7)
        cup.finish()
        self.assertTrue(any(b.depth!=0 for b in cup.bodies))
        for body in cup.bodies:self.assertAlmostEqual(body.y,cup.support(body)[0],places=6)

    def test_earth_gravity_and_depth_response_are_simulated(self):
        cup=CupMotion3D();cup.target(['1','1'],True)
        self.assertEqual(cup.gravity,981)
        body=cup.bodies[0];start_y=body.y
        cup.step(.05)
        self.assertGreater(body.y,start_y)
        self.assertNotEqual(body.depth,0)
        self.assertNotEqual(body.depth_velocity,0)
        self.assertLess(abs(body.depth),DEPTH)

    def test_stack_and_rapid_edits_stabilise_without_floor_penetration(self):
        cup=CupMotion3D()
        for values in [['1']*4,['1']*5,['x','1'],['1']*5]:
            cup.target(values,True)
            for _ in range(5):cup.step(.02)
        for _ in range(150):cup.step(.01)
        cup.finish()
        self.assertEqual(len(cup.bodies),5)
        top=next(b for b in cup.bodies if b.row)
        self.assertLess(top.y,0)
        for body in cup.bodies:
            self.assertAlmostEqual(body.y,cup.support(body)[0])
            self.assertEqual(body.vy,0);self.assertEqual(body.depth_velocity,0)

