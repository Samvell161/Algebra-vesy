"""Exercise the production QSS and font at the actual touch-screen size."""
import tempfile
import unittest
from functools import partial
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtGui import QFontDatabase
    from algebra_lab.qt_ui.app import Window as AppWindow
    Window=partial(AppWindow,software_view=True)
    from algebra_lab.adventure import ADVENTURE_TASKS
except ImportError:
    QApplication=None

ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(QApplication,'Qt development dependencies required')
class WorkshopLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        for path in (ROOT/'packaging/fonts').glob('*.ttf'):
            QFontDatabase.addApplicationFont(str(path))

    def setUp(self):
        self.old_style=self.app.styleSheet()
        self.app.setStyleSheet((ROOT/'algebra_lab/qt_ui/theme.qss').read_text())
        self.tmp=tempfile.TemporaryDirectory();self.window=Window(Path(self.tmp.name))
        self.window.show();self.app.processEvents()

    def tearDown(self):
        self.window.close();self.app.setStyleSheet(self.old_style);self.tmp.cleanup()

    def assert_touch_layout(self):
        w=self.window
        self.assertEqual((w.width(),w.height()),(1024,600))
        for button in w.centralWidget().findChildren(QPushButton):
            if not button.isVisible():continue
            self.assertIsNotNone(button.graphicsEffect(),button.text())
            self.assertGreaterEqual(button.height(),44,button.text())
            self.assertGreaterEqual(button.width(),44,button.text())
            position=button.mapTo(w.centralWidget(),button.rect().topLeft())
            bottom=button.mapTo(w.centralWidget(),button.rect().bottomRight())
            self.assertTrue(w.centralWidget().rect().contains(position),button.text())
            self.assertTrue(w.centralWidget().rect().contains(bottom),button.text())

    def test_taller_scene_keeps_touch_targets_and_narrows_balance(self):
        w=self.window;w.start('cups-4');self.app.processEvents()
        self.assert_touch_layout()
        self.assertGreaterEqual(w.board.height(),340)
        scale,_,_,arm,_=w.board._geometry()
        self.assertLessEqual(2*arm*scale,w.board.width()*.51)
        self.assertIs(w.left.parent(),w.board)
        self.assertIs(w.right.parent(),w.board)
        w.board.grab()
        for start,end in w.board.attachments:
            self.assertGreater(end.y()-start.y(),w.board.height()*.30)
        frame=w.board._stage.cacheKey();w.board.grab()
        self.assertEqual(w.board._stage.cacheKey(),frame)

    def test_all_lesson_titles_and_answer_controls_fit_without_clipping(self):
        w=self.window
        for lesson in ADVENTURE_TASKS:
            with self.subTest(lesson=lesson['id']):
                w.start(lesson['id']);self.app.processEvents();self.assert_touch_layout()
                self.assertGreaterEqual(w.board.height(),320)
                self.assertEqual(w.condition.text(),lesson['equation'])
        w.start('cups-4');w.store.bind('BB','2');w.operation('remove')
        for side in ['left','right']:w.scan({'uid':'BB','source':side})
        self.app.processEvents();self.assert_touch_layout()
        self.assertTrue(w.answers.isVisible())
        self.assertGreaterEqual(w.board.height(),280)
        w.session.cup_guess=2;w.check();self.app.processEvents();self.assert_touch_layout()
        self.assertTrue(w.session.completed)
