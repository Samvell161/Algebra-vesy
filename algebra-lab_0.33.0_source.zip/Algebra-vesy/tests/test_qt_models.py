"""Registration of the rendered block with its physical foot and shadow plane."""
import unittest

try:
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.block_model import block_geometry
    from algebra_lab.qt_ui.solids import project
except ImportError:
    QApplication = None


@unittest.skipUnless(QApplication, 'Qt development dependencies required')
class BlockModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_rounded_geometry_fits_sprite_and_foot_stays_on_physical_support(self):
        for width in [52, 150, 220]:
            geometry = block_geometry(width)
            foot = -geometry.sprite_top
            projected = [project(v, (width / 2 + 2, foot - geometry.bottom))
                         for vertices, _ in geometry.faces for v in vertices]
            self.assertGreaterEqual(min(v.x() for v in projected), 1)
            self.assertLessEqual(max(v.x() for v in projected), width + 3)
            self.assertGreater(min(v.y() for v in projected), 0)
            self.assertAlmostEqual(max(v.y() for v in projected), foot)
            self.assertLess(max(v.y() for v in projected), foot + 5)
            self.assertTrue(all(v.y < -50 for v in
                                [geometry.top.elementAt(i) for i in range(geometry.top.elementCount())]))

    def test_sprites_and_geometry_are_reused_without_losing_label_identity(self):
        from algebra_lab.qt_ui.balance import Balance
        board = Balance()
        try:
            for scale in [.55, 1.0, 1.1]:
                for label, width in [('x', 52), ('−1', 52), ('1/2', 220)]:
                    sprite = board._block_sprite(label, width, scale)
                    self.assertFalse(sprite.isNull())
                    self.assertEqual(sprite.cacheKey(), board._block_sprite(label, width, scale).cacheKey())
            self.assertNotEqual(board._block_sprite('x', 52, 1).cacheKey(),
                                board._block_sprite('1', 52, 1).cacheKey())
            self.assertIs(block_geometry(52), block_geometry(52))
        finally:
            board.close()
