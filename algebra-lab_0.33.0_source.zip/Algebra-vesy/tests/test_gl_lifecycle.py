"""A separate process must leave the real Qt/GL event loop cleanly."""
import os
import subprocess
import sys
import unittest

@unittest.skipUnless(os.environ.get('ALGEBRA_TEST_GL')=='1','An actual GL display is required')
class ApplicationExitTests(unittest.TestCase):
    def test_real_application_closes_during_physics_in_separate_processes(self):
        code='''
import sys,tempfile
sys.modules['numpy']=None
from unittest.mock import patch
from PyQt6.QtCore import QTimer
from algebra_lab.qt_ui.app import Window,main
original=Window.showFullScreen
state={'ready':False}
def display(w):
    original(w);w.start('cups-4')
    poll=QTimer(w);poll.setInterval(50)
    deadline=QTimer(w);deadline.setSingleShot(True)
    close=QTimer(w);close.setSingleShot(True)
    def finish():poll.stop();deadline.stop();w.close()
    close.timeout.connect(finish);deadline.timeout.connect(finish)
    def tick():
        if w.board.graphics_error:finish()
        elif w.board.surface is not None and w.board.surface.frames:
            state['ready']=True;poll.stop();deadline.stop()
            w.store.bind('A1','1');w.operation('add');w.scan({'uid':'A1','source':'left'})
            close.start(100)
    poll.timeout.connect(tick);poll.start();deadline.start(15000)
with tempfile.TemporaryDirectory() as path,patch.object(Window,'showFullScreen',display):
    assert main(['--data-dir',path])==0
assert state['ready']
print('Clean 3D application exit')
'''
        env=dict(os.environ);env.pop('ALGEBRA_VIEW',None)
        for _ in range(2):
            result=subprocess.run([sys.executable,'-X','faulthandler','-c',code],env=env,capture_output=True,text=True,timeout=40)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('Clean 3D application exit',result.stdout)
