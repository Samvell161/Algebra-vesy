import math
import unittest
from fractions import Fraction
from algebra_lab.qt_ui.balance_motion import MAX_TILT,ANGLE_STOP,tilt_for_difference,step_beam


class BalanceMotionTests(unittest.TestCase):
    def test_difference_controls_magnitude_direction_and_fractional_steps(self):
        for difference,angle in [(0,0),(Fraction(1,2),1),(1,1.8),(2,3),(4,4.5),(8,6)]:
            self.assertAlmostEqual(tilt_for_difference(difference),angle)
            self.assertAlmostEqual(tilt_for_difference(-difference),-angle)
        angles=[tilt_for_difference(Fraction(i,10)) for i in range(300)]
        self.assertTrue(all(a<b for a,b in zip(angles,angles[1:])))
        self.assertGreater(tilt_for_difference(Fraction(1,10**6)),0)
        self.assertLess(tilt_for_difference(Fraction(1,10**6)),.001)

    def test_huge_values_stay_finite_without_float_overflow(self):
        for difference in [10**1000,-10**1000,Fraction(10**2000,3)]:
            angle=tilt_for_difference(difference)
            self.assertTrue(math.isfinite(angle))
            self.assertLessEqual(abs(angle),MAX_TILT)
            self.assertEqual(angle>0,difference>0)

    def test_spring_settles_and_retargets_without_jumps_or_running_past_stop(self):
        for load in [0,4,10]:
            angle=velocity=0
            for target in [9,-9,1.8,0]:
                initial=angle
                angle,velocity=step_beam(angle,velocity,target,1/120,load)
                self.assertLess(abs(angle-initial),.5)
                for _ in range(240):
                    angle,velocity=step_beam(angle,velocity,target,1/120,load)
                    self.assertLessEqual(abs(angle),ANGLE_STOP)
                self.assertAlmostEqual(angle,target,places=3)
                self.assertLess(abs(velocity),.005)

    def test_loaded_beam_has_more_inertia(self):
        responses=[]
        for load in [0,10]:
            angle=velocity=0
            for _ in range(12):angle,velocity=step_beam(angle,velocity,6,1/120,load)
            responses.append(angle)
        self.assertGreater(responses[0],responses[1])
