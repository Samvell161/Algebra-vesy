import tempfile
import unittest
from functools import partial
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.app import Window as AppWindow
    Window=partial(AppWindow,software_view=True)
except ImportError:
    QApplication = None

@unittest.skipUnless(QApplication, 'Qt dependencies required')
class OriginalEquationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def test_rfid_one_and_two_unit_changes_produce_distinct_signed_angles(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.bind('AA','1');w.store.bind('BB','2');w.start('cups-4')
                w.operation('add');w.scan({'uid':'AA','source':'left'})
                self.assertAlmostEqual(w.board.tilt,-1.8)
                w.undo();self.assertEqual(w.board.tilt,0)
                w.operation('add');w.scan({'uid':'BB','source':'left'})
                self.assertAlmostEqual(w.board.tilt,-3)
                w.scan({'uid':'BB','source':'right'})
                self.assertEqual(w.board.tilt,0)
                self.assertEqual(w.condition.text(),'x + 2 = 4')
                w.operation('remove');w.scan({'uid':'AA','source':'left'})
                self.assertAlmostEqual(w.board.tilt,1.8)
                w.store.bind('CC','x');w.start('duet-5');w.operation('remove')
                w.scan({'uid':'CC','source':'left'})
                self.assertAlmostEqual(w.board.tilt,5.4)
                w.scan({'uid':'CC','source':'right'})
                self.assertEqual(w.board.tilt,0)
            finally:w.close()

    def test_original_stays_for_partial_pair_complete_pair_undo_and_answer(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.bind('AA','1');w.store.bind('BB','2')
                w.start('cups-4')
                original=w.condition.text()
                for op in ['add','remove']:
                    w.operation(op)
                    w.scan({'uid':'AA','source':'left'})
                    self.assertEqual(w.condition.text(),original)
                    w.scan({'uid':'AA','source':'right'})
                    self.assertEqual(w.condition.text(),original)
                    self.assertNotEqual(str(w.session.current.left)+' = '+str(w.session.current.right),original)
                    w.undo();self.assertEqual(w.condition.text(),original)
                w.operation('remove')
                for side in ['left','right']:w.scan({'uid':'BB','source':side})
                w.session.cup_guess=2;w.check()
                self.assertTrue(w.session.completed)
                self.assertEqual(w.condition.text(),original)
                w.start('cups-2')
                self.assertNotEqual(w.condition.text(),original)
            finally:w.close()

    def test_pending_preview_prompt_can_cancel_or_continue_after_restart(self):
        from unittest.mock import patch
        from PyQt6.QtWidgets import QMessageBox
        for choice in [QMessageBox.StandardButton.Yes,QMessageBox.StandardButton.No]:
            with self.subTest(choice=choice),tempfile.TemporaryDirectory() as tmp:
                data=Path(tmp);w=Window(data);w.start('cups-4');w.store.bind('AA','1');w.operation('remove')
                w.scan({'uid':'AA','source':'left'});w.close()
                with patch.object(QMessageBox,'question',return_value=choice) as question:
                    resumed=Window(data);resumed.show();self.app.processEvents()
                    try:
                        question.assert_called_once()
                        pending=resumed.service.cup_state(resumed.session)['pending']
                        self.assertEqual(pending,choice==QMessageBox.StandardButton.Yes)
                        self.assertEqual(len(resumed.session.history),1)
                    finally:resumed.close()

    def test_manual_backup_and_restore_from_qt_controls(self):
        from unittest.mock import patch
        from PyQt6.QtWidgets import QFileDialog,QMessageBox
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp);w=Window(data);w.start('cups-4');w.store.bind('AA','1')
            copy=data/'copy.sqlite3'
            try:
                with patch.object(QFileDialog,'getSaveFileName',return_value=(str(copy),'')),patch.object(QMessageBox,'information'):
                    w.make_backup()
                w.store.bind('BB','2')
                with patch.object(QFileDialog,'getOpenFileName',return_value=(str(copy),'')),patch.object(QMessageBox,'question',return_value=QMessageBox.StandardButton.Yes):
                    w.load_backup()
                self.assertEqual(w.store.tags(),{'AA':'1'})
                self.assertTrue((data/'before-restore.sqlite3').exists())
                self.assertEqual(w.session.task_id,'cups-4')
            finally:w.close()

    def test_profile_switch_retains_pending_step_and_distinct_progress(self):
        from unittest.mock import patch
        from PyQt6.QtWidgets import QMessageBox
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.bind('AA','1');w.start('cups-4');w.operation('remove')
                w.scan({'uid':'AA','source':'left'})
                other=w.store.create_profile('Саша')
                w.switch_profile(other)
                self.assertFalse(w.service.cup_state(w.session)['pending'])
                self.assertEqual(w.session.task_id,'cups-1')
                w.store.record('child-two','cups-1','practice',1,0,1)
                with patch.object(QMessageBox,'question',return_value=QMessageBox.StandardButton.Yes):
                    w.switch_profile('default');self.app.processEvents()
                self.assertTrue(w.service.cup_state(w.session)['pending'])
                self.assertEqual(w.session.task_id,'cups-4')
                self.assertEqual(w.store.progress()['completed'],0)
                self.assertEqual(w.store.tags(),{'AA':'1'})
            finally:w.close()

    def test_jury_demo_uses_real_math_without_real_xp_and_restores_child(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));real=w.store
            try:
                w.store.bind('AA','1');w.store.bind('BB','2');w.start('cups-4');w.operation('remove')
                w.scan({'uid':'AA','source':'left'})
                child=w.session;before=real.progress()
                with patch.object(w,'show_script'):w.begin_demo()
                self.assertTrue(w.demonstration)
                self.assertEqual(w.xp.text(),'ПОКАЗ')
                w.operation('remove');w.scan({'uid':'BB','source':'left'})
                self.assertIn('2/5',w.heading.text())
                w.scan({'uid':'BB','source':'right'})
                self.assertEqual(w.session.cup_phase,'answer')
                self.assertFalse(w.session.completed)
                w.session.cup_guess=2;w.check()
                self.assertTrue(w.session.completed)
                self.assertIn('5/5',w.heading.text())
                w.scan({'uid':'BB','source':'left'})
                self.assertTrue(w.session.completed)
                self.assertEqual(real.progress(),before)
                started=child.started
                with patch("algebra_lab.qt_ui.app.time.monotonic",return_value=w.demo_started+120):w.end_demo()
                self.assertAlmostEqual(child.started,started+120)
                self.assertIs(w.store,real);self.assertIs(w.session,child)
                self.assertTrue(w.service.cup_state(w.session)['pending'])
                self.assertEqual(w.store.progress(),before)
            finally:w.close()

    def test_closing_during_demo_saves_child_not_presentation(self):
        from unittest.mock import patch
        from algebra_lab.storage import Store
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp);w=Window(data);w.start('cups-3')
            with patch.object(w,'show_script'):w.begin_demo()
            w.close()
            store=Store(data/'algebra.sqlite3')
            try:
                self.assertEqual(store.settings()['practice_session']['task_id'],'cups-3')
                self.assertEqual(store.progress()['completed'],0)
            finally:store.close()

    def test_phone_access_dialog_does_not_change_child_or_profile(self):
        from PyQt6.QtCore import QTimer
        from PyQt6.QtWidgets import QApplication,QPushButton
        from algebra_lab.mobile import ProgressHub
        import time
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.start('cups-4')
            w.mobile=ProgressHub(Path(tmp),host='127.0.0.1',port=0,discovery_port=0)
            w.mobile.start()
            for _ in range(100):
                if w.mobile.running:break
                time.sleep(.01)
            self.assertTrue(w.mobile.running)
            before=w.session.current;profile=w.store.profile_id
            def choose():
                dialog=QApplication.activeModalWidget()
                for button in dialog.findChildren(QPushButton):
                    if button.text().startswith('Включить доступ'):button.click()
                    if button.text().startswith('Получить новый код'):button.click()
                dialog.accept()
            try:
                QTimer.singleShot(0,choose);w.mobile_access()
                self.assertEqual(len(w.mobile.status()['code']),6)
                self.assertTrue(w.store.settings()['mobile_enabled'])
                self.assertEqual(w.session.current,before)
                other=w.store.create_profile('Саша');w.store.select_profile(other)
                self.assertTrue(w.store.settings()['mobile_enabled'])
                w.store.select_profile(profile)
            finally:w.close()

    def test_phone_lesson_waits_for_completion_and_needs_child_acceptance(self):
        from unittest.mock import patch
        from algebra_lab import lesson_queue as queue
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.store.record('unlock','cups-1','practice',1,0,1)
            w.store.save_settings({'mobile_lessons_enabled':True});w.store.bind('BB','2');w.start('cups-4')
            try:
                with patch.object(w.mobile,'running',True):
                    queue.submit(w.store.db,'a'*32,'default','cups-3');w.mobile.requests_changed.set()
                    before=w.session.current;w.check_remote()
                    self.assertEqual(w.session.task_id,'cups-4');self.assertEqual(w.session.current,before)
                    self.assertTrue(w.remote_bar.isHidden())
                    w.operation('remove')
                    for side in ['left','right']:w.scan({'uid':'BB','source':side})
                    w.session.cup_guess=2;w.check();w.check_remote()
                    self.assertFalse(w.remote_bar.isHidden())
                    self.assertEqual(w.session.task_id,'cups-4')
                    w.respond_remote('accepted')
                    self.assertEqual(w.session.task_id,'cups-3');self.assertFalse(w.session.completed)
                    self.assertEqual(queue.latest(w.store.db,'default')['state'],'accepted')
                    self.assertTrue(w.remote_bar.isHidden())
                    queue.submit(w.store.db,'a'*32,'default','cups-3')
                    self.assertIsNone(queue.pending(w.store.db,'default'))
            finally:w.close()

    def test_proposal_for_other_profile_or_during_demo_does_not_interrupt(self):
        from unittest.mock import patch
        from algebra_lab import lesson_queue as queue
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.store.save_settings({'mobile_lessons_enabled':True})
            other=w.store.create_profile('Саша');queue.submit(w.store.db,'b'*32,other,'cups-1')
            try:
                with patch.object(w.mobile,'running',True):
                    w.session.completed=True;w.check_remote()
                    self.assertTrue(w.remote_bar.isHidden())
                    w.start('cups-4')
                    with patch.object(w,'show_script'):w.begin_demo()
                    w.check_remote();self.assertTrue(w.remote_bar.isHidden())
                    self.assertEqual(queue.latest(w.saved_workspace[0].db,other)['state'],'pending')
                    w.end_demo()
            finally:w.close()

    def test_motion_toggle_is_touch_accessible_persists_and_keeps_math_working(self):
        from PyQt6.QtCore import QTimer
        from PyQt6.QtWidgets import QPushButton
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.show();self.app.processEvents()
            try:
                def turn_off():
                    dialog=QApplication.activeModalWidget()
                    button=next(b for b in dialog.findChildren(QPushButton) if b.text().startswith('Анимации:'))
                    button.click();dialog.accept()
                QTimer.singleShot(0,turn_off);w.visual_settings()
                self.assertFalse(w.store.settings()['motion'])
                self.assertFalse(w.board._motion)
                w.start('cups-4');w.store.bind('BB','2');w.operation('remove')
                for side in ['left','right']:w.scan({'uid':'BB','source':side})
                self.assertEqual(w.session.cup_phase,'answer')
                w.session.cup_guess=2;w.check()
                self.assertTrue(w.session.completed);self.assertFalse(w.board.is_animating)
                self.assertEqual(w.condition.text(),'x + 2 = 4')
                from unittest.mock import patch
                with patch.object(w,'show_script'):
                    w.begin_demo()
                self.assertFalse(w.board._motion)
                w.end_demo()
            finally:w.close()
            reopened=Window(Path(tmp))
            try:
                self.assertFalse(reopened.board._motion)
                self.assertIn('cups-4',reopened.store.progress()['best'])
            finally:reopened.close()

    def test_hardware_actions_are_processed_while_balance_is_moving(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.show();self.app.processEvents()
            try:
                w.start('cups-4');w.store.bind('BB','2');w.operation('remove')
                w.reader.emit({'uid':'BB','source':'left'});w.poll()
                self.assertTrue(w.board.is_animating)
                w.reader.emit({'uid':'BB','source':'right'});w.poll()
                self.assertEqual(w.session.cup_phase,'answer')
                self.assertFalse(w.session.completed)
                self.assertEqual(w.condition.text(),'x + 2 = 4')
                w.session.cup_guess=2;w.check()
                self.assertTrue(w.session.completed)
            finally:w.close()

    def test_clock_preference_is_separate_from_balance_motion_and_per_profile(self):
        from PyQt6.QtCore import QTimer
        from PyQt6.QtWidgets import QPushButton
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp));w.show();self.app.processEvents()
            try:
                def disable_clock():
                    dialog=QApplication.activeModalWidget()
                    button=next(b for b in dialog.findChildren(QPushButton) if b.text().startswith('Фоновые часы:'))
                    button.click();dialog.accept()
                QTimer.singleShot(0,disable_clock);w.visual_settings()
                self.assertFalse(w.store.settings()['ambient_motion'])
                self.assertTrue(w.board._motion);self.assertFalse(w.board.clock.is_running)
                other=w.store.create_profile('Саша');w.switch_profile(other);self.app.processEvents()
                self.assertTrue(w.board.clock.is_running)
                w.switch_profile('default');self.app.processEvents()
                self.assertFalse(w.board.clock.is_running)
            finally:w.close()
            reopened=Window(Path(tmp));reopened.show();self.app.processEvents()
            try:
                self.assertFalse(reopened.board.clock.is_running)
                self.assertTrue(reopened.board._motion)
            finally:reopened.close()
