"""A software-rendered 3D balance with cached solids and finite lesson animations.

The scene and block sprites are cached. No OpenGL context, blur filters, or equipment/model work happens here.
The ambient clock updates a clipped room region behind the foreground solids.
"""
import math
from collections import Counter, OrderedDict
from PyQt6.QtCore import Qt, QRectF, QPointF, QTimer, QElapsedTimer
from PyQt6.QtGui import (QColor, QPainter, QPen, QBrush, QFont, QPainterPath,
                        QLinearGradient, QRadialGradient, QPixmap, QPolygonF)
from PyQt6.QtWidgets import QWidget, QSizePolicy
from .workshop import draw_workshop
from .solids import draw_mesh,plinth,cylinder,bowl,lathe,COS
from .workshop_clock import WorkshopClock
from .cube_motion import CupMotion,HEIGHT
from .scene_shadows import cast_solids,soft_path
from .block_model import block_geometry
from .balance_motion import MAX_TILT,step_beam
from PyQt6.QtGui import QTransform

INK = '#343360'


def gradient(y, height, light, dark):
    value = QLinearGradient(0, y, 0, y + height)
    value.setColorAt(0, QColor(light)); value.setColorAt(1, QColor(dark))
    return QBrush(value)


def polygon(p, points, brush, pen=Qt.PenStyle.NoPen):
    p.setPen(pen); p.setBrush(brush)
    p.drawPolygon(QPolygonF([QPointF(x, y) for x, y in points]))


def soft_shadow(p,x,y,rx,ry,opacity=68):
    """A local contact shadow, baked with the room; no per-widget blur effect."""
    p.save();p.translate(x,y);p.scale(rx,ry)
    brush=QRadialGradient(0,0,1)
    brush.setColorAt(0,QColor(49,37,27,opacity))
    brush.setColorAt(.18,QColor(49,37,27,round(opacity*.94)))
    brush.setColorAt(.65,QColor(49,37,27,round(opacity*.45)))
    brush.setColorAt(1,QColor(49,37,27,0))
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QBrush(brush))
    p.drawEllipse(QRectF(-1,-1,2,2));p.restore()


class Balance(QWidget):
    DURATION = 1200
    CELEBRATION_DURATION = 680

    def __init__(self, parent=None, cup_factory=CupMotion, clock_factory=WorkshopClock):
        super().__init__(parent)
        self.left, self.right, self.tilt = [], [], 0
        self._angle = 0.0
        self._start_angle = 0.0
        self._angular_velocity=0.0
        self._last_step=0
        self._cups=[cup_factory(),cup_factory()]
        self._progress = 1.0
        self._old = ([], [])
        self._motion = True
        self._initialized = False
        self._cache = self._stage = self._support = self._ground = self._shadows = None
        self._cache_key = self._stage_key = None
        self._shadow_key = None
        self._sprites = OrderedDict()
        self._parts = OrderedDict()
        self._ambient = True
        self.clock = clock_factory(self)
        self._clock = QElapsedTimer()
        self._celebration = QElapsedTimer()
        self._timer = QTimer(self)
        self._timer.setInterval(20)  # At most 50 frames/s, only during an action.
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self.attachments = []
        self.setMinimumSize(400, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAccessibleName('Алгебраические весы')

    @property
    def is_animating(self):
        return self._timer.isActive()

    def set_motion(self, enabled):
        if self._motion == bool(enabled):
            return
        self._motion = bool(enabled)
        self.clock.set_motion(self._motion and self._ambient)
        if not self._motion:
            self.stop_animation()

    def set_ambient(self,enabled):
        self._ambient=bool(enabled)
        self.clock.set_motion(self._motion and self._ambient)

    def resizeEvent(self,event):
        width=max(34,min(58,round(self.height()*.16)))
        self.clock.setGeometry(round(self.width()*.20-width/2),round(self.height()*.025),width,round(width*1.43))
        super().resizeEvent(event)

    def set_blocks(self, left, right, tilt=0):
        left, right = list(left), list(right)
        tilt = max(-MAX_TILT, min(MAX_TILT, tilt))
        if (left, right, tilt) == (self.left, self.right, self.tilt):
            return
        self._old = (self.left[:], self.right[:])
        animated=self._motion and self.isVisible() and self._initialized
        self._cups[0].target(left,animated);self._cups[1].target(right,animated)
        self._start_angle = self._angle
        self.left, self.right, self.tilt = left, right, tilt
        self.setAccessibleDescription('Левая чаша: %s. Правая чаша: %s.' %
                                      (', '.join(map(str, left)) or 'пусто', ', '.join(map(str, right)) or 'пусто'))
        if animated:
            self._last_step=0
            self._progress = 0.0
            self._clock.start(); self._timer.start()
        else:
            self.stop_animation()
        self._initialized = True
        self._invalidate()

    def celebrate(self):
        if self._motion and self.isVisible():
            self._celebration.start(); self._timer.start(); self._invalidate()

    def stop_animation(self):
        self._timer.stop(); self._clock.invalidate(); self._celebration.invalidate()
        self._angle = float(self.tilt); self._angular_velocity=0.0; self._progress = 1.0
        for cup in self._cups:cup.finish()
        self._old = (self.left[:], self.right[:])
        self._invalidate()

    def hideEvent(self, event):
        self.stop_animation()
        super().hideEvent(event)

    def _invalidate(self):
        self._cache_key = None; self.update()

    def _tick(self):
        moving = False
        if self._clock.isValid():
            elapsed=self._clock.elapsed();seconds=min(.10,max(0,(elapsed-self._last_step)/1000))
            self._last_step=elapsed
            remaining=seconds
            _,_,_,arm,_=self._geometry()
            load=sum(not body.removing for cup in self._cups for body in cup.bodies)
            while remaining>0:
                dt=min(1/120,remaining);remaining-=dt
                previous_velocity=self._angular_velocity
                self._angle,self._angular_velocity=step_beam(self._angle,self._angular_velocity,self.tilt,dt,load)
                angle=math.radians(self._angle);velocity=math.radians(self._angular_velocity)
                acceleration=math.radians((self._angular_velocity-previous_velocity)/dt)
                impulse=0
                for direction,cup in zip((-1,1),self._cups):
                    vertical=direction*arm*(math.cos(angle)*acceleration-math.sin(angle)*velocity**2)
                    lateral=-direction*arm*(math.cos(angle)*velocity**2+math.sin(angle)*acceleration)
                    impact=cup.step(dt,pan_acceleration=vertical,lateral_acceleration=lateral)
                    impulse+=direction*min(2.8,impact*.004)/load if load else 0
                self._angular_velocity+=impulse
            self._progress=min(1.0,elapsed/self.DURATION)
            if self._progress>=1:
                self._angle=float(self.tilt);self._angular_velocity=0;self._clock.invalidate()
                self._old=(self.left[:],self.right[:])
                for cup in self._cups:cup.finish()
            else:moving=True
        if self._celebration.isValid():
            if self._celebration.elapsed() >= self.CELEBRATION_DURATION:
                self._celebration.invalidate()
            else:
                moving = True
        if not moving:
            self._timer.stop()
        self._invalidate()

    def _geometry(self):
        scale = min(1.1, self.width()/1000, self.height()/360)
        w, h = self.width()/scale, self.height()/scale
        arm = min(w*.235, 250)
        clearance = arm*math.sin(math.radians(MAX_TILT+1))
        return scale, w, h, arm, clearance

    def paintEvent(self, event):
        ratio = self.devicePixelRatioF()
        key = (self.width(), self.height(), ratio, self.font().family())
        if key != self._stage_key:
            self._stage = QPixmap(round(self.width()*ratio), round(self.height()*ratio))
            self._stage.setDevicePixelRatio(ratio); self._stage.fill(Qt.GlobalColor.transparent)
            p = QPainter(self._stage); p.setRenderHint(QPainter.RenderHint.Antialiasing)
            self._draw_stage(p); p.end(); self._stage_key = key
            self._ground=self._stage.copy();self._ground.fill(Qt.GlobalColor.transparent)
            ground=QPainter(self._ground);ground.setRenderHint(QPainter.RenderHint.Antialiasing)
            self._draw_ground(ground);ground.end()
            self._support=self._stage.copy();self._support.fill(Qt.GlobalColor.transparent)
            support=QPainter(self._support);support.setRenderHint(QPainter.RenderHint.Antialiasing)
            self._draw_support(support);support.end()
            self._cache_key = None
        frame_key = (key, self._angle, self._progress, tuple(self.left), tuple(self.right),
                     self._celebration.elapsed()//33 if self._celebration.isValid() else -1)
        if frame_key != self._cache_key:
            shadow_key=(key,self._angle)
            if shadow_key!=self._shadow_key:
                self._shadows=self._stage.copy();self._shadows.fill(Qt.GlobalColor.transparent)
                shadows=QPainter(self._shadows);shadows.setRenderHint(QPainter.RenderHint.Antialiasing)
                self._draw_pan_shadows(shadows);shadows.end();self._shadow_key=shadow_key
            self._cache = self._stage.copy();self._cache.fill(Qt.GlobalColor.transparent)
            painter = QPainter(self._cache)
            painter.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
            self.draw_balance(painter); painter.end()
            self._cache_key = frame_key
        painter=QPainter(self);painter.drawPixmap(0,0,self._stage)
        self.clock.paint(painter)
        painter.drawPixmap(0,0,self._ground);painter.drawPixmap(0,0,self._shadows)
        painter.drawPixmap(0,0,self._support);painter.drawPixmap(0,0,self._cache);painter.end()

    def _draw_stage(self, p):
        w, h = self.width(), self.height()
        draw_workshop(p,w,h)
        p.setPen(QPen(QColor('#dbc9a9'),1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(1,1,w-2,h-2),24,24)

    def _draw_ground(self,p):
        scale,w,h,arm,clearance=self._geometry()
        p.save();p.scale(scale,scale)
        cx,cy,floor=w/2,max(40,clearance+18),h-30
        p.setClipRect(QRectF(0,h*.80,w,h*.15),Qt.ClipOperation.IntersectClip)
        pivot=(floor-cy)/COS
        cast_solids(p,[plinth(216,90,4,19,'#000000',bevel=4,radius=20),
                       lathe(self._column_profile(pivot),'#000000')],(cx,floor),80,7)
        soft_shadow(p,cx+5,floor+2,122,18,124)
        p.restore()

    def _draw_pan_shadows(self,p):
        scale,w,h,arm,clearance=self._geometry()
        p.save();p.scale(scale,scale)
        radius=min(w*.135,145);floor=h-30;angle=math.radians(self._angle)
        p.setClipRect(QRectF(0,h*.80,w,h*.15),Qt.ClipOperation.IntersectClip)
        pivot=(floor-max(40,clearance+18))/COS
        faces=[]
        for vertices,material in plinth(2*arm,18,-8,16,'#000000',bevel=2,radius=6):
            faces.append(([(vx*math.cos(angle)+vz*math.sin(angle),vy,
                            pivot+vz*math.cos(angle)-vx*math.sin(angle)/COS) for vx,vy,vz in vertices],material))
        cast_solids(p,[faces],(w/2,floor),43,10)
        for direction in [-1,1]:
            x=w/2+direction*arm*math.cos(angle)
            rim=h-110-clearance+direction*arm*math.sin(angle)
            above=max(0,floor-rim-34)
            soft_shadow(p,x+above*.56+8,floor-above*.13+3,radius*.92,22+above*.035,
                        round(max(105,min(140,150-above*.38))))
        p.restore()

    @staticmethod
    def _column_profile(pivot):
        return [(25,35),(24,43),(19,52),(16,67),(14,pivot*.34),(11,pivot*.65),(9,pivot-28),(11,pivot-13),(12,pivot-5)]

    def _draw_support(self,p):
        p.save()
        scale, width, height, arm, clearance = self._geometry()
        p.scale(scale, scale)
        cx, cy, floor = width/2, max(40, clearance+18), height-30
        # All support pieces are level 3D solids on the same horizontal plane.
        # No ellipse/rectangle overlap: the bevels, feet and column share a camera.
        for x in [-77,77]:
            for y in [-27,27]:draw_mesh(p,cylinder(10,0,5,'#514c40',x,y,segments=24),(cx,floor))
        draw_mesh(p,plinth(216,90,4,19,'#c4aa83',bevel=4,radius=20),(cx,floor),finish='wood')
        draw_mesh(p,plinth(207,83,23,5,'#eddbb6',bevel=1.3,radius=18),(cx,floor))
        draw_mesh(p,cylinder(33,28,7,'#dac496',top_radius=29),(cx,floor))
        pivot_z=(floor-cy)/COS
        profile=self._column_profile(pivot_z)
        draw_mesh(p,lathe(profile,'#9dcfc1'),(cx,floor),finish='enamel')
        draw_mesh(p,cylinder(28,35,5,'#ecd9af',top_radius=25),(cx,floor))
        draw_mesh(p,cylinder(17,52,3,'#dfcca6',top_radius=16),(cx,floor))
        draw_mesh(p,cylinder(11,pivot_z-7,8,'#e8d1a2',top_radius=12),(cx,floor))
        p.restore()

    def draw_balance(self, p):
        scale, w, h, arm, clearance = self._geometry()
        p.save();p.scale(scale, scale)
        cx, cy = w/2, max(40, clearance+18)
        radius = min(w*.135, 145)
        # Receiver-plane shadows are composed below the opaque support and cubes.
        p.save();p.translate(cx, cy);p.rotate(self._angle)
        beam=self._part(('beam',arm,scale),round(2*arm+12),42,scale,
            lambda painter:draw_mesh(painter,plinth(2*arm,18,-8,16,'#e5cc9b',bevel=2,radius=6),(arm+6,20)))
        p.drawPixmap(QPointF(-arm-6,-20),beam)
        for x in [-arm, arm]:
            self._orb(p, x, 0, 12, '#e7dcc1', '#a58d64', '#78684f')
            p.setBrush(QColor('#725839'));p.setPen(Qt.PenStyle.NoPen);p.drawEllipse(QPointF(x,2),3,3)
        p.restore()
        radians = math.radians(self._angle)
        self.attachments = []
        for index, (direction, values) in enumerate([(-1,self.left),(1,self.right)]):
            x = cx+direction*arm*math.cos(radians)
            y = cy+direction*arm*math.sin(radians)
            rim = h-110-clearance+direction*arm*math.sin(radians)
            light, middle, dark = ('#b2edf0','#4bbfd0','#278c9f') if index==0 else ('#ffe0c0','#f3977c','#c7705b')
            p.setPen(QPen(QColor('#817965'), 1.6));p.setBrush(gradient(y+8, 18, '#f8f1de','#aaa18b'))
            p.drawEllipse(QRectF(x-6,y+9,12,17))
            for edge in [-1,1]:
                start, end = QPointF(x+edge*3,y+24), QPointF(x+edge*(radius-8),rim+1)
                self.chain(p,start,end,1)
                self.attachments.append((QPointF(start.x()*scale,start.y()*scale),QPointF(end.x()*scale,end.y()*scale)))
            material='#9fd3d2' if index==0 else '#edbca2'
            cup=self._cups[index]
            if cup.radius!=radius:
                cup.radius=radius
                if not self.is_animating:cup.finish()
            for half in ['back','front']:
                part=self._part(('bowl',radius,index,half,scale),round(2*radius+14),100,scale,
                    lambda painter,half=half:draw_mesh(painter,bowl(radius,material,layer=half),(radius+7,35),finish='enamel'))
                p.drawPixmap(QPointF(x-radius-7,rim-35),part)
                if half=='back':self._draw_blocks(p,cup,x,rim,scale)
            for edge in [-1,1]:
                self._orb(p,x+edge*(radius-8),rim+1,4,'#eee4cc','#a39a85','#736b59')
        self._orb(p,cx+3,cy+4,26,'#d8bd8e','#b09261','#92784e')
        self._orb(p,cx,cy,26,'#fff0c7','#d5b77b','#ad905b')
        self._orb(p,cx,cy,12,'#cbebe0','#78ae9d','#4f8c7d')
        p.setPen(QPen(QColor('#e4e4cf'),1.5));p.drawLine(QPointF(cx-4,cy),QPointF(cx+4,cy))
        if self._celebration.isValid():
            self._draw_celebration(p,cx,cy,h)
        p.restore()

    def _part(self,key,width,height,scale,draw):
        ratio=self.devicePixelRatioF()*scale
        key=(key,round(ratio,5))
        if key in self._parts:
            self._parts.move_to_end(key);return self._parts[key]
        image=QPixmap(math.ceil(width*ratio),math.ceil(height*ratio))
        image.setDevicePixelRatio(ratio);image.fill(Qt.GlobalColor.transparent)
        painter=QPainter(image);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        draw(painter);painter.end();self._parts[key]=image
        while len(self._parts)>24:self._parts.popitem(last=False)
        return image

    @staticmethod
    def _orb(p,x,y,r,light,dark,edge):
        g=QRadialGradient(QPointF(x-r*.30,y-r*.40),r*1.45)
        g.setColorAt(0,QColor(light));g.setColorAt(1,QColor(dark))
        p.setPen(QPen(QColor(edge),1.3));p.setBrush(QBrush(g));p.drawEllipse(QPointF(x,y),r,r)

    @staticmethod
    def _items(values):
        return list(map(str, values)) if len(values)<=5 else [' · '.join(map(str,values))]

    @staticmethod
    def _cube_top(body):
        top=block_geometry(body.width,HEIGHT).top
        transform=QTransform();transform.translate(body.x,body.y);transform.rotate(body.roll)
        return transform.map(top)

    def _draw_blocks(self,p,cup,x,rim,scale):
        p.save();p.translate(x,rim)
        bodies=sorted(cup.bodies,key=lambda b:b.row)
        # All well shadows precede the opaque cube faces. They cannot tint a label.
        p.save();well=QPainterPath();well.addEllipse(QRectF(-cup.radius+6,-9,2*cup.radius-12,53))
        p.setClipPath(well,Qt.ClipOperation.IntersectClip)
        for body in bodies:
            if body.removing or body.row:continue
            floor,_=cup.support(body);gap=max(0,floor-body.y)
            opacity=round(max(18,112*(1-min(1,gap/110))))
            footprint=QPainterPath(QPointF(body.x-body.width/2,floor-1))
            footprint.lineTo(body.x+body.width/2,floor-1)
            footprint.lineTo(body.x+body.width/2+20,floor+6)
            footprint.lineTo(body.x-body.width/2+20,floor+6);footprint.closeSubpath()
            soft_path(p,footprint,round(opacity*.48),3+gap*.035)
            soft_shadow(p,body.x,floor,body.width*.46+gap*.06,3.5+gap*.025,opacity)
        p.restore()
        for body in bodies:
            if body.row and not body.removing:
                receiving=QPainterPath()
                for lower in bodies:
                    if not lower.removing and lower.row<body.row:receiving=receiving.united(self._cube_top(lower))
                p.save();p.setClipPath(receiving,Qt.ClipOperation.IntersectClip)
                floor,_=cup.support(body);gap=max(0,floor-body.y)
                soft_shadow(p,body.x+7,floor-4,body.width*.58,5.5,round(max(18,114-gap)))
                p.restore()
            p.save();p.translate(body.x,body.y);p.rotate(body.roll)
            if body.removing:p.setOpacity(max(0,1-body.age/.30))
            p.drawPixmap(QPointF(-body.width/2-2,block_geometry(body.width,HEIGHT).sprite_top),self._block_sprite(body.label,body.width,scale))
            p.restore()
        p.restore()

    def _block_sprite(self,text,width,scale):
        ratio=self.devicePixelRatioF()*scale
        key=(text,width,round(ratio,5),self.font().family())
        if key in self._sprites:
            self._sprites.move_to_end(key);return self._sprites[key]
        height=HEIGHT;geometry=block_geometry(width,height)
        sprite=QPixmap(math.ceil((width+4)*ratio),math.ceil((-geometry.sprite_top+5)*ratio))
        sprite.setDevicePixelRatio(ratio);sprite.fill(Qt.GlobalColor.transparent)
        p=QPainter(sprite);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        is_x='x' in text.lower();negative=text.startswith(('−','-'))
        base,ink=('#bce9dc','#2c554c') if is_x else (('#f2c2b0','#6a453b') if negative else ('#f7e6bc','#665034'))
        faces=[(vertices,base) for vertices,_ in geometry.faces]
        origin=(width/2+2,-geometry.sprite_top-geometry.bottom)
        draw_mesh(p,faces,origin,finish='clay')
        p.save();p.translate(width/2+2,-geometry.sprite_top);p.setTransform(geometry.front,combine=True)
        font=QFont(self.font());font.setPixelSize(33);font.setBold(True);p.setFont(font)
        while p.fontMetrics().horizontalAdvance(text)>geometry.front_width-10 and font.pixelSize()>12:
            font.setPixelSize(font.pixelSize()-1);p.setFont(font)
        label=QRectF(4,1,geometry.front_width-8,height-2)
        p.setPen(QColor(255,251,232,170));p.drawText(label.translated(0,1),int(Qt.AlignmentFlag.AlignCenter),text)
        p.setPen(QColor(ink));p.drawText(label,int(Qt.AlignmentFlag.AlignCenter),text)
        p.restore();p.end()
        self._sprites[key]=sprite
        while len(self._sprites)>64:self._sprites.popitem(last=False)
        return sprite

    def _draw_celebration(self,p,cx,cy,h):
        t=min(1,self._celebration.elapsed()/self.CELEBRATION_DURATION)
        p.save();p.setOpacity((1-t)**.65);p.setPen(Qt.PenStyle.NoPen)
        colors=['#e8be6d','#86cbb7','#c3bfd9','#e5aa97']
        for i in range(12):
            angle=math.radians(25+i*360/12)
            distance=36+105*t
            x,y=cx+math.cos(angle)*distance,cy+38+math.sin(angle)*distance*.65-18*t
            p.save();p.translate(x,y);p.rotate(i*31+t*100);p.setBrush(QColor(colors[i%4]))
            if i%2:p.drawRoundedRect(QRectF(-3,-5,6,10),1.5,1.5)
            else:
                star=[]
                for j in range(10):
                    r=7 if j%2==0 else 3
                    a=math.radians(-90+j*36);star.append((math.cos(a)*r,math.sin(a)*r))
                polygon(p,star,QColor(colors[i%4]))
            p.restore()
        p.restore()

    def chain(self,p,start,end,scale):
        dx,dy=end.x()-start.x(),end.y()-start.y();length=math.hypot(dx,dy)
        count=max(2,min(32,round(length/12)));step=length/count
        def draw_strip(q):
            for i in range(count):
                wide=3.8 if i%2==0 else 2.7;y=i*step+4
                q.setBrush(Qt.BrushStyle.NoBrush)
                q.setPen(QPen(QColor('#a79776'),3.0));q.drawEllipse(QRectF(9-wide+1,y+1,wide*2,step+3))
                q.setPen(QPen(QColor('#dfd1b3'),2.1));q.drawEllipse(QRectF(9-wide,y,wide*2,step+3))
                q.setPen(QPen(QColor('#fff4d9'),1.15));q.drawArc(QRectF(10-wide,y+.5,wide*2-1,step+2),20*16,170*16)
        strip=self._part(('chain',count,round(length,3),scale),20,math.ceil(length+12),self._geometry()[0],draw_strip)
        p.save();p.translate(start);p.rotate(math.degrees(math.atan2(dy,dx))-90)
        p.drawPixmap(QPointF(-9,-4),strip);p.restore()
