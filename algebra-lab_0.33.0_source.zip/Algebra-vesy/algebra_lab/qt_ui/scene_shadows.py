"""Soft, receiver-plane shadows for the small software-rendered scene."""
from PyQt6.QtCore import Qt,QPointF
from PyQt6.QtGui import QColor,QPen,QPainterPath,QPolygonF
from .solids import LIGHT,project


def soft_path(p,path,strength=86,softness=6):
    """Layered penumbra and a solid umbra; no live blur effects or image filters."""
    p.save()
    for spread,alpha in [(softness,4),(softness*.72,5),(softness*.45,7),(softness*.22,9)]:
        pen=QPen(QColor(39,31,24,alpha),max(.5,spread*2))
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen);p.setBrush(Qt.BrushStyle.NoBrush);p.drawPath(path)
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(39,31,24,strength));p.drawPath(path)
    p.restore()


def hull(points):
    pts=sorted(set(points))
    if len(pts)<3:return pts
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    lower=[];upper=[]
    for point in pts:
        while len(lower)>=2 and cross(lower[-2],lower[-1],point)<=0:lower.pop()
        lower.append(point)
    for point in reversed(pts):
        while len(upper)>=2 and cross(upper[-2],upper[-1],point)<=0:upper.pop()
        upper.append(point)
    return lower[:-1]+upper[:-1]


def cast_solids(p,solids,origin,strength=76,softness=7):
    """Project each convex part onto z=0 along the room's directional light."""
    shadow=QPainterPath()
    for faces in solids:
        points=[]
        for vertices,_ in faces:
            for x,y,z in vertices:
                q=project((x-LIGHT[0]/LIGHT[2]*z,y-LIGHT[1]/LIGHT[2]*z,0),origin)
                points.append((q.x(),q.y()))
        outline=hull(points)
        if len(outline)<3:continue
        path=QPainterPath();path.addPolygon(QPolygonF([QPointF(*xy) for xy in outline]));path.closeSubpath()
        shadow=path if shadow.isEmpty() else shadow.united(path)
    soft_path(p,shadow,strength,softness)
