"""Animated clock composed into the background, never a foreground child widget."""
import math
import weakref
from PyQt6.QtCore import Qt,QRect,QRectF,QPointF,QTimer,QElapsedTimer,QTime,QObject,QEvent
from PyQt6.QtGui import QColor,QPainter,QPen,QBrush,QRadialGradient,QPixmap

class WorkshopClock(QObject):
    def __init__(self,parent):
        super().__init__(parent)
        self._owner=weakref.proxy(parent);parent.installEventFilter(self)
        self._rect=QRect(0,0,58,83)
        self._motion=True;self._face=None;self._frame=None;self._key=None
        self._time=QTime.currentTime();self._phase=0
        self._elapsed=QElapsedTimer();self._elapsed.start()
        self._timer=QTimer(self);self._timer.setInterval(100)
        self._timer.timeout.connect(self._tick)

    @property
    def is_running(self):return self._timer.isActive()
    def width(self):return self._rect.width()
    def height(self):return self._rect.height()
    def devicePixelRatioF(self):return self._owner.devicePixelRatioF()
    def geometry(self):return QRect(self._rect)

    def setGeometry(self,*args):
        before=QRect(self._rect);self._rect=QRect(*args);self._frame=None
        self._owner.update(before.united(self._rect))

    def set_motion(self,enabled):
        enabled=bool(enabled)
        if enabled!=self._motion:
            self._motion=enabled;self._sync()

    def stop(self):self._timer.stop()
    def _sync(self):
        if self._motion and self._owner.isVisible() and not self._owner.window().isMinimized():
            if not self._timer.isActive():self._timer.start()
        else:self._timer.stop()

    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Show:self._sync()
        elif event.type()==QEvent.Type.Hide:self.stop()
        return False

    def _tick(self):
        self._time=QTime.currentTime();self._phase=self._elapsed.elapsed()/1000
        self._frame=None;self._owner.update(self._rect)

    def paint(self,painter):painter.drawPixmap(self._rect.topLeft(),self.grab())

    @staticmethod
    def _sphere(p,x,y,r,light,dark):
        g=QRadialGradient(QPointF(x-r*.30,y-r*.35),r*1.4)
        g.setColorAt(0,QColor(light));g.setColorAt(1,QColor(dark))
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QBrush(g));p.drawEllipse(QPointF(x,y),r,r)

    def _case(self,p):
        p.scale(self.width()/66,self.height()/94)
        # Rounded wood case and a brass face, with actual depth along the lower rim.
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(51,36,23,38))
        p.drawRoundedRect(QRectF(10,9,50,82),20,20)
        p.setBrush(QColor('#6c4e37'));p.drawRoundedRect(QRectF(13,27,41,59),13,13)
        p.setBrush(QColor('#a27c53'));p.drawRoundedRect(QRectF(12,24,39,58),12,12)
        p.setBrush(QColor('#4c4e41'));p.drawRoundedRect(QRectF(18,48,27,28),10,10)
        self._sphere(p,34,32,27,'#b39b70','#705c3d')
        self._sphere(p,31,28,26,'#e3d1a9','#a58e61')
        self._sphere(p,31,28,22,'#fff7df','#e7d6ac')
        for tick in range(12):
            p.save();p.translate(31,28);p.rotate(tick*30)
            p.setPen(QPen(QColor('#766449'),1.5 if tick%3 else 2.2))
            p.drawLine(QPointF(0,-18),QPointF(0,-15 if tick%3==0 else -16.5));p.restore()

    def grab(self):
        if self._frame is not None and self._frame.devicePixelRatioF()==self.devicePixelRatioF():return self._frame
        ratio=self.devicePixelRatioF();key=(self.width(),self.height(),ratio)
        if key!=self._key:
            self._face=QPixmap(round(self.width()*ratio),round(self.height()*ratio))
            self._face.setDevicePixelRatio(ratio);self._face.fill(Qt.GlobalColor.transparent)
            p=QPainter(self._face);p.setRenderHint(QPainter.RenderHint.Antialiasing);self._case(p);p.end();self._key=key
        self._frame=self._face.copy()
        p=QPainter(self._frame);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.scale(self.width()/66,self.height()/94)
        # Pendulum and real system-clock hands are independent of the lesson timer.
        p.save();p.translate(31,46);p.rotate(math.sin(self._phase*math.pi)*13)
        p.setPen(QPen(QColor('#c1a36d'),2));p.drawLine(QPointF(0,0),QPointF(0,24))
        self._sphere(p,0,24,6,'#ecd5a2','#a38750');p.restore()
        second=self._time.second()+self._time.msec()/1000
        minute=self._time.minute()+second/60
        hour=self._time.hour()%12+minute/60
        for angle,length,width,color in [(hour*30,10,2.6,'#4f6155'),(minute*6,15,1.8,'#4f6155'),(second*6,17,0.9,'#aa7657')]:
            p.save();p.translate(31,28);p.rotate(angle);p.setPen(QPen(QColor(color),width,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
            p.drawLine(QPointF(0,2),QPointF(0,-length));p.restore()
        self._sphere(p,31,28,2,'#f5e5c5','#a0895e');p.end()
        return self._frame
