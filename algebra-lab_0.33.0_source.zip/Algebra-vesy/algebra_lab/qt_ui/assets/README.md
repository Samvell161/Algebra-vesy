# Workshop background

`workshop-luxury.png` is an original, AI-generated background illustration prepared for Algebra LAB: a CGI-style miniature workshop in warm maple, ivory plaster and teal, with brass details. It was generated for this project with the OpenAI image generation tool and is bundled locally. No external asset store, stock artwork or third-party runtime is used.

Native size: 2042 × 770 pixels. The application preserves its aspect ratio with a centred cover crop. The image is decoded once per process; the scaled room and the ground shadows are drawn into the balance widget's static cache. It has no animation timer or network requests. The existing vector workshop remains the fallback if the artwork is missing or cannot be decoded.

Keep this asset in the installed `algebra_lab/qt_ui/assets/` directory. It is included by the normal recursive Qt payload packaging, and verified from the extracted DEB.

Version 0.21 uses an edited illustration with a framed adventure-map and planetary artwork, lighter daylight and pastel accents. The animated clock is deliberately excluded from the PNG and composed by the application behind the foreground solids.

Version 0.26 edits that original illustration with a small wooden abacus on the right shelf and a carved owl mascot with a paper boat on a central wall shelf. The central stand line is kept clear. These are static background objects, composed before the interactive balance and decoded once. They do not add animation timers, input handlers or gameplay rules. The edited artwork was prepared with the same OpenAI image generation tool and is bundled offline.

## Adventure diorama — 0.25

`adventure-diorama.png` is another original illustration generated for this project with the OpenAI image generation tool. It depicts a miniature meadow, trees, cottages and a stream with a wooden bridge. It contains no lesson numbers, equations or interactive controls. Those remain native Qt elements above the illustration, with the same real lesson access rules and touch targets. The texture is decoded once and cover-cropped into the chapter's cached landscape. A vector landscape is used if it cannot be decoded. Both illustrations are bundled offline; no new rendering dependency or background service is needed.
