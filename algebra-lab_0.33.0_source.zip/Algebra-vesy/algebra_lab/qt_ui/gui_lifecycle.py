"""Release GUI-backed caches while QApplication's font/display services live."""
def release_gui_caches():
    import qtawesome as qta
    from .button_shadow import shadow_image
    from .workshop import background_texture
    from .map_backdrop import texture
    qta.reset_cache()
    # QtAwesome 1.4 keeps QRawFont instances in thread-local dictionaries. They
    # must die before Qt's font backend. Preserve each dictionary entry because
    # QtAwesome's QThread.finished callback later removes that entry itself.
    iconic=getattr(qta,'_resource',{}).get('iconic')
    font_maps=getattr(iconic,'rawfont_cache',{})
    if isinstance(font_maps,dict):
        for fonts in font_maps.values():
            if isinstance(fonts,dict):fonts.clear()
    shadow_image.cache_clear();background_texture.cache_clear();texture.cache_clear()
