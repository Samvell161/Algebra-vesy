"""Bevelled 3D blocks with a shared projected label plane and shadow receiver."""
import math
from functools import lru_cache
from dataclasses import dataclass
from PyQt6.QtCore import QPointF
from PyQt6.QtGui import QPainterPath,QTransform
from .solids import plinth,project,COS

@dataclass
class BlockGeometry:
    faces:list
    top:QPainterPath
    front:QTransform
    front_width:float
    bottom:float
    sprite_top:int

@lru_cache(maxsize=32)
def block_geometry(width,height=58):
    yaw=math.radians(-14);co,si=math.cos(yaw),math.sin(yaw)
    depth=24
    front_width=(width-depth*abs(si))/co
    zheight=height/COS
    def rotate(v):
        x,y,z=v;return (x*co-y*si,x*si+y*co,z)
    raw=plinth(front_width,depth,0,zheight,'#ffffff',bevel=2.5,radius=4)
    faces=[([rotate(v) for v in vertices],color) for vertices,color in raw]
    bottom=max(project(v).y() for vertices,_ in faces for v in vertices if v[2]<.001)
    # Wide summary blocks have a deeper projected silhouette after the yaw.
    # Keep the physical foot at zero, extending the sprite upwards as needed.
    sprite_top=math.floor(min(-height-11,min(project(v).y()-bottom for vertices,_ in faces for v in vertices)-2))
    top=QPainterPath()
    for i,vertex in enumerate(faces[-1][0]):
        q=project(vertex,(0,-bottom))
        if i==0:top.moveTo(q)
        else:top.lineTo(q)
    top.closeSubpath()
    tl=project(rotate((-front_width/2,-depth/2,zheight)),(0,-bottom))
    tr=project(rotate((front_width/2,-depth/2,zheight)),(0,-bottom))
    transform=QTransform((tr.x()-tl.x())/front_width,(tr.y()-tl.y())/front_width,0,1,tl.x(),tl.y())
    return BlockGeometry(faces,top,transform,front_width,bottom,sprite_top)
