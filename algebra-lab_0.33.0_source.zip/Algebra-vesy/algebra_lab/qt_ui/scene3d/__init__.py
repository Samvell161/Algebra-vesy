"""Real, depth-tested OpenGL scene. No room images or software polygon painter."""
