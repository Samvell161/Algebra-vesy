"""Run with algebra-lab --check-3d; does not open a child database or RFID."""
import json
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication
from ..real_balance import RealBalance

def run():
    from PyQt6 import sip
    from ..gui_lifecycle import release_gui_caches
    app=QApplication([]);board=RealBalance();board.resize(1024,400)
    board.set_blocks(['x','1','1'],['1']*4);board.show()
    poll=QTimer();poll.setInterval(100);deadline=QTimer();deadline.setSingleShot(True)
    result={'ok':False}
    def check():
        surface=board.surface
        if board.graphics_error:
            result['error']=board.graphics_error;app.quit()
        elif surface is not None and surface.frames:
            result.update(ok=True,**surface.info,vertices=sum(m.vertex_count for m in surface.scene.static.values()),shadow_map=surface.shadow_size)
            app.quit()
    poll.timeout.connect(check);deadline.timeout.connect(app.quit);poll.start();deadline.start(20000)
    try:app.exec()
    finally:
        poll.stop();deadline.stop();board.shutdown();board.close();sip.delete(board)
        sip.delete(poll);sip.delete(deadline)
        del board,poll,deadline
        release_gui_caches();sip.delete(app)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['ok'] else 1
