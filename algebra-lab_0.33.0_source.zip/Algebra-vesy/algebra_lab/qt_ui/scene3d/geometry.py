"""Procedural triangle meshes in XYZ space, with smooth vertex normals.

World units are metres for drawing; Z points up, Y points into the room.
The mesh data has no dependency on Qt, NumPy, image assets or an OpenGL context.
"""
import math
from array import array
from dataclasses import dataclass,field

TAU=math.tau

def rgb(value):
    if isinstance(value,str):return tuple(int(value[i:i+2],16)/255 for i in (1,3,5))
    return tuple(value)

def unit(v):
    length=math.sqrt(sum(x*x for x in v)) or 1
    return tuple(x/length for x in v)

def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def sub(a,b):return tuple(x-y for x,y in zip(a,b))

@dataclass
class Mesh:
    data:array=field(default_factory=lambda:array('f'))

    @property
    def vertex_count(self):return len(self.data)//9

    def triangle(self,a,b,c,color,normals=None):
        face=unit(cross(sub(b,a),sub(c,a)))
        if sum(x*x for x in cross(sub(b,a),sub(c,a)))<1e-16:return
        normals=normals or (face,face,face)
        if sum(face[i]*sum(n[i] for n in normals) for i in range(3))<0:
            b,c=c,b;normals=(normals[0],normals[2],normals[1])
        color=rgb(color)
        for point,normal in zip((a,b,c),normals):self.data.extend((*point,*normal,*color))

    def add(self,mesh,position=(0,0,0),scale=(1,1,1),rotation=(0,0,0)):
        if isinstance(scale,(float,int)):scale=(scale,)*3
        angles=[math.radians(a) for a in rotation]
        def rotate(p):
            x,y,z=p
            for axis,a in enumerate(angles):
                co,si=math.cos(a),math.sin(a)
                if axis==0:y,z=y*co-z*si,y*si+z*co
                elif axis==1:x,z=x*co+z*si,-x*si+z*co
                else:x,y=x*co-y*si,x*si+y*co
            return x,y,z
        for i in range(0,len(mesh.data),9):
            p=rotate(tuple(mesh.data[i+j]*scale[j] for j in range(3)))
            n=unit(rotate(tuple(mesh.data[i+3+j]/scale[j] for j in range(3))))
            self.data.extend((*(p[j]+position[j] for j in range(3)),*n,*mesh.data[i+6:i+9]))
        return self

    def bounds(self):
        if not self.data:return ((0,0,0),(0,0,0))
        return tuple(tuple(fn(self.data[i::9]) for i in range(3)) for fn in (min,max))


def box(size=(1,1,1),color='#ffffff',radius=.04):
    half=[v/2 for v in size];r=min(radius,min(half)*.8)
    mesh=Mesh()
    for axis in range(3):
        u,v=(axis+1)%3,(axis+2)%3
        for sign in [-1,1]:
            coords=lambda h:sorted(set([-h,-h+r*.25,-h+r,0,h-r,h-r*.25,h]))
            if r<1e-6:coords=lambda h:[-h,h]
            us,vs=coords(half[u]),coords(half[v])
            def vertex(a,b):
                p=[0.,0.,0.];p[axis]=half[axis]*sign;p[u]=a;p[v]=b
                if r<1e-6:
                    n=[0.,0.,0.];n[axis]=sign;return tuple(p),tuple(n)
                q=[max(-half[i]+r,min(half[i]-r,p[i])) for i in range(3)]
                n=unit(sub(p,q));return tuple(q[i]+r*n[i] for i in range(3)),n
            for a,b in zip(us,us[1:]):
                for c,d in zip(vs,vs[1:]):
                    points=[vertex(x,y) for x,y in [(a,c),(b,c),(b,d),(a,d)]]
                    for indices in [(0,1,2),(0,2,3)]:
                        mesh.triangle(*(points[i][0] for i in indices),color,tuple(points[i][1] for i in indices))
    return mesh


def lathe(profile,color='#ffffff',segments=40,caps=False):
    mesh=Mesh();rings=[]
    for k,(r,z) in enumerate(profile):
        before=profile[max(0,k-1)];after=profile[min(len(profile)-1,k+1)]
        dr,dz=after[0]-before[0],after[1]-before[1]
        rings.append([((r*math.cos(a),r*math.sin(a),z),unit((dz*math.cos(a),dz*math.sin(a),-dr)))
                      for a in (i*TAU/segments for i in range(segments))])
    for lower,upper in zip(rings,rings[1:]):
        for i in range(segments):
            j=(i+1)%segments
            for indices in [(lower[i],lower[j],upper[j]),(lower[i],upper[j],upper[i])]:
                mesh.triangle(*(p[0] for p in indices),color,tuple(p[1] for p in indices))
    if caps:
        for ring,sign in [(rings[0],-1),(rings[-1],1)]:
            z=ring[0][0][2];n=(0,0,sign)
            for i in range(segments):mesh.triangle((0,0,z),ring[i][0],ring[(i+1)%segments][0],color,(n,n,n))
    return mesh

def cylinder(radius,height,color='#ffffff',segments=32):return lathe([(radius,0),(radius,height)],color,segments,True)

def sphere(radius=1,color='#ffffff',segments=20,rings=12):
    mesh=Mesh()
    def vertex(a,b):
        n=(math.cos(a)*math.sin(b),math.sin(a)*math.sin(b),math.cos(b))
        return tuple(x*radius for x in n),n
    for j in range(rings):
        for i in range(segments):
            pts=[vertex(a,b) for a,b in [(i*TAU/segments,j*math.pi/rings),((i+1)*TAU/segments,j*math.pi/rings),
                                          ((i+1)*TAU/segments,(j+1)*math.pi/rings),(i*TAU/segments,(j+1)*math.pi/rings)]]
            for ids in [(0,1,2),(0,2,3)]:mesh.triangle(*(pts[k][0] for k in ids),color,tuple(pts[k][1] for k in ids))
    return mesh

def torus(radius=.2,tube=.025,color='#ffffff',segments=24,sides=8,arc=TAU):
    mesh=Mesh()
    def vertex(a,b):
        n=(math.cos(a)*math.cos(b),math.sin(a)*math.cos(b),math.sin(b))
        return ((radius+tube*math.cos(b))*math.cos(a),(radius+tube*math.cos(b))*math.sin(a),tube*math.sin(b)),n
    for i in range(segments):
        for j in range(sides):
            pts=[vertex(a,b) for a,b in [(i*arc/segments,j*TAU/sides),((i+1)*arc/segments,j*TAU/sides),
                                          ((i+1)*arc/segments,(j+1)*TAU/sides),(i*arc/segments,(j+1)*TAU/sides)]]
            for ids in [(0,1,2),(0,2,3)]:mesh.triangle(*(pts[k][0] for k in ids),color,tuple(pts[k][1] for k in ids))
    return mesh

def rod(a,b,radius=.025,color='#ffffff',segments=12):
    direction=unit(sub(b,a));tangent=unit(cross(direction,(0,0,1) if abs(direction[2])<.9 else (0,1,0)))
    other=cross(direction,tangent);mesh=Mesh()
    def vertex(center,angle):
        n=tuple(tangent[i]*math.cos(angle)+other[i]*math.sin(angle) for i in range(3))
        return tuple(center[i]+radius*n[i] for i in range(3)),n
    for j in range(segments):
        pts=[vertex(p,t) for p,t in [(a,j*TAU/segments),(a,(j+1)*TAU/segments),(b,(j+1)*TAU/segments),(b,j*TAU/segments)]]
        for ids in [(0,1,2),(0,2,3)]:mesh.triangle(*(pts[k][0] for k in ids),color,tuple(pts[k][1] for k in ids))
    return mesh

def star(radius=.12,color='#e8c479',depth=.025):
    mesh=Mesh();points=[]
    for i in range(10):
        a=math.pi/2+i*TAU/10;r=radius if i%2==0 else radius*.44
        points.append((math.cos(a)*r,math.sin(a)*r))
    for i,(x,y) in enumerate(points):
        xx,yy=points[(i+1)%10]
        mesh.triangle((0,0,depth),(x,y,depth),(xx,yy,depth),color)
        mesh.triangle((x,y,0),(xx,yy,0),(xx,yy,depth),color)
        mesh.triangle((x,y,0),(xx,yy,depth),(x,y,depth),color)
    return mesh
