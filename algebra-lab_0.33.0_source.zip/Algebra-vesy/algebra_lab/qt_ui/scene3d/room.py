"""A furnished workshop with spaced display objects and real light fixtures.

All furniture and props are meshes. Named assemblies retain their actual mesh
bounds for layout checks, but are merged by material before reaching OpenGL.
"""
import math
from functools import lru_cache
from .geometry import Mesh,box,cylinder,lathe,sphere,torus,rod,star
from .lighting import CLOCK_POSITION,LAMP_POSITION,LAMP_ROTATION

@lru_cache(maxsize=48)
def ball(color):return sphere(1,color,12,8)

class Item:
    def __init__(self,scene,name):self.scene=scene;self.name=name;self.meshes={}
    def add(self,name,mesh,position=(0,0,0),scale=1,rotation=(0,0,0),finish='matte'):
        self.meshes.setdefault(finish,Mesh()).add(mesh,position,scale,rotation)
        self.scene.names.append(name)
    def finish(self):
        bounds=[mesh.bounds() for mesh in self.meshes.values()]
        self.scene.room_bounds[self.name]=tuple(tuple(fn(bound[axis][j] for bound in bounds) for j in range(3)) for axis,fn in [(0,min),(1,max)])
        for finish,mesh in self.meshes.items():self.scene.static.setdefault(finish,Mesh()).add(mesh)


def populate_room(s,detailed=False):
    add=s.add
    def block(name,pos,size,color,finish='matte',radius=.02,rotation=(0,0,0)):
        add(name,box(size,color,radius),pos,rotation=rotation,finish=finish)
    def orb(name,pos,scale,color,finish='matte'):
        add(name,ball(color),pos,scale,finish=finish)
    def bar(name,a,b,r,color,finish='wood'):
        add(name,rod(a,b,r,color),finish=finish)
    def begin(name):
        item=Item(s,name)
        return item,item.add
    frame='#d9b57f';brass='#d9bf8e'
    block('workbench',(0,.4,-.19),(15,7,.38),'#e6bd81','wood',.12)
    block('bench-front',(0,-3.02,-.60),(14.8,.18,.65),'#b4d5bc','enamel',.06)
    for x in [-5.5,-2.75,0,2.75,5.5]:
        block('drawer',(x,-3.14,-.57),(2.55,.15,.45),'#bedbc6','enamel',.06)
        orb('drawer-handle',(x,-3.25,-.52),.065,brass,'metal')

    # Architectural opening: light rays and the view really pass through it.
    wy=3.70;cx=-5.70;radius=.90;bottom=1.22;spring=2.17;top=spring+radius
    wall='#eee5cf'
    block('wall-right',(1.60,wy,2.9),(12.8,.26,6.2),wall,radius=0)
    block('wall-left',(-7.30,wy,2.9),(1.40,.26,6.2),wall,radius=0)
    block('wall-window-bottom',(cx,wy,(bottom-.2)/2),(radius*2,.26,bottom+.2),wall,radius=0)
    block('wall-window-top',(cx,wy,(top+6)/2),(radius*2,.26,6-top),wall,radius=0)
    infill=Mesh()
    for i in range(28):
        a,b=math.pi*i/28,math.pi*(i+1)/28
        x,z=cx+radius*math.cos(a),spring+radius*math.sin(a)
        xx,zz=cx+radius*math.cos(b),spring+radius*math.sin(b)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,zz),(xx,wy-.14,top+.01),wall,((0,-1,0),)*3)
        infill.triangle((x,wy-.14,z),(xx,wy-.14,top+.01),(x,wy-.14,top+.01),wall,((0,-1,0),)*3)
    add('arch-wall-infill',infill)
    for x in [-8,8]:block('side-room-wall',(x,0,2.7),(.24,7.6,6),'#e4dbc5',radius=0)
    block('wall-dado',(0,3.52,.12),(16,.12,.18),'#c1d5bf','enamel',.025)
    # Sky, distant hills and cloud meshes behind the actual window aperture.
    block('sky',(cx,8.9,3.1),(6,.10,7),'#c2e8ee','emissive',0)
    for x,y,z,scale in [(-6.1,5.3,.9,(1.5,1,1.25)),(-5.1,6.6,.8,(1.4,1.2,1.1))]:orb('distant-hill',(x,y,z),scale,'#a0caac')
    orb('sun',(-6.15,7.0,2.35),.22,'#ffdc8d','emissive')
    for index,(x,z) in enumerate([(-6.15,2.6),(-5.45,2.7)]):
        cloud=Mesh()
        for dx,r in [(-.16,.18),(0,.23),(.17,.17)]:cloud.add(ball('#f6fbf1'),(dx,0,0),(r,.12,r*.65))
        key='cloud-'+str(index);s.parts[key]=cloud;s.ambient_nodes.append((key,(x,5.5,z)));s.names.append('cloud')
    for x,y,z in [(-6.2,6.3,1.7),(-5.1,6.9,1.6)]:
        bar('garden-tree-trunk',(x,y,z-.3),(x,y,z+.35),.035,'#b69771')
        for dx,dz in [(-.12,.25),(.12,.35),(0,.53)]:orb('garden-tree',(x+dx,y,z+dz),(.25,.20,.27),'#8dbb91')
    item,put=begin('window')
    for x in [cx-radius,cx+radius]:put('window-jamb',rod((x,3.42,bottom),(x,3.42,spring),.085,frame),finish='wood')
    put('window-arch',torus(radius,.085,frame,40,8,math.pi),(cx,3.42,spring),rotation=(90,0,0),finish='wood')
    put('window-sill',box((2.04,.55,.12),'#ecd0a4',.04),(cx,3.22,bottom-.02),finish='wood')
    put('window-centre',rod((cx,3.4,bottom),(cx,3.4,top),.032,frame),finish='wood')
    put('window-crossbar',rod((cx-radius,3.4,1.95),(cx+radius,3.4,1.95),.032,frame),finish='wood');item.finish()

    # Left station: each toy has a clear silhouette and its own footprint.
    item,put=begin('plant')
    put('plant-pot',lathe([(.15,0),(.22,.29),(.23,.32),(.19,.34)],'#e9ad8c',20,True),(-6.98,2.65,0),finish='enamel')
    for i in range(7):
        a=i*2.4;tip=(-6.98+math.cos(a)*.20,2.65+math.sin(a)*.16,.43+i*.045)
        put('plant-stem',rod((-6.98,2.65,.25),tip,.009,'#63996c'))
        put('plant-leaf',ball('#82b98a' if i%2 else '#b1cb88'),tip,(.16,.06,.06),rotation=(0,i*7,i*47))
    item.finish()
    item,put=begin('globe')
    put('globe-foot',cylinder(.24,.06,frame,24),(-6.06,2.72,0),finish='wood')
    put('globe-stand',rod((-6.06,2.72,.04),(-6.06,2.72,.32),.035,brass),finish='metal')
    put('globe-ocean',ball('#79b9ce'),(-6.06,2.72,.62),.30,finish='enamel')
    put('globe-meridian',torus(.34,.018,brass,32,6),(-6.06,2.72,.62),rotation=(84,20,0),finish='metal')
    for dx,dy,dz,scale in [(-.10,-.24,.06,(.12,.045,.18)),(.12,-.23,-.09,(.10,.05,.13))]:
        put('globe-land',ball('#a8cf99'),(-6.06+dx,2.72+dy,.62+dz),scale)
    item.finish()
    item,put=begin('robot')
    for x in [-5.20,-4.99]:put('robot-foot',box((.15,.23,.08),'#85b6ad',.025),(x,2.71,.04),finish='enamel')
    for x in [-5.20,-4.99]:put('robot-leg',cylinder(.032,.10,brass,12),(x,2.75,.08),finish='metal')
    put('robot-neck',cylinder(.035,.05,brass,12),(-5.10,2.75,.45),finish='metal')
    put('robot-body',box((.39,.25,.32),'#e7ba7c',.05),(-5.10,2.75,.30),finish='enamel')
    put('robot-head',box((.37,.27,.25),'#91cbbd',.045),(-5.10,2.75,.60),finish='enamel')
    for x in [-5.20,-5.00]:
        put('robot-eye',ball('#fff7db'),(x,2.604,.62),(.046,.018,.048))
        put('robot-pupil',ball('#365d62'),(x,2.585,.62),(.020,.009,.023))
    put('robot-smile',rod((-5.18,2.608,.53),(-5.02,2.608,.53),.010,'#527c78'))
    for x in [-5.38,-4.82]:
        put('robot-arm',rod((-5.10,2.75,.30),(x,2.75,.30),.025,brass),finish='metal')
        put('robot-hand',ball('#e3cc9b'),(x,2.75,.30),.065,finish='metal')
    put('robot-antenna',rod((-5.10,2.75,.72),(-5.10,2.75,.82),.012,brass),finish='metal')
    put('robot-antenna-tip',ball('#edaa88'),(-5.10,2.75,.85),.043,finish='enamel');item.finish()
    item,put=begin('boat')
    boat=Mesh()
    for a,b,c in [((-.24,0,0),(.24,0,0),(0,0,.18)),((-.24,0,0),(0,.12,.04),(.24,0,0)),((-.24,0,0),(.24,0,0),(0,-.12,.04))]:boat.triangle(a,b,c,'#f8dfab')
    put('paper-boat',boat,(-4.25,2.85,.003));item.finish()

    # Three rows of distinct educational objects, with space around each group.
    for z in [.75,1.75,2.75]:
        block('shelf',(5.25,3.03,z),(2.65,.78,.12),frame,'wood',.035)
        for x in [4.05,6.45]:bar('shelf-bracket',(x,3.48,z-.22),(x,2.83,z-.07),.022,brass,'metal')
    for x in [3.98,6.52]:block('bookcase-upright',(x,3.36,1.65),(.075,.12,3.30),'#bba47e','wood')
    colors=['#5db9a5','#edac84','#a4c0d7','#dec383']
    for i,(x,h) in enumerate([(4.27,.42),(4.56,.58),(4.85,.50)]):
        item,put=begin('book-'+str(i))
        put('book',box((.22,.36,h),colors[i],.016),(x,3.0,2.82+h/2))
        for z in [2.90,3.01]:put('book-band',box((.20,.008,.015),'#efdbaf',0),(x,2.815,z),finish='metal')
        item.finish()
    item,put=begin('rocket')
    put('rocket-body',lathe([(0,0),(.16,0),(.16,.38),(.13,.48),(0,.67)],'#f5dfb3',24),(5.48,3.0,2.82),finish='enamel')
    put('rocket-nose',lathe([(.13,0),(.09,.10),(0,.19)],'#df9a7a',20),(5.48,3.0,3.30),finish='enamel')
    for x in [5.29,5.67]:put('rocket-fin',box((.10,.22,.22),'#dc9b83',.025),(x,3.0,2.94),finish='enamel')
    put('rocket-glass',ball('#68b8c6'),(5.48,2.843,3.12),(.07,.018,.07),finish='enamel')
    put('rocket-window',torus(.072,.012,brass,20,6),(5.48,2.832,3.12),rotation=(90,0,0),finish='metal');item.finish()
    item,put=begin('jar')
    put('specimen-jar',lathe([(.14,0),(.15,.07),(.14,.31),(.11,.36),(.11,.40)],'#9ecbbb',24,True),(6.08,3.0,2.82),finish='enamel')
    put('jar-cork',cylinder(.12,.055,frame,20),(6.08,3.0,3.22),finish='wood')
    put('jar-label',box((.18,.012,.12),'#fff0c8',.01),(6.08,2.85,3.02));item.finish()
    item,put=begin('telescope')
    for x,y in [(4.22,2.76),(4.77,2.76),(4.49,3.20)]:put('telescope-tripod',rod((4.49,2.98,2.28),(x,y,1.82),.022,brass),finish='metal')
    put('telescope-body',rod((4.21,2.97,2.18),(4.85,2.97,2.42),.09,'#dfbd7a'),finish='metal')
    put('telescope-lens',ball('#6baeba'),(4.86,2.97,2.42),(.032,.078,.076),finish='enamel');item.finish()
    item,put=begin('abacus')
    put('abacus-foot',box((1.18,.25,.06),frame,.02),(5.80,2.99,1.83),finish='wood')
    for x in [5.27,6.33]:put('abacus-post',rod((x,2.99,1.85),(x,2.99,2.44),.032,frame),finish='wood')
    for j,z in enumerate([1.98,2.16,2.34]):
        put('abacus-rod',rod((5.28,2.99,z),(6.32,2.99,z),.012,brass),finish='metal')
        for i in range(5):put('abacus-bead',ball(colors[j]),(5.42+i*.17,2.99,z),(.065,.055,.07),finish='enamel')
    item.finish()
    item,put=begin('pencils')
    put('pencil-cup',lathe([(.14,0),(.17,.25),(.17,.30),(.14,.30),(.12,.07)],'#8ac7be',24),(4.33,2.96,.82),finish='enamel')
    for i in range(5):
        x=4.33+(i-2)*.047;h=.47+(i%3)*.05
        put('pencil',cylinder(.019,h,colors[i%4],8),(x,2.96,.89))
        put('pencil-tip',lathe([(.019,0),(0,.055)],'#d7b683',8),(x,2.96,.89+h),finish='wood')
    item.finish()
    item,put=begin('rings')
    put('ring-toy-foot',box((.50,.33,.06),frame,.025),(5.18,2.98,.85),finish='wood')
    put('ring-toy-post',cylinder(.025,.50,brass,12),(5.18,2.98,.86),finish='metal')
    for i,r in enumerate([.20,.16,.12]):put('counting-ring',torus(r,.035,colors[i],24,6),(5.18,2.98,.925+i*.07),finish='enamel')
    item.finish()
    item,put=begin('shape-toys')
    put('shape-board',box((.72,.38,.055),frame,.02),(6.00,2.98,.85),finish='wood')
    put('shape-cube',box((.20,.22,.22),'#dba485',.024),(5.77,2.98,.99),finish='enamel')
    put('shape-ball',ball('#91bcba'),(6.03,2.98,1.01),.14,finish='enamel')
    put('shape-cone',lathe([(.105,0),(0,.32)],'#e5c56f',20),(6.23,2.98,.88),finish='enamel');item.finish()

    # Quiet, narrow accents in the gaps inside the balance silhouette.
    item,put=begin('ruler')
    put('ruler-back',box((.24,.08,.87),'#e3bf7b',.02),(-.65,3.42,1.77),finish='wood')
    for i in range(11):
        z=1.39+i*.074;w=.12 if i%5==0 else .07
        put('ruler-tick',box((w,.008,.012),'#718e7c',0),(-.69,3.374,z))
    item.finish()
    item,put=begin('owl')
    put('owl-shelf',box((.53,.40,.065),frame,.02),(.65,3.05,1.39),finish='wood')
    put('owl-body',ball('#e9cda0'),(.65,3.0,1.64),(.17,.12,.21))
    put('owl-head',ball('#eee0bc'),(.65,2.99,1.85),(.18,.13,.16))
    for x in [.50,.80]:put('owl-wing',ball('#86bca7'),(x,3.0,1.64),(.06,.09,.14),finish='enamel')
    for x in [.58,.72]:
        put('owl-eye',ball('#fff2cf'),(x,2.86,1.86),(.065,.026,.07))
        put('owl-pupil',ball('#31575b'),(x,2.832,1.86),(.024,.013,.032))
        put('owl-goggles',torus(.066,.009,brass,20,6),(x,2.826,1.86),rotation=(90,0,0),finish='metal')
    put('owl-beak',ball('#d7a962'),(.65,2.83,1.77),(.027,.035,.028),finish='metal');item.finish()

    # Small wall displays stay outside the pan/chain sweep.
    item,put=begin('planet-badge')
    put('planet-frame',torus(.27,.025,frame,32,6),(-4.25,3.29,1.50),rotation=(90,0,0),finish='wood')
    put('planet-disc',cylinder(.25,.025,'#81a9bd',28),(-4.25,3.33,1.50),rotation=(90,0,0))
    put('planet',ball('#a7d6d2'),(-4.25,3.23,1.50),(.13,.05,.13),finish='enamel')
    put('planet-ring',torus(.18,.016,'#e8d69b',24,6),(-4.25,3.19,1.50),rotation=(74,-25,0),finish='metal');item.finish()
    item,put=begin('mini-map')
    put('map-backing',box((.56,.07,.72),'#a1cfc6',.025),(6.99,3.35,1.55),finish='enamel')
    for x in [6.69,7.29]:put('map-frame',box((.045,.11,.80),frame,.01),(x,3.29,1.55),finish='wood')
    for z in [1.16,1.94]:put('map-frame',box((.64,.11,.045),frame,.01),(6.99,3.29,z),finish='wood')
    for x,z in [(6.84,1.76),(7.12,1.60),(6.91,1.35)]:put('map-island',ball('#bed197'),(x,3.26,z),(.105,.03,.065))
    for i in range(7):put('map-path',ball(brass),(6.86+i*.032,3.21,1.37+i*.055),.012,finish='metal')
    for x in [7.06,7.16]:
        put('map-castle-tower',box((.045,.04,.12),'#f0dcae',0),(x,3.20,1.66))
        put('map-castle-roof',lathe([(.038,0),(0,.07)],'#d6a084',10),(x,3.20,1.72),finish='enamel')
    item.finish()
    item,put=begin('garland')
    for i in range(12):
        x=-3.03+i*.55;xx=x+.55;z=3.41+.035*(x/3.1)**2;zz=3.41+.035*(xx/3.1)**2
        put('garland-cord',rod((x,3.32,z),(xx,3.32,zz),.007,brass),finish='metal')
        if i<11:
            flag=Mesh();flag.triangle((-.08,0,0),(0,0,-.13),(.08,0,0),colors[i%4])
            put('garland-pennant',flag,(x+.28,3.30,z-.015))
    item.finish()

    item,put=begin('star-badge')
    put('badge-disc',cylinder(.18,.035,'#9bcbbd',28),(0,3.31,3.00),rotation=(90,0,0),finish='enamel')
    put('badge-rim',torus(.18,.016,brass,28,6),(0,3.27,3.00),rotation=(90,0,0),finish='metal')
    put('badge-star',star(.115,'#f1d184',.025),(0,3.24,3.00),rotation=(90,0,0),finish='metal');item.finish()

    cx,cy,cz=CLOCK_POSITION
    item,put=begin('clock')
    put('clock-back',box((.53,.16,1.01),'#bf9c6c',.07),(cx,cy+.09,cz-.29),finish='wood')
    for x in [cx-.20,cx+.20]:put('clock-post',box((.06,.14,.54),'#c29d70',.015),(x,cy-.04,cz-.39),finish='wood')
    put('clock-bottom',box((.48,.18,.07),frame,.02),(cx,cy-.04,cz-.70),finish='wood')
    put('clock-rim',torus(.28,.04,brass,32,8),(cx,cy-.08,cz),rotation=(90,0,0),finish='metal')
    put('clock-face',cylinder(.26,.03,'#fff1ca',32),(cx,cy-.045,cz),rotation=(90,0,0))
    for i in range(12):
        a=i*math.pi/6
        put('clock-tick',rod((cx+.21*math.sin(a),cy-.09,cz+.21*math.cos(a)),(cx+.235*math.sin(a),cy-.09,cz+.235*math.cos(a)),.008,'#628374'))
    item.finish()

    # The shade, bulb and spotlight use the exact same world-space placement.
    item,put=begin('lamp')
    put('lamp-mount',cylinder(.115,.055,brass,24),(6.98,3.48,3.25),rotation=(90,0,0),finish='metal')
    put('lamp-arm',rod((6.98,3.43,3.25),(6.98,2.83,3.25),.025,brass),finish='metal')
    put('lamp-arm',rod((6.98,2.83,3.25),(7.08,2.73,3.05),.025,brass),finish='metal')
    shade=lathe([(.235,-.10),(.22,-.02),(.15,.19),(.10,.23),(.08,.23),(.13,.17),(.20,-.03),(.215,-.10),(.235,-.10)],'#75b9ad',40 if detailed else 28)
    put('lamp-shade',shade,LAMP_POSITION,rotation=LAMP_ROTATION,finish='enamel')
    lip=Mesh().add(torus(.225,.015,brass,32,6),(0,0,-.10))
    put('lamp-lip',lip,LAMP_POSITION,rotation=LAMP_ROTATION,finish='metal');item.finish()
    s.parts['lamp-bulb']=Mesh().add(ball('#ffe0a0'),LAMP_POSITION,.085)
