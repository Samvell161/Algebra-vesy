"""Load the pinned pure-Python binding from the offline package when present."""
import os
import sys
from pathlib import Path

from PyQt6.QtGui import QGuiApplication
platform_name=QGuiApplication.platformName() if QGuiApplication.instance() is not None else os.environ.get('QT_QPA_PLATFORM','')
if not platform_name and os.environ.get('XDG_SESSION_TYPE')=='wayland':platform_name='wayland'
if 'PYOPENGL_PLATFORM' not in os.environ and platform_name.startswith(('wayland','eglfs')):
    os.environ['PYOPENGL_PLATFORM']='egl'
for folder in [Path(__file__).parents[2]/'_vendor',Path(__file__).parents[3]/'packaging/vendor']:
    archives=[folder/'PyOpenGL-3.1.9-runtime.zip',folder/'PyOpenGL-3.1.9-py3-none-any.whl']
    archive=next((path for path in archives if path.is_file()),None)
    if archive is not None:
        sys.path.insert(0,str(archive));break
from OpenGL import GL
from OpenGL.GL.shaders import compileShader
from OpenGL.arrays import arraydatatype
# All uploads use bytes/ctypes. Select the standard-library output handler so
# generation/query calls also work without installing NumPy on the device.
arraydatatype.GLOBAL_REGISTRY.registerReturn('ctypesarrays')
