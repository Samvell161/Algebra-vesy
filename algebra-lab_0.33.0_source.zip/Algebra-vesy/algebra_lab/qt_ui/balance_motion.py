"""Bounded visual mechanics; independent of Qt and of answer validation.

Difference is evaluated by the lesson at its reference x. The angle is an
illustrative spring-balance response, not a physical measurement of tag mass.
"""
import math
from fractions import Fraction

MAX_TILT = 9.0
ANGLE_STOP = 9.7


def tilt_for_difference(difference):
    """Odd, monotone response: 1 -> 1.8°, 2 -> 3°, 8 -> 6°, bounded by 9°.

    Divide exact fractions before converting to float, including huge inputs.
    A tiny fractional difference stays tiny instead of jumping to a fixed angle.
    """
    difference = Fraction(difference)
    return float(9 * difference / (abs(difference) + 4))


def step_beam(angle, velocity, target, dt, load=0):
    """One short spring/inertia step, with slight overshoot and mechanical stops."""
    inertia = 1 + min(10, max(0, load)) * .055
    damping = 2 * .78 * math.sqrt(100 * inertia)
    acceleration = (100 * (target - angle) - damping * velocity) / inertia
    velocity += acceleration * dt
    angle += velocity * dt
    if abs(angle) > ANGLE_STOP:
        angle = math.copysign(ANGLE_STOP, angle)
        if velocity * angle > 0:
            velocity *= -.08
    return angle, velocity
