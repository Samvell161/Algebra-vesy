"""Cached touch trail with a finite reveal and lightweight ambient decorations."""
import math
from PyQt6.QtCore import Qt, QRectF, QPointF, QRect, QTimer, QElapsedTimer
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap, QLinearGradient, QRadialGradient, QBrush
from PyQt6.QtWidgets import QWidget,QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QLabel
from .map_backdrop import draw_backdrop
from ..adventure import ADVENTURE_TASKS,LANDS,QUIZZES,level_open,land_open,quiz_open

TITLES=['Начало','Числа побольше','Зеркальные весы','Два x']
PALETTES=[('#f5fbed','#d6ebcd','#9ec39d'),('#fff7df','#f1dcb0','#cdb185'),
          ('#eef9f8','#cce4df','#93bbb5'),('#fff1e4','#eed4c4','#cdaea2')]

class Trail(QWidget):
    def __init__(self,chapter,best,current,choose,parent=None,motion=True):
        super().__init__(parent)
        self.chapter,self.best,self.current=chapter,dict(best),current
        self.nodes={};self.labels=[];self.cache=None;self.cache_size=None
        self.route_cache=None;self._cloud=None;self._cloud_ratio=None
        self._motion=bool(motion);self._phase=0.;self._reveal=1.;self._started=False
        self._elapsed=QElapsedTimer();self._pulse=QElapsedTimer();self._pulse_index=None
        self._timer=QTimer(self);self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self.setMinimumHeight(260)
        for i,task in enumerate(ADVENTURE_TASKS[chapter*6:chapter*6+6]):
            number=chapter*6+i+1;done=task['id'] in best
            button=QPushButton(str(number),self);button.setFixedSize(72,72)
            button.setObjectName('route-'+task['id'])
            button.setEnabled(level_open(best,task['id']))
            color='#40a68c' if done else '#4d9eb5' if button.isEnabled() else '#c5cec4'
            light,shade=('#81e7c6','#117c72') if done else ('#a4dbe5','#346b82') if button.isEnabled() else ('#edf0f5','#a3abba')
            border='#ffc94c' if task['id']==current else '#ffffff'
            button.setStyleSheet('QPushButton {min-width:0;min-height:0;padding:0;border-radius:36px;'
                'border:4px solid '+border+';border-bottom:6px solid '+shade+';'
                'background:qradialgradient(cx:0.35,cy:0.25,radius:0.95,fx:0.3,fy:0.2,stop:0 '+light+',stop:0.55 '+color+',stop:1 '+shade+');color:white;font-size:25px;font-weight:bold;}'
                'QPushButton:hover {border-color:#ffc94c;} QPushButton:pressed {background:#347f83;}'
                'QPushButton:disabled {color:#71778a;} QPushButton:focus {border-color:#ffc94c;}')
            button.setAccessibleName('Уровень %d. %s. %s'%(number,task['title'], 'Пройден' if done else 'Доступен' if button.isEnabled() else 'Закрыт'))
            button.setToolTip(task['title']+' · '+task['equation'])
            button.pressed.connect(lambda index=i:self.press_pulse(index))
            button.clicked.connect(lambda checked=False,key=task['id']:choose(key))
            self.nodes[task['id']]=button
            equation=QLabel(task['equation'],self);equation.setAlignment(Qt.AlignmentFlag.AlignCenter)
            equation.setStyleSheet('background:#ffffff;color:#302755;border-radius:9px;font-size:17px;font-weight:bold;')
            status=QLabel('★'*best[task['id']] if done else 'Можно играть' if button.isEnabled() else 'Закрыто',self)
            status.setAlignment(Qt.AlignmentFlag.AlignCenter)
            status.setStyleSheet('background:transparent;color:'+('#846014' if done else '#5d5670')+';font-size:14px;')
            self.labels.append((equation,status))

    @property
    def is_animating(self):return self._timer.isActive()

    def set_motion(self,enabled):
        self._motion=bool(enabled)
        if not self._motion:
            self._timer.stop();self._reveal=1.;self._pulse.invalidate()
        elif self.isVisible():self._timer.start(100)
        self.update()

    def stop_motion(self):self._timer.stop()

    def showEvent(self,event):
        if self._motion:
            if not self._started:
                self._started=True;self._phase=0.;self._reveal=0.;self._elapsed.start()
            self._timer.start(33 if self._reveal<1 else 100)
        super().showEvent(event)

    def hideEvent(self,event):
        self.stop_motion();super().hideEvent(event)

    def press_pulse(self,index):
        if self._motion:
            self._pulse_index=index;self._pulse.start()
            if self.isVisible():self._timer.start(33)
            self.update()

    def _tick(self):
        if not self._motion or not self.isVisible():self.stop_motion();return
        if not self._elapsed.isValid():self._elapsed.start()
        self._phase=self._elapsed.elapsed()/1000
        t=min(1.,self._phase/1.05);self._reveal=1-(1-t)**3
        pulse=self._pulse.isValid() and self._pulse.elapsed()<360
        if self._pulse.isValid() and not pulse:
            point=self.points()[self._pulse_index]
            self.update(QRect(round(point.x()-58),round(point.y()-63),116,126))
            self._pulse.invalidate()
        fast=self._phase<1.5 or pulse
        self._timer.setInterval(33 if fast else 100)
        if self._phase<1.5:self.update()
        else:
            # Clouds, the small butterfly and only the active node halo change.
            self.update(QRect(0,0,self.width(),round(max(self.height()*.15,48+self.height()*.025))))
            self.update(QRect(round(self.width()*.32),round(self.height()*.86),round(self.width()*.28),round(self.height()*.14)))
            keys=list(self.nodes)
            indices=[]
            if self.current in self.nodes:indices.append(keys.index(self.current))
            if pulse:indices.append(self._pulse_index)
            for index in set(indices):
                point=self.points()[index]
                self.update(QRect(round(point.x()-58),round(point.y()-63),116,126))

    def _cloud_sprite(self):
        ratio=self.devicePixelRatioF()
        if self._cloud is None or self._cloud_ratio!=ratio:
            self._cloud=QPixmap(round(122*ratio),round(44*ratio))
            self._cloud.setDevicePixelRatio(ratio);self._cloud.fill(Qt.GlobalColor.transparent)
            p=QPainter(self._cloud);p.setRenderHint(QPainter.RenderHint.Antialiasing)
            shape=QPainterPath();shape.addRoundedRect(QRectF(8,19,106,19),10,10)
            for x,y,r in [(35,22,15),(58,17,17),(81,23,13)]:
                part=QPainterPath();part.addEllipse(QPointF(x,y),r,r);shape=shape.united(part)
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(88,126,123,20));p.save();p.translate(1,3);p.drawPath(shape);p.restore()
            g=QLinearGradient(0,2,0,40);g.setColorAt(0,QColor('#ffffff'));g.setColorAt(1,QColor('#dcebe6'))
            p.setBrush(QBrush(g));p.drawPath(shape);p.end();self._cloud_ratio=ratio
        return self._cloud

    @staticmethod
    def _star(p,x,y,r,color):
        path=QPainterPath()
        for i in range(10):
            a=math.radians(-90+i*36);size=r if i%2==0 else r*.43
            point=QPointF(x+math.cos(a)*size,y+math.sin(a)*size)
            if i==0:path.moveTo(point)
            else:path.lineTo(point)
        path.closeSubpath();p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(color));p.drawPath(path)

    def _decorations(self,p):
        phase=self._phase
        p.save();p.setOpacity(.84)
        cloud=self._cloud_sprite()
        for x,y,speed in [(.24,.015,.38),(.70,.025,.29)]:
            p.drawPixmap(QPointF(self.width()*x+math.sin(phase*speed)*13-61,self.height()*y),cloud)
        p.restore()
        # A tiny paper butterfly stays in the meadow below equations and status labels.
        x=self.width()*.46+math.sin(phase*.52)*46;y=self.height()*.935+math.sin(phase*1.1)*3
        flap=.55+.45*math.sin(phase*7)
        p.save();p.translate(x,y);p.rotate(math.sin(phase*1.4)*9)
        p.setPen(QPen(QColor('#68887d'),1));p.setBrush(QColor('#e9c47f'))
        p.drawEllipse(QRectF(-10*flap,-8,10*flap,13));p.setBrush(QColor('#a5cfc2'))
        p.drawEllipse(QRectF(0,-8,10*flap,13))
        p.setPen(QPen(QColor('#68887d'),2,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawLine(QPointF(0,-4),QPointF(0,5));p.restore()

    def _markers(self,p):
        points=self.points();keys=list(self.nodes)
        if self.current in self.nodes:
            point=points[keys.index(self.current)]
            breath=math.sin(self._phase*2.1) if self._motion else 0
            p.setPen(QPen(QColor(224,177,77,round(115+breath*35)),2.5))
            p.setBrush(Qt.BrushStyle.NoBrush);p.drawEllipse(point,42+breath*2,42+breath*2)
            # A waving pennant is drawn behind the native, fixed-size touch button.
            x,y=point.x()+28,point.y()-54
            p.setPen(QPen(QColor('#a68a57'),2));p.drawLine(QPointF(x,y),QPointF(x,y+39))
            wave=math.sin(self._phase*3)*2 if self._motion else 0
            flag=QPainterPath(QPointF(x,y));flag.cubicTo(x+7,y-2+wave,x+11,y+4-wave,x+19,y+1)
            flag.lineTo(x+17,y+13);flag.cubicTo(x+11,y+15-wave,x+6,y+8+wave,x,y+12);flag.closeSubpath()
            p.setPen(QPen(QColor('#c79b40'),1));p.setBrush(QColor('#f2ce79'));p.drawPath(flag)
        if self._pulse.isValid():
            t=min(1,self._pulse.elapsed()/360);point=points[self._pulse_index]
            p.setPen(QPen(QColor(65,159,151,round(160*(1-t))),3));p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(point,37+16*t,37+16*t)
        if self._motion and self._phase<1.5:
            for i,point in enumerate(points):
                if ADVENTURE_TASKS[self.chapter*6+i]['id'] not in self.best:continue
                t=(self._phase-(.12+i*.11))/.4
                if 0<t<1:
                    p.save();p.setOpacity(math.sin(math.pi*t))
                    self._star(p,point.x()-43,point.y()-27-9*t,4,'#e3b44c')
                    self._star(p,point.x()+42,point.y()+23+6*t,3.5,'#e3b44c');p.restore()

    def points(self):
        return [QPointF(self.width()*(.095+i*.162),self.height()*(.57 if i%2==0 else .23)) for i in range(6)]

    def resizeEvent(self,event):
        for point,button,labels in zip(self.points(),self.nodes.values(),self.labels):
            x,y=round(point.x()),round(point.y())
            button.move(x-36,y-36)
            labels[0].setGeometry(x-65,y+41,130,30)
            labels[1].setGeometry(x-65,y+73,130,23)
        self.cache_size=None
        super().resizeEvent(event)

    def paintEvent(self,event):
        key=(self.width(),self.height(),self.devicePixelRatioF())
        if key!=self.cache_size:
            w,h=self.width(),self.height();ratio=self.devicePixelRatioF()
            self.cache=QPixmap(round(w*ratio),round(h*ratio));self.cache.setDevicePixelRatio(ratio)
            self.cache.fill(Qt.GlobalColor.transparent)
            p=QPainter(self.cache);p.setRenderHint(QPainter.RenderHint.Antialiasing)
            sky,ground,hill=PALETTES[self.chapter]
            fill=QLinearGradient(0,0,0,h);fill.setColorAt(0,QColor(sky));fill.setColorAt(1,QColor(ground))
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(fill);p.drawRoundedRect(QRectF(0,0,w,h),22,22)
            if not draw_backdrop(p,w,h,self.chapter):
                p.setBrush(QColor(hill))
                landscape=QPainterPath(QPointF(0,h*.93));landscape.cubicTo(w*.25,h*.70,w*.38,h,w*.62,h*.89)
                landscape.cubicTo(w*.82,h*.75,w*.91,h*.91,w,h*.82);landscape.lineTo(w,h);landscape.lineTo(0,h);landscape.closeSubpath();p.drawPath(landscape)
            p.end()
            self.route_cache=QPixmap(round(w*ratio),round(h*ratio));self.route_cache.setDevicePixelRatio(ratio)
            self.route_cache.fill(Qt.GlobalColor.transparent)
            p=QPainter(self.route_cache);p.setRenderHint(QPainter.RenderHint.Antialiasing)
            pts=self.points()
            for i,(a,b) in enumerate(zip(pts,pts[1:])):
                path=QPainterPath(a);mid=(a.x()+b.x())/2
                path.cubicTo(mid,a.y(),mid,b.y(),b.x(),b.y())
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.save();p.translate(0,5);p.setPen(QPen(QColor(72,104,86,36),28,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path);p.restore()
                p.save();p.translate(0,3);p.setPen(QPen(QColor('#c0b89f'),24,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path);p.restore()
                p.setPen(QPen(QColor('#fffdf0'),24,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
                complete=ADVENTURE_TASKS[self.chapter*6+i]['id'] in self.best
                p.setPen(QPen(QColor('#8ec9b3' if complete else '#d9c49b'),15,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
                p.setPen(QPen(QColor('#ffffff'),2,Qt.PenStyle.DotLine,Qt.PenCapStyle.RoundCap));p.drawPath(path)
            p.end();self.cache_size=key
        painter=QPainter(self);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.drawPixmap(0,0,self.cache);self._decorations(painter)
        painter.save()
        if self._reveal<1:
            points=self.points();end=points[0].x()-14+(points[-1].x()-points[0].x()+28)*self._reveal
            painter.setClipRect(QRectF(0,0,end,self.height()))
        painter.drawPixmap(0,0,self.route_cache);painter.restore()
        self._markers(painter);painter.end()

class RouteMap(QDialog):
    def __init__(self,best,current,chapter=0,parent=None,motion=True):
        super().__init__(parent)
        self.setWindowTitle('Карта приключения');self.resize(980,560)
        self.best=dict(best);self.current=current;self.chosen_task=None;self.chosen_quiz=None;self.motion=bool(motion)
        layout=QVBoxLayout(self);layout.setContentsMargins(16,12,16,12);layout.setSpacing(8)
        heading=QHBoxLayout();layout.addLayout(heading)
        title=QLabel('Карта приключения');title.setStyleSheet('font-size:25px;font-weight:bold;');heading.addWidget(title)
        heading.addStretch();heading.addWidget(QLabel('%d / 24 пройдено'%sum(t['id'] in best for t in ADVENTURE_TASKS)))
        tabs=QHBoxLayout();layout.addLayout(tabs);self.tabs=[]
        for i,name in enumerate(TITLES):
            b=QPushButton('%d · %s'%(i+1,name));b.setCheckable(True)
            b.setEnabled(land_open(best,i) or any(t['id'] in best for t in ADVENTURE_TASKS[i*6:i*6+6]))
            b.clicked.connect(lambda checked=False,index=i:self.select_chapter(index));tabs.addWidget(b);self.tabs.append(b)
        self.subtitle=QLabel();self.subtitle.setWordWrap(True);self.subtitle.setStyleSheet('font-size:17px;');layout.addWidget(self.subtitle)
        self.scene_layout=QVBoxLayout();layout.addLayout(self.scene_layout,1);self.trail=None
        footer=QHBoxLayout();layout.addLayout(footer)
        self.quiz_button=QPushButton('Квиз главы →');self.quiz_button.clicked.connect(self.choose_quiz);footer.addWidget(self.quiz_button)
        legend=QLabel('Бирюзовый — пройдено · Синий — доступно · Серый — закрыто');legend.setWordWrap(True);legend.setStyleSheet('font-size:14px;');footer.addWidget(legend,1)
        close=QPushButton('Закрыть');close.clicked.connect(self.reject);footer.addWidget(close)
        if not self.tabs[chapter].isEnabled():chapter=0
        self.select_chapter(chapter)

    def select_chapter(self,index):
        if not self.tabs[index].isEnabled():return
        if self.trail is not None and index==self.chapter:
            self.tabs[index].setChecked(True)
            return
        self.chapter=index
        for i,b in enumerate(self.tabs):b.setChecked(i==index)
        self.subtitle.setText(LANDS[index][0]+' · '+LANDS[index][1])
        if self.trail is not None:
            self.scene_layout.removeWidget(self.trail);self.trail.hide();self.trail.deleteLater()
        self.trail=Trail(index,self.best,self.current,self.choose_task,self,motion=self.motion);self.scene_layout.addWidget(self.trail)
        self.quiz_button.setEnabled(quiz_open(self.best,index))

    def done(self,result):
        if self.trail is not None:self.trail.stop_motion()
        super().done(result)

    def closeEvent(self,event):
        if self.trail is not None:self.trail.stop_motion()
        super().closeEvent(event)

    def choose_task(self,key):
        if level_open(self.best,key):self.chosen_task=key;self.accept()

    def choose_quiz(self):
        if quiz_open(self.best,self.chapter):
            self.chosen_quiz=QUIZZES[self.chapter]['id'];self.accept()
