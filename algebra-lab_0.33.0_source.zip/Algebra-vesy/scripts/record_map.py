"""Record the real animated map with demo progress (development-only Pillow)."""
import argparse,io,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PIL import Image
from PyQt6.QtCore import QBuffer,QIODevice,QElapsedTimer
from PyQt6.QtGui import QFontDatabase
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication
from algebra_lab.qt_ui.route_map import RouteMap
from algebra_lab.qt_ui.button_shadow import install_button_shadows
from algebra_lab.adventure import ADVENTURE_TASKS

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
app=QApplication([])
for path in (ROOT/'packaging/fonts').glob('AlgebraRounded-*.ttf'):QFontDatabase.addApplicationFont(str(path))
app.setStyleSheet((ROOT/'algebra_lab/qt_ui/theme.qss').read_text());install_button_shadows()
best={t['id']:3 for t in ADVENTURE_TASKS[:6]}
dialog=RouteMap(best,'cups-4');dialog.show();app.processEvents()
frames=[];timestamps=[];clock=QElapsedTimer();clock.start()
def capture(count):
    for _ in range(count):
        QTest.qWait(max(1,round((len(frames)+1)*1000/30)-clock.elapsed()))
        buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly);dialog.grab().save(buffer,'PNG')
        frames.append(Image.open(io.BytesIO(bytes(buffer.data()))).convert('RGB'));timestamps.append(clock.elapsed())
try:
    capture(60);dialog.grab().save(str(args.output/'map.png'))
    dialog.tabs[1].click();capture(55);dialog.grab().save(str(args.output/'chapter-2.png'))
    dialog.tabs[0].click();capture(45)
finally:dialog.close()
frames=[frame.quantize(colors=192) for frame in frames]
durations=[max(10,b-a) for a,b in zip(timestamps,timestamps[1:])]+[33]
frames[0].save(args.output/'map-animation.gif',save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True)
print('Actual Qt map, demo progress only:',(args.output/'map-animation.gif').stat().st_size,'bytes')
