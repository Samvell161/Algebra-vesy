"""Record the compatible Qt view with simulated UID input.

For the default real 3D scene use verify_3d_release.py --record.

Development only: requires PyQt6, QtAwesome and Pillow. No runtime dependency.
"""
import argparse
import io
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PIL import Image
from PyQt6.QtCore import QBuffer,QIODevice,QElapsedTimer
from PyQt6.QtGui import QFontDatabase
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication
from algebra_lab.qt_ui.app import Window

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True)
app=QApplication([])
for path in (ROOT/'packaging/fonts').glob('*.ttf'):QFontDatabase.addApplicationFont(str(path))
app.setStyleSheet((ROOT/'algebra_lab/qt_ui/theme.qss').read_text())
frames=[];timestamps=[];clock=QElapsedTimer()
with tempfile.TemporaryDirectory() as tmp:
    window=Window(Path(tmp),software_view=True);window.start('cups-4');window.show();app.processEvents();clock.start()
    def capture(count):
        for _ in range(count):
            QTest.qWait(max(1,round((len(frames)+1)*1000/30)-clock.elapsed()))
            buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            window.grab().save(buffer,'PNG')
            frames.append(Image.open(io.BytesIO(bytes(buffer.data()))).convert('RGB'));timestamps.append(clock.elapsed())
    try:
        window.store.bind('BB','2');window.operation('add');capture(18)
        window.reader.emit({'uid':'BB','source':'left'});window.poll();capture(36)
        window.undo();capture(24)
        window.operation('remove')
        window.reader.emit({'uid':'BB','source':'left'});window.poll();capture(32)
        window.reader.emit({'uid':'BB','source':'right'});window.poll();capture(32)
        window.answer.setCurrentIndex(1);window.check();capture(30)
    finally:window.close()
frames=[frame.quantize(colors=192) for frame in frames]
durations=[max(10,b-a) for a,b in zip(timestamps,timestamps[1:])]+[33]
frames[0].save(args.output,save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True)
print('Recorded actual Qt widgets:',args.output,args.output.stat().st_size,'bytes')
