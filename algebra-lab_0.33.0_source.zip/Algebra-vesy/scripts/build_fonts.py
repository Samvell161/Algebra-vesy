"""Regenerate the static Nunito UI fonts, or the former Comfortaa family.

Development-only fontTools. Derivatives use Algebra family names; original
copyright and OFL notices are retained in the fonts and packaging/fonts/.
"""
import argparse
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools import subset

ROOT=Path(__file__).resolve().parents[1]
FONTS=ROOT/'packaging/fonts'
RANGES=[(0x20,0x024f),(0x400,0x052f),(0x2000,0x206f),(0x2070,0x209f),
        (0x20a0,0x20cf),(0x2100,0x22ff),(0x2500,0x27ff)]
parser=argparse.ArgumentParser()
parser.add_argument('--family',choices=['rounded','compass'],default='rounded')
args=parser.parse_args()
family,source,styles=('Algebra Rounded','Nunito-source.ttf',[(400,'Regular'),(700,'Bold')]) if args.family=='rounded' else ('Algebra Compass','Comfortaa-source.ttf',[(500,'Medium'),(700,'Bold')])
prefix=family.replace(' ','')
for weight,style in styles:
    font=instantiateVariableFont(TTFont(FONTS/source),{'wght':weight},inplace=False)
    opts=subset.Options();opts.layout_features=['*'];opts.name_IDs=['*'];opts.name_languages=['*'];opts.notdef_glyph=True
    cutter=subset.Subsetter(options=opts)
    cutter.populate(unicodes=[cp for low,high in RANGES for cp in range(low,high+1)])
    cutter.subset(font)
    names={1:family,2:style,3:prefix+'-'+style+'-1.0',
           4:family+' '+style,6:prefix+'-'+style,16:family,17:style,
           21:family,22:style,25:prefix}
    table=font['name']
    for record in table.names:
        if record.nameID in names:record.string=names[record.nameID].encode(record.getEncoding())
    for name_id,value in names.items():table.setName(value,name_id,3,1,0x409)
    font['OS/2'].usWeightClass=weight
    font['OS/2'].fsSelection &= ~((1<<5)|(1<<6))
    font['OS/2'].fsSelection |= (1<<5) if weight==700 else (1<<6)
    font['head'].macStyle=(font['head'].macStyle&~1)|(1 if weight==700 else 0)
    required=set(map(ord,'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя0123456789x−=+×÷½'))
    assert required.issubset(font.getBestCmap()),'Missing classroom glyphs'
    output=FONTS/f'{prefix}-{style}.ttf';font.save(output)
    print(output.name,output.stat().st_size,'bytes')
