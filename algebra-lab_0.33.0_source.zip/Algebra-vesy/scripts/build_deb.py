#!/usr/bin/env python3
"""Build a small architecture-independent package without bundling runtimes or browsers."""
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from algebra_lab import __version__

RUNTIME = ["__init__.py", "desktop.py", "learning.py", "math_engine.py", "service.py", "storage.py", "hardware.py", "rc522.py", "tasks.py", "tag_import.py", "balance_view.py", "adventure.py", "buttons.py", "diagnostics.py", "maintenance.py", "pending.py", "presentation.py", "mobile.py", "lesson_queue.py"]


def build(destination):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    output = destination / ("algebra-lab_" + __version__ + "_all.deb")
    with tempfile.TemporaryDirectory(prefix="algebra-package-") as temp:
        root = Path(temp)
        root.chmod(0o755)
        app = root / "usr/share/algebra-lab"
        package = app / "algebra_lab"
        package.mkdir(parents=True)
        for name in RUNTIME:
            shutil.copyfile(str(ROOT / "algebra_lab" / name), str(package / name))
        shutil.copytree(str(ROOT / "algebra_lab/qt_ui"), str(package / "qt_ui"), ignore=shutil.ignore_patterns("__pycache__"))
        vendor=package/'_vendor';vendor.mkdir()
        wheel=ROOT/'packaging/vendor/PyOpenGL-3.1.9-py3-none-any.whl'
        assert hashlib.sha256(wheel.read_bytes()).hexdigest()=='15995fd3b0deb991376805da36137a4ae5aba6ddbb5e29ac1f35462d130a3f77'
        runtime=vendor/'PyOpenGL-3.1.9-runtime.zip'
        # The universal upstream wheel also ships optional Windows DLLs. The
        # Linux runtime needs only its unchanged Python package, not those DLLs.
        with zipfile.ZipFile(wheel) as source,zipfile.ZipFile(runtime,'w',zipfile.ZIP_DEFLATED) as target:
            for member in source.infolist():
                if member.filename.startswith('OpenGL/') and not member.filename.startswith('OpenGL/DLLS/') and not member.is_dir():
                    target.writestr(member,source.read(member.filename))
        shutil.copyfile(str(ROOT / "packaging/launcher.py"), str(app / "launcher.py"))
        binary = root / "usr/bin/algebra-lab"
        binary.parent.mkdir(parents=True)
        binary.write_text('#!/bin/sh\nexec /usr/bin/python3 /usr/share/algebra-lab/launcher.py "$@"\n')
        binary.chmod(0o755)
        applications = root / "usr/share/applications"
        applications.mkdir(parents=True)
        shutil.copyfile(str(ROOT / "packaging/algebra-lab.desktop"), str(applications / "algebra-lab.desktop"))
        icons = root / "usr/share/icons/hicolor/scalable/apps"
        icons.mkdir(parents=True)
        shutil.copyfile(str(ROOT / "algebra_lab/static/favicon.svg"), str(icons / "algebra-lab.svg"))
        docs = root / "usr/share/doc/algebra-lab"
        docs.mkdir(parents=True)
        shutil.copyfile(str(ROOT / "docs/install.md"), str(docs / "README.ru.md"))
        shutil.copyfile(str(ROOT / "docs/hardware.md"), str(docs / "hardware.ru.md"))
        shutil.copyfile(str(ROOT / "docs/jury-demo.md"), str(docs / "jury-demo.ru.md"))
        shutil.copyfile(str(ROOT / "docs/mobile.md"), str(docs / "mobile.ru.md"))
        shutil.copyfile(str(ROOT / "docs/visual-3d.md"), str(docs / "visual-3d.ru.md"))
        shutil.copyfile(str(ROOT/'docs/real-3d.md'),str(docs/'real-3d.ru.md'))
        shutil.copyfile(str(ROOT / "docs/map-motion.md"), str(docs / "map-motion.ru.md"))
        shutil.copyfile(str(ROOT/'packaging/vendor/PyOpenGL-LICENSE.txt'),str(docs/'PyOpenGL-LICENSE.txt'))
        shutil.copyfile(str(ROOT/'packaging/vendor/README.md'),str(docs/'third-party.md'))
        (docs/'third-party.json').write_text(json.dumps({'name':'PyOpenGL','version':'3.1.9','source_wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
            'runtime_archive':runtime.name,'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),
            'modifications':'Unchanged OpenGL Python package; optional Windows DLLS and wheel installer metadata omitted.'},indent=2)+'\n')
        fonts = root / "usr/share/fonts/truetype/algebra-lab"
        fonts.mkdir(parents=True)
        for name in ("AlgebraRounded-Regular.ttf", "AlgebraRounded-Bold.ttf"):
            shutil.copyfile(str(ROOT / "packaging/fonts" / name), str(fonts / name))
        shutil.copyfile(str(ROOT / "packaging/fonts/OFL.txt"), str(docs / "font-OFL.txt"))
        shutil.copyfile(str(ROOT / "packaging/fonts/README.md"), str(docs / "font-source.md"))
        size = sum(path.stat().st_size for path in root.rglob("*") if path.is_file())
        control = root / "DEBIAN"
        control.mkdir()
        (control / "control").write_text(
            "Package: algebra-lab\nVersion: " + __version__ + "\nSection: education\nPriority: optional\n"
            "Architecture: all\nMaintainer: Algebra LAB project <algebra-lab@localhost>\n"
            "Depends: python3 (>= 3.9), python3-tk, python3-pyqt6 (>= 6.4), python3-qtawesome (>= 1.4), libgl1, libegl1\nSuggests: python3-spidev, python3-rpi.gpio\nInstalled-Size: " + str((size + 1023) // 1024) + "\n"
            "Description: Native offline linear equation learning lab\n"
            " Real OpenGL 3D workshop and Qt child workspace with legacy tools.\n"
            " Includes exercises, exact arithmetic, progress, and block simulation.\n"
            " No browser, HTTP server, pip, or network connection is required at runtime.\n"
        )
        # Files copied from this workspace may be 0600: install system files readable to all users.
        for path in root.rglob("*"):
            if path.is_dir():
                path.chmod(0o755)
            elif path != binary:
                path.chmod(0o644)
        hashes = []
        for path in sorted(root.rglob("*")):
            if path.is_file() and "DEBIAN" not in path.parts:
                hashes.append(hashlib.md5(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(root)))
        (control / "md5sums").write_text("\n".join(hashes) + "\n")
        # xz is supported by old Raspberry Pi OS; do not use newer zstd compression.
        subprocess.run(["dpkg-deb", "--root-owner-group", "-Zxz", "--build", str(root), str(output)], check=True)
    checksum = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(".deb.sha256").write_text(checksum + "  " + output.name + "\n")
    print(str(output))
    print("Package bytes:", output.stat().st_size, "Payload bytes:", size)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    build(parser.parse_args().output)
