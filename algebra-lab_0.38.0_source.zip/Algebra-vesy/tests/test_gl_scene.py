"""Opt in with ALGEBRA_TEST_GL=1, DISPLAY and the xcb Qt platform.

This exercises the real OpenGL/GLES renderer, not the compatible software view.
"""
import os
import sys
import tempfile
import unittest
from pathlib import Path
if os.environ.get('ALGEBRA_NO_NUMPY')=='1':sys.modules['numpy']=None
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtGui import QFontDatabase
    from PyQt6.QtTest import QTest
    from algebra_lab.qt_ui.app import Window
except ImportError:QApplication=None

@unittest.skipUnless(QApplication and os.environ.get('ALGEBRA_TEST_GL')=='1','An actual GL display is required')
class RealGLTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        root=Path(__file__).resolve().parents[1]
        for font in (root/'packaging/fonts').glob('AlgebraRounded*.ttf'):QFontDatabase.addApplicationFont(str(font))
        cls.app.setStyleSheet((root/'algebra_lab/qt_ui/theme.qss').read_text())

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.w=Window(Path(self.tmp.name));self.w.start('cups-4');self.w.show()
        self.surface=self.w.board.surface
        self.wait_for(lambda:self.surface.frames>0 or self.w.board.graphics_error)
        self.assertIsNone(self.w.board.graphics_error)
        QTest.qWait(80)

    def tearDown(self):
        from PyQt6 import sip
        if not sip.isdeleted(self.w):self.w.close();sip.delete(self.w)
        self.surface=None;self.w=None
        import gc
        gc.collect()
        self.tmp.cleanup()

    @classmethod
    def tearDownClass(cls):
        from algebra_lab.qt_ui.app import icon
        from algebra_lab.qt_ui.gui_lifecycle import release_gui_caches
        icon.cache_clear();release_gui_caches()

    def wait_for(self,predicate):
        for _ in range(200):
            if predicate():return
            QTest.qWait(50)
        self.fail('3D scene did not become ready')

    def frame(self):
        count=self.surface.frames;self.surface.update();self.wait_for(lambda:self.surface.frames>count)
        return self.surface.grabFramebuffer()

    def test_real_gl_context_depth_buffers_offline_geometry_and_no_numpy(self):
        from algebra_lab.qt_ui.scene3d.gl_api import GL
        from algebra_lab.qt_ui.workshop import background_texture
        import OpenGL
        self.assertTrue(self.surface.isValid())
        self.assertIn('PyOpenGL-3.1.9-',OpenGL.__file__)
        self.assertEqual(background_texture.cache_info().misses,0)
        self.assertTrue(self.surface.vp.isAffine())
        self.surface.makeCurrent()
        try:self.assertTrue(GL.glIsEnabled(GL.GL_DEPTH_TEST))
        finally:self.surface.doneCurrent()
        image=self.frame();colors={image.pixelColor(x,y).name() for x in range(0,image.width(),12) for y in range(0,image.height(),12)}
        self.assertGreater(len(colors),80)
        self.assertGreater(self.surface.shadow_frames,0)
        self.assertGreater(sum(m.vertex_count for m in self.surface.scene.static.values()),10000)

    def test_fixed_front_camera_preserves_parallel_scale_and_ignores_drag(self):
        from PyQt6.QtCore import Qt,QPoint
        from PyQt6.QtGui import QVector3D,QMatrix4x4
        self.w.board.set_ambient(False);initial=self.frame();handles=dict(self.surface.buffers)
        shadow_frames=self.surface.shadow_frames;projection=QMatrix4x4(self.surface.vp)
        self.assertAlmostEqual(self.surface.eye.x(),0)
        self.assertTrue(projection.isAffine())
        # Equal widths at different depths, and a level, symmetrical beam.
        widths=[]
        for depth in [-1,0,3]:
            a,b=[projection.map(QVector3D(x,depth,1.5)) for x in [-1,1]]
            widths.append(b.x()-a.x())
        self.assertAlmostEqual(min(widths),max(widths),places=6)
        from algebra_lab.qt_ui.scene3d.model import PIVOT,ARM,HERO_SCALE
        left,right=[projection.map(QVector3D(x*HERO_SCALE,0,PIVOT*HERO_SCALE)) for x in [-ARM,ARM]]
        self.assertAlmostEqual(left.y(),right.y(),places=6)
        self.assertAlmostEqual(left.x(),-right.x(),places=6)
        QTest.mousePress(self.surface,Qt.MouseButton.LeftButton,pos=QPoint(120,100))
        QTest.mouseMove(self.surface,QPoint(270,155),delay=30)
        QTest.mouseRelease(self.surface,Qt.MouseButton.LeftButton,pos=QPoint(270,155))
        other=self.frame()
        self.assertEqual(projection,self.surface.vp);self.assertEqual(initial,other)
        self.assertEqual(handles,self.surface.buffers);self.assertEqual(shadow_frames,self.surface.shadow_frames)
        self.assertFalse(any(b.text()=='Ракурс' for b in self.w.board.findChildren(QPushButton)))

    def test_real_shadows_and_clock_reuse_static_geometry(self):
        self.w.board.set_ambient(False);shadows=self.frame()
        self.surface.shadows_enabled=False;unshadowed=self.frame()
        self.assertNotEqual(shadows,unshadowed)
        self.surface.shadows_enabled=True;self.w.board.set_ambient(True)
        buffers=dict(self.surface.buffers);shadow_frames=self.surface.shadow_frames
        QTest.qWait(350)
        self.assertEqual(buffers,self.surface.buffers)
        self.assertEqual(shadow_frames,self.surface.shadow_frames)
        self.w.board.hide();self.assertFalse(self.w.board.clock.is_running)

    def test_rfid_equation_touch_targets_contacts_and_motion_setting_in_real_window(self):
        w=self.w;original=w.condition.text()
        for button in w.centralWidget().findChildren(QPushButton):
            if button.isVisible():self.assertGreaterEqual(min(button.width(),button.height()),44,button.text())
        self.assertLess(w.board.container.geometry().bottom(),w.left.geometry().top())
        w.store.bind('A1','1');w.operation('add');w.reader.emit({'uid':'A1','source':'left'});w.poll()
        self.assertAlmostEqual(w.board.tilt,-1.8)
        self.assertEqual(w.condition.text(),original)
        QTest.qWait(w.board.DURATION+150)
        self.assertFalse(w.board.is_animating)
        for cup in w.board._cups:
            for body in cup.bodies:self.assertAlmostEqual(body.y,cup.support(body)[0],places=5)
        w.reader.emit({'uid':'A1','source':'right'});w.poll();self.assertEqual(w.board.tilt,0)
        w.board.set_motion(False);self.assertFalse(w.board.clock.is_running);self.assertFalse(w.board.is_animating)
        self.assertEqual(w.condition.text(),original)

    def test_quality_switch_rebuilds_only_geometry_and_preserves_lesson_and_labels(self):
        w=self.w;surface=self.surface;w.board.set_ambient(False)
        original=w.condition.text();progress=w.store.progress();tags=w.store.tags()
        w.board.set_quality('detail');self.wait_for(lambda:surface._applied_quality=='detail')
        high=self.frame();high_vertices=surface.scene.parts['chains'].vertex_count
        self.assertEqual(surface.shadow_size,2048)
        self.assertTrue(surface.info['contact_shading'])
        textures=dict(surface.textures)
        w.board.set_quality('smooth');self.wait_for(lambda:surface._applied_quality=='smooth')
        low=self.frame()
        self.assertEqual(surface.shadow_size,1024)
        self.assertFalse(surface.info['contact_shading'])
        self.assertLess(surface.scene.parts['chains'].vertex_count,high_vertices)
        self.assertNotEqual(high,low);self.assertEqual(dict(surface.textures),textures)
        self.assertEqual(w.condition.text(),original);self.assertEqual(w.store.progress(),progress);self.assertEqual(w.store.tags(),tags)
        # Several quick requests must not install a stale model or shader.
        for key in ['detail','smooth','detail','smooth','detail']:w.board.set_quality(key)
        self.wait_for(lambda:surface._applied_quality=='detail');self.frame()
        self.assertEqual(surface.shadow_size,2048)
        self.assertEqual(surface.scene.parts['chains'].vertex_count,high_vertices)
        w.board.set_motion(False);self.assertFalse(w.board.clock.is_running)
        w.board.set_quality('smooth');self.wait_for(lambda:surface._applied_quality=='smooth')
        self.assertFalse(w.board.clock.is_running);self.assertFalse(w.board.is_animating)

    def test_quality_dialog_persists_touch_selection_and_returns_to_real_scene(self):
        from PyQt6.QtCore import QTimer
        w=self.w;seen=[]
        def choose():
            dialog=QApplication.activeModalWidget();self.assertIsNotNone(dialog)
            buttons=dialog.findChildren(QPushButton)
            selection=next(b for b in buttons if b.text().startswith('Плавнее'))
            self.assertGreaterEqual(selection.height(),44);selection.click()
            lamp=next(b for b in buttons if b.text().startswith('Светильник'))
            self.assertFalse(lamp.visibleRegion().isEmpty())
            lamp.click();self.assertFalse(w.store.settings()['room_lamp'])
            seen.append(w.store.settings()['graphics_quality']);dialog.accept()
        QTimer.singleShot(150,choose);w.visual_settings()
        self.assertEqual(seen,['smooth'])
        self.wait_for(lambda:self.surface._applied_quality=='smooth')
        self.assertTrue(self.surface.isValid());self.assertFalse(w.closed)
        self.assertEqual(w.board.clock._timer.interval(),160)
        self.assertFalse(self.surface.lamp_enabled)
        w.refresh();self.assertEqual(w.store.settings()['graphics_quality'],'smooth')

    def test_lamp_has_local_lighting_its_own_shadows_and_cached_depth(self):
        from PyQt6.QtGui import QVector3D
        from algebra_lab.qt_ui.scene3d.lighting import LAMP_POSITION,LAMP_DIRECTION
        w=self.w;surface=self.surface;w.board.set_ambient(False)
        lit=self.frame();buffers=dict(surface.buffers);shadows=surface.lamp_shadow_frames
        self.assertGreater(shadows,0);self.assertEqual(surface.lamp_shadow_size,1024)
        centre=surface.lamp_light.map(QVector3D(*(p+2*d for p,d in zip(LAMP_POSITION,LAMP_DIRECTION))))
        self.assertAlmostEqual(centre.x(),0,places=5);self.assertAlmostEqual(centre.y(),0,places=5)
        surface.lamp_shadows_enabled=False;unshadowed=self.frame()
        self.assertNotEqual(lit,unshadowed)
        surface.lamp_shadows_enabled=True;w.store.save_settings({'room_lamp':False});w.board.set_lamp(False);dark=self.frame()
        self.assertNotEqual(lit,dark);self.assertEqual(buffers,surface.buffers)
        self.assertEqual(shadows,surface.lamp_shadow_frames)
        w.store.bind('A1','1');w.operation('add');w.scan({'uid':'A1','source':'left'})
        QTest.qWait(w.board.DURATION+150)
        self.assertEqual(shadows,surface.lamp_shadow_frames)
        w.store.save_settings({'room_lamp':True});w.board.set_lamp(True);self.frame();self.assertEqual(surface.lamp_shadow_frames,shadows+1)
        w.board.set_motion(False);w.board.set_lamp(False);self.frame()
        self.assertFalse(w.board.clock.is_running);self.assertFalse(w.board.is_animating)

    def test_large_viewport_tall_models_and_original_condition_fit_the_lcd(self):
        from PyQt6.QtGui import QVector3D
        from algebra_lab.qt_ui.scene3d.model import PIVOT,HERO_SCALE
        w=self.w;surface=self.surface
        self.assertEqual((w.width(),w.height()),(1024,600))
        self.assertGreaterEqual(surface.height(),375)
        self.assertGreater(surface.scene_size[0],surface.width())
        self.assertLessEqual(surface.scene_size[0],1600)
        top=surface.vp.map(QVector3D(0,0,(PIVOT+.25)*HERO_SCALE))
        foot=surface.vp.map(QVector3D(0,0,.06*HERO_SCALE))
        self.assertGreater((top.y()-foot.y())*surface.height()/2,270)
        self.assertEqual(w.remove.parent(),w.board);self.assertEqual(w.add.parent(),w.board)
        for button in [w.left,w.remove,w.add,w.right]:
            self.assertGreaterEqual(min(button.width(),button.height()),44)
            self.assertLess(w.board.container.geometry().bottom(),button.geometry().top())
        original=w.condition.text();w.store.bind('A2','2');w.operation('remove')
        for side in ['left','right']:w.scan({'uid':'A2','source':side})
        self.app.processEvents();self.assertTrue(w.answers.isVisible())
        self.assertGreaterEqual(surface.height(),320);self.assertEqual(w.condition.text(),original)
        self.assertLess(w.condition.mapTo(w.centralWidget(),w.condition.rect().topLeft()).y(),60)

    def test_contact_shadows_and_living_room_reuse_geometry_and_depth(self):
        from unittest.mock import patch
        from PyQt6.QtCore import QTime
        w=self.w;surface=self.surface;w.board.set_ambient(False)
        with_contacts=self.frame();buffers=dict(surface.buffers);texture=surface.contact_texture
        depth=(surface.shadow_frames,surface.lamp_shadow_frames)
        self.assertGreater(texture,0)
        surface.contact_shadows_enabled=False;without=self.frame()
        self.assertNotEqual(with_contacts,without)
        surface.contact_shadows_enabled=True;self.frame()
        w.board.set_ambient(True);clock=w.board.clock
        with patch.object(clock,'_elapsed') as elapsed,patch('PyQt6.QtCore.QTime') as time:
            time.currentTime.return_value=QTime(10,30)
            elapsed.elapsed.return_value=1000;clock._tick();opened=self.frame()
            count=surface.frames;clock._tick();QTest.qWait(20)
            self.assertEqual(count,surface.frames)
            elapsed.elapsed.return_value=3000;clock._tick();other=self.frame()
            self.assertNotEqual(opened,other)
            elapsed.elapsed.return_value=6160;clock._tick();closed=self.frame()
            self.assertNotEqual(opened,closed)
            elapsed.elapsed.return_value=6500;clock._tick();self.assertNotEqual(closed,self.frame())
        self.assertEqual(buffers,surface.buffers);self.assertEqual(texture,surface.contact_texture)
        self.assertEqual(depth,(surface.shadow_frames,surface.lamp_shadow_frames))

    def test_room_animation_stops_and_pan_walls_are_opaque(self):
        from unittest.mock import patch
        from PyQt6.QtGui import QVector3D
        from algebra_lab.qt_ui.scene3d.gl_api import GL
        from algebra_lab.qt_ui.scene3d.model import ARM,RIM,HERO_SCALE
        w=self.w;surface=self.surface
        w.board.set_motion(False);still=self.frame();count=surface.frames
        QTest.qWait(260)
        self.assertEqual(count,surface.frames);self.assertEqual(still,self.frame())
        original=surface.draw
        def without_room(key,program):
            if not key.startswith('static:'):original(key,program)
        with patch.object(surface,'draw',side_effect=without_room):isolated=self.frame()
        for direction in [-1,1]:
            p=surface.vp.map(QVector3D(direction*ARM*HERO_SCALE,-1.10*HERO_SCALE,(RIM-.23)*HERO_SCALE))
            x=round((p.x()+1)*still.width()/2);y=round((1-p.y())*still.height()/2)
            for dx in [-1,0,1]:
                for dy in [-1,0,1]:self.assertEqual(still.pixelColor(x+dx,y+dy),isolated.pixelColor(x+dx,y+dy))
            color=still.pixelColor(x,y)
            self.assertGreater(color.green(),color.red()*1.1) if direction<0 else self.assertGreater(color.red(),color.green()*1.05)
        surface.makeCurrent();GL.glEnable(GL.GL_BLEND);surface.doneCurrent()
        self.frame();surface.makeCurrent()
        try:self.assertFalse(GL.glIsEnabled(GL.GL_BLEND))
        finally:surface.doneCurrent()

    def test_live_background_switch_is_separate_persistent_and_restarts(self):
        from PyQt6.QtCore import QTimer
        w=self.w;original=w.condition.text();progress=w.store.progress()
        def toggle():
            dialog=QApplication.activeModalWidget()
            button=next(b for b in dialog.findChildren(QPushButton) if b.text().startswith('Живой фон:'))
            button.click();dialog.accept()
        QTimer.singleShot(50,toggle);w.visual_settings()
        self.assertFalse(w.store.settings()['ambient_motion'])
        self.assertTrue(w.board._motion);self.assertFalse(w.board.clock.is_running)
        w.refresh();self.assertFalse(w.board.clock.is_running)
        QTest.qWait(180)  # Drain the native surface exposure after closing the dialog.
        still=self.frame();count=self.surface.frames;QTest.qWait(250)
        self.assertEqual(count,self.surface.frames);self.assertEqual(still,self.frame())
        QTimer.singleShot(50,toggle);w.visual_settings()
        self.assertTrue(w.store.settings()['ambient_motion']);self.assertTrue(w.board.clock.is_running)
        count=self.surface.frames;QTest.qWait(260);self.assertGreater(self.surface.frames,count)
        self.assertEqual(original,w.condition.text());self.assertEqual(progress,w.store.progress())

    def test_symbols_remain_dark_and_readable_on_both_pans(self):
        from scripts.scene_readability import measure_symbols
        self.w.board.set_ambient(False);self.frame()
        records=measure_symbols(self.surface)
        self.assertEqual(len(records),7)
        self.assertTrue(any(r['symbol']=='x' for r in records))
        for row in records:
            self.assertGreaterEqual(row['contrast'],3.0,row)
            self.assertGreaterEqual(row['dark_pixels'],12,row)
        values={side:[r['background'] for r in records if r['side']==side and r['symbol']=='1'] for side in ['left','right']}
        ratio=(sum(values['right'])/len(values['right']))/(sum(values['left'])/len(values['left']))
        self.assertTrue(.80<=ratio<=1.25,ratio)

    def test_symbols_remain_readable_through_full_tilt_range_in_both_profiles(self):
        from scripts.scene_readability import measure_symbols
        w=self.w;w.board.set_motion(False);w.board.set_ambient(False)
        for mode in ['smooth','detail']:
            w.board.set_quality(mode);self.wait_for(lambda:self.surface._applied_quality==mode)
            for left,right in [(['x','1','1'],['1']*4),(['x','1','1','1','1'],['1']*4)]:
                for angle in [-9.7,-9,-6,-3,0,3,6,9,9.7]:
                    w.board.set_blocks(left,right,angle);w.board._angle=angle;self.frame()
                    rows=measure_symbols(self.surface)
                    self.assertEqual(len(rows),len(left)+len(right),(mode,angle))
                    for row in rows:
                        self.assertGreaterEqual(row['contrast'],3.0,(mode,angle,row))
                        self.assertGreaterEqual(row['dark_pixels'],12,(mode,angle,row))
        w.board.set_blocks(['x','1','1'],['1']*4,-9);self.frame();w.board.set_motion(True)
        w.board.set_blocks(['x','1','1'],['1']*4,9)
        for _ in range(6):
            QTest.qWait(180)
            for row in measure_symbols(self.surface):self.assertGreaterEqual(row['contrast'],3.0,row)

    def test_large_robot_and_cars_never_cover_symbols_and_stay_in_view(self):
        from scripts.scene_readability import measure_symbols
        from PyQt6.QtGui import QVector3D
        w=self.w;surface=self.surface
        w.board.set_motion(False);w.board.set_blocks(['x','1','1'],['1']*4)
        w.board.set_motion(True);w.board.set_ambient(True);w.board.clock._timer.stop()
        for mode in ['smooth','detail']:
            w.board.set_quality(mode);self.wait_for(lambda:surface._applied_quality==mode)
            w.board.clock._timer.stop()
            for phase in [0,4,8.6,12,17.8]:
                w.board.clock._phase=phase
                for angle in [-9.7,0,9.7]:
                    w.board._angle=angle;self.frame()
                    rows=measure_symbols(surface);self.assertEqual(len(rows),7)
                    self.assertTrue(all(r['contrast']>=3 and r['dark_pixels']>=12 for r in rows),(mode,phase,angle))
                    for key,transform,finish,casts in surface._nodes()[0]:
                        if not (key.startswith('room-robot-') or key.startswith('room-car')):continue
                        lo,hi=surface.scene.parts[key].bounds()
                        for x in [lo[0],hi[0]]:
                            for y in [lo[1],hi[1]]:
                                for z in [lo[2],hi[2]]:
                                    p=surface.vp.map(transform.map(QVector3D(x,y,z)))
                                    self.assertTrue(-1<=p.x()<=1 and -1<=p.y()<=1,(key,phase,p))

    def test_shader_failure_leaves_native_controls_responsive(self):
        from unittest.mock import patch
        from algebra_lab.qt_ui.scene3d.renderer import SceneSurface
        self.w.close()
        with patch.object(SceneSurface,'_program',side_effect=RuntimeError('test shader failure')):
            data=Path(self.tmp.name)/'failure';data.mkdir()
            other=Window(data);other.start('cups-4');other.show()
            try:
                self.wait_for(lambda:bool(other.board.graphics_error))
                self.assertIn('test shader failure',other.board.graphics_error)
                self.assertFalse(other.board.container.isVisible())
                self.assertTrue(other.left.isEnabled())
                other.operation('add');self.assertEqual(other.session.cup_operation,'add')
            finally:
                from PyQt6 import sip
                other.close();sip.delete(other)
