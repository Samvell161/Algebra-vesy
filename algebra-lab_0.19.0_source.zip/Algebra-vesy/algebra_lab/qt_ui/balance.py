"""A small software-rendered 3D-style balance, with finite action animations.

The scene and block sprites are cached. No OpenGL context, animation at idle,
blur effects, or equipment/model work happens in this widget.
"""
import math
from collections import Counter, OrderedDict
from PyQt6.QtCore import Qt, QRectF, QPointF, QTimer, QElapsedTimer
from PyQt6.QtGui import (QColor, QPainter, QPen, QBrush, QFont, QPainterPath,
                        QLinearGradient, QRadialGradient, QPixmap, QPolygonF)
from PyQt6.QtWidgets import QWidget, QSizePolicy
from .workshop import draw_workshop

INK = '#343360'


def gradient(y, height, light, dark):
    value = QLinearGradient(0, y, 0, y + height)
    value.setColorAt(0, QColor(light)); value.setColorAt(1, QColor(dark))
    return QBrush(value)


def polygon(p, points, brush, pen=Qt.PenStyle.NoPen):
    p.setPen(pen); p.setBrush(brush)
    p.drawPolygon(QPolygonF([QPointF(x, y) for x, y in points]))


def soft_shadow(p,x,y,rx,ry,opacity=68):
    """A local contact shadow, baked with the room; no per-widget blur effect."""
    p.save();p.translate(x,y);p.scale(rx,ry)
    brush=QRadialGradient(0,0,1)
    brush.setColorAt(0,QColor(49,37,27,opacity))
    brush.setColorAt(.45,QColor(49,37,27,round(opacity*.52)))
    brush.setColorAt(1,QColor(49,37,27,0))
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QBrush(brush))
    p.drawEllipse(QRectF(-1,-1,2,2));p.restore()


class Balance(QWidget):
    DURATION = 460
    CELEBRATION_DURATION = 680

    def __init__(self, parent=None):
        super().__init__(parent)
        self.left, self.right, self.tilt = [], [], 0
        self._angle = 0.0
        self._start_angle = 0.0
        self._progress = 1.0
        self._old = ([], [])
        self._motion = True
        self._initialized = False
        self._cache = self._stage = None
        self._cache_key = self._stage_key = None
        self._sprites = OrderedDict()
        self._clock = QElapsedTimer()
        self._celebration = QElapsedTimer()
        self._timer = QTimer(self)
        self._timer.setInterval(33)  # At most about 30 frames/s, only during an action.
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self.attachments = []
        self.setMinimumSize(400, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAccessibleName('Алгебраические весы')

    @property
    def is_animating(self):
        return self._timer.isActive()

    def set_motion(self, enabled):
        if self._motion == bool(enabled):
            return
        self._motion = bool(enabled)
        if not self._motion:
            self.stop_animation()

    def set_blocks(self, left, right, tilt=0):
        left, right = list(left), list(right)
        tilt = max(-5, min(5, tilt))
        if (left, right, tilt) == (self.left, self.right, self.tilt):
            return
        self._old = (self.left[:], self.right[:])
        self._start_angle = self._angle
        self.left, self.right, self.tilt = left, right, tilt
        self.setAccessibleDescription('Левая чаша: %s. Правая чаша: %s.' %
                                      (', '.join(map(str, left)) or 'пусто', ', '.join(map(str, right)) or 'пусто'))
        if self._motion and self.isVisible() and self._initialized:
            self._progress = 0.0
            self._clock.start(); self._timer.start()
        else:
            self.stop_animation()
        self._initialized = True
        self._invalidate()

    def celebrate(self):
        if self._motion and self.isVisible():
            self._celebration.start(); self._timer.start(); self._invalidate()

    def stop_animation(self):
        self._timer.stop(); self._clock.invalidate(); self._celebration.invalidate()
        self._angle = float(self.tilt); self._progress = 1.0
        self._old = (self.left[:], self.right[:])
        self._invalidate()

    def hideEvent(self, event):
        self.stop_animation()
        super().hideEvent(event)

    def _invalidate(self):
        self._cache_key = None; self.update()

    def _tick(self):
        moving = False
        if self._clock.isValid():
            self._progress = min(1.0, self._clock.elapsed()/self.DURATION)
            t = self._progress
            eased = (1-math.exp(-7*t)*math.cos(2*math.pi*t))/(1-math.exp(-7))
            self._angle = self._start_angle+(self.tilt-self._start_angle)*eased
            if t >= 1:
                self._angle = float(self.tilt); self._clock.invalidate()
                self._old = (self.left[:], self.right[:])
            else:
                moving = True
        if self._celebration.isValid():
            if self._celebration.elapsed() >= self.CELEBRATION_DURATION:
                self._celebration.invalidate()
            else:
                moving = True
        if not moving:
            self._timer.stop()
        self._invalidate()

    def _geometry(self):
        scale = min(1.1, self.width()/1000, self.height()/360)
        w, h = self.width()/scale, self.height()/scale
        arm = min(w*.235, 250)
        clearance = arm*math.sin(math.radians(6))
        return scale, w, h, arm, clearance

    def paintEvent(self, event):
        ratio = self.devicePixelRatioF()
        key = (self.width(), self.height(), ratio, self.font().family())
        if key != self._stage_key:
            self._stage = QPixmap(round(self.width()*ratio), round(self.height()*ratio))
            self._stage.setDevicePixelRatio(ratio); self._stage.fill(Qt.GlobalColor.transparent)
            p = QPainter(self._stage); p.setRenderHint(QPainter.RenderHint.Antialiasing)
            self._draw_stage(p); p.end(); self._stage_key = key
            self._cache_key = None
        frame_key = (key, self._angle, self._progress, tuple(self.left), tuple(self.right),
                     self._celebration.elapsed()//33 if self._celebration.isValid() else -1)
        if frame_key != self._cache_key:
            self._cache = self._stage.copy()
            painter = QPainter(self._cache)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            self.draw_balance(painter); painter.end()
            self._cache_key = frame_key
        painter = QPainter(self); painter.drawPixmap(0, 0, self._cache); painter.end()

    def _draw_stage(self, p):
        w, h = self.width(), self.height()
        draw_workshop(p,w,h)
        p.setPen(QPen(QColor('#dbc9a9'),1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(1,1,w-2,h-2),24,24)
        p.save()
        scale, width, height, arm, clearance = self._geometry()
        p.scale(scale, scale)
        cx, cy, floor = width/2, max(40, clearance+18), height-19
        radius=min(width*.135,145)
        for direction in [-1,1]:soft_shadow(p,cx+direction*arm,height-22,radius*.87,11,56)
        soft_shadow(p,cx+6,floor,131,14,86)
        p.setPen(Qt.PenStyle.NoPen)
        # The base is a short elliptical cylinder with a lit top and a deep front.
        p.setBrush(gradient(floor-30,31,'#4b9c8d','#286e67'))
        p.drawRoundedRect(QRectF(cx-104, floor-26, 208, 26), 12, 12)
        p.setBrush(gradient(floor-40,24,'#a8d8be','#5db097'))
        p.setPen(QPen(QColor('#34796e'), 1.6)); p.drawEllipse(QRectF(cx-104, floor-39, 208, 27))
        p.setPen(QPen(QColor('#d7f2d8'), 2));p.drawArc(QRectF(cx-98, floor-36, 196, 23), 0, 180*16)
        # Three faces of the upright, including a narrow illuminated edge.
        polygon(p, [(cx,cy+8),(cx-37,floor-31),(cx+8,floor-23),(cx+12,cy+13)],
                gradient(cy,floor-cy,'#87c8af','#3c8d7a'))
        polygon(p, [(cx+12,cy+13),(cx+8,floor-23),(cx+39,floor-32),(cx+22,cy+13)],
                QColor('#2e7769'))
        polygon(p, [(cx,cy+8),(cx+12,cy+13),(cx+22,cy+13),(cx+7,cy+5)], QColor('#c7ead0'))
        p.setPen(QPen(QColor('#bde7c9'), 2));p.drawLine(QPointF(cx-1,cy+36),QPointF(cx-23,floor-44))
        p.restore()

    def draw_balance(self, p):
        scale, w, h, arm, clearance = self._geometry()
        p.save();p.scale(scale, scale)
        cx, cy = w/2, max(40, clearance+18)
        radius = min(w*.135, 145)
        # Ground shadows live in the immutable background cache.
        p.save();p.translate(cx, cy);p.rotate(self._angle)
        beam = [(-arm,-9),(-9,-14),(arm,-9),(arm,7),(0,13),(-arm,7)]
        polygon(p, [(x+3,y+7) for x,y in beam], QColor('#ce9633'), QPen(QColor('#916322'),1.5))
        polygon(p, beam, QColor('#f3c14e'), QPen(QColor('#bd8b27'),1.6))
        polygon(p, [(-arm,-9),(-arm+7,-14),(6,-20),(arm+7,-14),(arm,-9),(-9,-14)], QColor('#fff2b9'))
        p.setPen(QPen(QColor('#fff6cd'), 2));p.drawLine(QPointF(-arm+17,-5),QPointF(arm-17,-5))
        for x in [-arm, arm]:
            self._orb(p, x, 0, 12, '#fff2ba', '#c58e26', '#9e7429')
            p.setBrush(QColor('#725839'));p.setPen(Qt.PenStyle.NoPen);p.drawEllipse(QPointF(x,2),3,3)
        p.restore()
        radians = math.radians(self._angle)
        self.attachments = []
        for index, (direction, values) in enumerate([(-1,self.left),(1,self.right)]):
            x = cx+direction*arm*math.cos(radians)
            y = cy+direction*arm*math.sin(radians)
            rim = h-110-clearance+direction*arm*math.sin(radians)
            light, middle, dark = ('#b2edf0','#4bbfd0','#278c9f') if index==0 else ('#ffe0c0','#f3977c','#c7705b')
            p.setPen(QPen(QColor('#77738d'), 1.6));p.setBrush(gradient(y+8, 18, '#ffffff','#ada8c4'))
            p.drawEllipse(QRectF(x-6,y+9,12,17))
            for edge in [-1,1]:
                start, end = QPointF(x+edge*3,y+24), QPointF(x+edge*(radius-8),rim+1)
                self.chain(p,start,end,1)
                self.attachments.append((QPointF(start.x()*scale,start.y()*scale),QPointF(end.x()*scale,end.y()*scale)))
            # Concave bowl: back rim, inner well, front shell and reflection.
            p.setPen(QPen(QColor(dark), 1.8));p.setBrush(gradient(rim-14, 29, light,dark))
            p.drawEllipse(QRectF(x-radius,rim-14,radius*2,28))
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(gradient(rim-10, 20, dark,middle))
            p.drawEllipse(QRectF(x-radius+6,rim-10,radius*2-12,20))
            shell=QPainterPath(QPointF(x-radius,rim))
            shell.cubicTo(x-radius*.85,rim+48,x+radius*.85,rim+48,x+radius,rim)
            shell.quadTo(x,rim+24,x-radius,rim)
            p.setPen(QPen(QColor(dark),1.6));p.setBrush(QColor(middle));p.drawPath(shell)
            lower=QPainterPath(QPointF(x-radius,rim))
            lower.cubicTo(x-radius*.85,rim+48,x+radius*.85,rim+48,x+radius,rim)
            lower.cubicTo(x+radius*.78,rim+34,x-radius*.78,rim+34,x-radius,rim)
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(dark));p.drawPath(lower)
            p.setPen(QPen(QColor(light),2.5));shine=QPainterPath(QPointF(x-radius+18,rim+10))
            shine.cubicTo(x-radius*.45,rim+34,x+radius*.40,rim+34,x+radius*.68,rim+18);p.drawPath(shine)
            self._draw_blocks(p,values,self._old[index],x,rim,radius,scale)
            # Front lip partly occludes the block feet, grounding them in the bowl.
            lip=QPainterPath(QPointF(x-radius,rim))
            lip.quadTo(x,rim+24,x+radius,rim);lip.quadTo(x,rim+15,x-radius,rim)
            p.setPen(QPen(QColor(dark),1.3));p.setBrush(gradient(rim,18,light,middle));p.drawPath(lip)
            p.setPen(QPen(QColor('#f5ffff' if index==0 else '#fff1ea'),2.2))
            shine=QPainterPath(QPointF(x-radius+6,rim+1));shine.quadTo(x,rim+18,x+radius-6,rim+1);p.drawPath(shine)
            for edge in [-1,1]:
                self._orb(p,x+edge*(radius-8),rim+1,4,'#ffffff','#9b96b5','#68627e')
        self._orb(p,cx+3,cy+4,26,'#c99a36','#9d7028','#805927')
        self._orb(p,cx,cy,26,'#fff4b7','#e7ac27','#bd8729')
        self._orb(p,cx,cy,12,'#d6f3d4','#489884','#2b7469')
        p.setPen(QPen(QColor('#e8ffe6'),1.5));p.drawLine(QPointF(cx-4,cy),QPointF(cx+4,cy))
        if self._celebration.isValid():
            self._draw_celebration(p,cx,cy,h)
        p.restore()

    @staticmethod
    def _orb(p,x,y,r,light,dark,edge):
        g=QRadialGradient(QPointF(x-r*.30,y-r*.40),r*1.45)
        g.setColorAt(0,QColor(light));g.setColorAt(1,QColor(dark))
        p.setPen(QPen(QColor(edge),1.3));p.setBrush(QBrush(g));p.drawEllipse(QPointF(x,y),r,r)

    @staticmethod
    def _items(values):
        return list(map(str, values)) if len(values)<=5 else [' · '.join(map(str,values))]

    def _draw_blocks(self,p,values,old_values,x,rim,radius,scale):
        items, old = self._items(values), self._items(old_values)
        counts = Counter(old); new_flags=[]
        for item in items:
            new_flags.append(counts[item]==0)
            if counts[item]:counts[item]-=1
        def widths(strings):
            sizes=[54 if len(text)<=2 else min(2*radius-35,232) for text in strings]
            available=2*radius-26-max(0,len(strings)-1)*9
            factor=min(1,available/max(1,sum(sizes)))
            return [size*factor for size in sizes]
        sizes=widths(items); bx=x-(sum(sizes)+max(0,len(items)-1)*9)/2
        for text,bw,new in zip(items,sizes,new_flags):
            t=self._progress
            lift=(-28*(1-t)**2) if new else 0
            p.save()
            if new:p.setOpacity(.35+.65*min(1,t*3))
            p.drawPixmap(QPointF(bx-2,rim-58-11+lift),self._block_sprite(text,bw,scale))
            p.restore();bx+=bw+9
        # Removed blocks rise and fade, then leave the cacheable final scene.
        if self._progress<1:
            sizes=widths(old);bx=x-(sum(sizes)+max(0,len(old)-1)*9)/2
            removed=Counter(old)-Counter(items)
            for text,bw in zip(old,sizes):
                if removed[text]:
                    p.save();p.setOpacity((1-self._progress)*.65)
                    p.drawPixmap(QPointF(bx-2,rim-69-24*self._progress),self._block_sprite(text,bw,scale));p.restore()
                    removed[text]-=1
                bx+=bw+9

    def _block_sprite(self,text,width,scale):
        ratio=self.devicePixelRatioF()*scale
        key=(text,width,round(ratio,5),self.font().family())
        if key in self._sprites:
            self._sprites.move_to_end(key);return self._sprites[key]
        depth,height=10,58
        sprite=QPixmap(math.ceil((width+depth+4)*ratio),math.ceil((height+depth+5)*ratio))
        sprite.setDevicePixelRatio(ratio);sprite.fill(Qt.GlobalColor.transparent)
        p=QPainter(sprite);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.translate(2,depth+1)
        is_x='x' in text.lower();negative=text.startswith(('−','-'))
        front,shade,top,edge,ink=('#55c3de','#2b91ac','#b6eaf1','#3486a1','#16495d') if is_x else (
            ('#f4a18c','#ca7565','#ffdac0','#bc6e61','#672e35') if negative else
            ('#ffd66b','#dca43d','#fff0b1','#c69437','#604514'))
        polygon(p,[(width,0),(width+depth,-depth),(width+depth,height-depth),(width,height)],gradient(0,height,front,shade),QPen(QColor(edge),1))
        polygon(p,[(0,0),(depth,-depth),(width+depth,-depth),(width,0)],QColor(top),QPen(QColor(edge),1))
        p.setPen(QPen(QColor(edge),1.5));p.setBrush(QColor(front));p.drawRoundedRect(QRectF(0,0,width,height),6,6)
        p.setPen(QPen(QColor(top),2));p.drawLine(QPointF(7,5),QPointF(width-7,5))
        font=QFont(self.font());font.setPixelSize(33 if len(text)<=2 else 20);font.setBold(True);p.setFont(font)
        # Shrink long exact expressions until they fit; never clip the mathematical label.
        while p.fontMetrics().horizontalAdvance(text)>width-10 and font.pixelSize()>12:
            font.setPixelSize(font.pixelSize()-1);p.setFont(font)
        p.setPen(QColor(ink));p.drawText(QRectF(2,0,width-4,height),int(Qt.AlignmentFlag.AlignCenter),text);p.end()
        self._sprites[key]=sprite
        while len(self._sprites)>64:self._sprites.popitem(last=False)
        return sprite

    def _draw_celebration(self,p,cx,cy,h):
        t=min(1,self._celebration.elapsed()/self.CELEBRATION_DURATION)
        p.save();p.setOpacity((1-t)**.65);p.setPen(Qt.PenStyle.NoPen)
        colors=['#f0b936','#1dbaaa','#8d79d9','#ec8196']
        for i in range(12):
            angle=math.radians(25+i*360/12)
            distance=36+105*t
            x,y=cx+math.cos(angle)*distance,cy+38+math.sin(angle)*distance*.65-18*t
            p.save();p.translate(x,y);p.rotate(i*31+t*100);p.setBrush(QColor(colors[i%4]))
            if i%2:p.drawRoundedRect(QRectF(-3,-5,6,10),1.5,1.5)
            else:
                star=[]
                for j in range(10):
                    r=7 if j%2==0 else 3
                    a=math.radians(-90+j*36);star.append((math.cos(a)*r,math.sin(a)*r))
                polygon(p,star,QColor(colors[i%4]))
            p.restore()
        p.restore()

    @staticmethod
    def chain(p,start,end,scale):
        dx,dy=end.x()-start.x(),end.y()-start.y()
        length=math.hypot(dx,dy);count=max(2,min(30,round(length/12)))
        step=length/count
        p.save();p.translate(start);p.rotate(math.degrees(math.atan2(dy,dx))-90)
        for i in range(count):
            wide=3.6 if i%2==0 else 2.5
            p.setPen(QPen(QColor('#666780'),2.2));p.setBrush(QColor('#d5dae8'))
            p.drawEllipse(QRectF(-wide,i*step-2,wide*2,step+4))
            p.setPen(QPen(QColor('#ffffff'),1.2));p.drawArc(QRectF(-wide+1,i*step-1,wide*2-2,step+2),20*16,170*16)
        p.restore()
