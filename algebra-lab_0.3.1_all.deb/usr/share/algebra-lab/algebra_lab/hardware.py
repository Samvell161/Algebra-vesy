"""One UID per presentation. No assumption of bulk RFID inventory or measured algebra."""
import threading
import time
from collections import deque

from .math_engine import Linear
from fractions import Fraction

BLOCKS = {
    "x": {"label": "x", "a": 1, "b": 0},
    "-x": {"label": "−x", "a": -1, "b": 0},
    "1": {"label": "+1", "a": 0, "b": 1},
    "-1": {"label": "−1", "a": 0, "b": -1},
    "2": {"label": "+2", "a": 0, "b": 2},
    "-2": {"label": "−2", "a": 0, "b": -2},
    "5": {"label": "+5", "a": 0, "b": 5},
}


def normalize_uid(uid):
    uid = str(uid).strip().upper()
    if not uid or len(uid) > 64 or not all(c in "0123456789ABCDEF:-" for c in uid):
        raise ValueError("UID: используйте до 64 символов 0–9, A–F, : или −.")
    return uid


def expression(blocks):
    result = Linear()
    for block in blocks:
        kind = BLOCKS[block["kind"]]
        result += Linear(Fraction(kind["a"]), Fraction(kind["b"]))
    return result


class Reader:
    def __init__(self, mode="simulator"):
        self.mode = mode
        self.error = None
        self.events = deque(maxlen=100)
        self.sequence = 0
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.driver = None
        self.configure(mode)

    def configure(self, mode):
        if mode not in ("simulator", "rc522"):
            raise ValueError("Неизвестный режим считывателя.")
        self.close()
        if self.thread and self.thread.is_alive():
            raise OSError("Предыдущий опрос ещё завершается. Повторите подключение.")
        self.mode, self.error, self.driver = mode, None, None
        self.stop_event = threading.Event()
        if mode == "rc522":
            self.thread = threading.Thread(target=self._connect, daemon=True)
            self.thread.start()

    def _connect(self):
        try:
            from .rc522 import RC522
            self.driver = RC522()
            self._poll()
        except ImportError:
            self.error = "Нужны системные библиотеки. В терминале: sudo apt install python3-spidev python3-rpi.gpio"
        except Exception as exc:
            self.error = "RC522 недоступен: " + str(exc)
        finally:
            if self.driver:
                self.driver.close()
                self.driver = None

    def _poll(self):
        last = None
        absent_since = None
        try:
            while not self.stop_event.wait(0.12):
                uid = self.driver.read_id_no_block()
                if uid is None:
                    absent_since = absent_since or time.monotonic()
                    if time.monotonic() - absent_since > 0.6:
                        last = None
                    continue
                absent_since = None
                uid = format(uid, "X")
                if uid != last:
                    with self.lock:
                        self.sequence += 1
                        self.events.append({"sequence": self.sequence, "uid": uid})
                    last = uid
        except Exception as exc:
            self.error = f"Чтение остановлено: {type(exc).__name__}: {exc}. Нажмите «Считать метку» для повторного подключения."

    def status(self):
        return {"mode": self.mode, "connected": self.driver is not None and self.error is None,
                "error": self.error, "hx711": "not_configured", "sequence": self.sequence}

    def since(self, sequence):
        with self.lock:
            return [event.copy() for event in self.events if event["sequence"] > sequence]

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=0.3)
