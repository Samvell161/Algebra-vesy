"""Small seeded walkers on reserved floor corridors, independent of lessons.

Only positions, speeds and timers change. No navigation library, geometry
rebuilds or extra GUI timer is needed. Cars share a lane and yield to the car
ahead; the robot has its own corridor in front of it.
"""
import math
import random


RADIUS = .90
X = 6.25
BOTTOM = -.84
TOP = 1.10
HORIZONTAL = 2 * (X - RADIUS)
VERTICAL = TOP - BOTTOM - 2 * RADIUS
ARC = math.pi * RADIUS / 2
LENGTH = 2 * HORIZONTAL + 2 * VERTICAL + 4 * ARC
CAR_GAP = 2.20
ROBOT_Y = -1.55


def lane(distance):
    """Position and unit tangent on a rounded rectangular, obstacle-free lane."""
    s = distance % LENGTH
    segments = [
        (HORIZONTAL, (-X + RADIUS, BOTTOM), (1, 0), None),
        (ARC, (X - RADIUS, BOTTOM + RADIUS), None, -math.pi / 2),
        (VERTICAL, (X, BOTTOM + RADIUS), (0, 1), None),
        (ARC, (X - RADIUS, TOP - RADIUS), None, 0),
        (HORIZONTAL, (X - RADIUS, TOP), (-1, 0), None),
        (ARC, (-X + RADIUS, TOP - RADIUS), None, math.pi / 2),
        (VERTICAL, (-X, TOP - RADIUS), (0, -1), None),
        (ARC, (-X + RADIUS, BOTTOM + RADIUS), None, math.pi),
    ]
    for length, origin, tangent, angle in segments:
        if s <= length:
            if tangent is not None:
                return origin[0] + tangent[0] * s, origin[1] + tangent[1] * s, *tangent
            a = angle + s / RADIUS
            return origin[0] + RADIUS * math.cos(a), origin[1] + RADIUS * math.sin(a), -math.sin(a), math.cos(a)
        s -= length
    return lane(0)  # Floating-point roundoff at the end of a lap.


class _Car:
    ACCELERATION = .85

    def __init__(self, rng, position):
        self.rng = rng
        self.position = position
        self.distance = 0.0
        self.speed = 0.0
        self.remaining = 0.0
        self.pause = rng.uniform(.2, 1.6)
        self.cruise = 0.0

    def step(self, dt, gap):
        if self.pause > 0:
            self.pause = max(0.0, self.pause - dt)
            return
        if self.remaining <= 1e-7:
            self.remaining = self.rng.uniform(2.5, 10.5)
            self.cruise = self.rng.uniform(.75, 1.35)
        clearance = max(0.0, gap - CAR_GAP)
        target = min(self.cruise, math.sqrt(2 * self.ACCELERATION * self.remaining),
                     math.sqrt(2 * self.ACCELERATION * max(0.0, clearance - .12)))
        previous = self.speed
        delta = self.ACCELERATION * dt
        self.speed = max(previous - delta, min(previous + delta, target))
        proposed = (previous + self.speed) * .5 * dt
        move = min(proposed, self.remaining, clearance)
        self.position = (self.position + move) % LENGTH
        self.distance += move
        self.remaining -= move
        if move < proposed:
            self.speed = max(0.0, 2 * move / dt - previous)
        if self.remaining <= 1e-7:
            self.remaining = 0.0
            self.speed = 0.0
            self.pause = self.rng.uniform(.6, 2.6)


class _Robot:
    def __init__(self, rng):
        self.rng = rng
        self.x = -5.8
        self.heading = 90.0
        self.start = self.x
        self.target = self.x
        self.phase = 'pause'
        self.time = 0.0
        self.duration = rng.uniform(.3, 1.1)
        self.stride = 0.0

    def _next(self):
        self.time = 0.0
        if self.phase == 'pause':
            candidates = [x for x in (-5.8, -4.1, -2.3, -.2, 2.1, 4.0, 5.8) if abs(x - self.x) >= 3.4]
            self.target = self.rng.choice(candidates)
            self.start = self.x
            self.turn_start = self.heading
            desired = 90.0 if self.target > self.x else -90.0
            self.turn_delta = (desired - self.heading + 180) % 360 - 180
            self.phase = 'turn'
            self.duration = self.rng.uniform(1.1, 1.5) if self.turn_delta else .15
        elif self.phase == 'turn':
            self.phase = 'walk'
            self.duration = abs(self.target - self.start) / self.rng.uniform(1.05, 1.48) + .4
        else:
            self.x = self.target
            self.phase = 'pause'
            self.duration = self.rng.uniform(.7, 2.8)

    def step(self, dt):
        self.time = min(self.duration, self.time + dt)
        self.stride = 0.0
        if self.phase == 'turn':
            u = self.time / self.duration
            self.heading = self.turn_start + self.turn_delta * u * u * (3 - 2 * u)
        elif self.phase == 'walk':
            t, duration, ramp = self.time, self.duration, .4
            if t < ramp:travel = t * t / (2 * ramp)
            elif t > duration - ramp:travel = duration - ramp - (duration - t) ** 2 / (2 * ramp)
            else:travel = t - ramp / 2
            self.x = self.start + (self.target - self.start) * travel / (duration - ramp)
            # The gait fades with walking speed, so feet land before a pause.
            envelope = min(1.0, t / ramp, (duration - t) / ramp)
            self.stride = math.sin(t * math.tau / .8) * max(0.0, envelope)
        if self.time >= self.duration:self._next()


class RoomTraffic:
    def __init__(self, seed=None):
        rng = random.Random(seed)
        self.direction = rng.choice((-1, 1))
        start = rng.uniform(0, LENGTH)
        self.cars = [_Car(random.Random(rng.getrandbits(64)), (start + i * LENGTH / 2) % LENGTH) for i in range(2)]
        self.robot = _Robot(random.Random(rng.getrandbits(64)))

    def advance(self, car_seconds, robot_seconds):
        # Substeps also make test/replay calls safe at lower frame rates.
        duration = max(0.0, car_seconds, robot_seconds)
        count = max(1, math.ceil(duration / .025))
        for _ in range(count):
            if car_seconds > 0:
                positions = [car.position for car in self.cars]
                for i, car in enumerate(self.cars):
                    gap = (positions[1 - i] - positions[i]) % LENGTH
                    car.step(car_seconds / count, gap)
            if robot_seconds > 0:self.robot.step(robot_seconds / count)

    def car_poses(self):
        from .room_motion import CarPose
        result = []
        for car in self.cars:
            x, y, dx, dy = lane(self.direction * car.position)
            heading = math.degrees(math.atan2(self.direction * dx, -self.direction * dy))
            result.append(CarPose(x, y, heading, car.distance * 500))
        return tuple(result)
