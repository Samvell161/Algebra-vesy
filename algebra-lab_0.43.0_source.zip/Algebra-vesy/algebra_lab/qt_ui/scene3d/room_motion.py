"""Bounded, slow room movement; no mesh rebuilds or simulation state."""
import math
from dataclasses import dataclass

@dataclass(frozen=True)
class CarPose:
    x:float
    y:float
    heading:float
    wheel:float

@dataclass(frozen=True)
class RoomPose:
    clouds:tuple
    robot_x:float
    robot_y:float
    robot_heading:float
    robot_bob:float
    feet:tuple
    foot_stride:tuple
    arms:tuple
    owl_angle:float
    pendulum:float
    cars:tuple

ROBOT_WALK=8.0
ROBOT_TURN=1.2
ROBOT_CYCLE=2*(ROBOT_WALK+ROBOT_TURN)
ROBOT_Y=-1.55
CAR_RADII=(6.25,.90)

def _travel(t):
    # Short acceleration/deceleration zones, then a steady walking speed.
    ramp=.4;duration=ROBOT_WALK
    if t<ramp:distance=t*t/(2*ramp)
    elif t>duration-ramp:distance=duration-ramp-(duration-t)**2/(2*ramp)
    else:distance=t-ramp/2
    return distance/(duration-ramp)

def _smooth(t):return t*t*(3-2*t)

def room_pose(seconds,car_seconds=None,robot_seconds=None,traffic=None):
    t=max(0.0,seconds)
    robot_time=t if robot_seconds is None else max(0.0,robot_seconds)
    stage=robot_time%ROBOT_CYCLE
    returning=stage>=ROBOT_WALK+ROBOT_TURN
    local=stage-(ROBOT_WALK+ROBOT_TURN if returning else 0)
    turning=local>=ROBOT_WALK
    progress=_travel(min(ROBOT_WALK,local))
    x=5.8-11.6*progress if returning else -5.8+11.6*progress
    heading=-90 if returning else 90
    if turning:
        u=_smooth(min(1,(local-ROBOT_WALK)/ROBOT_TURN))
        heading+=180*u if returning else -180*u
    stride=0.0 if turning else math.sin(local*math.tau/.8)
    arms=(27*stride,-27*stride)
    # Visible, leisurely yaw around the vertical neck axis, not a tiny roll.
    owl=30*math.sin(t*math.tau/7.2)
    cars=[]
    car_time=t if car_seconds is None else max(0.0,car_seconds)
    for index in range(2):
        a=car_time*math.tau/16+index*math.pi
        dx,dy=-CAR_RADII[0]*math.sin(a),CAR_RADII[1]*math.cos(a)
        cars.append(CarPose(CAR_RADII[0]*math.cos(a),CAR_RADII[1]*math.sin(a),
                            math.degrees(math.atan2(dx,-dy)),car_time*300))
    robot_y=ROBOT_Y
    if traffic is not None:
        robot=traffic.robot
        x,robot_y,heading,stride=robot.x,ROBOT_Y,robot.heading,robot.stride
        arms=(27*stride,-27*stride)
        cars=traffic.car_poses()
    return RoomPose((.8*math.sin(t*math.tau/22),.65*math.sin(t*math.tau/29),.7*math.sin(t*math.tau/25)),
                    x,robot_y,heading,.018*stride*stride,
                    (.095*max(0.0,stride),.095*max(0.0,-stride)),
                    (-.10*stride,.10*stride),arms,owl,8*math.sin(t*math.tau/2.4),tuple(cars))
