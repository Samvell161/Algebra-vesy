"""Seeded foreground traffic: varied trips, no clipping/collisions or jumps."""
import math
import unittest
from algebra_lab.qt_ui.scene3d.traffic import RoomTraffic,CAR_GAP,LENGTH,ROBOT_Y
from algebra_lab.qt_ui.scene3d.room_motion import room_pose
from algebra_lab.qt_ui.scene3d.scene_effects import SceneEffects


class RandomTrafficTests(unittest.TestCase):
    def test_seeds_reproduce_routes_and_different_launches_vary(self):
        a,b,c=[RoomTraffic(seed) for seed in (7,7,9)]
        traces=[[],[],[]]
        for _ in range(1800):
            for traffic,trace in zip((a,b,c),traces):
                traffic.advance(1/30,1/30)
                trace.append((traffic.car_poses(),traffic.robot.x,traffic.robot.heading))
        self.assertEqual(traces[0],traces[1]);self.assertNotEqual(traces[0],traces[2])

    def test_long_runs_keep_clear_of_base_toys_robot_lane_and_each_other(self):
        for seed in range(12):
            traffic=RoomTraffic(seed)
            for frame in range(9000):
                traffic.advance(1/30,1/30)
                if frame%7:continue
                cars=traffic.car_poses()
                for car in cars:
                    angle=math.radians(car.heading)
                    hx=.26*abs(math.cos(angle))+.37*abs(math.sin(angle))
                    hy=.26*abs(math.sin(angle))+.37*abs(math.cos(angle))
                    self.assertTrue(abs(car.x)-hx>1.25 or abs(car.y)-hy>.55,(seed,frame,car))
                    self.assertGreater(car.y-hy,ROBOT_Y+.34)
                    self.assertLess(abs(car.x)+hx,7.4)
                    self.assertLess(abs(car.y)+hy,3.0)
                    for x in [-4.7,4.7]:
                        self.assertTrue(abs(car.x-x)>hx+.47 or car.y-hy>.57 or car.y+hy<-.36,(seed,frame,car))
                a,b=cars
                self.assertGreater(math.hypot(a.x-b.x,a.y-b.y),1.7)
                separation=(traffic.cars[0].position-traffic.cars[1].position)%LENGTH
                self.assertGreaterEqual(min(separation,LENGTH-separation),CAR_GAP-1e-9)
                self.assertLessEqual(abs(traffic.robot.x),5.8+1e-9)

    def test_pauses_variable_destinations_and_continuity(self):
        traffic=RoomTraffic(19);previous=room_pose(0,traffic=traffic)
        stops=set();robot_stops=set();max_car_step=0;max_robot_step=0
        for _ in range(18000):
            traffic.advance(1/30,1/30)
            pose=room_pose(0,traffic=traffic)
            for car,old,state in zip(pose.cars,previous.cars,traffic.cars):
                step=math.hypot(car.x-old.x,car.y-old.y);max_car_step=max(max_car_step,step)
                self.assertLess(step,.047)
                turn=(car.heading-old.heading+180)%360-180
                self.assertLess(abs(turn),3.1)
                if state.pause>0:stops.add(round(state.position,1))
            max_robot_step=max(max_robot_step,abs(pose.robot_x-previous.robot_x))
            self.assertLess(abs(pose.robot_x-previous.robot_x),.056)
            self.assertLess(abs(pose.robot_heading-previous.robot_heading),9)
            self.assertLess(abs(pose.arms[0]-previous.arms[0]),8)
            if traffic.robot.phase=='pause':
                robot_stops.add(round(traffic.robot.x,1));self.assertEqual(pose.feet,(0,0))
            previous=pose
        self.assertGreater(len(stops),20);self.assertGreater(len(robot_stops),4)
        self.assertGreater(max_car_step,.02);self.assertGreater(max_robot_step,.03)

    def test_background_freezes_and_keeps_routes_on_new_lesson(self):
        fx=SceneEffects(traffic_seed=23)
        for _ in range(90):fx.advance(1/30)
        def pose():return room_pose(0,traffic=fx.traffic)
        before=pose();fx.advance(.1,ambient=False);self.assertEqual(before,pose())
        fx.advance(.1,motion=False);self.assertEqual(before,pose())
        fx.lesson('new',True,None);self.assertEqual(before,pose())
        for _ in range(60):fx.advance(1/30)
        self.assertLess(fx.car_speed,.023);self.assertLess(fx.robot_speed,.023)
