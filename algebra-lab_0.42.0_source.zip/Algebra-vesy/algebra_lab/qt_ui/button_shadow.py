"""Soft cached button shadows without a live blur filter per widget."""
import math
from functools import lru_cache
from PyQt6.QtCore import QObject,QEvent,QRectF,QPointF,QPoint,Qt
from PyQt6.QtGui import QPainter,QColor,QPixmap
from PyQt6.QtWidgets import QApplication,QGraphicsEffect,QPushButton

@lru_cache(maxsize=64)
def shadow_image(width,height,ratio,radius):
    image=QPixmap(math.ceil((width+4)*ratio),math.ceil((height+4)*ratio))
    image.setDevicePixelRatio(ratio);image.fill(Qt.GlobalColor.transparent)
    p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
    for spread,alpha in [(2,4),(1,7)]:
        p.setBrush(QColor(42,36,26,alpha))
        p.drawRoundedRect(QRectF(2-spread,2-spread*.4,width+2*spread,height+spread*.8),radius+spread,radius+spread)
    p.end();return image

class ButtonShadow(QGraphicsEffect):
    def boundingRectFor(self,rect):return rect.adjusted(-2,-1,2,3)
    def draw(self,painter):
        button=self.parent()
        rect=self.sourceBoundingRect(Qt.CoordinateSystem.LogicalCoordinates)
        if rect.isEmpty():return
        radius=36 if button.objectName().startswith('route-') else 11
        image=shadow_image(round(rect.width()),round(rect.height()),round(button.devicePixelRatioF(),3),radius)
        painter.save();painter.setOpacity(.30 if not button.isEnabled() else .45 if button.isDown() else 1)
        painter.drawPixmap(QPointF(rect.x()-2,rect.y()-1),image);painter.restore();self.drawSource(painter)

def painted_bounds(widget,ancestor):
    """Visible bounds including the effect, clipped by parent viewports."""
    rect=QRectF(widget.rect());effect=widget.graphicsEffect()
    if effect is not None and effect.isEnabled():rect=effect.boundingRectFor(rect)
    point=widget.mapTo(ancestor,QPoint(0,0));rect.translate(point.x(),point.y())
    parent=widget.parentWidget()
    while parent is not None:
        point=parent.mapTo(ancestor,QPoint(0,0))
        rect=rect.intersected(QRectF(point.x(),point.y(),parent.width(),parent.height()))
        if parent is ancestor:break
        parent=parent.parentWidget()
    return rect

class ShadowFilter(QObject):
    def eventFilter(self,obj,event):
        if event.type() in (QEvent.Type.Polish,QEvent.Type.Show) and isinstance(obj,QPushButton) and obj.graphicsEffect() is None:
            parent=obj.parentWidget()
            while parent is not None and not getattr(parent,'is_3d',False):parent=parent.parentWidget()
            # Qt does not support graphics effects on an OpenGL-composited
            # subtree. Native 3D overlays keep their QSS depth and touch states.
            if parent is None:obj.setGraphicsEffect(ButtonShadow(obj))
        return False

def install_button_shadows():
    app=QApplication.instance()
    if app is not None and not hasattr(app,'_algebra_button_shadows'):
        app._algebra_button_shadows=ShadowFilter(app)
        app.installEventFilter(app._algebra_button_shadows)
