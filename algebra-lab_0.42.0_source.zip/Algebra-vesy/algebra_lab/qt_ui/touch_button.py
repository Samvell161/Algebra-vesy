"""Touch buttons with a stable, explicitly spaced icon and label.

Qt still paints the QSS frame and handles input/accessibility. Only the label is
laid out here: platform push-button offsets must not move it when pressed.
Long labels in vertical dialog lists grow downwards instead of being clipped.
"""
import math
from PyQt6.QtCore import Qt, QRect, QSize, QEvent, QPointF
from PyQt6.QtGui import QIcon, QPainter, QPen, QColor
from PyQt6.QtWidgets import QPushButton, QStyle, QStyleOptionButton, QSizePolicy, QComboBox


class TouchComboBox(QComboBox):
    """Keep the answer arrow inside its reserved area on every Qt platform."""
    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor('#347c80' if self.isEnabled() else '#94988a'), 2,
            Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        x, y = self.width() - 16, self.height() / 2
        painter.drawLine(QPointF(x - 4, y - 2), QPointF(x, y + 2))
        painter.drawLine(QPointF(x, y + 2), QPointF(x + 4, y - 2))


class TouchButton(QPushButton):
    GAP = 8

    def __init__(self, text='', parent=None, wrap=False):
        self.wrap_label = wrap
        super().__init__(text, parent)
        self.setIconSize(QSize(20, 20))
        policy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        policy.setHeightForWidth(wrap)
        self.setSizePolicy(policy)

    def _option(self):
        option = QStyleOptionButton()
        self.initStyleOption(option)
        return option

    def label_layout(self):
        """Return content, icon, text rectangle and required text bounds in pixels."""
        option = self._option()
        content = self.style().subElementRect(QStyle.SubElement.SE_PushButtonContents, option, self)
        icon_size = self.iconSize() if not self.icon().isNull() else QSize(0, 0)
        gap = self.GAP if icon_size.width() and self.text() else 0
        available = max(1, content.width() - icon_size.width() - gap)
        flags = Qt.AlignmentFlag.AlignCenter | (Qt.TextFlag.TextWordWrap if self.wrap_label else Qt.TextFlag.TextSingleLine)
        bounds = self.fontMetrics().boundingRect(QRect(0, 0, available, 10000), int(flags), self.text())
        width = min(available, max(0, bounds.width()))
        group = width + icon_size.width() + gap
        x = content.x() + (content.width() - group) // 2
        icon_rect = QRect(x, content.y() + (content.height() - icon_size.height()) // 2, icon_size.width(), icon_size.height())
        text_rect = QRect(x + icon_size.width() + gap, content.y(), width, content.height())
        if self.layoutDirection() == Qt.LayoutDirection.RightToLeft:
            icon_rect = QStyle.visualRect(self.layoutDirection(), content, icon_rect)
            text_rect = QStyle.visualRect(self.layoutDirection(), content, text_rect)
        return content, icon_rect, text_rect, bounds

    def paintEvent(self, event):
        option = self._option()
        option.text = ''
        option.icon = QIcon()
        painter = QPainter(self)
        self.style().drawControl(QStyle.ControlElement.CE_PushButton, option, painter, self)
        content, icon_rect, text_rect, _ = self.label_layout()
        painter.setClipRect(content)
        mode = QIcon.Mode.Normal if self.isEnabled() else QIcon.Mode.Disabled
        if not self.icon().isNull():
            state = QIcon.State.On if self.isChecked() else QIcon.State.Off
            self.icon().paint(painter, icon_rect, Qt.AlignmentFlag.AlignCenter, mode, state)
        painter.setFont(self.font())
        painter.setPen(self.palette().buttonText().color())
        flags = Qt.AlignmentFlag.AlignCenter | (Qt.TextFlag.TextWordWrap if self.wrap_label else Qt.TextFlag.TextSingleLine)
        painter.drawText(text_rect, int(flags), self.text())

    def heightForWidth(self, width):
        if not self.wrap_label:
            return self.sizeHint().height()
        self.ensurePolished()
        option = self._option()
        option.rect = QRect(0, 0, max(1, width), 1000)
        content = self.style().subElementRect(QStyle.SubElement.SE_PushButtonContents, option, self)
        reserve = self.iconSize().width() + self.GAP if not self.icon().isNull() else 0
        bounds = self.fontMetrics().boundingRect(QRect(0, 0, max(1, content.width() - reserve), 10000),
            int(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap), self.text())
        return max(44, math.ceil(bounds.height()) + 1000 - content.height())

    def minimumSizeHint(self):
        if self.wrap_label:
            return QSize(80, 44)
        return self.sizeHint()

    def sizeHint(self):
        size = super().sizeHint()
        if self.wrap_label:
            size.setWidth(min(480, size.width()))
        elif not self.icon().isNull() and self.text():
            # Native styles may reserve only four pixels between icon and text.
            size.setWidth(size.width() + self.GAP)
        size.setHeight(max(44, size.height()))
        return size

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.wrap_label and self.maximumHeight() >= 44:
            height = self.heightForWidth(self.width())
            if self.minimumHeight() != height:
                self.setMinimumHeight(height)

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() in (QEvent.Type.FontChange, QEvent.Type.StyleChange):
            self.updateGeometry()
