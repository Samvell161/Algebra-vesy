"""OpenGL 2.1 / GLES 2 renderer: fixed frontal projection, depth, normals and shadow map.

Uses standard PyOpenGL and Qt's OpenGL widget. Geometry is uploaded once;
the room never comes from an image. Only block lettering uses small textures.
"""
import ctypes
import math
import os
import weakref
from array import array
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from PyQt6.QtCore import Qt,QTimer,pyqtSignal
from PyQt6.QtGui import QMatrix4x4,QVector3D,QImage,QPainter,QFont,QColor
from PyQt6.QtOpenGL import QOpenGLWindow
from .gl_api import GL,compileShader
from .model import build_workshop,PIVOT,ARM,RIM,RADIUS,CLOCK,HERO_SCALE
from .quality import quality
from .lighting import WINDOW_DIRECTION,LAMP_POSITION,LAMP_DIRECTION
from .room_light import ATLAS_WIDTH,ATLAS_HEIGHT,owl_openness
from .room_motion import room_pose
from .scene_effects import landing_shadow

_executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='algebra-mesh')
_futures={}

VERTEX='''
attribute vec3 a_position;
attribute vec3 a_normal;
attribute vec3 a_color;
uniform mat4 u_model;
uniform mat4 u_vp;
uniform mat4 u_light;
uniform mat4 u_lamp;
uniform mat3 u_normal;
uniform vec2 u_label_size;
varying vec3 v_world;
varying vec3 v_normal;
varying vec3 v_color;
varying vec4 v_shadow;
varying vec4 v_lamp;
varying vec3 v_label;
varying vec3 v_object;
void main(){
    vec4 world=u_model*vec4(a_position,1.0);
    v_world=world.xyz;v_normal=normalize(u_normal*a_normal);v_color=a_color;
    v_shadow=u_light*world;v_lamp=u_lamp*world;gl_Position=u_vp*world;
    v_object=a_position;
    v_label=vec3(a_position.x/u_label_size.x+.5,a_position.z/u_label_size.y+.5,-a_normal.y);
}
'''
FRAGMENT='''
uniform sampler2D u_shadow;
uniform vec3 u_eye;
uniform vec4 u_finish;
uniform float u_alpha;
uniform float u_shadows;
uniform float u_labelled;
uniform float u_shadow_texel;
uniform sampler2D u_contact_atlas;
uniform sampler2D u_back_label;
uniform float u_two_sided_label;
uniform float u_success_glow;
uniform float u_pan_receiver;
uniform vec4 u_pan_shadows[5];
uniform float u_contact_enabled;
uniform vec4 u_room_contacts[3];
uniform sampler2D u_lamp_shadow;
uniform float u_lamp_texel;
uniform float u_lamp_enabled;
uniform float u_lamp_shadows;
uniform vec3 u_lamp_position;
uniform vec3 u_lamp_direction;
uniform vec3 u_day_direction;
#if DETAIL_MODE
uniform vec4 u_contacts[12];
#endif
uniform sampler2D u_label;
varying vec3 v_world;
varying vec3 v_normal;
varying vec3 v_color;
varying vec4 v_shadow;
varying vec4 v_lamp;
varying vec3 v_label;
varying vec3 v_object;
float unpackDepth(vec4 v){return dot(v.rg,vec2(1.0,1.0/255.0));}
float visibility(vec3 n,vec3 light){
    vec3 q=v_shadow.xyz/v_shadow.w*.5+.5;
    if(q.x<.002||q.x>.998||q.y<.002||q.y>.998||q.z<0.0||q.z>1.0)return 1.0;
    float bias=max(.00145,.0032*(1.0-max(0.0,dot(n,light))));
    float sum=0.0;
    float ground=step(.85,n.z)*(1.0-step(.08,abs(v_world.z)));
    float penumbra=mix(5.0,8.0,ground);
    float shade=mix(.28,.55,ground);
#if DETAIL_MODE
    for(int i=0;i<3;i++)for(int j=0;j<3;j++){
        vec2 offset=(vec2(float(i),float(j))-1.0)*u_shadow_texel*penumbra;
#else
    for(int i=0;i<2;i++)for(int j=0;j<2;j++){
        vec2 offset=(vec2(float(i),float(j))-.5)*u_shadow_texel*3.4;
#endif
        float depth=unpackDepth(texture2D(u_shadow,q.xy+offset));
        sum+=q.z-bias<=depth?1.0:shade;
    }
#if DETAIL_MODE
    return mix(1.0,sum/9.0,u_shadows);
#else
    return mix(1.0,sum*.25,u_shadows);
#endif
}
float lampVisibility(vec3 n,vec3 light){
    vec3 q=v_lamp.xyz/v_lamp.w*.5+.5;
    if(q.x<.002||q.x>.998||q.y<.002||q.y>.998||q.z<0.0||q.z>1.0)return 1.0;
    float bias=max(.0012,.0025*(1.0-max(0.0,dot(n,light))));
    float sum=0.0;
    for(int i=0;i<2;i++)for(int j=0;j<2;j++){
        vec2 offset=(vec2(float(i),float(j))-.5)*u_lamp_texel*1.5;
        float depth=unpackDepth(texture2D(u_lamp_shadow,q.xy+offset));
        sum+=q.z-bias<=depth?1.0:.12;
    }
    return mix(1.0,sum*.25,u_shadows*u_lamp_shadows);
}
void main(){
    vec3 n=normalize(v_normal),l=normalize(u_day_direction);
    vec3 eye=normalize(u_eye-v_world),halfway=normalize(eye+l);
    float vis=visibility(n,l),diff=max(0.0,dot(n,l));
    float wall=1.0-step(-.5,u_finish.z);
    float floorMaterial=step(1.5,u_finish.z)*(1.0-step(2.5,u_finish.z));
    float wood=step(.5,u_finish.z)*(1.0-step(2.5,u_finish.z));
    float grain=1.0;
    if(wood>.5){
        float rings=sin(v_world.x*15.0+sin(v_world.y*.9)*.45+sin(v_world.x*.7)*.5);
        grain=1.0+.008*rings+.002*sin(v_world.x*65.0+v_world.y*.6);
    }
    float roomContact=0.0,windowPool=0.0;
    if(floorMaterial>.5&&n.z>.85){
        vec2 uv=vec2((v_world.x+8.0)/16.0,(v_world.y+3.2)/7.1);
        vec4 field=texture2D(u_contact_atlas,uv);
        roomContact=field.r*u_contact_enabled*(1.0-smoothstep(.015,.075,abs(v_world.z)));
        for(int i=0;i<3;i++){
            vec2 delta=(v_world.xy-u_room_contacts[i].xy)/u_room_contacts[i].zw;
            roomContact=1.0-(1.0-roomContact)*(1.0-.30*exp(-3.0*dot(delta,delta))*u_contact_enabled);
        }
        windowPool=field.b*max(0.0,n.z);
    }
    if(u_contact_enabled>.5&&wall>.5&&n.y<-.85&&v_world.y>3.4){
        roomContact=texture2D(u_contact_atlas,vec2((v_world.x+8.0)/16.0,v_world.z/6.0)).g;
    }
    if(floorMaterial>.5)diff*=mix(.24,1.12,windowPool);
    // Printed faces are matte. Their rounded edges keep the material highlight.
    float printedFace=max(step(.98,v_label.z),u_two_sided_label*step(.98,-v_label.z));
    float specMask=1.0-.94*u_labelled*printedFace;
    vec3 base=pow(v_color,vec3(2.2))*grain;
    float printInk=0.0;
    if(u_labelled>.5){
        vec4 printColor=texture2D(u_label,v_label.xy);
        if(u_two_sided_label>.5&&v_label.z<-.98)printColor=texture2D(u_back_label,vec2(1.0-v_label.x,v_label.y));
        printInk=printColor.a*printedFace;
        base=mix(base,pow(printColor.rgb,vec3(2.2)),printInk);
    }
    vec3 ambient=mix(vec3(.19,.18,.16),vec3(.43,.42,.38),n.z*.5+.5);
    ambient+=vec3(.32,.31,.28)*max(0.0,dot(n,normalize(vec3(-.35,-.80,.7))));
    ambient+=vec3(.19,.20,.20)*max(0.0,dot(n,normalize(vec3(.65,-.75,.35))));
    if(floorMaterial>.5)ambient*=.80;
    if(wall>.5){
        float daylight=exp(-.032*pow(v_world.x+5.6,2.0)-.10*pow(v_world.z-2.7,2.0));
        ambient+=vec3(.19,.145,.085)*daylight;
    }
    ambient*=1.0-roomContact;
    vis*=1.0-roomContact*.28;
    float spec=pow(max(0.0,dot(n,halfway)),u_finish.x)*u_finish.y*vis*specMask;
#if DETAIL_MODE
    // GGX microfacets: enamel, brushed metal and wood keep distinct roughness.
    float roughness=clamp(sqrt(2.0/(u_finish.x+2.0)),.16,.75);
    float a2=roughness*roughness; a2*=a2;
    float nh=max(0.0,dot(n,halfway)),nv=max(.025,dot(n,eye));
    float d=nh*nh*(a2-1.0)+1.0;
    float distribution=a2/(3.141593*d*d);
    float k=(roughness+1.0)*(roughness+1.0)/8.0;
    float geometry=(nv/(nv*(1.0-k)+k))*(diff/(diff*(1.0-k)+k));
    vec3 f0=mix(vec3(.04),base,step(2.5,u_finish.z)*.70);
    vec3 fresnel=f0+(1.0-f0)*pow(1.0-max(0.0,dot(halfway,eye)),5.0);
    vec3 glossy=distribution*geometry*fresnel/max(.08,4.0*nv*diff);
    float occlusion=1.0;
    for(int i=0;i<12;i++){
        vec3 delta=u_contacts[i].xyz-v_world;
        float distance2=max(.0001,dot(delta,delta));
        float facing=max(0.0,dot(n,delta)*inversesqrt(distance2));
        float solidAngle=min(.85,u_contacts[i].w*u_contacts[i].w/distance2);
        occlusion*=1.0-.55*facing*solidAngle;
    }
    // Broad, cool reflection from the window, without an environment image.
    vec3 reflection=reflect(-eye,n);
    float windowLight=pow(max(0.0,dot(reflection,normalize(vec3(-.65,-.2,.7)))),12.0);
    vec3 lit=base*(ambient*max(.42,occlusion)+vec3(1.12,1.00,.80)*diff*vis)
        +vec3(1.0,.94,.82)*glossy*diff*vis*.7*specMask
        +vec3(.85,.89,.87)*windowLight*fresnel*.18*specMask;
#else
    vec3 lit=base*(ambient+vec3(1.12,1.00,.80)*diff*vis)+vec3(1.0,.94,.82)*spec;
#endif
    // A broad front fill reveals the bevels and enamel without a third depth pass.
    vec3 frontLight=normalize(vec3(-.35,-.80,.7));
    float frontSpec=pow(max(0.0,dot(n,normalize(eye+frontLight))),max(12.0,u_finish.x*.55))*u_finish.y*specMask;
    lit+=vec3(1.0,.94,.82)*frontSpec*.36;
    if(u_lamp_enabled>.5){
        vec3 delta=u_lamp_position-v_world;
        float distance2=max(.01,dot(delta,delta));
        vec3 lamp=delta*inversesqrt(distance2);
        float cone=smoothstep(.66,.87,dot(-lamp,u_lamp_direction));
        float falloff=3.1*cone/(1.0+.13*distance2);
        float localVis=lampVisibility(n,lamp);
        float localDiffuse=max(0.0,dot(n,lamp));
        float localSpec=pow(max(0.0,dot(n,normalize(eye+lamp))),u_finish.x)*u_finish.y*specMask;
        lit+=base*vec3(.07,.055,.035)/(1.0+.35*distance2);
        lit+=(base*localDiffuse+vec3(localSpec)) * vec3(1.0,.83,.63)*falloff*localVis;
    }
    lit+=base*vec3(.48,.37,.22)*windowPool*vis*(1.0-roomContact);
    if(u_pan_receiver>.5&&n.z>.15){
        float shade=0.0;
        for(int i=0;i<5;i++){
            vec4 s=u_pan_shadows[i];
            if(s.w>.001){
                float gap=clamp(s.z,0.0,1.0);
                vec2 d=(v_object.xy-s.xy)/(s.w+.32*gap);
                shade+=mix(.31,.12,gap)*exp(-mix(3.0,1.7,gap)*dot(d,d));
            }
        }
        lit*=1.0-min(.50,shade);
    }
    lit+=vec3(.22,.18,.09)*u_success_glow*(1.0-.92*printInk)*mix(.18,1.0,1.0-printedFace);
    lit=mix(lit,base*1.12,u_finish.w);
    vec3 mapped=(lit*(2.51*lit+.03))/(lit*(2.43*lit+.59)+.14);
    gl_FragColor=vec4(pow(clamp(mapped,0.0,1.0),vec3(1.0/2.2)),u_alpha);
}
'''
DEPTH_VERTEX='''attribute vec3 a_position;uniform mat4 u_mvp;void main(){gl_Position=u_mvp*vec4(a_position,1.0);}'''
DEPTH_FRAGMENT='''void main(){float d=min(gl_FragCoord.z,.99999);vec2 e=fract(vec2(1.0,255.0)*d);e.x-=e.y/255.0;gl_FragColor=vec4(e,0.0,1.0);}'''
POST_VERTEX='''attribute vec3 a_position;varying vec2 v_uv;void main(){v_uv=a_position.xy*.5+.5;gl_Position=vec4(a_position,1.0);}'''
POST_FRAGMENT='''
uniform sampler2D u_scene;uniform vec2 u_texel;varying vec2 v_uv;
void main(){
    vec3 nw=texture2D(u_scene,v_uv+vec2(-1.0,1.0)*u_texel).rgb;
    vec3 ne=texture2D(u_scene,v_uv+vec2(1.0,1.0)*u_texel).rgb;
    vec3 sw=texture2D(u_scene,v_uv+vec2(-1.0,-1.0)*u_texel).rgb;
    vec3 se=texture2D(u_scene,v_uv+vec2(1.0,-1.0)*u_texel).rgb;
    vec3 mid=texture2D(u_scene,v_uv).rgb,luma=vec3(.299,.587,.114);
    float a=dot(nw,luma),b=dot(ne,luma),c=dot(sw,luma),d=dot(se,luma),m=dot(mid,luma);
    float low=min(m,min(min(a,b),min(c,d))),high=max(m,max(max(a,b),max(c,d)));
    if(high-low<max(.035,high*.08)){gl_FragColor=vec4(mid,1.0);return;}
    vec2 dir=vec2(-((a+b)-(c+d)),(a+c)-(b+d));
    float reduce=max((a+b+c+d)*.03125,.0078125);
    dir=clamp(dir/(min(abs(dir.x),abs(dir.y))+reduce),vec2(-6.0),vec2(6.0))*u_texel;
    vec3 first=.5*(texture2D(u_scene,v_uv-dir/6.0).rgb+texture2D(u_scene,v_uv+dir/6.0).rgb);
    vec3 second=first*.5+.25*(texture2D(u_scene,v_uv-dir*.5).rgb+texture2D(u_scene,v_uv+dir*.5).rgb);
    float lum=dot(second,luma);gl_FragColor=vec4(lum<low||lum>high?first:second,1.0);
}
'''

FINISH={'matte':(28,.06,0,0),'wood':(16,.025,1,0),'metal':(36,.28,3,0),
        'enamel':(48,.20,0,0),'pan':(18,.045,.25,0),'emissive':(8,0,0,1),
        'plaster':(8,.012,-1,0),'floor':(14,.02,2,0)}

def matrix(position=(0,0,0),rotation=(0,0,0),scale=(1,1,1)):
    m=QMatrix4x4();m.translate(*position)
    for a,axis in zip(rotation,[(1,0,0),(0,1,0),(0,0,1)]):
        if a:m.rotate(a,*axis)
    if isinstance(scale,(int,float)):m.scale(scale)
    else:m.scale(*scale)
    return m

class SceneSurface(QOpenGLWindow):
    ready=pyqtSignal()
    failed=pyqtSignal(str)

    def __init__(self,board):
        super().__init__();self.owner=weakref.proxy(board)
        self.buffers={};self.textures=OrderedDict();self.programs=[];self.scene=None
        self.error=None;self.info={};self.initialized=False;self._dead=False
        self.frames=0;self.shadow_frames=0;self._shadow_key=None;self._press=None
        self.shadows_enabled=True;self.lamp_enabled=True;self.lamp_shadows_enabled=True
        self.lamp_shadow_frames=0;self._lamp_shadow_key=None
        self.contact_shadows_enabled=True;self.contact_texture=0;self._contact_blob=None
        self.pan_shadows_enabled=True;self._flip_labels={};self._glow_nodes=set()
        self.scene_size=None;self.scene_fbo=self.scene_texture=self.scene_depth=0
        self.setTitle('Трёхмерная мастерская')
        self.quality=quality();self._pending_scene=None;self._applied_quality=None
        self.shadow_size=0;self.lamp_shadow_size=0
        self._select_mesh(self.quality)
        self._loading=QTimer(self);self._loading.setInterval(40);self._loading.timeout.connect(self._poll_mesh)
        self._loading.start()

    def _select_mesh(self,profile):
        if profile.key not in _futures:
            _futures[profile.key]=_executor.submit(build_workshop,profile.detailed)
        self._mesh_future=_futures[profile.key]

    def set_quality(self,key):
        profile=quality(key)
        if profile==self.quality:return
        self.quality=profile;self._pending_scene=None;self._select_mesh(profile)
        self._loading.start();self.update()

    def _apply_quality(self):
        if self._pending_scene is None:return
        if self._applied_quality==self.quality.key:
            self._pending_scene=None;return
        # paintGL owns the context. No GL allocations happen in button handlers.
        if self.buffers:
            GL.glDeleteBuffers(len(self.buffers),[value[0] for value in self.buffers.values()])
            self.buffers.clear()
        self.scene=self._pending_scene;self._pending_scene=None
        if self._applied_quality is not None:GL.glDeleteProgram(self.main_program);self.programs.remove(self.main_program);self.locations.pop(self.main_program,None)
        self.main_program=self._program(VERTEX,'#define DETAIL_MODE '+str(int(self.quality.detailed))+'\n'+FRAGMENT)
        self.locations[self.main_program]={}
        self._resize_shadow(self.quality.shadow)
        self._resize_lamp_shadow(self.quality.lamp_shadow)
        self._upload_contacts()
        self._applied_quality=self.quality.key;self._shadow_key=None;self._lamp_shadow_key=None
        self.info.update(quality=self.quality.key,shadow_size=self.shadow_size,
                         contact_shading=self.quality.detailed,lamp_shadow_size=self.lamp_shadow_size,lighting="warm window daylight + diffuse fill + soft lamp + contact occlusion")

    def _poll_mesh(self):
        if not self._mesh_future.done():return
        self._loading.stop()
        try:self._pending_scene=self._mesh_future.result()
        except Exception as exc:self._fail('Не удалось построить модели: '+str(exc));return
        self.update()

    def _fail(self,text):
        self.error=text;self.failed.emit(text)

    def _program(self,vertex,fragment):
        prefix='#version 100\nprecision highp float;\n' if self.context().isOpenGLES() else '#version 120\n'
        shaders=[]
        try:
            shaders=[compileShader(prefix+vertex,GL.GL_VERTEX_SHADER),compileShader(prefix+fragment,GL.GL_FRAGMENT_SHADER)]
            program=GL.glCreateProgram()
            for shader in shaders:GL.glAttachShader(program,shader)
            for i,name in enumerate(['a_position','a_normal','a_color','a_uv']):GL.glBindAttribLocation(program,i,name)
            GL.glLinkProgram(program)
            if not GL.glGetProgramiv(program,GL.GL_LINK_STATUS):raise RuntimeError(GL.glGetProgramInfoLog(program).decode())
            self.programs.append(program);return program
        finally:
            for shader in shaders:GL.glDeleteShader(shader)

    def initializeGL(self):
        try:
            self._drain_qt_errors()
            self.context().aboutToBeDestroyed.connect(self.cleanup,Qt.ConnectionType.DirectConnection)
            self.info={key:GL.glGetString(value).decode() for key,value in [('version',GL.GL_VERSION),('renderer',GL.GL_RENDERER),('vendor',GL.GL_VENDOR),('glsl',GL.GL_SHADING_LANGUAGE_VERSION)]}
            self.info['api']='OpenGL ES' if self.context().isOpenGLES() else 'OpenGL'
            self.info['samples']=self.context().format().samples()
            self.info['depth_bits']=self.context().format().depthBufferSize()
            self.main_program=0
            self.depth_program=self._program(DEPTH_VERTEX,DEPTH_FRAGMENT)
            self.post_program=self._program(POST_VERTEX,POST_FRAGMENT)
            self.locations={p:{} for p in self.programs}
            self._make_shadow()
            self.light=QMatrix4x4();self.light.ortho(-8.5,8.5,-7,7,1,30)
            view=QMatrix4x4();view.lookAt(QVector3D(*(v*2 for v in WINDOW_DIRECTION)),QVector3D(0,0,0),QVector3D(0,0,1));self.light=self.light*view
            self.lamp_light=QMatrix4x4();self.lamp_light.perspective(88,1,.18,18)
            view=QMatrix4x4();view.lookAt(QVector3D(*LAMP_POSITION),QVector3D(*(p+d for p,d in zip(LAMP_POSITION,LAMP_DIRECTION))),QVector3D(0,0,1));self.lamp_light=self.lamp_light*view
            GL.glEnable(GL.GL_DEPTH_TEST);GL.glEnable(GL.GL_CULL_FACE);GL.glCullFace(GL.GL_BACK)
            GL.glDisable(GL.GL_DITHER)
            self.initialized=True
        except Exception as exc:self._fail('OpenGL: '+str(exc))

    def _shadow_target(self,size):
        texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,size,size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
        for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_NEAREST),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_NEAREST),
                            (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
        fbo=int(GL.glGenFramebuffers(1));GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,fbo)
        GL.glFramebufferTexture2D(GL.GL_FRAMEBUFFER,GL.GL_COLOR_ATTACHMENT0,GL.GL_TEXTURE_2D,texture,0)
        depth=int(GL.glGenRenderbuffers(1));GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,depth)
        GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,size,size)
        GL.glFramebufferRenderbuffer(GL.GL_FRAMEBUFFER,GL.GL_DEPTH_ATTACHMENT,GL.GL_RENDERBUFFER,depth)
        if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Карта теней недоступна')
        return texture,fbo,depth

    def _make_shadow(self):
        self.shadow_texture,self.shadow_fbo,self.shadow_depth=self._shadow_target(1024)
        self.lamp_texture,self.lamp_fbo,self.lamp_depth=self._shadow_target(512)
        self.shadow_size=1024;self.lamp_shadow_size=512
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.defaultFramebufferObject())

    def _resize_shadow(self,size):
        if self.shadow_size==size:return
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D,self.shadow_texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,size,size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
        GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.shadow_depth)
        GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,size,size)
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.shadow_fbo)
        if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Недоступен выбранный размер теней')
        self.shadow_size=size

    def _resize_lamp_shadow(self,size):
        if self.lamp_shadow_size==size:return
        GL.glActiveTexture(GL.GL_TEXTURE0);GL.glBindTexture(GL.GL_TEXTURE_2D,self.lamp_texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,size,size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
        GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.lamp_depth)
        GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,size,size)
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.lamp_fbo)
        if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Карта теней светильника недоступна')
        self.lamp_shadow_size=size

    def _upload_contacts(self):
        data=self.scene.contact_atlas
        if data is self._contact_blob and self.contact_texture:return
        if not self.contact_texture:self.contact_texture=int(GL.glGenTextures(1))
        GL.glActiveTexture(GL.GL_TEXTURE3);GL.glBindTexture(GL.GL_TEXTURE_2D,self.contact_texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,ATLAS_WIDTH,ATLAS_HEIGHT,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,data)
        for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_LINEAR),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_LINEAR),
                            (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
        self._contact_blob=data;GL.glActiveTexture(GL.GL_TEXTURE0)

    def _shadow_pass(self,nodes,fbo,size,light):
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,fbo);GL.glViewport(0,0,size,size)
        GL.glClearColor(1,1,1,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
        GL.glUseProgram(self.depth_program)
        for key,model,finish,casts in nodes:
            if casts:self.mat4(self.depth_program,'u_mvp',light*model);self.draw(key,self.depth_program)

    def _frame_target(self):
        ratio=self.devicePixelRatioF();profile=quality(self._applied_quality)
        width=max(1,round(self.width()*ratio*profile.supersample));height=max(1,round(self.height()*ratio*profile.supersample))
        scale=min(1,profile.frame_width/width,profile.frame_height/height);size=(max(1,round(width*scale)),max(1,round(height*scale)))
        if self.scene_size!=size:
            if self.scene_fbo:
                GL.glDeleteTextures([self.scene_texture]);GL.glDeleteRenderbuffers(1,[self.scene_depth]);GL.glDeleteFramebuffers(1,[self.scene_fbo])
            self.scene_texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,self.scene_texture)
            GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,*size,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,None)
            for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_LINEAR),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_LINEAR),
                                (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
            self.scene_fbo=int(GL.glGenFramebuffers(1));GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.scene_fbo)
            GL.glFramebufferTexture2D(GL.GL_FRAMEBUFFER,GL.GL_COLOR_ATTACHMENT0,GL.GL_TEXTURE_2D,self.scene_texture,0)
            self.scene_depth=int(GL.glGenRenderbuffers(1));GL.glBindRenderbuffer(GL.GL_RENDERBUFFER,self.scene_depth)
            GL.glRenderbufferStorage(GL.GL_RENDERBUFFER,GL.GL_DEPTH_COMPONENT16,*size)
            GL.glFramebufferRenderbuffer(GL.GL_FRAMEBUFFER,GL.GL_DEPTH_ATTACHMENT,GL.GL_RENDERBUFFER,self.scene_depth)
            if GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)!=GL.GL_FRAMEBUFFER_COMPLETE:raise RuntimeError('Недоступен 3D-буфер кадра')
            self.scene_size=size
            self.info.update(render_buffer=list(size),render_scale=size[0]/max(1,self.width()*ratio))
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.scene_fbo);GL.glViewport(0,0,*size)

    def _finish_frame(self):
        GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,self.defaultFramebufferObject())
        ratio=self.devicePixelRatioF();GL.glViewport(0,0,round(self.width()*ratio),round(self.height()*ratio))
        GL.glDisable(GL.GL_DEPTH_TEST);GL.glDisable(GL.GL_CULL_FACE)
        p=self.post_program;GL.glUseProgram(p)
        GL.glBindTexture(GL.GL_TEXTURE_2D,self.scene_texture);GL.glUniform1i(self.location(p,'u_scene'),0)
        GL.glUniform2f(self.location(p,'u_texel'),1/self.scene_size[0],1/self.scene_size[1])
        if 'screen-quad' not in self.buffers:self._buffer('screen-quad',array('f',[-1,-1,0,1,-1,0,1,1,0,-1,-1,0,1,1,0,-1,1,0]),3)
        self.draw('screen-quad',p)
        GL.glEnable(GL.GL_DEPTH_TEST);GL.glEnable(GL.GL_CULL_FACE)

    def location(self,p,name):
        if name not in self.locations[p]:self.locations[p][name]=GL.glGetUniformLocation(p,name)
        return self.locations[p][name]
    def mat4(self,p,name,m):GL.glUniformMatrix4fv(self.location(p,name),1,False,(ctypes.c_float*16)(*m.data()))

    def mesh(self,key):
        if key in self.buffers:return self.buffers[key]
        data=self.scene.static[key[7:]].data if key.startswith('static:') else self.scene.parts[key].data
        return self._buffer(key,data,9)

    def _buffer(self,key,data,stride):
        handle=int(GL.glGenBuffers(1));GL.glBindBuffer(GL.GL_ARRAY_BUFFER,handle)
        GL.glBufferData(GL.GL_ARRAY_BUFFER,len(data)*4,data.tobytes(),GL.GL_STATIC_DRAW)
        self.buffers[key]=(handle,len(data)//stride,stride);return self.buffers[key]

    def draw(self,key,program):
        handle,count,stride=self.mesh(key);GL.glBindBuffer(GL.GL_ARRAY_BUFFER,handle)
        GL.glEnableVertexAttribArray(0);GL.glVertexAttribPointer(0,3,GL.GL_FLOAT,False,stride*4,ctypes.c_void_p(0))
        if program==self.main_program:
            for i,offset in [(1,12),(2,24)]:
                GL.glEnableVertexAttribArray(i);GL.glVertexAttribPointer(i,3,GL.GL_FLOAT,False,stride*4,ctypes.c_void_p(offset))
        GL.glDrawArrays(GL.GL_TRIANGLES,0,count)
        for i in range(4):GL.glDisableVertexAttribArray(i)

    def _nodes(self):
        board=self.owner;angle=math.radians(board._angle);nodes=[];labels={}
        for finish in self.scene.static:nodes.append(('static:'+finish,QMatrix4x4(),finish,finish!='plaster'))
        nodes.append(('lamp-bulb',QMatrix4x4(),'emissive' if self.lamp_enabled else 'matte',False))
        moving=board._motion and board._ambient
        phase=board.clock._phase if moving else 0.0
        pose=room_pose(phase,board.effects.car_time,board.effects.robot_time);openness=owl_openness(phase) if moving else 1.0
        activity=min(1.0,board.effects.robot_speed/.5)
        self._flip_labels={};self._glow_nodes=set()
        head=matrix((.65,2.99,1.85),(0,0,pose.owl_angle))
        eyes=QMatrix4x4(head);eyes.translate(0,-.13,.01);eyes.scale(1,1,openness)
        nodes.append(('owl-eyes',eyes,'enamel',False))
        for key in self.scene.parts:
            if key.startswith('room-robot-'):
                root=matrix((pose.robot_x,pose.robot_y,0),(0,0,pose.robot_heading))
                root.translate(5.10,-2.75,0)
                if '-body-' in key:root.translate(0,0,pose.robot_bob*activity)
                elif '-arm' in key:
                    i=0 if '-arm0-' in key else 1;x=[-5.34,-4.86][i]
                    root.translate(x,2.75,.42+pose.robot_bob*activity);root.rotate(pose.arms[i]*activity,1,0,0);root.translate(-x,-2.75,-.42)
                else:
                    i=0 if '-foot0-' in key else 1
                    root.translate(0,pose.foot_stride[i]*activity,pose.feet[i]*activity)
                nodes.append((key,root,key.rsplit('-',1)[1],False))
            elif key.startswith('room-owl-head-'):
                transform=QMatrix4x4(head);transform.translate(-.65,-2.99,-1.85)
                nodes.append((key,transform,key.rsplit('-',1)[1],False))
        for index,car in enumerate(pose.cars):
            root=matrix((car.x,car.y,0),(0,0,car.heading))
            nodes.append(('room-car'+str(index)+'-body-enamel',root,'enamel',False))
            for x in [-.235,.235]:
                for y in [-.22,.22]:
                    wheel=QMatrix4x4(root);wheel.translate(x,y,.09);wheel.rotate(90,0,1,0);wheel.rotate(car.wheel,0,0,1)
                    nodes.append(('room-car-wheel',wheel,'matte',False))
        for index,(key,(x,y,z)) in enumerate(self.scene.ambient_nodes):
            nodes.append((key,matrix((x+pose.clouds[index],y,z)),'matte',False))
        nodes.append(('beam',matrix((0,0,PIVOT),(0,board._angle,0)),'metal',True))
        nodes.append(('pivot',matrix((0,-.13,PIVOT),(90,0,0)),'metal',True))
        nodes.append(('pivot-inlay',matrix((0,-.278,PIVOT),(90,0,0)),'enamel',False))
        nodes.append(('pivot-scale',matrix((0,-.329,PIVOT)),'matte',False))
        nodes.append(('pivot-needle',matrix((0,-.342,PIVOT),(0,board._angle*4,0)),'enamel',False))
        x_side=next((i for i,cup in enumerate(board._cups) if any(b.label=='x' and not b.removing for b in cup.bodies)),None)
        for index,(direction,cup) in enumerate(zip((-1,1),board._cups)):
            x=direction*ARM*math.cos(angle);z=RIM-direction*ARM*math.sin(angle)-cup.recoil/100
            nodes.extend([(f'bowl-{index}',matrix((x,0,z)),'pan',True),('bowl-rim',matrix((x,0,z)),'metal',True),
                          ('chains',matrix((x,0,z),scale=(1,1,1+cup.recoil/(100*(PIVOT-RIM-.16)))),'metal',True),('hook',matrix((x,0,PIVOT-direction*ARM*math.sin(angle)-.10),(90,0,0)),'metal',True)])
            for body in cup.bodies:
                if body.removing and body.age>.27:continue
                key='xblock' if 'x' in body.label else 'negative' if body.label.startswith(('−','-')) else 'block'
                wide=body.width>60
                scale=(body.width/220 if wide else body.width/52,1,1)
                # Model origin is the physical centre of the bottom edge.
                transform=matrix((x+body.x/100,body.depth/100,z-body.y/100),(body.pitch,body.roll,0),scale)
                centre=QMatrix4x4(transform);centre.translate(0,0,.29)
                shown=body.label
                if body.label=='x' and board.effects.answer is not None:
                    centre.rotate(board.effects.reveal_angle,0,0,1)
                    self._flip_labels[id(centre)]=(body.label,board.effects.answer)
                    if board.effects.reveal_angle>=90:shown=board.effects.answer
                nodes.append((key+('-wide' if wide else ''),centre,'matte',True))
                labels[id(centre)]=(shown,2.2 if wide else .52)
                if board.effects.answer is not None and x_side is not None and index!=x_side and body.label.lstrip('−-').isdigit():self._glow_nodes.add(id(centre))
        clock=board.clock;t=clock._time
        sec=t.second()+t.msec()/1000;minute=t.minute()+sec/60;hour=t.hour()%12+minute/60
        for key,rotation in [('hour-hand',hour*30),('minute-hand',minute*6),('second-hand',sec*6)]:
            nodes.append((key,matrix((CLOCK[0],CLOCK[1]-.115,CLOCK[2]),(0,rotation,0)),'matte',False))
        nodes.append(('pendulum',matrix((CLOCK[0],CLOCK[1]-.03,CLOCK[2]-.14),(0,pose.pendulum,0)),'metal',False))
        if board._celebration.isValid():
            t=min(1,board._celebration.elapsed()/board.CELEBRATION_DURATION)
            for i in range(12):
                a=i*math.tau/12;distance=.3+.9*t
                position=(math.cos(a)*distance,-.35-(i%3)*.1,2.15+math.sin(a)*distance*.6+.15*t)
                nodes.append((['star-gold','star-mint','star-peach'][i%3],matrix(position,(90,i*18+t*140,0),max(.02,1-t)),'metal',False))
        # Scale all moving balance parts together. Mutate the matrices in place
        # so the cached label-to-matrix identities remain valid.
        room_parts={'lamp-bulb','owl-eyes','hour-hand','minute-hand','second-hand','pendulum'}
        for key,model,finish,casts in nodes:
            if key.startswith(('static:','cloud-','room-')) or key in room_parts:continue
            for row in range(3):model.setRow(row,model.row(row)*HERO_SCALE)
        return nodes,labels

    def _camera(self):
        # A fixed, centred parallel view keeps both pans equally sized. The
        # small elevation exposes their interiors without a sideways perspective.
        elevation=math.radians(12);target=QVector3D(0,.15,2.52)
        eye=target+QVector3D(0,-math.cos(elevation)*12,math.sin(elevation)*12)
        view=QMatrix4x4();view.lookAt(eye,target,QVector3D(0,0,1))
        aspect=max(.25,self.width()/max(1,self.height()));half_height=max(2.85,7.45/aspect)
        projection=QMatrix4x4();projection.ortho(-half_height*aspect,half_height*aspect,-half_height,half_height,1,35)
        self.eye=eye;self.vp=projection*view
        self.info.update(projection='orthographic',view='fixed-front',lamp_enabled=self.lamp_enabled)

    def paintGL(self):
        if self._dead:return
        try:
            self._drain_qt_errors()
            # Opaque depth-tested surfaces, independent of Qt's preceding pass.
            GL.glDisable(GL.GL_BLEND)
            GL.glClearColor(.965,.937,.87,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
            if self.error or not self.initialized:return
            self._apply_quality()
            if self.scene is None:return
            if not self.buffers:
                for key in self.scene.static:self.mesh('static:'+key)
                for key in self.scene.parts:self.mesh(key)
            nodes,labels=self._nodes();self._camera()
            shadow_key=(self.owner._angle,self.owner.effects.reveal_angle,tuple(c.recoil for c in self.owner._cups),tuple((b.x,b.y,b.depth,b.roll,b.pitch,b.age if b.removing else 0,b.label) for c in self.owner._cups for b in c.bodies))
            if shadow_key!=self._shadow_key:
                self._shadow_pass(nodes,self.shadow_fbo,self.shadow_size,self.light)
                self._shadow_key=shadow_key;self.shadow_frames+=1
            if self.lamp_enabled and shadow_key!=self._lamp_shadow_key:
                self._shadow_pass(nodes,self.lamp_fbo,self.lamp_shadow_size,self.lamp_light)
                self._lamp_shadow_key=shadow_key;self.lamp_shadow_frames+=1
            self._frame_target()
            GL.glClearColor(.965,.937,.87,1);GL.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT)
            p=self.main_program;GL.glUseProgram(p)
            self.mat4(p,'u_vp',self.vp);self.mat4(p,'u_light',self.light);self.mat4(p,'u_lamp',self.lamp_light)
            GL.glUniform3f(self.location(p,'u_eye'),self.eye.x(),self.eye.y(),self.eye.z())
            GL.glUniform1f(self.location(p,'u_alpha'),1);GL.glUniform1f(self.location(p,'u_shadows'),float(self.shadows_enabled))
            GL.glActiveTexture(GL.GL_TEXTURE0);GL.glBindTexture(GL.GL_TEXTURE_2D,self.shadow_texture);GL.glUniform1i(self.location(p,'u_shadow'),0)
            GL.glUniform1f(self.location(p,'u_shadow_texel'),1/self.shadow_size)
            GL.glUniform3f(self.location(p,'u_day_direction'),*WINDOW_DIRECTION)
            GL.glUniform3f(self.location(p,'u_lamp_position'),*LAMP_POSITION)
            GL.glUniform3f(self.location(p,'u_lamp_direction'),*LAMP_DIRECTION)
            GL.glUniform1f(self.location(p,'u_lamp_enabled'),float(self.lamp_enabled))
            GL.glUniform1f(self.location(p,'u_lamp_shadows'),float(self.lamp_shadows_enabled))
            GL.glUniform1f(self.location(p,'u_lamp_texel'),1/self.lamp_shadow_size)
            GL.glActiveTexture(GL.GL_TEXTURE2);GL.glBindTexture(GL.GL_TEXTURE_2D,self.lamp_texture);GL.glUniform1i(self.location(p,'u_lamp_shadow'),2)
            GL.glActiveTexture(GL.GL_TEXTURE3);GL.glBindTexture(GL.GL_TEXTURE_2D,self.contact_texture);GL.glUniform1i(self.location(p,'u_contact_atlas'),3)
            GL.glUniform1f(self.location(p,'u_contact_enabled'),float(self.contact_shadows_enabled))
            pose=room_pose(self.owner.clock._phase if self.owner._motion and self.owner._ambient else 0.0,self.owner.effects.car_time,self.owner.effects.robot_time)
            room_contacts=[(pose.robot_x,pose.robot_y,.34,.30)]+[(c.x,c.y,.43,.36) for c in pose.cars]
            GL.glUniform4fv(self.location(p,'u_room_contacts[0]'),3,(ctypes.c_float*12)(*(v for c in room_contacts for v in c)))
            GL.glActiveTexture(GL.GL_TEXTURE0)
            if quality(self._applied_quality).detailed:
                contacts=[(0,.1*HERO_SCALE,.22*HERO_SCALE,.52*HERO_SCALE)]
                for key,model,finish,casts in nodes:
                    if id(model) in labels:
                        centre=model.map(QVector3D(0,0,0))
                        contacts.append((centre.x(),centre.y(),centre.z(),.24*HERO_SCALE))
                contacts=(contacts+[(0,0,0,0)]*12)[:12]
                GL.glUniform4fv(self.location(p,'u_contacts[0]'),12,(ctypes.c_float*48)(*(v for c in contacts for v in c)))
            GL.glUniform1i(self.location(p,'u_label'),1);GL.glUniform2f(self.location(p,'u_label_size'),1,1)
            GL.glUniform1i(self.location(p,'u_back_label'),4)
            for key,model,finish,casts in nodes:
                label=labels.get(id(model))
                GL.glUniform1f(self.location(p,'u_labelled'),float(label is not None))
                flip=self._flip_labels.get(id(model))
                GL.glUniform1f(self.location(p,'u_two_sided_label'),float(flip is not None))
                GL.glUniform1f(self.location(p,'u_success_glow'),self.owner.effects.glow if id(model) in self._glow_nodes else 0.0)
                receiver=key in ('bowl-0','bowl-1') and self.pan_shadows_enabled
                GL.glUniform1f(self.location(p,'u_pan_receiver'),float(receiver))
                if receiver:
                    cup=self.owner._cups[int(key[-1])]
                    fields=[landing_shadow(b,cup.support(b)[0]) for b in cup.bodies if not b.removing][:5]
                    fields+=(5-len(fields))*[(0,0,0,0)]
                    GL.glUniform4fv(self.location(p,'u_pan_shadows[0]'),5,(ctypes.c_float*20)(*(v for s in fields for v in s)))
                if label is not None:
                    text,width=label
                    GL.glActiveTexture(GL.GL_TEXTURE1);GL.glBindTexture(GL.GL_TEXTURE_2D,self._label(flip[0] if flip else text,width))
                    if flip:
                        GL.glActiveTexture(GL.GL_TEXTURE4);GL.glBindTexture(GL.GL_TEXTURE_2D,self._label(flip[1],width))
                    GL.glUniform2f(self.location(p,'u_label_size'),width,.58)
                self.mat4(p,'u_model',model)
                GL.glUniformMatrix3fv(self.location(p,'u_normal'),1,False,(ctypes.c_float*9)(*model.normalMatrix().data()))
                GL.glUniform4f(self.location(p,'u_finish'),*FINISH[finish]);self.draw(key,p)
            GL.glActiveTexture(GL.GL_TEXTURE0)
            self._finish_frame()
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER,0);GL.glUseProgram(0)
            self.frames+=1
            if self.frames==1:self.ready.emit()
        except Exception as exc:self._fail('Ошибка 3D-отрисовки: '+str(exc))

    def _drain_qt_errors(self):
        # Qt owns the context between callbacks. Do not attribute a stale Qt
        # state error (e.g. unsupported sRGB on ES 2) to our next GL operation.
        # Errors from our own calls remain checked by the binding.
        for _ in range(8):
            error=GL.glGetError()
            if error==GL.GL_NO_ERROR:return
            self.info.setdefault('qt_entry_errors',[])
            if int(error) not in self.info['qt_entry_errors']:self.info['qt_entry_errors'].append(int(error))

    def _label(self,text,width):
        key=(text,width)
        if key in self.textures:self.textures.move_to_end(key);return self.textures[key]
        image_width=512 if width>1 else 128
        image=QImage(image_width,128,QImage.Format.Format_RGBA8888);image.fill(Qt.GlobalColor.transparent)
        painter=QPainter(image);painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        font=QFont('Algebra Rounded');font.setBold(True);font.setPixelSize(104)
        painter.setFont(font)
        while painter.fontMetrics().horizontalAdvance(text)>image_width-12 and font.pixelSize()>20:
            font.setPixelSize(font.pixelSize()-2);painter.setFont(font)
        painter.setPen(QColor('#34564d') if 'x' in text else QColor('#5f4d32'))
        painter.drawText(image.rect(),int(Qt.AlignmentFlag.AlignCenter),text);painter.end()
        image=image.mirrored(False,True);data=image.bits().asstring(image.sizeInBytes())
        texture=int(GL.glGenTextures(1));GL.glBindTexture(GL.GL_TEXTURE_2D,texture)
        GL.glTexImage2D(GL.GL_TEXTURE_2D,0,GL.GL_RGBA,image_width,128,0,GL.GL_RGBA,GL.GL_UNSIGNED_BYTE,data)
        GL.glGenerateMipmap(GL.GL_TEXTURE_2D)
        for param,value in [(GL.GL_TEXTURE_MIN_FILTER,GL.GL_LINEAR_MIPMAP_LINEAR),(GL.GL_TEXTURE_MAG_FILTER,GL.GL_LINEAR),
                            (GL.GL_TEXTURE_WRAP_S,GL.GL_CLAMP_TO_EDGE),(GL.GL_TEXTURE_WRAP_T,GL.GL_CLAMP_TO_EDGE)]:GL.glTexParameteri(GL.GL_TEXTURE_2D,param,value)
        self.textures[key]=texture
        while len(self.textures)>64:
            _,old=self.textures.popitem(last=False);GL.glDeleteTextures([old])
        return texture

    def cleanup(self):
        if self._dead:return
        self._dead=True;self._loading.stop()
        context=self.context()
        if context is not None:
            try:context.aboutToBeDestroyed.disconnect(self.cleanup)
            except (TypeError,RuntimeError):pass
        if not self.initialized:return
        self.makeCurrent()
        try:
            GL.glFinish()
            if self.buffers:GL.glDeleteBuffers(len(self.buffers),[item[0] for item in self.buffers.values()])
            for texture in self.textures.values():GL.glDeleteTextures([texture])
            GL.glDeleteTextures([self.shadow_texture,self.lamp_texture,self.contact_texture]);GL.glDeleteRenderbuffers(2,[self.shadow_depth,self.lamp_depth]);GL.glDeleteFramebuffers(2,[self.shadow_fbo,self.lamp_fbo])
            if self.scene_fbo:
                GL.glDeleteTextures([self.scene_texture]);GL.glDeleteRenderbuffers(1,[self.scene_depth]);GL.glDeleteFramebuffers(1,[self.scene_fbo])
            for program in self.programs:GL.glDeleteProgram(program)
            self.buffers.clear();self.textures.clear()
            GL.glFinish()
        except Exception as exc:self.info['cleanup_error']=str(exc)
        finally:self.doneCurrent()
