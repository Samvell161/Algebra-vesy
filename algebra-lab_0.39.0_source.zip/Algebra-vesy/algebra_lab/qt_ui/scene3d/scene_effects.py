"""Presentation-only timing: verified reveal and gentle foreground traffic.

No equation, progress or input rules live here. The owner supplies a value
only after the existing answer checker has accepted it.
"""
import math

def smooth(value):
    t=max(0.0,min(1.0,value))
    return t*t*(3-2*t)

class SceneEffects:
    REVEAL_SECONDS=.90
    GLOW_SECONDS=1.25

    def __init__(self):
        self.context=None;self.answer=None;self.answering=False
        self.reveal_time=0.0;self.car_time=0.0;self.car_speed=1.0
        self.robot_time=0.0;self.robot_speed=1.0

    def lesson(self,context,answering,verified_answer,animate=True):
        value=None if verified_answer is None else str(verified_answer)
        if context!=self.context or value!=self.answer:
            self.context=context;self.answer=value
            self.reveal_time=0.0 if animate else self.GLOW_SECONDS
        self.answering=bool(answering)

    @property
    def turning(self):return self.answer is not None and self.reveal_time<self.GLOW_SECONDS
    @property
    def reveal_angle(self):return 0.0 if self.answer is None else 180*smooth(self.reveal_time/self.REVEAL_SECONDS)
    @property
    def glow(self):
        if self.answer is None or self.reveal_time>=self.GLOW_SECONDS:return 0.0
        return math.sin(math.pi*self.reveal_time/self.GLOW_SECONDS)**2

    def advance(self,seconds,busy=False,motion=True,ambient=True):
        dt=max(0.0,min(.1,seconds))
        if not motion:
            self.finish();return
        target=.02 if self.answering or self.turning else .14 if busy else 1.0
        previous=self.car_speed
        self.car_speed=target+(previous-target)*math.exp(-dt/.32)
        if ambient:self.car_time+=dt*(previous+self.car_speed)/2
        target=.02 if self.answering or self.turning else .45 if busy else 1.0
        previous=self.robot_speed
        self.robot_speed=target+(previous-target)*math.exp(-dt/.32)
        if ambient:self.robot_time+=dt*(previous+self.robot_speed)/2
        if self.turning:self.reveal_time=min(self.GLOW_SECONDS,self.reveal_time+dt)

    def finish(self):
        if self.answer is not None:self.reveal_time=self.GLOW_SECONDS

def landing_shadow(body,floor):
    """Local XY, gap above support and half-width; the pan shader softens it."""
    return (body.x/100,getattr(body,'depth',0)/100,max(0.0,(floor-body.y)/100),body.width/200+.035)
