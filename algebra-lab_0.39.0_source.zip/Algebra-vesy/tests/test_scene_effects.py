import unittest
from algebra_lab.qt_ui.scene3d.scene_effects import SceneEffects,landing_shadow
from algebra_lab.qt_ui.scene3d.physics import CupMotion3D

class PresentationTests(unittest.TestCase):
    def test_only_verified_answer_reveals_once_and_new_lesson_resets(self):
        fx=SceneEffects();fx.lesson('lesson',True,None)
        for _ in range(30):fx.advance(1/30)
        self.assertIsNone(fx.answer);self.assertEqual(fx.reveal_angle,0)
        fx.lesson('lesson',False,'2');angles=[]
        for _ in range(40):
            fx.advance(1/30);angles.append(fx.reveal_angle)
        self.assertEqual(angles,sorted(angles));self.assertEqual(angles[-1],180)
        self.assertEqual(fx.glow,0);self.assertFalse(fx.turning)
        fx.lesson('lesson',False,'2');self.assertEqual(fx.reveal_angle,180)
        fx.lesson('other',False,None);self.assertIsNone(fx.answer)
        fx.lesson('other',False,'7',animate=False);self.assertEqual(fx.reveal_angle,180)

    def test_traffic_brakes_and_resumes_without_position_jump(self):
        fx=SceneEffects();speeds=[]
        for _ in range(45):fx.advance(1/30,busy=True);speeds.append(fx.car_speed)
        self.assertEqual(speeds,sorted(speeds,reverse=True));self.assertLess(speeds[-1],.16)
        fx.lesson('a',True,None)
        for _ in range(60):fx.advance(1/30)
        self.assertLess(fx.car_speed,.023)
        self.assertLess(fx.robot_speed,.023)
        at=fx.car_time;fx.lesson('a',False,None);self.assertEqual(at,fx.car_time)
        for _ in range(45):fx.advance(1/30)
        self.assertGreater(fx.car_speed,.98)
        at=fx.car_time;fx.advance(.1,motion=False);self.assertEqual(at,fx.car_time)
        fx.advance(.1,ambient=False);self.assertEqual(at,fx.car_time)

    def test_landing_gap_contracts_and_recoil_is_small_and_damped(self):
        cup=CupMotion3D();cup.target(['1'],True);body=cup.bodies[0]
        initial=landing_shadow(body,cup.support(body)[0]);self.assertGreater(initial[2],.6)
        samples=[]
        for _ in range(240):cup.step(1/120);samples.append(cup.recoil)
        self.assertGreater(max(samples),.1);self.assertLessEqual(max(samples),1.5)
        self.assertLess(abs(samples[-1]),.01)
        final=landing_shadow(body,cup.support(body)[0]);self.assertLess(final[2],.001)
        self.assertEqual(final[3],initial[3]);cup.finish();self.assertEqual(cup.recoil,0)
