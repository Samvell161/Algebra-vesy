import tempfile
import unittest
from pathlib import Path
from fractions import Fraction
from algebra_lab.adventure import ADVENTURE_TASKS,LANDS,QUIZZES,land_open,quiz_open,next_level
from algebra_lab.hardware import Reader,NUMERIC_TAGS
from algebra_lab.service import Service,Session
from algebra_lab.storage import Store
from algebra_lab.tag_import import parse_tags
from algebra_lab.math_engine import Linear,equation
from algebra_lab.mobile import snapshot

class ExtendedLessonTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name)/'db.sqlite3')
        self.service=Service(self.store,Reader());self.session=Session()
        for digit in NUMERIC_TAGS:self.store.bind('A'+digit,digit)
        self.store.bind('FF','x')
    def tearDown(self):self.store.close();self.temp.cleanup()
    def start(self,key):
        self.service.start(self.session,{'task_id':key});self.service.begin_student(self.session)
    def scan(self,kind,side='left'):
        return self.service.scan_cup(self.session,{'uid':'FF' if kind=='x' else 'A'+str(kind),'source':side})
    def solve(self):
        original=self.session.current.solution()
        for _ in range(30):
            if self.session.current.isolated():break
            eq=self.session.current
            if eq.left.a and eq.right.a:kind,operation='x','remove'
            else:
                part=eq.left if eq.left.a else eq.right
                kind=str(min(9,abs(int(part.b))));operation='remove' if part.b>0 else 'add'
            self.session.cup_operation=operation
            self.scan(kind,'right');self.assertTrue(self.service.cup_state(self.session)['pending'])
            self.scan(kind,'left');self.assertEqual(self.session.current.solution(),original)
        self.assertTrue(self.session.current.isolated());self.assertFalse(self.session.completed)
        return int(Fraction(original['value']))
    def test_every_new_level_uses_real_paired_tags_and_explicit_answer(self):
        for task in ADVENTURE_TASKS[24:]:
            with self.subTest(task=task['id']):
                self.start(task['id']);answer=self.solve()
                if task.get('answer_digits',1)>1:
                    for digit in str(answer):self.scan(digit)
                    self.assertFalse(self.session.completed);self.assertEqual(self.session.cup_guess,answer)
                    self.scan('x')
                else:self.scan(str(answer))
                self.assertTrue(self.session.completed)
        self.assertEqual(self.store.progress()['completed'],48)
    def test_zero_does_not_mutate_a_move_and_can_be_a_correct_answer(self):
        self.start('nothing-1');current=self.session.current
        self.session.cup_operation='remove'
        with self.assertRaisesRegex(ValueError,'Ноль'):self.scan('0')
        self.assertEqual(self.session.current,current);self.assertEqual(self.session.cup_actions,[])
        self.assertFalse(self.service.cup_state(self.session)['pending'])
        self.solve();self.scan('0');self.assertTrue(self.session.completed)
    def test_two_digit_answer_requires_confirmation_and_can_be_reentered(self):
        self.start('teens-1');self.solve()
        self.scan('1');self.assertEqual(self.session.cup_guess,1);self.assertFalse(self.session.completed)
        self.scan('1');self.assertEqual(self.session.cup_guess,11)
        wrong=self.scan('x');self.assertFalse(self.session.completed)
        self.scan('1');self.scan('0');self.assertEqual(self.session.cup_guess,10)
        self.assertFalse(self.session.completed);self.scan('x');self.assertTrue(self.session.completed)
        self.start('teens-2');self.assertEqual(self.session.cup_answer_digits,'')
    def test_mismatched_tag_and_overflow_leave_a_valid_pending_pair(self):
        self.start('heavy-1');self.session.cup_operation='remove';self.scan('6','left')
        with self.assertRaises(ValueError):self.scan('5','right')
        self.assertTrue(self.service.cup_state(self.session)['pending']);self.scan('6','right')
        self.assertEqual(self.session.cup_phase,'answer')
        self.start('master-4');self.session.cup_operation='add'
        with self.assertRaises(ValueError):self.scan('9','right')
        self.assertFalse(self.service.cup_state(self.session)['pending'])
    def test_old_progress_unlocks_extension_and_mobile_lists_every_chapter(self):
        for task in ADVENTURE_TASKS[:24]:self.store.record(task['id'],task['id'],'practice',1,0,1)
        best=self.store.progress()['best'];self.assertTrue(land_open(best,4));self.assertFalse(land_open(best,5))
        self.assertEqual(next_level(best,'duet-6')['id'],'digits-1')
        chapters=snapshot(self.store.path if hasattr(self.store,'path') else Path(self.temp.name)/'db.sqlite3','test')['profiles'][0]['chapters']
        self.assertEqual(len(chapters),12);self.assertEqual(chapters[4]['completed'],0)
        for index in [-1,12,100]:self.assertFalse(land_open(best,index));self.assertFalse(quiz_open(best,index))
    def test_all_digits_import_from_phone_and_reopen_without_old_data_loss(self):
        text='\n'.join(f'12:34:56:{i:02X};+{i}' for i in range(10))
        tags=parse_tags(text);self.assertEqual(set(tags.values()),set(NUMERIC_TAGS))
        self.service.import_tags(self.session,tags);self.assertEqual(self.store.tags()['FF'],'x')
        self.assertEqual(len(ADVENTURE_TASKS),6*len(LANDS));self.assertEqual(len(QUIZZES),len(LANDS))
