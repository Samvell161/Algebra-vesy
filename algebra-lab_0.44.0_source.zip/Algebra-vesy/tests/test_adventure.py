import tempfile
import unittest
from pathlib import Path
from fractions import Fraction
from algebra_lab.adventure import ADVENTURE_TASKS, ADVENTURE_IDS, LANDS, QUIZZES, land_open, level_open, quiz_open, next_level
from algebra_lab.tasks import STARTER_TASKS, TASKS
from algebra_lab.math_engine import equation
from algebra_lab.hardware import Reader
from algebra_lab.service import Service, Session
from algebra_lab.storage import Store
from algebra_lab.learning import game_progress, progress_csv


class AdventureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'adventure.sqlite3')
        self.service, self.session = Service(self.store, Reader()), Session()
        for uid, kind in [('AA','1'),('BB','2'),('CC','x')]:
            self.store.bind(uid,kind)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def test_catalog_is_bounded_unique_and_preserves_existing_equations(self):
        self.assertEqual(len(ADVENTURE_TASKS),72)
        self.assertEqual(len(ADVENTURE_IDS),72)
        self.assertEqual(len(LANDS),12)
        self.assertEqual(ADVENTURE_TASKS[:6],STARTER_TASKS)
        self.assertEqual(len(TASKS),24)
        self.assertFalse(ADVENTURE_IDS & {t['id'] for t in TASKS})
        for task in ADVENTURE_TASKS:
            result=equation(task['equation']).solution()
            self.assertEqual(result['kind'],'one')
            answer=Fraction(result['value'])
            self.assertEqual(answer.denominator,1)
            self.assertTrue(0 <= answer <= 99)

    def test_chapter_gates_and_choice_of_levels(self):
        self.assertTrue(level_open({},'cups-1'))
        self.assertFalse(level_open({},'cups-2'))
        best={'cups-1':3}
        self.assertTrue(level_open(best,'cups-6'))
        self.assertFalse(land_open(best,1))
        best.update({t['id']:3 for t in STARTER_TASKS})
        self.assertTrue(land_open(best,1))
        self.assertTrue(level_open(best,'trail-6'))
        self.assertTrue(quiz_open(best,0))
        self.assertFalse(quiz_open(best,1))

    def test_next_does_not_bypass_chapter_gate_when_a_level_was_selected_out_of_order(self):
        best={'cups-1':3,'cups-6':3}
        self.assertEqual(next_level(best,'cups-6')['id'],'cups-2')
        self.service.start(self.session,{'task_id':'cups-6'})
        self.service.begin_student(self.session)
        self.session.completed=True
        for key in best:
            self.store.record(key,key,'practice',1,0,1)
        self.service.scan_cup(self.session,{'uid':'AA'})
        self.assertEqual(self.session.task_id,'cups-2')

    def test_all_72_are_solvable_with_unit_double_and_x_tags_without_auto_answer(self):
        for index,task in enumerate(ADVENTURE_TASKS):
            with self.subTest(task=task['id']):
                self.service.start(self.session,{'task_id':task['id']})
                self.service.begin_student(self.session)
                original=self.session.current.solution()
                for _ in range(49):
                    current=self.session.current
                    if current.isolated(): break
                    if current.left.a and current.right.a:
                        operation,uid='remove','CC'
                    else:
                        side=current.left if current.left.a else current.right
                        operation='remove' if side.b > 0 else 'add'
                        uid='BB' if abs(side.b)>=2 and task['id']!='cups-1' else 'AA'
                    self.session.cup_operation=operation
                    self.session.cup_side='right' if index % 2 else 'left'
                    self.service.scan_cup(self.session,{'uid':uid})
                    self.session.cup_side='left' if index % 2 else 'right'
                    self.service.scan_cup(self.session,{'uid':uid})
                    self.assertEqual(self.session.current.solution(),original)
                self.assertTrue(self.session.current.isolated())
                self.assertFalse(self.session.completed)
                self.assertEqual(self.session.cup_phase,'answer')
                self.session.cup_guess=int(Fraction(original['value']))
                self.service.scan_cup(self.session,{'uid':'CC'})
                self.assertTrue(self.session.completed)
        self.assertEqual(self.store.progress()['completed'],72)

    def unlock_quiz(self,index):
        for task in ADVENTURE_TASKS[:(index+1)*6]:
            self.store.record(task['id'],task['id'],'practice',1,0,1)

    def finish_quiz(self,state):
        for question in QUIZZES[next(i for i,q in enumerate(QUIZZES) if q['id']==state['id'])]['questions']:
            self.service.quiz_answer(state,question[2])
            self.service.quiz_next(state)

    def test_quiz_needs_levels_and_only_completion_awards_xp(self):
        with self.assertRaises(ValueError): self.service.start_quiz('quiz-1')
        self.unlock_quiz(0)
        before=game_progress(self.store.progress())['xp']
        state=self.service.start_quiz('quiz-1')
        self.assertFalse(self.service.quiz_answer(state,1))
        self.assertEqual(game_progress(self.store.progress())['xp'],before)
        self.finish_quiz(state)
        self.assertTrue(state['completed'])
        self.assertEqual(game_progress(self.store.progress())['xp'],before+20)
        self.assertIn('Квиз',progress_csv(self.store.progress()))
        with self.assertRaises(ValueError): self.service.quiz_next(state)

    def test_all_twelve_quizzes_and_repeat_do_not_farm_xp(self):
        self.unlock_quiz(len(QUIZZES)-1)
        before=game_progress(self.store.progress())['xp']
        for quiz in QUIZZES:
            state=self.service.start_quiz(quiz['id'])
            self.finish_quiz(state)
        after=game_progress(self.store.progress())['xp']
        self.assertEqual(after,before+30*len(QUIZZES))
        self.finish_quiz(self.service.start_quiz('quiz-4'))
        self.assertEqual(game_progress(self.store.progress())['xp'],after)

    def test_quiz_cannot_be_started_as_a_math_equation(self):
        with self.assertRaises(ValueError): self.service.start(self.session,{'task_id':'quiz-1'})
