import tempfile
import unittest
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QFontDatabase
    from algebra_lab.qt_ui.app import Window,pieces
    from algebra_lab.qt_ui.route_map import RouteMap
    from algebra_lab.adventure import ADVENTURE_TASKS
    from algebra_lab.math_engine import Linear,equation,parse
except ImportError:QApplication=None

@unittest.skipUnless(QApplication,'Qt dependencies required')
class ExtendedTouchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        root=Path(__file__).resolve().parents[1]
        for font in (root/'packaging/fonts').glob('*.ttf'):QFontDatabase.addApplicationFont(str(font))
        cls.app.setStyleSheet((root/'algebra_lab/qt_ui/theme.qss').read_text())
    def test_large_weights_keep_the_unknown_separate_and_preserve_exact_value(self):
        from algebra_lab.qt_ui.scene3d.physics import CupMotion3D
        self.assertEqual(pieces(Linear(1,12)),['x','12'])
        for task in ADVENTURE_TASKS:
            eq=equation(task['equation'])
            for side in [eq.left,eq.right]:
                labels=pieces(side)
                self.assertLessEqual(len(labels),5)
                self.assertEqual(sum((parse(label) for label in labels),Linear()),side)
                if side.a==1:self.assertIn('x',labels)
        cup=CupMotion3D();cup.target(['x','x','x','−63'],False)
        for body in cup.bodies:
            self.assertEqual(body.width,52)
            self.assertLessEqual(abs(body.x)+body.width/2,cup.radius)
    def test_two_digit_tags_update_the_answer_field_without_auto_completion(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp),software_view=True);w.store.save_settings({'motion':False});w.start('teens-1');w.show();self.app.processEvents()
            try:
                before=w.board.geometry()
                for digit in ['0','1','6']:w.store.bind('A'+digit,digit)
                w.operation('remove')
                for side in ['left','right']:w.scan({'uid':'A6','source':side})
                for digit in ['1','0']:w.scan({'uid':'A'+digit,'source':'left'})
                self.assertEqual(w.answer.currentText(),'10');self.assertFalse(w.session.completed)
                self.assertEqual(w.board.geometry(),before)
                w.answer.showPopup();self.app.processEvents()
                popup=self.app.activePopupWidget()
                self.assertIsNotNone(popup);self.assertLessEqual(popup.height(),354)
                self.assertGreaterEqual(w.answer.view().sizeHintForRow(0),40)
                w.answer.hidePopup()
                w.check();self.assertTrue(w.session.completed)
                w.start('nothing-1');w.answer.setCurrentIndex(w.answer.findText('0'))
                self.assertEqual(w.session.cup_guess,0)
            finally:w.close()
    def test_chapter_paging_previews_locked_paths_and_opens_unlocked_extension(self):
        d=RouteMap({},'cups-1',motion=False);d.show();self.app.processEvents()
        try:
            d.next_page.click();self.app.processEvents()
            self.assertEqual(d.chapter,4);self.assertIn('Закрытая глава',d.subtitle.text())
            self.assertEqual(sum(b.isVisible() for b in d.tabs),4)
            self.assertTrue(all(not b.isEnabled() for b in d.trail.nodes.values()))
            d.choose_task('digits-1');self.assertIsNone(d.chosen_task)
            d.previous_page.click();self.assertEqual(d.chapter,0)
        finally:d.close()
        best={t['id']:3 for t in ADVENTURE_TASKS[:24]};d=RouteMap(best,'duet-6',motion=False)
        try:
            d.next_page.click();self.assertEqual(d.chapter,4)
            self.assertTrue(d.trail.nodes['digits-1'].isEnabled())
            d.choose_task('digits-1');self.assertEqual(d.chosen_task,'digits-1')
        finally:d.close()
