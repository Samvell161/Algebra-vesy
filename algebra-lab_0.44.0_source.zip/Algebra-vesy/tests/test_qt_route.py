import tempfile
import unittest
from functools import partial
from pathlib import Path
try:
    from PyQt6.QtWidgets import QApplication,QPushButton
    from PyQt6.QtCore import QTimer
    from algebra_lab.qt_ui.route_map import RouteMap
    from algebra_lab.qt_ui.app import Window as AppWindow
    Window=partial(AppWindow,software_view=True)
    from algebra_lab.adventure import ADVENTURE_TASKS
except ImportError:
    QApplication=None

@unittest.skipUnless(QApplication,'Qt dependencies required')
class RouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def test_first_lesson_gate_replay_and_quiz_gate(self):
        dialog=RouteMap({},'cups-1');dialog.show();self.app.processEvents()
        try:
            self.assertTrue(dialog.trail.nodes['cups-1'].isEnabled())
            self.assertFalse(dialog.trail.nodes['cups-2'].isEnabled())
            self.assertFalse(dialog.tabs[1].isEnabled())
            dialog.choose_task('cups-2');self.assertIsNone(dialog.chosen_task)
            dialog.choose_quiz();self.assertIsNone(dialog.chosen_quiz)
        finally:dialog.close()
        best={t['id']:3 for t in ADVENTURE_TASKS[:6]}
        dialog=RouteMap(best,'cups-6');dialog.show();self.app.processEvents()
        try:
            self.assertTrue(dialog.tabs[1].isEnabled())
            self.assertTrue(dialog.quiz_button.isEnabled())
            dialog.trail.nodes['cups-1'].click();self.assertEqual(dialog.chosen_task,'cups-1')
        finally:dialog.close()
        dialog=RouteMap(best,'cups-6')
        try:
            dialog.quiz_button.click();self.assertEqual(dialog.chosen_quiz,'quiz-1')
        finally:dialog.close()

    def test_all_chapters_fit_and_cache_background_with_six_touch_stops(self):
        best={t['id']:3 for t in ADVENTURE_TASKS}
        dialog=RouteMap(best,'duet-1');dialog.show();self.app.processEvents()
        try:
            for chapter in range(12):
                dialog.select_chapter(chapter);self.app.processEvents()
                self.assertLessEqual(dialog.width(),1000);self.assertLessEqual(dialog.height(),560)
                self.assertEqual(len(dialog.trail.nodes),6)
                for button in dialog.trail.nodes.values():
                    self.assertGreaterEqual(button.width(),44);self.assertGreaterEqual(button.height(),44)
                    self.assertTrue(dialog.trail.rect().contains(button.geometry()))
                dialog.trail.grab();key=dialog.trail.cache.cacheKey();dialog.trail.grab()
                self.assertEqual(dialog.trail.cache.cacheKey(),key)
        finally:dialog.close()

    def test_route_click_starts_selected_task_in_real_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.record('unlock','cups-1','practice',1,0,1)
                def choose():
                    dialog=QApplication.activeModalWidget()
                    dialog.findChild(QPushButton,'route-cups-4').click()
                QTimer.singleShot(0,choose);w.map()
                self.assertEqual(w.session.task_id,'cups-4')
                self.assertTrue(w.session.cup_play)
                self.assertEqual(w.condition.text(),'x + 2 = 4')
            finally:w.close()

    def test_animation_keeps_targets_and_caches_and_stops_on_hide_or_reduced_motion(self):
        from PyQt6.QtTest import QTest
        best={t['id']:3 for t in ADVENTURE_TASKS[:6]}
        dialog=RouteMap(best,'cups-4');dialog.show();self.app.processEvents()
        try:
            trail=dialog.trail;self.assertTrue(trail.is_animating)
            dialog.tabs[0].click()
            self.assertIs(dialog.trail,trail);self.assertTrue(dialog.tabs[0].isChecked())
            geometry={key:button.geometry() for key,button in trail.nodes.items()}
            trail.grab();cache=trail.cache.cacheKey();route=trail.route_cache.cacheKey()
            QTest.qWait(160)
            self.assertGreater(trail._reveal,0);self.assertLess(trail._reveal,1)
            self.assertEqual({key:button.geometry() for key,button in trail.nodes.items()},geometry)
            QTest.qWait(1450);trail.grab()
            self.assertEqual(trail._reveal,1)
            self.assertEqual(trail.cache.cacheKey(),cache);self.assertEqual(trail.route_cache.cacheKey(),route)
            dialog.tabs[1].click()
            self.assertFalse(trail.is_animating)
            self.app.processEvents()
            self.assertTrue(dialog.trail.is_animating)
            dialog.trail.set_motion(False);self.assertFalse(dialog.trail.is_animating)
            self.assertEqual(dialog.trail._reveal,1)
            phase=dialog.trail._phase;QTest.qWait(140);self.assertEqual(dialog.trail._phase,phase)
            dialog.trail.set_motion(True);self.assertTrue(dialog.trail.is_animating)
            dialog.hide();self.assertFalse(dialog.trail.is_animating)
            dialog.show();self.assertTrue(dialog.trail.is_animating)
        finally:
            dialog.close()
        self.assertFalse(dialog.trail.is_animating)

    def test_real_workspace_passes_motion_preference_and_selection_remains_immediate(self):
        with tempfile.TemporaryDirectory() as tmp:
            w=Window(Path(tmp))
            try:
                w.store.save_settings({'motion':False})
                checks={}
                def choose_without_animation():
                    dialog=QApplication.activeModalWidget()
                    checks['running']=dialog.trail.is_animating
                    checks['reveal']=dialog.trail._reveal
                    dialog.trail.nodes['cups-1'].click()
                QTimer.singleShot(0,choose_without_animation);w.map()
                self.assertFalse(checks['running']);self.assertEqual(checks['reveal'],1)
                self.assertEqual(w.session.task_id,'cups-1')
                w.store.save_settings({'motion':True});w.store.record('unlock','cups-1','practice',1,0,1)
                def choose_during_reveal():
                    dialog=QApplication.activeModalWidget()
                    checks['intro']=dialog.trail._reveal
                    dialog.trail.nodes['cups-4'].click()
                QTimer.singleShot(0,choose_during_reveal);w.map()
                self.assertLess(checks['intro'],1)
                self.assertEqual(w.session.task_id,'cups-4')
            finally:w.close()
