import json
import socket
import tempfile
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from algebra_lab.storage import Store
from algebra_lab.mobile import ProgressHub,snapshot,SERVICE

class MobileTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)
        self.store=Store(self.path/'algebra.sqlite3');self.store.save_settings({'name':'Маша'})
        self.store.record('first','cups-1','practice',2,0,15)
        self.other=self.store.create_profile('Саша');self.store.select_profile(self.other)
        self.hub=ProgressHub(self.path,host='127.0.0.1',port=0,discovery_port=0);self.hub.start()
        for _ in range(100):
            if self.hub.running or self.hub.error:break
            time.sleep(.01)
        self.assertTrue(self.hub.running,self.hub.error)
        self.base='http://127.0.0.1:'+str(self.hub.port)
    def tearDown(self):
        self.hub.close();self.store.close();self.tmp.cleanup()
    def request(self,path,body=None,token=None,headers=None):
        values=dict(headers or {})
        if token:values['Authorization']='Bearer '+token
        return urllib.request.urlopen(urllib.request.Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=values),timeout=2)
    def pair(self):
        with self.request('/v1/pair',{'code':self.hub.new_code()}) as r:return json.load(r)['token']
    def test_auth_snapshot_is_readonly_and_complete_with_etag(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/progress')
        self.assertEqual(e.exception.code,401)
        token=self.pair()
        with self.request('/v1/progress',token=token) as r:
            data=json.load(r);etag=r.headers['ETag']
        self.assertEqual(len(data['profiles']),2)
        self.assertEqual(data['profiles'][0]['xp'],30)
        self.assertEqual(data['profiles'][1]['xp'],0)
        self.assertEqual(data['profiles'][0]['chapters'][0]['completed'],1)
        self.assertEqual(self.store.profile_id,self.other)
        self.assertNotIn('tags',data);self.assertNotIn('token',data)
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/progress',token=token,headers={'If-None-Match':etag})
        self.assertEqual(e.exception.code,304)
        self.store.record('second','cups-2','practice',2,1,20)
        with self.request('/v1/progress',token=token) as r:self.assertEqual(json.load(r)['profiles'][1]['xp'],20)
    def test_discovery_nonce_metadata_only_and_revocation(self):
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.settimeout(2);sock.sendto(json.dumps({'service':SERVICE,'schema':1,'nonce':'abc'}).encode(),('127.0.0.1',self.hub.discovery_port))
            value=json.loads(sock.recv(2048))
        self.assertEqual(value['nonce'],'abc');self.assertEqual(value['port'],self.hub.port)
        self.assertNotIn('profiles',value)
        token=self.pair();self.hub.revoke()
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/progress',token=token)
        self.assertEqual(e.exception.code,401)
    def test_pair_code_one_use_rate_limit_and_tokens_survive_restart(self):
        token=self.pair()
        for _ in range(4):self.assertEqual(self.hub.pair('wrong','test')[0],403)
        self.assertEqual(self.hub.pair('wrong','test')[0],403)
        self.assertEqual(self.hub.pair('wrong','test')[0],429)
        self.hub.close();self.hub.start()
        for _ in range(100):
            if self.hub.running:break
            time.sleep(.01)
        self.base='http://127.0.0.1:'+str(self.hub.port)
        with self.request('/v1/progress',token=token) as r:self.assertEqual(r.status,200)

    def test_authenticated_lesson_catalog_proposals_and_cancel(self):
        token=self.pair()
        self.store.save_settings({'mobile_lessons_enabled':True})
        with self.request('/v1/lessons?profile=default',token=token) as r:
            catalog=json.load(r)
        self.assertTrue(catalog['can_propose']);self.assertEqual(len(catalog['lessons']),72)
        body={'id':'a'*32,'profile_id':'default','task_id':'cups-3'}
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/lesson-requests',body)
        self.assertEqual(e.exception.code,401)
        with self.request('/v1/lesson-requests',body,token) as r:self.assertEqual(json.load(r)['request']['state'],'pending')
        with self.request('/v1/lesson-requests',body,token) as r:self.assertEqual(json.load(r)['request']['id'],'a'*32)
        with self.request('/v1/progress',token=token) as r:self.assertEqual(json.load(r)['profiles'][0]['lesson_request']['id'],'a'*32)
        self.assertEqual(self.store.profile_id,self.other)
        with self.request('/v1/lesson-requests/cancel',{'id':'a'*32,'profile_id':'default'},token) as r:self.assertEqual(json.load(r)['request']['state'],'cancelled')
        self.store.save_settings({'mobile_lessons_enabled':False})
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/lesson-requests',dict(body,id='b'*32),token)
        self.assertEqual(e.exception.code,403)
