"""Native Raspberry Pi application. One Python/Tk process; no HTTP server or browser."""
import argparse
import fcntl
import logging
import math
import os
import sqlite3
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter import font as tkfont

from . import __version__
from .tag_import import phone_uid, parse_tags, export_tags, MAX_BYTES
from .mobile import ProgressHub
from .hardware import BLOCKS, COMMANDS, TAG_KINDS, NUMERIC_TAGS, Reader, normalize_uid
from .service import Service, Session
from .buttons import Buttons
from .math_engine import Linear
from .storage import Store
from .tasks import TASKS, STARTER_TASKS
from .adventure import ADVENTURE_TASKS, ADVENTURE_IDS, LANDS, QUIZZES, QUIZ_BY_ID, land_index, land_open, level_open, quiz_open, next_level
PLAY_TASKS = ADVENTURE_TASKS + TASKS
TOTAL_ACTIVITIES = len(PLAY_TASKS) + len(QUIZZES)
from .learning import CHAPTERS, daily_task, learning_stats, progress_csv, game_progress
from .balance_view import BalanceCanvas, symbolic_tilt

PAPER, WHITE, INK, MUTED, GREEN = "#f5f6ff", "#ffffff", "#233254", "#536580", "#6451d8"
LINE, MINT, GOLD, BLUE = "#d8e0f2", "#eef0ff", "#ffc454", "#70c8f3"


def data_directory():
    """Use a user-writable location regardless of launcher working directory."""
    base = os.environ.get("XDG_DATA_HOME")
    return (Path(base) if base and Path(base).is_absolute() else Path.home() / ".local/share") / "algebra-lab"


class ScrollArea(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, style="Paper.TFrame")
        self.canvas = tk.Canvas(self, bg=PAPER, highlightthickness=0)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = ttk.Frame(self.canvas, padding=(24, 18), style="Paper.TFrame")
        self.window = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.canvas.bind("<Configure>", self.fit)
        self.body.bind("<Configure>", self.fit)

    def fit(self, event=None):
        width = max(1, self.canvas.winfo_width())
        height = max(self.body.winfo_reqheight(), self.canvas.winfo_height())
        if int(float(self.canvas.itemcget(self.window, "width") or 0)) != width or int(float(self.canvas.itemcget(self.window, "height") or 0)) != height:
            self.canvas.itemconfigure(self.window, width=width, height=height)
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))


class Scale(tk.Canvas):
    def __init__(self, parent, left, right, tilt=0, motion=True, height=175):
        super().__init__(parent, bg=MINT, highlightthickness=0, height=height)
        self.left, self.right = left, right
        self.angle, self.target = (0 if motion else tilt * 6), tilt * 6
        self.timer = None
        self.bind("<Configure>", lambda e: self.draw())
        if motion and tilt:
            self.timer = self.after(20, self.animate)

    def animate(self):
        self.angle += (self.target - self.angle) * .3
        self.draw()
        self.timer = self.after(20, self.animate) if abs(self.angle - self.target) > .1 else None

    def draw(self):
        self.delete("all")
        w, h = max(300, self.winfo_width()), max(100, self.winfo_height())
        cx, cy, length = w / 2, h * .31, min(w * .31, 160)
        angle = math.radians(self.angle)
        self.create_oval(cx - 95, h - 20, cx + 95, h - 4, fill="#e0e8d7", outline="")
        self.create_polygon(cx - 8, cy, cx + 8, cy, cx + 22, h - 20, cx - 22, h - 20, fill="#becdb9", outline="")
        self.create_line(cx - 55, h - 18, cx + 55, h - 18, width=9, fill=GREEN, capstyle="round")
        ends = [(cx - length * math.cos(angle), cy - length * math.sin(angle)),
                (cx + length * math.cos(angle), cy + length * math.sin(angle))]
        self.create_line(*ends[0], *ends[1], fill=GREEN, width=7, capstyle="round")
        for (x, y), label, color in zip(ends, [self.left, self.right], [GOLD, BLUE]):
            py, pw = y + h * .42, min(63, w * .13)
            self.create_line(x, y, x - pw, py, fill="#92a78c", width=2)
            self.create_line(x, y, x + pw, py, fill="#92a78c", width=2)
            self.create_rectangle(x - pw + 8, py - 37, x + pw - 8, py - 2, fill=color, outline="")
            text = label if len(label) <= 15 else label[:13] + "…"
            self.create_text(x, py - 20, text=text, font=("DejaVu Serif", 14), fill=INK)
            self.create_arc(x - pw, py - 16, x + pw, py + 22, start=180, extent=180, fill=GREEN, outline=GREEN)
        self.create_oval(cx - 9, cy - 9, cx + 9, cy + 9, fill=GOLD, outline="")
        self.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=WHITE, outline="")

    def destroy(self):
        if self.timer:
            self.after_cancel(self.timer)
        super().destroy()


class Desktop:
    def __init__(self, root, store, reader):
        self.root, self.store, self.reader = root, store, reader
        families = set(tkfont.families(root))
        self.ui_font = "Algebra Rounded" if "Algebra Rounded" in families else "DejaVu Sans"
        self.mobile = ProgressHub(Path(store.db.execute("PRAGMA database_list").fetchone()[2]).parent)
        if store.settings().get("mobile_enabled", False):
            self.mobile.start()
        self.service, self.session = Service(store, reader), Session()
        self.service.restore_practice(self.session)
        self.page, self.side, self.level = "home", "left", 0
        self.hint_text, self.last_uid = "", ""
        self.feedback = ""
        self.balance_pose = 0
        self.round_start_xp = game_progress(self.store.progress())["xp"]
        self.round_start_stars = self.store.progress()["best"].get(self.session.task_id, 0)
        self.quiz_state = None
        self.closed, self.dialog = False, None
        self.child_requested = False
        self.tag_waiting = False
        self.controls, self.errors = {}, []
        self.buttons = Buttons(reader.emit, store.settings().get("buttons_enabled", False))
        self.event_sequence = reader.sequence
        self.timer_id = None
        self.operation = tk.StringVar(root, "subtract")
        self.operand, self.answer = tk.StringVar(root), tk.StringVar(root)
        self.x_value, self.custom = tk.StringVar(root, "1"), tk.StringVar(root)
        self.status = tk.StringVar(root, "Можно начинать.")
        root.title("Алгебра LAB " + __version__)
        root.geometry("1024x600")
        root.minsize(1024, 480)
        root.configure(bg=PAPER)
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.report_callback_exception = self.callback_error
        root.bind("<F11>", lambda e: root.attributes("-fullscreen", not root.attributes("-fullscreen")))
        root.bind("<Escape>", lambda e: root.attributes("-fullscreen", False))
        root.bind_all("<MouseWheel>", lambda e: self.wheel(e, -int(e.delta / 120)))
        root.bind_all("<Button-4>", lambda e: self.wheel(e, -1))
        root.bind_all("<Button-5>", lambda e: self.wheel(e, 1))
        self.setup_styles()
        header = ttk.Frame(root, padding=(16, 7), style="Paper.TFrame")
        header.pack(fill="x")
        ttk.Label(header, text="⚖ алгебра LAB", style="Brand.TLabel").pack(side="left", padx=(0, 20))
        self.navigation = {}
        for page, label in [("home", "Главная"), ("practice", "Практика"), ("lab", "Лаборатория"), ("progress", "Прогресс")]:
            button = self.button(header, label, lambda p=page: self.navigate(p))
            button.pack(side="left", padx=2)
            self.navigation[page] = button
        self.adult_button = self.button(header, "Для взрослого", self.settings, "adult")
        self.adult_button.pack(side="right")
        ttk.Separator(root).pack(fill="x")
        bottom = ttk.Frame(root, style="Paper.TFrame", padding=(22, 6))
        bottom.pack(side="bottom", fill="x")
        self.status_label = ttk.Label(bottom, textvariable=self.status, style="Small.TLabel", wraplength=480)
        self.status_label.pack(side="left")
        self.help_button = self.button(bottom, "Как играть", self.help)
        self.help_button.pack(side="right")
        child_button = self.button(bottom, "← Детский экран", self.return_to_child, "return-child")
        child_button.configure(style="Compact.TButton")
        child_button.pack(side="right", padx=6)
        self.area = ScrollArea(root)
        self.area.pack(fill="both", expand=True)
        self.render()
        self.tick()

    def setup_styles(self):
        prefs = self.store.settings()
        self.muted = INK if prefs["contrast"] else MUTED
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", font=(self.ui_font, 10), foreground=INK, background=PAPER)
        style.configure("Paper.TFrame", background=PAPER)
        style.configure("Card.TFrame", background=WHITE, borderwidth=1, bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, relief="solid")
        style.configure("Hero.TFrame", background=GREEN)
        style.configure("Hero.TLabel", background=GREEN, foreground=WHITE)
        style.configure("HeroSmall.TLabel", background=GREEN, foreground="#eeeaff", font=(self.ui_font, 10))
        style.configure("Success.TLabel", background=MINT, foreground=GREEN, font=(self.ui_font, 12, "bold"))
        style.configure("Mint.TFrame", background=MINT)
        for name, bg in [("TLabel", PAPER), ("Card.TLabel", WHITE), ("Mint.TLabel", MINT)]:
            style.configure(name, background=bg, foreground=INK)
        style.configure("Brand.TLabel", font=(self.ui_font, 19, "bold"), foreground=GREEN)
        style.configure("Title.TLabel", font=(self.ui_font, 24, "bold"))
        style.configure("Heading.TLabel", font=(self.ui_font, 15, "bold"))
        style.configure("Small.TLabel", font=(self.ui_font, 9), foreground=self.muted)
        style.configure("CardSmall.TLabel", background=WHITE, font=(self.ui_font, 9), foreground=self.muted)
        style.configure("Eyebrow.TLabel", font=(self.ui_font, 9, "bold"), foreground=GREEN)
        style.layout("TButton", [("Button.padding", {"sticky": "nswe", "children": [("Button.focus", {"sticky": "nswe", "children": [("Button.label", {"sticky": "nswe"})]})]})])
        style.configure("TButton", padding=(12, 10), background="#e5e9fc", borderwidth=0, focusthickness=1)
        style.map("TButton", background=[("active", MINT)])
        style.configure("Primary.TButton", background=GREEN, foreground=WHITE, padding=(12, 10))
        style.map("Primary.TButton", background=[("active", "#4938b5"), ("disabled", "#9eada3")], foreground=[("disabled", WHITE)])
        style.configure("Compact.TButton", font=(self.ui_font, 11), padding=(9, 4))
        style.configure("Game.TButton", font=(self.ui_font, 14, "bold"), padding=(12, 8))
        style.configure("GamePrimary.TButton", font=(self.ui_font, 14, "bold"), padding=(12, 8), background=GREEN, foreground=WHITE)
        style.map("GamePrimary.TButton", background=[("active", "#4938b5"), ("disabled", "#a6acd1")])
        style.configure("GameHeading.TLabel", font=(self.ui_font, 18, "bold"))
        style.configure("GameHint.TLabel", font=(self.ui_font, 14), foreground=INK, background=MINT)
        style.configure("GameFeedback.TLabel", font=(self.ui_font, 12), foreground=INK)
        style.configure("Tag.TButton", font=(self.ui_font, 9), padding=(7, 6))
        style.configure("SelectedTag.TButton", font=(self.ui_font, 9), padding=(7, 6), background=GREEN, foreground=WHITE)
        style.map("SelectedTag.TButton", background=[("active", "#4938b5")])
        style.configure("TEntry", padding=7, fieldbackground=WHITE)
        style.configure("TRadiobutton", background=WHITE, padding=(6, 8))
        style.configure("TCheckbutton", background=PAPER, padding=7)
        style.configure("TProgressbar", background=GREEN, troughcolor=MINT)

    def guard(self, command):
        try:
            return command()
        except (ValueError, sqlite3.Error, OSError) as exc:
            self.status.set(str(exc))
            return None

    def wheel(self, event, units):
        widget = event.widget
        while widget is not None:
            if isinstance(widget, ScrollArea):
                widget.canvas.yview_scroll(units, "units")
                return
            widget = getattr(widget, "master", None)
        self.area.canvas.yview_scroll(units, "units")

    def callback_error(self, kind, value, traceback):
        self.errors.append(value)
        logging.error("Desktop callback failed", exc_info=(kind, value, traceback))
        self.status.set("Ошибка интерфейса. Закройте окно и запустите приложение снова.")

    def button(self, parent, text, command, key=None, primary=False):
        button = ttk.Button(parent, text=text, command=lambda: self.guard(command), style="Primary.TButton" if primary else "TButton")
        if key:
            self.controls[key] = button
        return button

    def label(self, parent, text, style="TLabel", **kwargs):
        kwargs.setdefault("wraplength", 900 if parent is self.body else 430)
        widget = ttk.Label(parent, text=text, style=style, **kwargs)
        widget.pack(anchor="w", pady=(0, 8))
        return widget

    def card(self, parent, **kwargs):
        return ttk.Frame(parent, style="Card.TFrame", padding=16, **kwargs)

    def heading(self, eyebrow, title, subtitle=""):
        self.label(self.body, eyebrow.upper(), "Eyebrow.TLabel")
        self.label(self.body, title, "Title.TLabel")
        if subtitle:
            self.label(self.body, subtitle, "Small.TLabel", wraplength=900)

    def navigate(self, page):
        self.page = page
        self.render()
        self.area.canvas.yview_moveto(0)

    def simple_ui(self):
        return bool(self.store.settings().get("simple_ui", True))

    def sync_navigation(self):
        for page, button in self.navigation.items():
            button.pack_forget()
            if not self.simple_ui() or page == "home":
                button.configure(text="Занятие" if self.simple_ui() else {"home": "Главная", "practice": "Практика", "lab": "Лаборатория", "progress": "Прогресс"}[page])
                button.pack(side="left", padx=2)
        self.adult_button.configure(text="Для взрослого" if self.simple_ui() else "Настройки")
        self.help_button.configure(text="Как играть" if self.simple_ui() else "Справка", style="Compact.TButton" if self.simple_ui() else "TButton")
        self.status_label.pack_forget()
        if not self.simple_ui():
            self.status_label.pack(side="left")
        self.area.body.configure(padding=(14, 8) if self.simple_ui() else (24, 18))

    def render(self):
        board = getattr(self, "balance_widget", None)
        if getattr(self, "reset_balance_on_render", False):
            self.balance_pose = 0
            self.reset_balance_on_render = False
        elif board is not None and board.winfo_exists():
            self.balance_pose = board.angle
        self.sync_navigation()
        self.service.save_practice(self.session)
        for page, button in self.navigation.items():
            button.configure(style="Primary.TButton" if page == ("practice" if self.page == "exercise" else self.page) else "TButton")
        for child in self.area.body.winfo_children():
            child.destroy()
        self.body = self.area.body
        self.controls = {key: widget for key, widget in self.controls.items() if widget.winfo_exists()}
        {"home": self.home, "practice": self.practice, "exercise": self.exercise,
         "lab": self.lab, "progress": self.progress, "quiz": self.quiz_screen}[self.page]()

    def next_task(self):
        best = self.store.progress()["best"]
        return next((t for t in TASKS if t["id"] not in best), TASKS[0])

    def start(self, task_id=None, mode="practice"):
        self.round_start_xp = game_progress(self.store.progress())["xp"]
        self.reset_balance_on_render = True
        self.service.start(self.session, {"task_id": task_id or self.next_task()["id"], "mode": mode})
        self.round_start_stars = self.store.progress()["best"].get(self.session.task_id, 0)
        if self.simple_ui() and self.session.task_id in ADVENTURE_IDS:
            self.service.begin_student(self.session)
        self.operand.set("")
        self.answer.set("")
        self.operation.set("subtract")
        self.hint_text = ""
        self.feedback = ""
        self.navigate("exercise")

    def home(self):
        if self.simple_ui():
            self.simple_home()
            return
        progress = self.store.progress()
        stats = learning_stats(progress)
        self.label(self.body, "ТВОЯ ЛАБОРАТОРИЯ ОТКРЫТИЙ  /  ЭКСПЕДИЦИЯ 01", "Eyebrow.TLabel")
        hero = ttk.Frame(self.body, style="Hero.TFrame", padding=18)
        hero.pack(fill="x", pady=(4, 16))
        copy = ttk.Frame(hero, style="Hero.TFrame")
        copy.pack(side="left", fill="both", expand=True)
        self.label(copy, "Большие открытия.\nМаленькими шагами.", "Hero.TLabel", font=(self.ui_font, 21, "bold"))
        self.label(copy, "Уравновешивай чаши. Проверяй идеи.\nСтань мастером своей лаборатории.", "HeroSmall.TLabel")
        continuing = self.session.current and not self.session.completed
        self.button(copy, "Продолжить решение  →" if continuing else "Начать исследование  →",
                    lambda: self.navigate("exercise") if continuing else (self.start_physical() if self.reader.mode in ("rc522", "rc522_dual") else self.start()), "start").pack(anchor="w", pady=(6, 0))
        self.button(copy, "Решать физическими метками", self.start_physical, "physical-start", True).pack(anchor="w", pady=(5, 0))
        Scale(hero, "x + 3", "7", height=150).pack(side="right", fill="both", expand=True, padx=(22, 0))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(0, 16))
        for title, value, note in [("ТВОЙ УРОВЕНЬ", stats["rank"], f'{stats["xp"]} XP · за лучшие результаты'),
                                   ("РИТМ ПРАКТИКИ", f'{stats["streak"]} дн. подряд', f'Сегодня: {stats["today"]} / 3 разных задания'),
                                   ("КОЛЛЕКЦИЯ ЗВЁЗД", f'{progress["stars"]} / {TOTAL_ACTIVITIES * 3}', f'{progress["completed"]} из {TOTAL_ACTIVITIES} открытий')]:
            card = ttk.Frame(row, style="Card.TFrame", padding=12)
            card.pack(side="left", fill="both", expand=True, padx=(0, 8))
            self.label(card, title, "CardSmall.TLabel")
            self.label(card, value, "Card.TLabel", font=(self.ui_font, 15, "bold"))
            self.label(card, note, "CardSmall.TLabel")
        daily = daily_task()
        mission = ttk.Frame(self.body, style="Card.TFrame", padding=12)
        mission.pack(fill="x", pady=(0, 16))
        self.button(mission, "Повторить" if stats["daily_done"] else "Решить задание  →", lambda: self.start(daily["id"]), "daily", True).pack(side="right", padx=(12, 0))
        self.label(mission, "✓ ЗАДАНИЕ ДНЯ ВЫПОЛНЕНО" if stats["daily_done"] else "НОВАЯ ИДЕЯ КАЖДЫЙ ДЕНЬ", "CardSmall.TLabel")
        self.label(mission, daily["title"] + "   ·   " + daily["equation"], "Card.TLabel", font=(self.ui_font, 14, "bold"))
        self.label(self.body, "Твоя экспедиция", "Heading.TLabel")
        chapters = ttk.Frame(self.body)
        chapters.pack(fill="x")
        for i, chapter in enumerate(CHAPTERS):
            chapters.columnconfigure(i, weight=1, uniform="chapters")
            card = self.card(chapters)
            card.grid(row=0, column=i, sticky="nsew", padx=(0, 8))
            count = stats["chapters"][i]
            badge = tk.Canvas(card, height=42, width=160, bg=chapter[2], highlightthickness=0)
            badge.pack(fill="x", pady=(0, 12))
            badge.create_oval(12, 7, 40, 35, fill=GREEN, outline="")
            badge.create_text(26, 21, text=str(i+1), fill=WHITE, font=(self.ui_font, 12, "bold"))
            badge.create_line(48, 21, 152, 21, fill="#a2b7ab", width=2, dash=(3, 5))
            self.label(card, f'0{i+1}  /  {count["completed"]} из {count["total"]}', "CardSmall.TLabel")
            self.label(card, chapter[0], "Card.TLabel", font=(self.ui_font, 12, "bold"), wraplength=182)
            self.label(card, chapter[1], "CardSmall.TLabel", wraplength=182)
            ttk.Progressbar(card, maximum=count["total"], value=count["completed"]).pack(fill="x", pady=(0, 12))
            self.button(card, "Открыть  →", lambda v=i+1: self.open_chapter(v), "chapter-" + str(i+1)).pack(fill="x")

    def simple_home(self):
        stats = game_progress(self.store.progress())
        self.heading("МАСТЕРСКАЯ РАВНОВЕСИЯ", "Привет, исследователь!", "Один блок — один шаг. Помоги чашам снова стать ровно.")
        summary = ttk.Frame(self.body)
        summary.pack(fill="x", pady=(0, 8))
        ttk.Label(summary, text="★ Уровень " + str(stats["level"]), style="Heading.TLabel").pack(side="left")
        ttk.Label(summary, text=str(stats["xp"]) + " XP · до следующего уровня " + str(stats["next_xp"]) + " XP", style="Small.TLabel").pack(side="right")
        ttk.Progressbar(self.body, maximum=60, value=stats["level_xp"]).pack(fill="x", pady=(0, 8))
        hero = ttk.Frame(self.body, style="Mint.TFrame", padding=12)
        hero.pack(fill="x")
        board = BalanceCanvas(hero, Linear(1, 1), Linear(0, 2), height=180, motion=False, font_family=self.ui_font)
        board.pack(fill="x")
        self.balance_widget = board
        continuing = self.session.task_id in ADVENTURE_IDS and not self.session.completed
        button = self.button(hero, "Продолжить приключение →" if continuing else "Начать приключение →", self.start_physical, "physical-start", True)
        button.pack(fill="x", pady=(6, 0))
        self.controls["start"] = button
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(10, 0))
        self.button(row, "Карта уроков", self.lesson_map, "lesson-map").pack(side="left", expand=True, fill="x", padx=(0, 8))
        self.button(row, "Мои открытия", self.child_statistics, "child-stats").pack(side="left", expand=True, fill="x")
        if not self.store.tags():
            self.label(self.body, "Взрослый поможет подготовить метку +1 в разделе «Для взрослого».", "Small.TLabel")

    def lesson_map(self, area=None):
        area = land_index(self.session.task_id) if area is None else area
        dialog, frame = self.modal("Карта приключения", scroll=True)
        dialog.geometry("860x540+%d+%d" % (max(0, self.root.winfo_rootx() + (self.root.winfo_width()-860)//2), max(0, self.root.winfo_rooty() + (self.root.winfo_height()-540)//2)))
        best = self.store.progress()["best"]
        tabs = ttk.Frame(frame)
        tabs.pack(fill="x", pady=(0, 8))
        for i, (name, description) in enumerate(LANDS):
            button = self.button(tabs, str(i+1) + " · " + name, lambda index=i: self.lesson_map(index), "land-" + str(i+1), i == area)
            button.configure(style="Compact.TButton" if i != area else "Primary.TButton")
            button.grid(row=i//2, column=i%2, sticky="ew", padx=2, pady=2)
            tabs.columnconfigure(i%2, weight=1)
            if not land_open(best, i):
                button.state(["disabled"])
        tasks = ADVENTURE_TASKS[area*6:(area+1)*6]
        completed = sum(task["id"] in best for task in tasks)
        self.label(frame, LANDS[area][1] + "  ·  " + str(completed) + "/6", "GameFeedback.TLabel", wraplength=760)
        for index, task in enumerate(tasks):
            done = task["id"] in best
            text = ("✓ " if done else str(area*6+index+1) + ". ") + task["title"] + " · " + task["equation"]
            button = self.button(frame, text, lambda t=task: self.open_map_lesson(t["id"]), "map-" + task["id"], not done and level_open(best, task["id"]))
            button.configure(style="GamePrimary.TButton" if not done and level_open(best, task["id"]) else "Game.TButton")
            button.pack(fill="x", pady=3)
            if not level_open(best, task["id"]):
                button.state(["disabled"])
        footer = dialog.winfo_children()[0]
        quiz = QUIZZES[area]
        text = "✓ Квиз пройден" if quiz["id"] in best else "Квиз главы · 3 вопроса"
        button = self.button(footer, text, lambda key=quiz["id"]: self.open_quiz(key), "quiz-" + quiz["id"], True)
        button.pack(side="left")
        if not quiz_open(best, area):
            button.state(["disabled"])

    def open_map_lesson(self, task_id):
        if not level_open(self.store.progress()["best"], task_id):
            return
        if self.reader.mode not in ("rc522", "rc522_dual") or self.reader.error:
            self.reader.configure(self.reader_mode())
        self.store.save_settings({"reader_mode": self.reader.mode, "rfid_style": "cups"})
        self.event_sequence = self.reader.sequence
        self.dialog.destroy()
        self.start(task_id)
        if not self.session.cup_play:
            self.service.begin_student(self.session)
            self.render()

    def child_statistics(self):
        dialog, frame = self.modal("Мои открытия")
        stats = game_progress(self.store.progress())
        for title, value in [("Мой уровень", str(stats["level"])), ("Заработано XP", str(stats["xp"])),
                             ("Пройдено заданий", str(stats["completed"])), ("Решённых попыток", str(stats["attempts"])),
                             ("Время занятий", str(stats["seconds"] // 60) + " мин")]:
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=7)
            ttk.Label(row, text=title).pack(side="left")
            ttk.Label(row, text=value, style="Heading.TLabel").pack(side="right")
        self.label(frame, "Твой прогресс хранится на этих весах и остаётся после закрытия программы.", "Small.TLabel", wraplength=430)

    def open_quiz(self, quiz_id):
        state = self.service.start_quiz(quiz_id)
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
        self.quiz_state = state
        self.navigate("quiz")

    def quiz_choose(self, choice):
        self.service.quiz_answer(self.quiz_state, choice)
        self.render()

    def quiz_continue(self):
        self.service.quiz_next(self.quiz_state)
        self.render()

    def quiz_screen(self):
        state = self.quiz_state
        if not state:
            self.navigate("home")
            return
        quiz = QUIZ_BY_ID[state["id"]]
        area = next(i for i, item in enumerate(QUIZZES) if item["id"] == state["id"])
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=6)
        self.button(top, "← Карта", lambda: self.lesson_map(area), "quiz-map").pack(side="left")
        self.button(top, "Начало", lambda: self.navigate("home"), "quiz-home").pack(side="right")
        self.label(self.body, quiz["title"], "GameHeading.TLabel", wraplength=950)
        if state["completed"]:
            stars = max(1, 3-min(2, state["wrong"]))
            self.label(self.body, "Квиз пройден! " + "★"*stars, "GameHeading.TLabel", wraplength=950)
            self.label(self.body, "Все три вопроса разобраны. Лучший результат сохранён в «Моих открытиях».", "GameHint.TLabel", wraplength=950)
            stats = game_progress(self.store.progress())
            self.label(self.body, "Уровень " + str(stats["level"]) + " · " + str(stats["xp"]) + " XP", "Heading.TLabel")
            self.button(self.body, "Вернуться на карту", lambda: self.lesson_map(area), "quiz-finish", True).pack(fill="x", pady=12)
            return
        question = quiz["questions"][state["index"]]
        self.label(self.body, "Вопрос %d/3 · ответ выбирается касанием" % (state["index"]+1), "Small.TLabel", wraplength=950)
        self.label(self.body, question[0], "GameHint.TLabel", wraplength=950)
        for i, answer in enumerate(question[1]):
            button = self.button(self.body, answer, lambda value=i: self.quiz_choose(value), "quiz-choice-" + str(i))
            button.configure(style="Game.TButton")
            button.pack(fill="x", pady=5)
            if state["answered"]:
                button.state(["disabled"])
        if state["feedback"]:
            self.label(self.body, state["feedback"], "GameFeedback.TLabel", wraplength=950)
        if state["answered"]:
            next_button = self.button(self.body, "Готово" if state["index"] == 2 else "Дальше →", self.quiz_continue, "quiz-next", True)
            next_button.configure(style="GamePrimary.TButton")
            next_button.pack(fill="x", pady=8)

    def round_gain(self):
        best = self.store.progress()["best"].get(self.session.task_id, 0)
        return max(0, best - self.round_start_stars) * 10

    def next_adventure(self):
        task = next_level(self.store.progress()["best"], self.session.task_id)
        self.start(task["id"])

    def answer_choices(self):
        value = int(self.session.current.solution()["value"])
        if value <= 5:
            return range(0, 6)
        offset = 1 + sum(ord(char) for char in self.session.task_id) % 3
        lower = max(0, min(95, value-offset))
        return range(lower, lower+5)

    def adult_open(self, page):
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
        self.navigate(page)

    def adult_menu(self):
        dialog, frame = self.modal("Для взрослого")
        self.label(frame, "Подготовьте метки один раз — затем можно заниматься.", "Small.TLabel")
        for text, command, key in [
            ("← Вернуться в детский экран", self.return_to_child, "adult-return-child"),
            ("Мои метки · номера с телефона / файл", self.tag_manager, "manage-tags"),
            ("Проверка считывателя", self.reader_details, "adult-reader"),
            ("История решений", self.saved_solutions, "adult-solutions"),
            ("Результаты занятий", lambda: self.adult_open("progress"), "adult-progress"),
            ("Все задания и дополнительные режимы", lambda: self.adult_open("practice"), "adult-practice"),
            ("Настройки приложения", self.full_settings, "adult-settings"),
        ]:
            self.button(frame, text, command, key).pack(fill="x", pady=5)

    def open_chapter(self, level):
        self.level = level
        self.navigate("practice")

    def lesson(self, level=None):
        level = level or (self.service.exercise(self.session)["task"]["level"] if self.page == "exercise" and self.session.current else self.level or 1)
        chapter = CHAPTERS[level - 1]
        dialog, frame = self.modal("Открытие " + str(level) + " · " + chapter[3], scroll=True)
        self.label(frame, chapter[4], wraplength=430)
        example = ttk.Frame(frame, style="Mint.TFrame", padding=16)
        example.pack(fill="x", pady=12)
        self.label(example, chapter[5], "Mint.TLabel", font=(self.ui_font, 15), wraplength=400)
        self.label(frame, chapter[6], "Small.TLabel", wraplength=430)
        def try_task():
            dialog.destroy()
            self.start(next(t["id"] for t in TASKS if t["level"] == level))
        self.button(frame, "Попробовать самому  →", try_task, "lesson-try", True).pack(fill="x", pady=12)

    def task_grid(self, tasks):
        frame = ttk.Frame(self.body, style="Paper.TFrame")
        frame.pack(fill="x", pady=8)
        for col in range(3):
            frame.columnconfigure(col, weight=1, uniform="task")
        best = self.store.progress()["best"]
        for index, task in enumerate(tasks):
            card = self.card(frame)
            card.grid(row=index // 3, column=index % 3, sticky="nsew", padx=(0, 10), pady=(0, 10))
            self.label(card, f"УРОВЕНЬ {task['level']}  ·  {task['minutes']} МИН", "CardSmall.TLabel")
            self.label(card, task["title"], "Card.TLabel", font=(self.ui_font, 11, "bold"), wraplength=220)
            self.label(card, task["equation"].replace("-", "−"), "Card.TLabel", font=("DejaVu Serif", 18), wraplength=230)
            self.button(card, "Решить  →" + ("  " + "★" * best[task["id"]] if task["id"] in best else ""),
                        lambda t=task: self.start(t["id"]), "task-" + task["id"]).pack(fill="x")

    def practice(self):
        self.heading("ЭКСПЕДИЦИЯ / 24 ОТКРЫТИЯ", CHAPTERS[self.level - 1][0] if self.level else "Собери свою коллекцию открытий.")
        self.button(self.body, "Сначала: 6 простых уроков с чашами", self.start_physical, "starter-course", True).pack(anchor="w", pady=(0, 8))
        self.button(self.body, "Как это работает?  ·  Мини-урок", self.lesson, "lesson").pack(anchor="w", pady=(0, 10))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(6, 14))
        for level in range(5):
            self.button(row, f"Уровень {level}" if level else "Все задания", lambda v=level: self.filter_tasks(v),
                        "level-" + str(level), self.level == level).pack(side="left", padx=(0, 7))
        self.button(row, "Вызов · 3 минуты", lambda: self.start(mode="challenge"), "challenge").pack(side="right")
        self.task_grid([t for t in TASKS if not self.level or t["level"] == self.level])

    def filter_tasks(self, level):
        self.level = level
        self.render()

    def math_field(self, parent, variable, key, numeric=False, width=12):
        frame = ttk.Frame(parent, style="Paper.TFrame")
        entry = ttk.Entry(frame, textvariable=variable, width=width, font=(self.ui_font, 13))
        entry.pack(side="left", fill="x", expand=True)
        self.controls[key] = entry
        keyboard = self.button(frame, "⌨", lambda: self.keypad(variable, numeric), "keys-" + key)
        keyboard.configure(width=3)
        keyboard.pack(side="left", padx=(4, 0))
        return frame

    def exercise(self):
        self.clock_is_game = False
        ex = self.service.exercise(self.session)
        if ex and self.reader.mode in ("rc522", "rc522_dual"):
            self.physical_exercise(ex)
            return
        if not ex:
            self.heading("Практика", "Выбери первое задание.")
            self.button(self.body, "К заданиям", lambda: self.navigate("practice")).pack(anchor="w")
            return
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 10))
        self.button(top, "← Задания", lambda: self.navigate("practice")).pack(side="left")
        self.button(top, "Начать заново", lambda: self.start(ex["task"]["id"], ex["mode"]), "restart").pack(side="right")
        self.clock = ttk.Label(top, text=self.clock_text(ex), style="Small.TLabel")
        self.clock.pack(side="right", padx=14)
        title_row = ttk.Frame(self.body)
        title_row.pack(fill="x", pady=(0, 10))
        ttk.Label(title_row, text=ex["task"]["title"], style="Heading.TLabel").pack(side="left")
        self.button(title_row, "Правило", self.lesson, "lesson").pack(side="right")
        grid = ttk.Frame(self.body)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=16)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        eq = ex["equation"]
        self.label(left, f"{eq['left']} = {eq['right']}", "Mint.TLabel", font=("DejaVu Serif", 28), wraplength=560, anchor="center")
        Scale(left, eq["left"], eq["right"], height=130).pack(fill="x")
        self.label(left, "Схема уравнения · не показание датчика массы", "Mint.TLabel", font=(self.ui_font, 8))
        if ex["completed"]:
            self.label(left, "ОТКРЫТИЕ СОСТОЯЛОСЬ", "Success.TLabel")
            self.label(left, f"Верно! x = {eq['solution']['value']}    {'★' * ex['stars']}", "Mint.TLabel", font=(self.ui_font, 16, "bold"))
            self.button(left, "Следующее задание  →", self.next_exercise, "next", True).pack(anchor="w")
        elif ex["expired"]:
            self.label(left, "Время вышло. Можно попробовать ещё раз.", "Mint.TLabel")
            self.button(left, "Решать без таймера", lambda: self.start(ex["task"]["id"]), "untimed").pack(anchor="w")
        else:
            answer = ttk.Frame(left, style="Mint.TFrame")
            answer.pack(fill="x", pady=(8, 0))
            ttk.Label(answer, text="Ответ: x =", style="Mint.TLabel").pack(side="left", padx=(0, 8))
            self.math_field(answer, self.answer, "answer", True, 7).pack(side="left", fill="x", expand=True)
            self.button(answer, "Проверить", self.check_answer, "check-answer").pack(side="left", padx=(8, 0))
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        self.label(right, "Сохраним равенство", "Card.TLabel", font=(self.ui_font, 13, "bold"))
        self.label(right, "Действие с обеими частями:", "CardSmall.TLabel")
        operations = ttk.Frame(right, style="Card.TFrame", relief="flat")
        operations.pack(fill="x", pady=(0, 8))
        for index, (op, text) in enumerate([("add", "+ Прибавить"), ("subtract", "− Вычесть"), ("multiply", "× Умножить"), ("divide", "÷ Разделить")]):
            radio = ttk.Radiobutton(operations, text=text, value=op, variable=self.operation)
            radio.grid(row=index // 2, column=index % 2, sticky="w")
            if ex["completed"] or ex["expired"]:
                radio.state(["disabled"])
        self.label(right, "Число / выражение с x\nДля × и ÷ — только число", "CardSmall.TLabel")
        self.math_field(right, self.operand, "operand", width=15).pack(fill="x")
        apply = self.button(right, "Применить к обеим частям", self.transform, "transform", True)
        apply.pack(fill="x", pady=8)
        extras = ttk.Frame(right, style="Card.TFrame", relief="flat")
        extras.pack(fill="x")
        hint = self.button(extras, "Подсказка", self.hint, "hint")
        hint.pack(side="left", expand=True, fill="x", padx=(0, 5))
        undo = self.button(extras, "Отменить", self.undo, "undo")
        undo.pack(side="left", expand=True, fill="x")
        if ex["completed"] or ex["expired"]:
            for button in [apply, hint, undo]:
                button.state(["disabled"])
        elif len(ex["history"]) < 2:
            undo.state(["disabled"])
        if self.feedback:
            self.label(self.body, self.feedback, "Small.TLabel", wraplength=900)
        if self.hint_text:
            self.label(self.body, self.hint_text, "Small.TLabel", wraplength=900)
        self.button(self.body, f"Путь к решению · {len(ex['history']) - 1} шагов", self.history, "history").pack(anchor="w", pady=(12, 0))

    def rfid_style(self):
        style = self.store.settings().get("rfid_style", "cups" if self.session.task_id in ADVENTURE_IDS else "guided")
        if self.session.task_id in ADVENTURE_IDS and style not in ("guided", "independent"):
            return "cups"
        return style if style in ("guided", "independent") else ("cups" if self.session.task_id in ADVENTURE_IDS else "guided")

    def set_rfid_style(self, style):
        self.store.save_settings({"rfid_style": style})
        self.event_sequence = self.reader.sequence
        self.session.rfid_terms = []
        self.session.cup_delta = {"left": Linear(), "right": Linear()}
        self.feedback = "Режим выбран. Уберите метку на две секунды и поднесите снова."
        self.render()

    def reader_mode(self):
        return "rc522_dual" if self.store.settings().get("reader_mode") == "rc522_dual" or self.reader.mode == "rc522_dual" else "rc522"

    def start_physical(self):
        if self.reader.mode not in ("rc522", "rc522_dual") or self.reader.error:
            self.reader.configure(self.reader_mode())
        self.store.save_settings({"reader_mode": self.reader.mode, "rfid_style": "cups"})
        self.event_sequence = self.reader.sequence
        if self.session.task_id in ADVENTURE_IDS and not self.session.completed:
            if not self.session.cup_play:
                self.service.begin_student(self.session)
            self.navigate("exercise")
        else:
            best = self.store.progress()["best"]
            task = next_level(best)
            self.start(task["id"])

    def physical_exercise(self, ex):
        if self.rfid_style() == "cups":
            self.cups_exercise(ex)
            return
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 6))
        self.button(top, "← Задания", lambda: self.navigate("practice")).pack(side="left")
        self.button(top, "Мои метки", self.tags, "exercise-tags").pack(side="right")
        self.clock = ttk.Label(top, text=self.clock_text(ex), style="Small.TLabel")
        self.clock.pack(side="right", padx=10)
        modes = ttk.Frame(self.body)
        modes.pack(fill="x", pady=(0, 8))
        style = self.rfid_style()
        self.button(modes, "Одна метка · обучение", lambda: self.set_rfid_style("guided"), "rfid-guided", style == "guided").pack(side="left", padx=(0, 6))
        self.button(modes, "Набор меток · свои действия", lambda: self.set_rfid_style("independent"), "rfid-independent", style == "independent").pack(side="left")
        grid = ttk.Frame(self.body)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.label(left, ex["task"]["title"] + " · " + ex["task"]["equation"], "Mint.TLabel", wraplength=500)
        eq = ex["equation"]
        self.label(left, eq["left"] + " = " + eq["right"], "Mint.TLabel", font=("DejaVu Serif", 27), wraplength=510)
        Scale(left, eq["left"], eq["right"], height=115).pack(fill="x")
        self.label(left, "Символические весы · одинаковое действие с обеими частями", "Mint.TLabel", font=(self.ui_font, 9), wraplength=510)
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        if ex["completed"]:
            self.label(right, "✓ Решение получено", "Card.TLabel", font=(self.ui_font, 15, "bold"), wraplength=310)
            self.label(right, "x = " + eq["solution"]["value"], "Card.TLabel", font=("DejaVu Serif", 24), wraplength=310)
            text = "Поднесите любую привязанную метку для следующего задания." if style == "guided" else "Поднесите метку «Следующее»."
            self.label(right, text, "CardSmall.TLabel", wraplength=310)
        elif ex["expired"]:
            self.label(right, "Время вышло", "Card.TLabel", wraplength=310)
            self.button(right, "Без таймера", lambda: self.start(ex["task"]["id"]), "untimed").pack(fill="x")
        elif style == "guided":
            step = self.service.guided_step(self.session)
            self.label(right, "ПОДНЕСИТЕ МЕТКУ", "CardSmall.TLabel", wraplength=310)
            self.label(right, step["label"] if step else "Подтвердить решение", "Card.TLabel", font=(self.ui_font, 14, "bold"), wraplength=310)
            self.label(right, "Любая привязанная метка — пульт этого шага. Уберите на 2 секунды и поднесите снова.", "CardSmall.TLabel", wraplength=310)
            self.label(right, "Обучение с подсказкой: помощь учитывается в результате.", "CardSmall.TLabel", wraplength=310)
        else:
            self.label(right, "СОБЕРИТЕ ДЕЙСТВИЕ МЕТКАМИ", "CardSmall.TLabel", wraplength=310)
            self.label(right, TAG_KINDS[self.session.rfid_operation]["label"], "Card.TLabel", font=(self.ui_font, 14, "bold"), wraplength=310)
            self.label(right, "Набрано: " + self.service.rfid_pending(self.session) + "  ·  " + str(len(self.session.rfid_terms)) + " меток", "Card.TLabel", wraplength=310)
            self.label(right, "Команда → числа / x → «Применить». Повторное поднесение +1 добавляет ещё единицу в набор.", "CardSmall.TLabel", wraplength=310)
            self.label(right, "Без команды действует вычитание. «Очистить набор» начинает набор заново.", "CardSmall.TLabel", wraplength=310)
        self.physical_status = tk.StringVar(self.root)
        ttk.Label(self.body, textvariable=self.physical_status, style="Small.TLabel", wraplength=900).pack(fill="x", pady=(6, 0))
        self.update_physical_status()
        if self.feedback:
            self.label(self.body, self.feedback, "Small.TLabel", wraplength=900)
        self.button(self.body, "История физических шагов · " + str(len(ex["history"]) - 1), self.history, "history").pack(anchor="w", pady=(4, 0))

    def choose_cup(self, side):
        self.session.cup_side = side
        self.feedback = ("Выбрана левая чаша." if side == "left" else "Выбрана правая чаша.") + " Теперь поднеси метку к считывателю."
        self.render()

    def choose_cup_operation(self, operation):
        if self.service.cup_state(self.session)["pending"]:
            self.feedback = "Сначала повтори действие на второй чаше или нажми «Отменить»."
            self.status.set(self.feedback)
            self.render()
            return
        self.session.cup_operation = operation
        self.feedback = ("Добавляем" if operation == "add" else "Убираем") + " блоки. Поднеси метку к нужной чаше."
        self.render()

    def cup_undo(self):
        if self.service.cup_state(self.session)["pending"]:
            self.session.cup_delta = {"left": Linear(), "right": Linear()}
            self.session.cup_actions = []
            self.session.cup_side = "left"
        else:
            self.service.undo(self.session)
        if self.session.cup_play:
            self.service.begin_student(self.session)
        self.feedback = "Действие отменено. Попробуем снова."
        self.render()

    def student_hint(self):
        self.feedback = self.service.student_hint(self.session)["text"]
        self.render()

    def select_student_answer(self, value):
        self.session.cup_guess = value
        self.session.cup_answer_digits = ""
        self.feedback = "Выбрано x = " + str(value) + ". Проверь кнопкой или меткой x."
        self.render()

    def check_student_answer(self):
        if self.session.cup_guess is None:
            self.feedback = "Сначала выбери число или покажи ответ числовой меткой."
        else:
            result = self.service.student_answer(self.session, self.session.cup_guess)
            self.feedback = result["message"]
        self.render()

    def student_exercise(self, ex):
        self.clock_is_game = True
        state = self.service.cup_state(self.session)
        stage = self.service.student_stage(self.session)
        phase = self.session.cup_phase
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 4))
        self.button(top, "← Начало", lambda: self.navigate("home"), "student-home").pack(side="left")
        stats = game_progress(self.store.progress())
        gained = self.round_gain()
        badge = ("★ +" + str(gained) + " XP" if gained else "★ Урок повторён") if ex["completed"] else "★ Уровень " + str(stats["level"]) + " · " + str(stats["xp"]) + " XP"
        self.clock = ttk.Label(top, text=badge, style="Heading.TLabel")
        self.clock.pack(side="right")
        index = next(i for i, t in enumerate(ADVENTURE_TASKS) if t["id"] == self.session.task_id)
        stage_label = {"demo": "Покажем вместе", "supported": "Выбирай сам", "independent": "Твоя задача"}[stage]
        self.label(self.body, "%d/%d · %s · Старт: %s" % (index + 1, len(ADVENTURE_TASKS), stage_label, ex["task"]["equation"]), "GameHeading.TLabel", wraplength=950)
        if ex["completed"]:
            instruction = "Верно! x = " + ex["equation"]["solution"]["value"] + "." + (" Все уроки пройдены." if all(t["id"] in self.store.progress()["best"] for t in ADVENTURE_TASKS) else " Можно открыть следующий урок.")
        elif phase == "answer":
            instruction = "Чему равен x? Выбери число или набери его цифры метками. Подтверди кнопкой или меткой x."
        elif stage == "demo":
            instruction = "Показ: выбрана " + ("левая" if self.session.cup_side == "left" else "правая") + " чаша. Поднеси +1 к считывателю — уберём единицу."
        elif state["pending"]:
            instruction = "Весы наклонились. Какую чашу теперь нужно изменить? Выбери её и повтори действие."
        elif self.session.cup_operation is None:
            instruction = "Освободи x. На обеих чашах есть x — можно убирать одинаковые x." if self.session.current.left.a and self.session.current.right.a else "Освободи x от лишних единиц. Сам выбери: добавить или убрать?"
        elif self.session.cup_side is None:
            instruction = "Выбери чашу и поднеси числовую метку 1–9" + (" или x." if self.session.current.left.a and self.session.current.right.a else ".")
        else:
            instruction = "Выбрано: " + ("убрать" if self.session.cup_operation == "remove" else "добавить") + ". Чаша: " + ("левая" if self.session.cup_side == "left" else "правая") + ". Поднеси числовую метку" + (" или x." if self.session.current.left.a and self.session.current.right.a else ".")
        if self.reader.mode == "rc522_dual" and not ex["completed"] and phase == "choose":
            if state["pending"]:
                other = "справа" if self.session.cup_delta["left"] != Linear() else "слева"
                instruction = "Повтори то же действие " + other + ": поднеси метку к этому считывателю."
            elif stage == "demo":
                instruction = "Показ: уберём по одной единице. Поднеси +1 сначала к левой, затем к правой чаше."
            else:
                instruction = "Выбери «Добавить» или «Убрать», затем поднеси метку к левой или правой чаше."
        self.label(self.body, instruction, "GameHint.TLabel", wraplength=950)
        tools = ttk.Frame(self.body)
        tools.pack(fill="x", pady=(0, 3))
        def game_button(parent, text, command, key, selected=False):
            button = self.button(parent, text, command, key)
            button.configure(style="GamePrimary.TButton" if selected else "Game.TButton")
            return button
        if phase == "answer" and not ex["completed"]:
            for value in self.answer_choices():
                choice = game_button(tools, str(value), lambda v=value: self.select_student_answer(v), "student-answer-" + str(value), self.session.cup_guess == value)
                choice.configure(width=4)
                choice.pack(side="left", padx=(0, 5))
            check = game_button(tools, "Проверить", self.check_student_answer, "student-check", True)
            check.pack(side="left", padx=5)
            if self.session.cup_guess is None:
                check.state(["disabled"])
        elif ex["completed"]:
            command = (lambda: self.start(STARTER_TASKS[0]["id"])) if all(t["id"] in self.store.progress()["best"] for t in ADVENTURE_TASKS) else self.next_adventure
            game_button(tools, "Повторить с начала" if all(t["id"] in self.store.progress()["best"] for t in ADVENTURE_TASKS) else "Следующий урок →", command, "student-next", True).pack(side="left")
            game_button(tools, "Мой путь", self.history, "history").pack(side="left", padx=5)
            game_button(tools, "Карта уроков", self.lesson_map, "student-map").pack(side="right")
        else:
            for operation, text in [("remove", "− Убрать"), ("add", "+ Добавить")]:
                button = game_button(tools, text, lambda o=operation: self.choose_cup_operation(o), "cup-op-" + operation, self.session.cup_operation == operation)
                button.pack(side="left", padx=(0, 6))
                if state["pending"] or stage == "demo":
                    button.state(["disabled"])
        if not ex["completed"]:
            game_button(tools, "Подсказка", self.student_hint, "student-hint").pack(side="right", padx=(5, 0))
            undo = game_button(tools, "Отменить", self.cup_undo, "cup-undo")
            undo.pack(side="right")
            if not state["pending"] and len(ex["history"]) < 2:
                undo.state(["disabled"])
        preview = state["preview"]
        can_select = not ex["completed"] and phase == "choose"
        board = BalanceCanvas(self.body, preview.left, preview.right,
                              selected=self.session.cup_side if can_select else None,
                              tilt=symbolic_tilt(self.session.current, preview), initial=self.balance_pose,
                              motion=self.store.settings()["motion"], won=ex["completed"], height=210,
                              on_select=self.choose_cup if can_select else None, font_family=self.ui_font)
        board.pack(fill="both", expand=True, pady=(3, 0))
        self.balance_widget = board
        buttons = []
        for side, label in [("left", "← Левая чаша"), ("right", "Правая чаша →")]:
            selected = side == self.session.cup_side and can_select
            button = game_button(board, label + (" · выбрана" if selected else ""), lambda s=side: self.choose_cup(s), "cup-" + side, selected)
            if not can_select:
                button.state(["disabled"])
            buttons.append(button)
        board.attach_controls(*buttons)
        feedback_box = ttk.Frame(self.body, height=42)
        feedback_box.pack(fill="x", pady=(3, 0))
        feedback_box.pack_propagate(False)
        ttk.Label(feedback_box, text=self.feedback or "Метки: +1 — одна единица, +2 — две. x — неизвестное число.", style="GameFeedback.TLabel", wraplength=950).pack(fill="both", expand=True)
        self.physical_status = tk.StringVar(self.root)
        ttk.Label(self.body, textvariable=self.physical_status, style="Small.TLabel", wraplength=940).pack(fill="x")
        self.update_physical_status()

    def cups_exercise(self, ex):
        if self.session.cup_play:
            self.student_exercise(ex)
            return
        self.clock_is_game = True
        state = self.service.cup_state(self.session)
        preview = state["preview"]
        top = ttk.Frame(self.body)
        top.pack(fill="x", pady=(0, 5))
        self.button(top, "← Начало" if self.simple_ui() else "← Уроки", lambda: self.navigate("home" if self.simple_ui() else "practice")).pack(side="left")
        if not self.simple_ui():
            self.button(top, "Мои метки", self.tags, "exercise-tags").pack(side="right")
        self.clock = ttk.Label(top, text="Без спешки · один считыватель", style="Small.TLabel")
        self.clock.pack(side="right", padx=8)
        self.label(self.body, ex["task"]["title"] + "   ·   Было: " + ex["task"]["equation"], "Heading.TLabel", wraplength=900)
        if ex["completed"]:
            instruction = "Получилось! x = " + ex["equation"]["solution"]["value"] + (". Ты прошёл все шесть уроков!" if self.session.task_id == STARTER_TASKS[-1]["id"] else ". Поднеси метку ещё раз для следующего урока.")
        else:
            side = "левая" if self.session.cup_side == "left" else "правая"
            verb = "Убираем +1" if self.session.cup_operation == "remove" else "Добавляем +1"
            instruction = verb + ". Подсвечена " + side + " чаша. Поднеси метку +1 к считывателю."
        self.label(self.body, instruction, "Success.TLabel", wraplength=920)
        if ex["completed"]:
            gained = self.round_gain()
            reward = ("★ +" + str(gained) + " XP!" if gained else "★ Отличное повторение!")
            current_level = game_progress(self.store.progress())["level"]
            if gained and current_level > 1 + self.round_start_xp // 60:
                reward += " Уровень " + str(current_level) + "!"
        else:
            stats = game_progress(self.store.progress())
            reward = "★ Уровень " + str(stats["level"]) + "  ·  " + str(stats["xp"]) + " XP"
        self.clock.configure(text=reward)
        board = BalanceCanvas(self.body, preview.left, preview.right,
                              selected=None if ex["completed"] else self.session.cup_side,
                              tilt=symbolic_tilt(self.session.current, preview), initial=self.balance_pose,
                              motion=self.store.settings()["motion"], won=ex["completed"], height=195,
                              on_select=None if ex["completed"] else self.choose_cup, font_family=self.ui_font)
        board.pack(fill="x")
        self.balance_widget = board
        buttons = []
        for side, label in [("left", "← ЛЕВАЯ ЧАША"), ("right", "ПРАВАЯ ЧАША →")]:
            selected = side == self.session.cup_side and not ex["completed"]
            button = self.button(board, label + (" · ВЫБРАНА" if selected else ""), lambda s=side: self.choose_cup(s), "cup-" + side, selected)
            if ex["completed"]:
                button.state(["disabled"])
            buttons.append(button)
        board.attach_controls(*buttons)
        status = "Одна чаша изменилась. Теперь повтори то же на другой — так сохраняется равенство." if state["pending"] else "Синий x — неизвестное число. Жёлтый +1 — единица. Выбери чашу и поднеси метку."
        if ex["completed"]:
            status = ("Все шесть уроков пройдены. Можно повторить сначала." if self.session.task_id == STARTER_TASKS[-1]["id"]
                      else "Ты освободил x! Убери метку на 2 секунды; потом можно открыть следующий урок.")
        self.label(self.body, status, "Small.TLabel", wraplength=900)
        tools = ttk.Frame(self.body)
        tools.pack(fill="x")
        for op, label in ([] if self.simple_ui() else [("remove", "− Убрать блок"), ("add", "+ Добавить блок")]):
            button = self.button(tools, label, lambda o=op: self.choose_cup_operation(o), "cup-op-" + op, self.session.cup_operation == op)
            button.pack(side="left", padx=(0, 5))
            if state["pending"] or ex["completed"]:
                button.state(["disabled"])
        undo = self.button(tools, "Отменить", self.cup_undo, "cup-undo")
        undo.pack(side="left", padx=5)
        if ex["completed"] or (not state["pending"] and len(ex["history"]) < 2):
            undo.state(["disabled"])
        if not self.simple_ui():
            self.button(tools, "Моя метка — +1", self.assign_unit_tag, "cup-unit").pack(side="right")
        if self.feedback:
            self.label(self.body, self.feedback, "Small.TLabel", wraplength=900)
        bottom = ttk.Frame(self.body)
        bottom.pack(fill="x", pady=5)
        self.physical_status = tk.StringVar(self.root)
        ttk.Label(bottom, textvariable=self.physical_status, style="Small.TLabel", wraplength=650).pack(side="left")
        if not self.simple_ui():
            self.button(bottom, "Проверка считывателя", self.reader_details, "reader-details").pack(side="right")
        self.update_physical_status()
        if ex["completed"] and self.session.task_id == STARTER_TASKS[-1]["id"]:
            if self.simple_ui():
                self.button(self.body, "Повторить сначала", lambda: self.start(STARTER_TASKS[0]["id"]), "repeat-course").pack(anchor="w")
            else:
                self.button(self.body, "Дальше: уравнения посложнее →", self.start_advanced, "advanced").pack(anchor="w")

    def assign_unit_tag(self):
        self.tags(self.last_uid or None)
        if self.last_uid:
            self.choose_tag("1")

    def start_advanced(self):
        self.store.save_settings({"rfid_style": "guided"})
        self.start(TASKS[0]["id"])

    def reader_details(self):
        dialog, frame = self.modal("Считыватели и кнопки", scroll=True)
        self.label(frame, "Настройка для взрослого", "Heading.TLabel")
        dual = tk.BooleanVar(dialog, self.reader_mode() == "rc522_dual")
        enabled = tk.BooleanVar(dialog, self.buttons.enabled)
        for text, variable, key in [("Два считывателя: левый SPI0, правый SPI1", dual, "dual-readers"),
                                    ("Кнопки BCM13 (+) и BCM26 (−) подключены и проверены", enabled, "gpio-buttons")]:
            button = ttk.Checkbutton(frame, text=text, variable=variable)
            button.pack(anchor="w", pady=5)
            self.controls[key] = button
        self.label(frame, "Кнопки: входы с подтяжкой вверх, замыкание на GND. Проверяйте плату кнопки до подключения. Режим VCC→GND нельзя подтвердить по таблице.", "Small.TLabel", wraplength=430)
        def apply():
            mode = "rc522_dual" if dual.get() else "rc522"
            self.reader.configure(mode)
            self.buttons.configure(enabled.get())
            self.store.save_settings({"reader_mode": mode, "buttons_enabled": enabled.get()})
            self.event_sequence = self.reader.sequence
            self.status.set("Оборудование подключается. Состояние показано ниже.")
        self.button(frame, "Применить / переподключить", apply, "save-hardware", True).pack(fill="x", pady=5)
        self.hardware_note = tk.StringVar(dialog)
        ttk.Label(frame, textvariable=self.hardware_note, wraplength=430, style="Small.TLabel").pack(fill="x", pady=5)
        self.hardware_note_dialog = dialog
        self.update_hardware_note()
        self.button(frame, "Обновить сведения", self.update_hardware_note, "reader-refresh").pack(fill="x")
        self.button(frame, "Переподключить RC522", self.reconnect_reader, "reader-retry").pack(fill="x", pady=5)

    def update_hardware_note(self):
        if not getattr(self, "hardware_note_dialog", None) or not self.hardware_note_dialog.winfo_exists():
            return
        state = self.reader.status()
        lines = ["Опрос: от 0,8 с на чашу. Версия " + __version__]
        if self.reader.mode == "rc522_dual":
            for side, label in [("left", "Левая"), ("right", "Правая")]:
                channel = state.get("channels", {}).get(side, {})
                version = channel.get("version")
                lines.append(label + ": SPI%d CE0 / RST BCM%d" % ((0,25) if side == "left" else (1,5)))
                lines.append(("VersionReg=0x%02X. " % version if version is not None else "") +
                             (channel.get("error") or channel.get("warning") or ("Готов" if channel.get("connected") else "Подключение…")))
                lines.append("UID: " + str(channel.get("present_uid") or "—") + "; последняя ошибка: " + str(channel.get("last_error") or "—"))
        else:
            lines += ["SPI0 CE0 / RST BCM25", state.get("error") or state.get("warning") or "Ошибок нет.",
                      "UID: " + str(state.get("present_uid") or "—"),
                      "Последняя ошибка: " + str(state.get("last_error") or "—")]
        buttons = self.buttons.status()
        lines.append("Кнопки: " + (buttons["error"] or ("готовы" if buttons["connected"] else "выключены / подключение")))
        lines.append(" + BCM13: " + ("нажата" if buttons["levels"].get(13) is False else "отпущена") +
                     "; − BCM26: " + ("нажата" if buttons["levels"].get(26) is False else "отпущена"))
        text = "\n".join(lines)
        if self.hardware_note.get() != text:
            self.hardware_note.set(text)

    def reconnect_reader(self):
        self.reader.configure(self.reader_mode())
        self.dialog.destroy()
        self.status.set("Подключаю считыватель…")

    def update_physical_status(self):
        if self.page != "exercise" or self.reader.mode not in ("rc522", "rc522_dual") or not hasattr(self, "physical_status"):
            return
        state = self.reader.status()
        text = (("Считыватель не подключён. Попроси взрослого открыть «Для взрослого»." if self.simple_ui() else "Считыватель не подключён. Открой «Проверка считывателя».") if state["error"] and self.rfid_style() == "cups" else state["error"]) or state.get("warning")
        if not text:
            text = ("Метка считана — убери её от считывателя." if state.get("present_uid") else "Можно поднести метку.") if state["connected"] else "Подключение RC522…"
        if self.reader.mode == "rc522_dual":
            parts = []
            for side, label in [("left", "Левая"), ("right", "Правая")]:
                channel = state.get("channels", {}).get(side, {})
                parts.append(label + ": " + ("нужна проверка взрослого" if channel.get("error") else
                             "повтори чтение" if channel.get("warning") else "убери метку" if channel.get("present_uid") else
                             "готова" if channel.get("connected") else "подключение…"))
            text = " · ".join(parts)
        if self.buttons.error:
            text += " · Кнопки недоступны; используй экран."
        if self.physical_status.get() != text:
            self.physical_status.set(text)

    def handle_physical_scan(self, uid, source=None):
        if uid not in self.store.tags():
            if self.simple_ui():
                self.feedback = "Эта метка ещё не подготовлена. Попроси взрослого добавить её в «Мои метки»."
                self.status.set(self.feedback)
                self.render()
            else:
                self.tags(uid)
            return
        if self.page != "exercise":
            if self.session.current and not self.session.completed:
                self.navigate("exercise")
            else:
                self.store.save_settings({"rfid_style": "cups"})
                self.start(STARTER_TASKS[0]["id"])
            self.feedback = "Метка считана. Задание открыто. Уберите метку на 2 секунды и поднесите для действия."
        else:
            try:
                previous_task = self.session.task_id
                previous_xp = game_progress(self.store.progress())["xp"]
                previous_best = self.store.progress()["best"]
                if self.rfid_style() == "cups":
                    if self.session.completed and all(t["id"] in self.store.progress()["best"] for t in ADVENTURE_TASKS):
                        self.feedback = "Приключение пройдено! Можно повторять уровни и квизы на карте." if self.simple_ui() else "Ты прошёл первые шесть уроков! Нажми «Дальше», когда будешь готов."
                        self.render()
                        return
                    result = self.service.scan_cup(self.session, {"uid": uid, **({"source": source} if source else {})})
                else:
                    result = self.service.scan_exercise(self.session, {"uid": uid, "style": self.rfid_style()})
                if self.session.task_id != previous_task:
                    self.round_start_xp = previous_xp
                    self.round_start_stars = previous_best.get(self.session.task_id, 0)
                    self.reset_balance_on_render = True
                self.feedback = "Метка «" + TAG_KINDS[result["kind"]]["label"] + "» → " + result["message"]
            except (ValueError, sqlite3.Error, OSError) as exc:
                self.feedback = "Метка считана; действие не выполнено: " + str(exc)
        self.status.set("Метка обработана." if self.simple_ui() else self.feedback)
        self.render()

    def transform(self):
        self.service.transform(self.session, {"operation": self.operation.get(), "value": self.operand.get()})
        self.hint_text = ""
        self.feedback = ""
        self.render()

    def check_answer(self):
        result = self.service.answer(self.session, {"answer": self.answer.get()})
        self.status.set(result["message"])
        self.feedback = "" if result["correct"] else result["message"]
        self.render()

    def hint(self):
        self.hint_text = self.service.hint(self.session)["text"]
        self.status.set(self.hint_text)
        self.render()

    def undo(self):
        self.service.undo(self.session)
        self.hint_text = ""
        self.feedback = ""
        self.render()

    def next_exercise(self):
        index = next(i for i, task in enumerate(PLAY_TASKS) if task["id"] == self.session.task_id)
        self.start(PLAY_TASKS[(index + 1) % len(PLAY_TASKS)]["id"], self.session.mode)

    def history(self, saved=None):
        dialog, frame = self.modal("Мой путь решения", scroll=True)
        steps = saved["steps"] if saved else self.session.history
        for i, step in enumerate(steps):
            self.label(frame, f"{i:02} · {step['label']}", "Small.TLabel", wraplength=440)
            for action in step.get("actions", []):
                self.label(frame, ("Слева" if action["side"] == "left" else "Справа") + ": " +
                           ("добавили " if action["operation"] == "add" else "убрали ") + BLOCKS[action["kind"]]["label"], wraplength=440)
            self.label(frame, f"{step['left']} = {step['right']}", font=(self.ui_font, 18), wraplength=440)
            if i:
                self.label(frame, "Одинаковое действие с обеих сторон сохраняет равенство.", "Small.TLabel", wraplength=440)
        proof = saved.get("check") if saved else None
        if not saved and self.session.completed:
            from .math_engine import equation
            original = equation(steps[0]["left"] + "=" + steps[0]["right"])
            result = original.solution()
            if result["kind"] == "one":
                from fractions import Fraction
                value = Fraction(result["value"])
                proof = {"x": str(value), "left": str(original.left.at(value)), "right": str(original.right.at(value))}
        if proof:
            self.label(frame, "Проверка в исходном условии при x = " + proof["x"], "Heading.TLabel", wraplength=440)
            self.label(frame, proof["left"] + " = " + proof["right"] + " — ответ подходит!", wraplength=440)
        elif not saved and self.service.cup_state(self.session)["pending"]:
            self.label(frame, "Последнее действие на одной чаше ещё не завершено. В историю оно попадёт после такой же операции на второй.", wraplength=440)

    def saved_solutions(self):
        dialog, frame = self.modal("История решений", scroll=True)
        rows = self.store.solutions()
        self.label(frame, "Последние 30 решений. Новые завершённые задания сохраняются вместе с ходами и проверкой.", "Small.TLabel", wraplength=440)
        if not rows:
            self.label(frame, "Пока нет сохранённых путей. Решите любое задание в новой версии. Прежние звёзды и результаты сохранены.", wraplength=440)
        for i, row in enumerate(rows):
            self.button(frame, row["completed_at"][:10] + " · " + row["data"]["original"],
                        lambda data=row["data"]: self.history(data), "saved-solution-" + str(i)).pack(fill="x", pady=4)

    def mutate_lab(self, endpoint, data):
        lab = self.service.dispatch("/api/lab/" + endpoint, self.session, data)
        if endpoint == "x":
            self.status.set(f"При x = {lab['x']}: слева {lab['left_value']}, справа {lab['right_value']}. " + ("Равенство выполняется." if lab["balanced"] else "Значения отличаются."))
        self.render()

    def lab(self):
        lab = self.service.lab(self.session)
        top = ttk.Frame(self.body)
        top.pack(fill="x")
        self.button(top, "Решать задание метками →", self.start_physical, "lab-physical", True).pack(side="right")
        self.label(top, "Твоя лаборатория.", "Title.TLabel", wraplength=500)
        self.label(self.body, "Здесь — реестр блоков на чашах. Для преобразования заданий нажми «Решать задание метками».", "Small.TLabel", wraplength=900)
        grid = ttk.Frame(self.body)
        grid.pack(fill="x", pady=(6, 0))
        grid.columnconfigure(0, weight=1)
        left = ttk.Frame(grid, style="Mint.TFrame", padding=14)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        self.label(left, f"{lab['equation']['left']} = {lab['equation']['right']}", "Mint.TLabel", font=("DejaVu Serif", 24), wraplength=550)
        Scale(left, lab["equation"]["left"], lab["equation"]["right"], lab["tilt"], self.store.settings()["motion"], 105).pack(fill="x")
        trays = ttk.Frame(left, style="Mint.TFrame")
        trays.pack(fill="x", pady=8)
        for i, side in enumerate(["left", "right"]):
            trays.columnconfigure(i, weight=1, uniform="tray")
            tray = ttk.Frame(trays, style="Card.TFrame", padding=8)
            tray.grid(row=0, column=i, sticky="nsew", padx=(0, 7))
            self.button(tray, ("Левая" if side == "left" else "Правая") + " чаша", lambda s=side: self.select_side(s), "side-" + side, side == self.side).pack(fill="x")
            if not lab["blocks"][side]:
                self.label(tray, "Пока без блоков", "CardSmall.TLabel")
            chips = ttk.Frame(tray, style="Card.TFrame", relief="flat")
            chips.pack(fill="x", pady=(5, 0))
            for n, block in enumerate(lab["blocks"][side]):
                chip = self.button(chips, BLOCKS[block["kind"]]["label"] + " ×", lambda uid=block["uid"]: self.mutate_lab("remove", {"uid": uid}), "remove-" + block["uid"])
                chip.configure(width=4)
                chip.grid(row=n // 3, column=n % 3, sticky="w", padx=1, pady=2)
        row = ttk.Frame(left, style="Mint.TFrame")
        row.pack(fill="x")
        ttk.Label(row, text="При x =", style="Mint.TLabel").pack(side="left", padx=(0, 8))
        self.math_field(row, self.x_value, "lab-x", True, 7).pack(side="left", fill="x", expand=True)
        self.button(row, "Подставить", lambda: self.mutate_lab("x", {"value": self.x_value.get()}), "substitute").pack(side="left", padx=8)
        self.label(left, f"Значения: {lab['left_value']} {'=' if lab['balanced'] else '≠'} {lab['right_value']} · {self.solution_text(lab['equation']['solution'])}", "Mint.TLabel", wraplength=550)
        right = self.card(grid)
        right.grid(row=0, column=1, sticky="nsew")
        self.label(right, "Палитра блоков", "Card.TLabel", font=(self.ui_font, 14, "bold"))
        self.label(right, f"На {'левую' if self.side == 'left' else 'правую'} чашу", "CardSmall.TLabel")
        palette = ttk.Frame(right, style="Card.TFrame", relief="flat")
        palette.pack(fill="x")
        if self.reader.mode == "simulator":
            for i, (kind, block) in enumerate(BLOCKS.items()):
                button = self.button(palette, block["label"], lambda k=kind: self.mutate_lab("simulate", {"kind": k, "side": self.side}), "block-" + kind)
                button.configure(width=3)
                button.grid(row=i // 5, column=i % 5, sticky="ew", padx=3, pady=4)
        else:
            self.label(right, self.reader.error or self.reader.warning or "Поднеси метку и держи неподвижно около секунды", "CardSmall.TLabel", wraplength=220)
        self.button(right, "RFID-метки", self.tags, "tags").pack(fill="x", pady=(14, 6))
        self.button(right, "Очистить чаши", lambda: self.mutate_lab("clear", {}), "clear-lab").pack(fill="x")
        self.label(right, "HX711 не подключён.\nНаклон вычислен по выражениям,\nа не по массе блоков.", "CardSmall.TLabel", wraplength=220)
        custom = ttk.Frame(self.body)
        custom.pack(fill="x", pady=(14, 0))
        ttk.Label(custom, text="Своё уравнение:").pack(side="left", padx=(0, 10))
        self.math_field(custom, self.custom, "custom", width=20).pack(side="left", fill="x", expand=True)
        self.button(custom, "Исследовать", self.check_custom, "check-custom", True).pack(side="left", padx=(8, 0))

    def select_side(self, side):
        self.side = side
        self.render()

    @staticmethod
    def solution_text(solution):
        return f"x = {solution['value']}" if solution["kind"] == "one" else "любое x" if solution["kind"] == "all" else "решений нет"

    def check_custom(self):
        result = self.service.dispatch("/api/equation/check", self.session, {"equation": self.custom.get()})
        self.status.set(f"{result['left']} = {result['right']}: {self.solution_text(result['solution'])}")
        dialog, frame = self.modal("Математический вывод")
        self.label(frame, f"{result['left']} = {result['right']}", font=("DejaVu Serif", 23), wraplength=440)
        self.label(frame, self.solution_text(result["solution"]), "Heading.TLabel")

    def progress(self):
        progress = self.store.progress()
        self.heading("Каждый шаг имеет значение", "Твои открытия в цифрах.")
        stats = learning_stats(progress)
        self.label(self.body, f"{stats['rank']}  ·  {stats['xp']} XP  ·  {stats['streak']} дней практики подряд", "Small.TLabel")
        self.button(self.body, "Экспорт результатов CSV", self.export_progress, "export").pack(anchor="w", pady=(0, 8))
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(10, 18))
        for title, value in [("ПРОЙДЕНО", f"{progress['completed']} / {TOTAL_ACTIVITIES}"), ("ЗВЁЗДЫ", f"{progress['stars']} / {TOTAL_ACTIVITIES*3}"), ("УСПЕШНЫХ ПОПЫТОК", str(len(progress["attempts"])))]:
            card = self.card(row)
            card.pack(side="left", fill="both", expand=True, padx=(0, 12))
            self.label(card, title, "CardSmall.TLabel")
            self.label(card, value, "Card.TLabel", font=(self.ui_font, 26, "bold"))
        goals = [("Первое открытие", progress["completed"] >= 1), ("В ритме науки · 3 задания", progress["completed"] >= 3),
                 ("Без подсказок", 3 in progress["best"].values()), ("Мастер равновесия", all(t["id"] in progress["best"] for t in PLAY_TASKS))]
        self.label(self.body, "Коллекция достижений", "Heading.TLabel")
        self.label(self.body, "   ·   ".join(("★ " if done else "☆ ") + title for title, done in goals), wraplength=900)
        self.label(self.body, "Карта навыков", "Heading.TLabel")
        for i, chapter in enumerate(CHAPTERS):
            count = stats["chapters"][i]
            self.label(self.body, f"{chapter[0]}  ·  {count['completed']} / {count['total']}", "Small.TLabel")
            ttk.Progressbar(self.body, maximum=count["total"], value=count["completed"]).pack(fill="x", pady=(0, 10))
        self.label(self.body, "Последние решения", "Heading.TLabel")
        for attempt in progress["attempts"][:15]:
            task = next((t for t in TASKS if t["id"] == attempt["task_id"]), {"title": attempt["task_id"]})
            self.label(self.body, f"{task['title']}    {'★' * attempt['stars']}    ·    {attempt['steps']} шагов    ·    {attempt['hints']} подсказок    ·    {attempt['seconds']} сек", wraplength=900)
        if not progress["attempts"]:
            self.label(self.body, "Первое решение появится здесь после практики.", "Small.TLabel")

    def export_progress(self):
        filename = filedialog.asksaveasfilename(parent=self.root, title="Сохранить результаты", defaultextension=".csv", initialfile="algebra-progress.csv", filetypes=[("CSV", "*.csv")])
        if filename:
            Path(filename).write_text(progress_csv(self.store.progress()), encoding="utf-8-sig")
            self.status.set("Результаты сохранены: " + str(filename))

    def modal(self, title, scroll=False):
        if self.dialog and self.dialog.winfo_exists():
            self.dialog.destroy()
        dialog = tk.Toplevel(self.root)
        self.dialog = dialog
        dialog.title(title)
        dialog.configure(bg=PAPER)
        dialog.transient(self.root)
        dialog.resizable(False, False)
        width, height = 530, min(520, self.root.winfo_screenheight() - 60)
        x = max(0, self.root.winfo_rootx() + (self.root.winfo_width() - width) // 2)
        y = max(0, self.root.winfo_rooty() + (self.root.winfo_height() - height) // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")
        bottom = ttk.Frame(dialog, padding=(18, 8))
        bottom.pack(side="bottom", fill="x")
        self.button(bottom, "Закрыть", dialog.destroy, "close-dialog").pack(side="right")
        if scroll:
            area = ScrollArea(dialog)
            area.pack(fill="both", expand=True)
            frame = area.body
        else:
            frame = ttk.Frame(dialog, padding=22)
            frame.pack(fill="both", expand=True)
        self.label(frame, title, "Heading.TLabel")
        dialog.grab_set()
        dialog.bind("<Escape>", lambda e: dialog.destroy())
        return dialog, frame

    def keypad(self, variable, numeric=False):
        dialog, frame = self.modal("Сенсорный ввод")
        draft = tk.StringVar(dialog, variable.get())
        entry = ttk.Entry(frame, textvariable=draft, font=(self.ui_font, 18))
        entry.pack(fill="x", pady=(0, 10))
        self.controls["keypad-entry"] = entry
        entry.focus_set()
        entry.icursor("end")
        keys = ["7", "8", "9", "+", "−", "4", "5", "6", "×", "÷", "1", "2", "3", "(", ")", "0", ".", "/", "x", "="]
        if numeric:
            keys = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "−", "0", "/", "."]
        grid = ttk.Frame(frame)
        grid.pack(fill="both", expand=True)
        columns = 4 if numeric else 5
        for col in range(columns):
            grid.columnconfigure(col, weight=1)

        def insert(key):
            text = {"−": "-", "×": "*", "÷": "/"}.get(key, key)
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
            entry.insert("insert", text)
            entry.focus_set()

        def backspace():
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
            elif entry.index("insert"):
                pos = entry.index("insert")
                entry.delete(pos - 1, pos)

        def accept():
            variable.set(draft.get())
            dialog.destroy()

        for i, key in enumerate(keys):
            button = self.button(grid, key, lambda k=key: insert(k), "key-" + key)
            button.configure(width=3)
            button.grid(row=i // columns, column=i % columns, sticky="nsew", padx=3, pady=3)
        tools = ttk.Frame(frame)
        tools.pack(fill="x", pady=(8, 0))
        self.button(tools, "Очистить", lambda: draft.set(""), "key-clear").pack(side="left")
        self.button(tools, "⌫", backspace, "key-back").pack(side="left", padx=8)
        self.button(tools, "Готово", accept, "key-accept", True).pack(side="right")
        entry.bind("<Return>", lambda e: accept())

    def settings(self):
        if self.simple_ui():
            self.adult_menu()
        else:
            self.full_settings()

    def full_settings(self):
        dialog, frame = self.modal("Настроим под тебя", scroll=True)
        prefs = self.store.settings()
        name = tk.StringVar(dialog, prefs["name"])
        motion, contrast = tk.BooleanVar(dialog, prefs["motion"]), tk.BooleanVar(dialog, prefs["contrast"])
        self.label(frame, "Как тебя называть?")
        entry = ttk.Entry(frame, textvariable=name)
        entry.pack(fill="x", pady=(0, 10))
        self.controls["name"] = entry
        ttk.Checkbutton(frame, text="Анимация весов", variable=motion).pack(anchor="w")
        ttk.Checkbutton(frame, text="Повышенный контраст текста", variable=contrast).pack(anchor="w")
        simple = tk.BooleanVar(dialog, prefs.get("simple_ui", True))
        simple_switch = ttk.Checkbutton(frame, text="Простой детский экран", variable=simple)
        simple_switch.pack(anchor="w")
        self.controls["simple-ui"] = simple_switch

        def save():
            self.service.dispatch("/api/settings", self.session, {"name": name.get(), "motion": motion.get(), "contrast": contrast.get()})
            self.store.save_settings({"simple_ui": simple.get()})
            self.setup_styles()
            dialog.destroy()
            self.render()
            self.status.set("Настройки сохранены на этом устройстве.")

        self.label(frame, "Экран: %d×%d; окно: %d×%d" % (self.root.winfo_screenwidth(), self.root.winfo_screenheight(), self.root.winfo_width(), self.root.winfo_height()), "Small.TLabel")
        self.button(frame, "Оконный / полноэкранный режим", self.toggle_fullscreen, "toggle-fullscreen").pack(fill="x", pady=6)
        self.button(frame, "Сохранить настройки", save, "save-settings", True).pack(fill="x", pady=12)
        self.button(frame, "RFID-метки", self.tags).pack(fill="x")
        self.button(frame, "Использовать экранные блоки без RC522", self.use_simulator, "reader-simulator").pack(fill="x", pady=6)
        self.button(frame, "Сбросить учебный прогресс", self.reset_progress, "reset-progress").pack(fill="x", pady=8)
        self.label(frame, f"Режим: {self.reader.mode}\n{self.reader.error or 'HX711 не подключён.'}", "Small.TLabel", wraplength=430)

    def toggle_fullscreen(self):
        value = not bool(self.root.attributes("-fullscreen"))
        self.root.attributes("-fullscreen", value)
        self.store.save_settings({"fullscreen": value})

    def use_simulator(self):
        self.reader.configure("simulator")
        self.store.save_settings({"reader_mode": "simulator"})
        self.dialog.destroy()
        self.render()
        self.status.set("Включены экранные блоки. RC522 выключен.")

    def reset_progress(self):
        if messagebox.askyesno("Сброс прогресса", "Удалить историю, звёзды и достижения? Имя и метки сохранятся.", parent=self.dialog):
            self.service.dispatch("/api/progress/reset", self.session, {"confirm": "RESET"})
            self.dialog.destroy()
            self.render()
            self.status.set("Учебный прогресс сброшен.")

    def tag_manager(self):
        dialog, frame = self.modal("Мои метки", scroll=True)
        self.label(frame, "Можно считать UID телефоном и заранее добавить назначения. Для первых уроков нужна +1.", wraplength=430)
        self.import_notice = tk.StringVar(dialog)
        ttk.Label(frame, textvariable=self.import_notice, wraplength=430).pack(fill="x", pady=4)
        self.button(frame, "Добавить номер с телефона", self.phone_tag, "phone-tag", True).pack(fill="x", pady=4)
        self.button(frame, "Загрузить список с флешки", self.choose_tag_file, "import-tags").pack(fill="x", pady=4)
        self.button(frame, "Сохранить копию назначений", self.export_tag_file, "export-tags").pack(fill="x", pady=4)
        self.button(frame, "Считать метку самим RC522", self.tags, "scan-tag").pack(fill="x", pady=4)
        self.button(frame, "Посмотреть / изменить назначения (" + str(len(self.store.tags())) + ")", self.tag_list, "list-tags").pack(fill="x", pady=4)

    def phone_tag(self):
        dialog, frame = self.modal("Добавить UID с телефона",scroll=True)
        self.label(frame, "Android: NFC Tools → Прочитать → UID / серийный номер. Скопируйте номер в HEX, сохранив порядок байтов.", wraplength=430)
        uid = tk.StringVar(dialog)
        kind = tk.StringVar(dialog, "1")
        note = tk.StringVar(dialog, "Введите UID и выберите значение. Пример формата: 12:34:56:78.")
        entry = ttk.Entry(frame, textvariable=uid, font=(self.ui_font, 14))
        entry.pack(fill="x", pady=6)
        self.controls["phone-uid"] = entry
        self.label(frame, "Что будет означать метка?", wraplength=430)
        grid = ttk.Frame(frame)
        grid.pack(fill="x")
        choices = {}
        def update(*args):
            try:
                canonical = phone_uid(uid.get())
                old = self.store.tags().get(canonical)
                text = "Будет сохранено: " + TAG_KINDS[kind.get()]["label"] + "."
                if old and old != kind.get():
                    text += " Было: " + TAG_KINDS[old]["label"] + "."
                note.set(text)
                self.controls["save-phone-tag"].state(["!disabled"])
            except ValueError as exc:
                note.set(str(exc))
                self.controls["save-phone-tag"].state(["disabled"])
            for value, button in choices.items():
                button.configure(style="SelectedTag.TButton" if value == kind.get() else "Tag.TButton")
        def choose(value):
            kind.set(value)
            update()
        for i, value in enumerate(list(NUMERIC_TAGS)+["x", "-1", "-2", "-x"]):
            grid.columnconfigure(i % 3, weight=1)
            button = self.button(grid, TAG_KINDS[value]["label"], lambda v=value: choose(v), "phone-kind-" + value)
            button.grid(row=i // 3, column=i % 3, sticky="ew", padx=2, pady=2)
            choices[value] = button
        ttk.Label(frame, textvariable=note, wraplength=430).pack(fill="x", pady=8)
        def save():
            try:
                self.service.import_tags(self.session, {phone_uid(uid.get()): kind.get()})
            except (ValueError, OSError, sqlite3.Error) as exc:
                note.set("Не сохранено: " + str(exc))
                return
            self.tag_manager()
            self.import_notice.set("Сохранено. Номер телефона преобразован в формат RC522 автоматически.")
        self.button(frame, "Сохранить назначение", save, "save-phone-tag", True).pack(fill="x", pady=6)
        uid.trace_add("write", update)
        update()
        entry.focus_set()

    def choose_tag_file(self):
        filename = filedialog.askopenfilename(parent=self.dialog, title="Список меток", filetypes=[("Список меток", "*.json *.csv *.txt"), ("Все файлы", "*")])
        if not filename:
            return
        try:
            with open(filename, "rb") as stream:
                data = stream.read(MAX_BYTES + 1)
            if len(data) > MAX_BYTES:
                raise ValueError("Файл больше 128 КБ.")
            text = data.decode("utf-8-sig")
            tags = parse_tags(text)
        except (ValueError, OSError) as exc:
            self.import_notice.set("Список не загружен: " + str(exc))
            return
        self.preview_tag_import(tags)

    def preview_tag_import(self, tags):
        dialog, frame = self.modal("Проверить список меток", scroll=True)
        self.label(frame, "Ничего ещё не сохранено. Проверьте значения и подтвердите импорт.", wraplength=430)
        existing = self.store.tags()
        changed = sum(uid in existing and existing[uid] != kind for uid, kind in tags.items())
        self.label(frame, "Метки: " + str(len(tags)) + ". Изменятся прежние назначения: " + str(changed) + ".", wraplength=430)
        for uid, kind in list(tags.items())[:40]:
            old = existing.get(uid)
            text = uid + " → " + TAG_KINDS[kind]["label"]
            if old and old != kind:
                text += " (было " + TAG_KINDS[old]["label"] + ")"
            self.label(frame, text, wraplength=430)
        if len(tags) > 40:
            self.label(frame, "Ещё " + str(len(tags) - 40) + " назначений в файле.", wraplength=430)
        self.import_preview_notice = tk.StringVar(dialog)
        ttk.Label(frame, textvariable=self.import_preview_notice, wraplength=430).pack(fill="x")
        def save():
            try:
                self.service.import_tags(self.session, tags)
            except (ValueError, OSError, sqlite3.Error) as exc:
                self.import_preview_notice.set("Импорт не выполнен: " + str(exc))
                return
            self.tag_manager()
            self.import_notice.set("Готово: загружено " + str(len(tags)) + " назначений. Остальные метки и прогресс сохранены.")
        # Confirmation stays reachable even for a long list.
        self.button(dialog, "Сохранить этот список", save, "confirm-tag-import", True).pack(side="bottom", fill="x", padx=18, pady=6, before=dialog.winfo_children()[1])

    def export_tag_file(self):
        tags = self.store.tags()
        if not tags:
            self.import_notice.set("Пока нет назначений для сохранения.")
            return
        filename = filedialog.asksaveasfilename(parent=self.dialog, title="Копия назначений", initialfile="algebra-tags.json", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if filename:
            try:
                Path(filename).write_text(export_tags(tags), encoding="utf-8")
            except OSError as exc:
                self.import_notice.set(str(exc))
                return
            self.import_notice.set("Копия сохранена: " + filename)

    def tags(self, known_uid=None):
        dialog, frame = self.modal("Привязать метку",scroll=True)
        dialog.geometry("820x540+%d+%d" % (
            max(0, self.root.winfo_rootx() + (self.root.winfo_width() - 820) // 2),
            max(0, self.root.winfo_rooty() + (self.root.winfo_height() - 540) // 2)))
        columns = ttk.Frame(frame)
        columns.pack(fill="both", expand=True)
        left, right = ttk.Frame(columns), ttk.Frame(columns)
        left.pack(side="left", fill="both", expand=True, padx=(0, 18))
        right.pack(side="left", fill="both", expand=True)
        def close_tags():
            dialog.destroy()
            self.render()
        self.controls["close-dialog"].configure(command=close_tags)
        dialog.protocol("WM_DELETE_WINDOW", close_tags)
        dialog.bind("<Escape>", lambda e: close_tags())
        self.tag_dialog = dialog
        self.tag_waiting = False
        self.tag_uid = tk.StringVar(dialog, known_uid or "")
        self.tag_kind = tk.StringVar(dialog, "")
        self.tag_message = tk.StringVar(dialog, "Метка уже считана. Выберите её значение." if known_uid else "Начните с кнопки «Считать метку».")
        self.tag_connection = tk.StringVar(dialog)
        self.label(left, "1. Считайте метку", "Heading.TLabel", wraplength=330)
        self.button(left, "Считать метку / считать другую", self.capture_tag, "read-tag", True).pack(fill="x")
        ttk.Label(left, textvariable=self.tag_connection, wraplength=330, style="Small.TLabel").pack(fill="x", pady=4)
        entry = ttk.Entry(left, textvariable=self.tag_uid, state="readonly")
        entry.pack(fill="x")
        self.controls["tag-uid"] = entry
        self.label(right, "2. Выберите роль метки", "Heading.TLabel", wraplength=350)
        tabs = ttk.Frame(right)
        tabs.pack(fill="x", pady=(0, 4))
        self.button(tabs, "Числа и x", lambda: self.show_tag_roles("blocks"), "tag-blocks").pack(side="left")
        self.button(tabs, "Команды", lambda: self.show_tag_roles("commands"), "tag-commands").pack(side="left")
        choices = ttk.Frame(right)
        choices.pack(fill="x")
        self.tag_choices = {}
        for kind, definition in TAG_KINDS.items():
            button = self.button(choices, definition["label"], lambda k=kind: self.choose_tag(k), "tag-kind-" + kind)
            self.tag_choices[kind] = button
        self.show_tag_roles("blocks")
        ttk.Label(right, textvariable=self.tag_message, wraplength=350).pack(fill="x", pady=6)
        self.button(right, "3. Сохранить привязку", self.save_tag, "bind-tag", True).pack(fill="x")
        tools = ttk.Frame(frame)
        tools.pack(fill="x", pady=4)
        self.button(tools, "Мои метки (" + str(len(self.store.tags())) + ")", self.tag_list, "tag-list").pack(side="left")
        self.button(left, "UID вручную", self.manual_tag, "manual-tag").pack(fill="x", pady=12)
        self.button(left, "Проверка считывателя", self.reader_details, "tag-reader-details").pack(fill="x")
        self.refresh_tag_controls()
        self.update_tag_connection()
        if known_uid and self.session.task_id in ADVENTURE_IDS and known_uid not in self.store.tags():
            self.choose_tag("1")
            self.tag_message.set("Для первых уроков нужна +1. Подтвердите «Сохранить привязку».")

    def show_tag_roles(self, group):
        kinds = list(NUMERIC_TAGS)+["x","-1","-2","-x"] if group == "blocks" else list(COMMANDS)
        for button in self.tag_choices.values():
            button.grid_remove()
        for index, kind in enumerate(kinds):
            button = self.tag_choices[kind]
            button.grid(row=index // 3, column=index % 3, sticky="ew", padx=2, pady=2)
            button.master.columnconfigure(index % 3, weight=1)

    def tag_window_open(self):
        dialog = getattr(self, "tag_dialog", None)
        return bool(dialog and dialog.winfo_exists())

    def update_tag_connection(self):
        if not self.tag_window_open():
            return
        state = self.reader.status()
        if state["error"]:
            text = state["error"]
        elif state.get("warning"):
            text = state["warning"]
        elif state["mode"] == "simulator":
            text = "Считыватель выключен. «Считать метку» включит RC522 на SPI0."
        elif state["connected"]:
            text = "RC522 подключён · SPI0 CE0 · RST GPIO25"
        else:
            text = "Подключение RC522…"
        self.tag_connection.set(text)

    def refresh_tag_controls(self):
        ready = bool(self.tag_uid.get()) and not self.tag_waiting
        for kind, button in self.tag_choices.items():
            button.state(["!disabled"] if ready else ["disabled"])
            button.configure(style="SelectedTag.TButton" if self.tag_kind.get() == kind else "Tag.TButton")
        self.controls["bind-tag"].state(["!disabled"] if ready and self.tag_kind.get() else ["disabled"])

    def capture_tag(self):
        self.tag_uid.set("")
        self.tag_kind.set("")
        self.tag_waiting = True
        self.controls["tag-uid"].configure(state="readonly")
        self.tag_message.set("Уберите метку на 2 секунды, затем поднесите и держите неподвижно около секунды.")
        self.event_sequence = self.reader.sequence
        try:
            if self.reader.mode not in ("rc522", "rc522_dual") or self.reader.error or not self.reader.status()["connected"]:
                self.reader.configure(self.reader_mode())
            self.store.save_settings({"reader_mode": self.reader.mode})
        except (OSError, ValueError) as exc:
            self.tag_message.set(str(exc))
        self.refresh_tag_controls()
        self.update_tag_connection()

    def receive_tag(self, uid):
        if not self.tag_window_open() or not self.tag_waiting:
            return
        self.tag_waiting = False
        self.tag_uid.set(uid)
        existing = self.store.tags().get(uid)
        self.tag_kind.set(existing or "")
        self.show_tag_roles("commands" if existing in COMMANDS else "blocks")
        self.tag_message.set("Метка считана. " + ("Сейчас: " + TAG_KINDS[existing]["label"] + ". Выберите новое значение или сохраните." if existing else "Теперь выберите значение ниже."))
        self.refresh_tag_controls()

    def manual_tag(self):
        self.tag_waiting = False
        self.tag_kind.set("")
        self.controls["tag-uid"].configure(state="normal")
        self.controls["tag-uid"].focus_set()
        self.tag_message.set("Ручной ввод для проверки. Введите UID, затем выберите значение.")
        self.tag_uid.trace_add("write", lambda *args: self.refresh_tag_controls() if self.tag_window_open() else None)
        self.refresh_tag_controls()

    def choose_tag(self, kind):
        self.tag_kind.set(kind)
        self.tag_message.set("Выбрано: " + TAG_KINDS[kind]["label"] + ". Нажмите «Сохранить привязку».")
        self.refresh_tag_controls()

    def save_tag(self):
        try:
            uid, kind = normalize_uid(self.tag_uid.get()), self.tag_kind.get()
            self.service.dispatch("/api/tags/bind", self.session, {"uid": uid, "kind": kind})
        except (ValueError, sqlite3.Error, OSError) as exc:
            self.tag_message.set("Не сохранено: " + str(exc))
            return
        self.tag_message.set("✓ Сохранено: эта метка = " + TAG_KINDS[kind]["label"] + ". Закройте окно и поднесите метку снова.")
        self.status.set("Метка привязана: " + TAG_KINDS[kind]["label"])
        self.controls["bind-tag"].state(["disabled"])
        self.controls["tag-list"].configure(text="Мои метки (" + str(len(self.store.tags())) + ")")

    def tag_list(self):
        dialog, frame = self.modal("Мои метки", scroll=True)
        tags = self.store.tags()
        if not tags:
            self.label(frame, "Пока нет привязанных меток.")
        self.button(frame, "Привязать новую метку", self.tags, "new-tag", True).pack(fill="x", pady=6)
        for uid, kind in tags.items():
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=TAG_KINDS[kind]["label"] + " · " + uid, wraplength=200).pack(side="left")
            self.button(row, "Изменить", lambda u=uid: self.tags(u), "edit-" + uid).pack(side="right")
            self.button(row, "Удалить", lambda u=uid: self.unbind(u), "unbind-" + uid).pack(side="right")

    def unbind(self, uid):
        self.service.dispatch("/api/tags/remove", self.session, {"uid": uid})
        self.tag_list()

    def help(self):
        if self.simple_ui():
            dialog, frame = self.modal("Как играть")
            for text in ["Синий x — число, которое мы ищем. Жёлтый +1 — одна единица.",
                         "Первый урок показывает правило. Дальше ты сам выбираешь действие и чашу. +1 и +2 означают величину блока, а добавить или убрать ты выбираешь кнопкой.",
                         "Убери метку на две секунды. Затем поднеси снова, чтобы повторить действие на другой чаше.",
                         "Освободи x, затем сам покажи, сколько он стоит: меткой +1/+2 или выбранным числом. Меткой x можно подтвердить выбранный ответ. Награда — после твоего ответа."]:
                self.label(frame, text, wraplength=430)
            return
        dialog, frame = self.modal("Здесь всё можно понять", scroll=True)
        for title, text in [
            ("01 · Равенство — это баланс", "Блок x — неизвестное число. В практике сохраняй одинаковые значения обеих частей уравнения."),
            ("02 · Одно действие — две стороны", "Прибавляй или вычитай одно и то же выражение. Умножай и дели на одно и то же ненулевое число. Например, для x + 3 = 7 вычти 3 с обеих сторон."),
            ("03 · Физические блоки — по одному", "Выбери чашу, поднеси одну метку и убери её из зоны RC522. Программа ведёт реестр. При снятии или переносе блока удали запись с прежней чаши."),
            ("04 · Числа без клавиатуры", "Кнопка ⌨ открывает сенсорный ввод. F11 включает полный экран, Esc возвращает обычное окно. Прогресс хранится локально."),
        ]:
            self.label(frame, title, "Heading.TLabel", wraplength=430)
            self.label(frame, text, wraplength=430)

    @staticmethod
    def clock_text(ex):
        if ex["mode"] != "challenge":
            return "Практика без спешки"
        if ex["completed"]:
            return "Вызов завершён"
        return f"Осталось {ex['remaining'] // 60}:{ex['remaining'] % 60:02}"

    def tick(self):
        if self.closed:
            return
        if self.page == "exercise" and self.session.current:
            ex = self.service.exercise(self.session)
            if not getattr(self, "clock_is_game", False):
                self.clock.configure(text=self.clock_text(ex))
            if ex["expired"] and not self.controls.get("untimed"):
                self.render()
        for event in self.reader.since(self.event_sequence):
            self.event_sequence = event["sequence"]
            if event.get("type") == "button":
                if (self.page == "exercise" and self.session.cup_play and not self.session.completed
                        and self.session.cup_phase == "choose" and not (self.dialog and self.dialog.winfo_exists())):
                    if self.service.student_stage(self.session) != "demo":
                        self.choose_cup_operation(event["operation"])
                continue
            if self.reader.mode not in ("rc522", "rc522_dual"):
                continue
            self.last_uid = event["uid"]
            if self.dialog and self.dialog.winfo_exists():
                self.receive_tag(self.last_uid)
            elif self.page == "lab":
                if self.last_uid not in self.store.tags():
                    self.tags(self.last_uid)
                else:
                    self.guard(lambda e=event: self.service.scan(self.session, {"uid": e["uid"], "side": e.get("source", self.side)}))
                    self.render()
            elif self.page == "quiz":
                pass
            elif not self.simple_ui() or self.page in ("home", "exercise"):
                self.handle_physical_scan(self.last_uid, event.get("source"))
        self.update_hardware_note()
        self.update_tag_connection()
        self.update_physical_status()
        self.timer_id = self.root.after(150, self.tick)

    def return_to_child(self):
        self.child_requested = True
        self.close()

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.timer_id:
            self.root.after_cancel(self.timer_id)
        self.service.save_practice(self.session)
        self.buttons.close()
        self.reader.close()
        self.mobile.close()
        self.store.close()
        self.root.destroy()
        # Release the application reference on the Tk owner thread.
        del self.root.report_callback_exception


def main(argv=None):
    parser = argparse.ArgumentParser(description="Алгебра LAB — нативное приложение для Raspberry Pi")
    parser.add_argument("--data-dir", type=Path, default=data_directory())
    parser.add_argument("--reader", choices=["simulator", "rc522", "rc522_dual"], default=None)
    display_mode = parser.add_mutually_exclusive_group()
    display_mode.add_argument("--fullscreen", action="store_true")
    display_mode.add_argument("--windowed", action="store_true")
    parser.add_argument("--check-hardware", action="store_true", help="Проверка SPI/RC522 без окна, 8 секунд")
    parser.add_argument("--check-buttons", action="store_true", help="Включить GPIO13/26 в аппаратную проверку")
    args = parser.parse_args(argv)
    args.data_dir.mkdir(parents=True, exist_ok=True)
    # Do not let two GUI instances consume memory or share the physical reader.
    with (args.data_dir / "desktop.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("Алгебра LAB уже запущена для этого профиля.", file=sys.stderr)
            return 1
        if args.check_hardware:
            from .diagnostics import check
            check(args.reader or "rc522_dual", args.check_buttons)
            return 0
        try:
            root = tk.Tk(className="AlgebraLAB")
        except tk.TclError:
            print("Нужен графический рабочий стол. Запустите Алгебра LAB из меню Raspberry Pi OS.", file=sys.stderr)
            return 1
        store = Store(args.data_dir / "algebra.sqlite3")
        mode = args.reader or store.settings().get("reader_mode", "simulator")
        reader = Reader(mode if mode in ("simulator", "rc522", "rc522_dual") else "simulator")
        app = Desktop(root, store, reader)
        root.attributes("-fullscreen", args.fullscreen or (not args.windowed and store.settings().get("fullscreen", True)))
        try:
            root.mainloop()
        finally:
            if not app.closed:
                app.close()
    if app.child_requested:
        launcher = Path(__file__).resolve().parent.parent / "launcher.py"
        command = ([sys.executable, str(launcher)] if launcher.exists() else
                   [sys.executable, "-m", "algebra_lab.qt_ui.app"])
        command += ["--data-dir", str(args.data_dir)]
        if args.windowed:
            command.append("--windowed")
        # The old window, hardware and profile lock are closed before restart.
        os.execv(sys.executable, command)
    return 0


if __name__ == "__main__":
    sys.exit(main())
