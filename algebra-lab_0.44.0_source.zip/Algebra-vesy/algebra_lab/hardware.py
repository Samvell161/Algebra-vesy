"""One UID per presentation. No assumption of bulk RFID inventory or measured algebra."""
import threading
import time
from collections import deque

from .math_engine import Linear
from .rc522 import CardReadError
from fractions import Fraction

BLOCKS = {
    "x": {"label": "x", "a": 1, "b": 0},
    "-x": {"label": "−x", "a": -1, "b": 0},
    "1": {"label": "+1", "a": 0, "b": 1},
    "-1": {"label": "−1", "a": 0, "b": -1},
    "2": {"label": "+2", "a": 0, "b": 2},
    "-2": {"label": "−2", "a": 0, "b": -2},
    "5": {"label": "+5", "a": 0, "b": 5},
}
NUMERIC_TAGS = tuple(str(i) for i in range(10))
for _digit in NUMERIC_TAGS:
    BLOCKS.setdefault(_digit, {"label": "0" if _digit == "0" else "+" + _digit, "a": 0, "b": int(_digit)})


COMMANDS = {
    "add": {"label": "+ Прибавить"},
    "subtract": {"label": "− Вычесть"},
    "multiply": {"label": "× Умножить"},
    "divide": {"label": "÷ Разделить"},
    "apply": {"label": "✓ Применить"},
    "clear": {"label": "Очистить набор"},
    "undo": {"label": "↶ Отмена"},
    "hint": {"label": "? Подсказка"},
    "next": {"label": "→ Следующее"},
    "guide": {"label": "Шаг с подсказкой"},
}
TAG_KINDS = {**BLOCKS, **COMMANDS}


def normalize_uid(uid):
    uid = str(uid).strip().upper()
    if not uid or len(uid) > 64 or not all(c in "0123456789ABCDEF:-" for c in uid):
        raise ValueError("UID: используйте до 64 символов 0–9, A–F, : или −.")
    return uid


def expression(blocks):
    result = Linear()
    for block in blocks:
        kind = BLOCKS[block["kind"]]
        result += Linear(Fraction(kind["a"]), Fraction(kind["b"]))
    return result


class Reader:
    POLL_SECONDS = 0.8
    REMOVE_SECONDS = 0.7
    ABSENT_READS = 2

    def __init__(self, mode="simulator"):
        self.mode = mode
        self.error = None
        self.warning = None
        self.last_error = None
        self.failures = 0
        self.present_uid = None
        self.events = deque(maxlen=100)
        self.sequence = 0
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.driver = None
        self.channels = {}
        self.configure(mode)

    def configure(self, mode):
        if mode not in ("simulator", "rc522", "rc522_dual"):
            raise ValueError("Неизвестный режим считывателя.")
        self.close()
        if self.thread and self.thread.is_alive():
            raise OSError("Предыдущий опрос ещё завершается. Повторите подключение.")
        self.mode, self.error, self.driver = mode, None, None
        self.warning, self.last_error, self.failures, self.present_uid = None, None, 0, None
        self.stop_event = threading.Event()
        self.channels = {}
        if mode in ("rc522", "rc522_dual"):
            self.thread = threading.Thread(target=self._connect_dual if mode == "rc522_dual" else self._connect, daemon=True)
            self.thread.start()

    def _connect(self):
        try:
            from .rc522 import RC522
            self.driver = RC522()
            self._poll()
        except ImportError:
            self.error = "Нужны системные библиотеки. В терминале: sudo apt install python3-spidev python3-rpi.gpio"
        except Exception as exc:
            self.error = "RC522 недоступен: " + str(exc)
        finally:
            if self.driver:
                self.driver.close()
                self.driver = None

    def _poll(self):
        last, absent_since, absent_reads = None, None, 0
        delay = self.POLL_SECONDS
        try:
            while not self.stop_event.wait(delay):
                try:
                    uid = self.driver.read_id_no_block()
                except CardReadError as exc:
                    # RF faults prove neither removal nor a different tag.
                    absent_since, absent_reads = None, 0
                    self.last_error = str(exc)
                    self.failures += 1
                    delay = min(2.0, self.POLL_SECONDS + self.failures * .2)
                    if self.failures >= 3:
                        self.warning = "Метка пока не прочитана. Попробуй поднести её чуть ближе. Взрослый может открыть «Проверка считывателя»."
                    # Do not continually interrupt the RF field on every sample.
                    if self.failures % 3 == 0:
                        self.driver.recover()
                    continue
                delay = self.POLL_SECONDS
                if uid is None:
                    now = time.monotonic()
                    absent_reads += 1
                    if absent_since is None:
                        absent_since = now
                    if absent_reads >= self.ABSENT_READS and now - absent_since >= self.REMOVE_SECONDS:
                        last = None
                        self.present_uid = None
                    continue
                absent_since, absent_reads = None, 0
                self.warning, self.failures = None, 0
                uid = format(uid, "X")
                self.present_uid = uid
                # The low-level driver has validated ATQA length, full UID and BCC.
                # One valid sample is sufficient; faults before/after it cannot
                # prevent recognition or create another presentation.
                if last is None:
                    self.emit({"uid": uid})
                    last = uid
        except Exception as exc:
            self.error = f"Чтение остановлено: {type(exc).__name__}: {exc}. Нажмите «Считать метку» для повторного подключения."
            self.last_error = self.error

    def emit(self, event):
        # RFID and physical buttons share a single ordered event queue.
        with self.lock:
            self.sequence += 1
            self.events.append({"sequence": self.sequence, **event})

    def _connect_dual(self):
        from .rc522 import RC522
        self.channels = {side: {"bus": bus, "rst": rst, "driver": None, "error": None,
                              "warning": None, "last_error": None, "failures": 0,
                              "present_uid": None, "last": None, "absent_since": None,
                              "absent_reads": 0, "next": 0, "version": None}
                         for side, bus, rst in [("left", 0, 25), ("right", 1, 5)]}
        try:
            while not self.stop_event.wait(.05):
                for side, channel in self.channels.items():
                    if self.stop_event.is_set():
                        break
                    now = time.monotonic()
                    if now < channel["next"]:
                        continue
                    if channel["driver"] is None:
                        try:
                            driver = RC522(bus=channel["bus"], device=0, rst=channel["rst"])
                            channel["driver"] = driver
                            driver.antenna(False)
                            channel["version"], channel["error"] = driver.version, None
                        except Exception as exc:
                            if channel["driver"]:
                                channel["driver"].close()
                                channel["driver"] = None
                            channel["error"] = channel["last_error"] = str(exc)
                            channel["next"] = now + 5
                            continue
                    self._sample_channel(side, channel)
        finally:
            for channel in self.channels.values():
                if channel["driver"]:
                    channel["driver"].close()
                    channel["driver"] = None

    def _sample_channel(self, side, channel):
        driver = channel["driver"]
        delay = self.POLL_SECONDS
        try:
            # One RF field at a time, in a single worker. Never inventory a pile.
            driver.antenna(True)
            if self.stop_event.wait(.02):
                return
            try:
                uid = driver.read_id_no_block()
            finally:
                driver.antenna(False)
            if uid is None:
                now = time.monotonic()
                channel["absent_reads"] += 1
                if channel["absent_since"] is None:
                    channel["absent_since"] = now
                if channel["absent_reads"] >= self.ABSENT_READS and now - channel["absent_since"] >= self.REMOVE_SECONDS:
                    channel["last"] = channel["present_uid"] = None
            else:
                channel["absent_since"], channel["absent_reads"] = None, 0
                channel["warning"], channel["failures"] = None, 0
                uid = format(uid, "X")
                channel["present_uid"] = uid
                if channel["last"] is None:
                    self.emit({"uid": uid, "source": side})
                    channel["last"] = uid
        except CardReadError as exc:
            channel["absent_since"], channel["absent_reads"] = None, 0
            channel["failures"] += 1
            channel["last_error"] = str(exc)
            delay = min(2, self.POLL_SECONDS + channel["failures"] * .2)
            if channel["failures"] >= 3:
                channel["warning"] = "Метка пока не прочитана. Убери её и поднеси снова."
        except Exception as exc:
            channel["error"] = channel["last_error"] = str(exc)
            channel["absent_since"], channel["absent_reads"] = None, 0
            driver.close()
            channel["driver"] = None
            delay = 5
            # A reconnect does not count as confirmed physical removal.
        finally:
            if channel["driver"]:
                try:
                    driver.antenna(False)
                except Exception as exc:
                    channel["error"] = channel["last_error"] = str(exc)
                    driver.close()
                    channel["driver"] = None
                    delay = 5
            channel["next"] = time.monotonic() + delay

    def status(self):
        if self.mode == "rc522_dual":
            channels = {side: {key: value for key, value in channel.items()
                              if key in ("bus", "rst", "error", "warning", "last_error", "failures", "present_uid", "version")}
                        for side, channel in self.channels.copy().items()}
            for side, channel in channels.items():
                channel["connected"] = self.channels[side]["driver"] is not None and channel["error"] is None
            return {"mode": self.mode, "connected": any(c["connected"] for c in channels.values()),
                    "channels": channels, "error": None, "warning": None, "last_error": None,
                    "present_uid": None, "poll_seconds": self.POLL_SECONDS,
                    "hx711": "not_configured", "sequence": self.sequence}
        return {"mode": self.mode, "connected": self.driver is not None and self.error is None,
                "error": self.error, "warning": self.warning, "last_error": self.last_error, "failures": self.failures,
                "present_uid": self.present_uid, "poll_seconds": self.POLL_SECONDS, "hx711": "not_configured", "sequence": self.sequence}

    def since(self, sequence):
        with self.lock:
            return [event.copy() for event in self.events if event["sequence"] > sequence]

    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=0.3)
