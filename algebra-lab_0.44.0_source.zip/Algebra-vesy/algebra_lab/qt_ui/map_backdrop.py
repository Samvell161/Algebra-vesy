"""Offline diorama artwork for the map, decoded once and drawn into its cache."""
from functools import lru_cache
from pathlib import Path
from PyQt6.QtCore import QRectF
from PyQt6.QtGui import QPixmap,QPainter,QPainterPath,QColor

@lru_cache(maxsize=1)
def texture():return QPixmap(str(Path(__file__).with_name('assets')/'adventure-diorama.png'))

def draw_backdrop(p,width,height,chapter):
    image=texture()
    if image.isNull():return False
    p.save();clip=QPainterPath();clip.addRoundedRect(QRectF(0,0,width,height),22,22);p.setClipPath(clip)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    factor=max(width/image.width(),height/image.height());w,h=width/factor,height/factor
    p.drawPixmap(QRectF(0,0,width,height),image,QRectF((image.width()-w)/2,(image.height()-h)/2,w,h))
    tint=[QColor(242,255,245,12),QColor(255,226,175,25),QColor(186,235,246,26),QColor(232,207,248,26)][chapter%4]
    p.fillRect(QRectF(0,0,width,height),tint);p.restore();return True
