import time
import uuid
from dataclasses import dataclass, field
from typing import Optional
from fractions import Fraction

from .hardware import BLOCKS, TAG_KINDS, NUMERIC_TAGS, expression, normalize_uid
from .math_engine import Equation, Linear, MathError, equation, fmt, number
from .tasks import BY_ID, TASKS, STARTER_IDS
from .adventure import ADVENTURE_TASKS, ADVENTURE_IDS, QUIZ_BY_ID, next_level, quiz_open
PLAY_TASKS = ADVENTURE_TASKS + TASKS


@dataclass
class Session:
    task_id: Optional[str] = None
    mode: str = "practice"
    current: Optional[Equation] = None
    history: list = field(default_factory=list)
    hints: int = 0
    started: float = 0
    attempt: str = ""
    completed: bool = False
    blocks: dict = field(default_factory=lambda: {"left": [], "right": []})
    x: Fraction = Fraction(1)
    rfid_operation: str = "subtract"
    rfid_terms: list = field(default_factory=list)
    cup_side: str = "left"
    cup_operation: str = "remove"
    cup_delta: dict = field(default_factory=lambda: {"left": Linear(), "right": Linear()})
    cup_play: bool = False
    cup_phase: str = "choose"
    cup_guess: Optional[int] = None
    cup_answer_digits: str = ""
    cup_actions: list = field(default_factory=list)


class Service:
    def __init__(self, store, reader):
        self.store = store
        self.reader = reader

    def bootstrap(self, session):
        return {"tasks": TASKS, "progress": self.store.progress(), "settings": self.store.settings(),
                "hardware": self.reader.status(), "tags": self.store.tags(), "blocks": BLOCKS,
                "exercise": self.exercise(session), "lab": self.lab(session)}

    def exercise(self, session):
        if not session.current:
            return None
        elapsed = int(time.monotonic() - session.started)
        return {"task": BY_ID[session.task_id], "equation": session.current.json(),
                "history": session.history, "hints": session.hints, "mode": session.mode,
                "completed": session.completed, "expired": session.mode == "challenge" and elapsed >= 180 and not session.completed,
                "seconds": elapsed, "remaining": max(0, 180 - elapsed),
                "stars": max(1, 3 - min(2, session.hints)) if session.completed else 0}

    def lab(self, session):
        left, right = expression(session.blocks["left"]), expression(session.blocks["right"])
        lv, rv = left.at(session.x), right.at(session.x)
        return {"blocks": session.blocks, "equation": Equation(left, right).json(), "x": str(session.x),
                "left_value": fmt(lv), "right_value": fmt(rv), "balanced": lv == rv,
                "tilt": 0 if lv == rv else (-1 if lv > rv else 1)}

    def start(self, session, data):
        task_id = data.get("task_id")
        if task_id not in BY_ID or BY_ID[task_id].get("kind") == "quiz":
            raise ValueError("Задание не найдено. Квиз открывается отдельно с карты.")
        mode = data.get("mode", "practice")
        if mode not in ("practice", "challenge"):
            raise ValueError("Неизвестный режим.")
        session.task_id, session.mode = task_id, mode
        session.current = equation(BY_ID[task_id]["equation"])
        session.history = [{"label": "Начальное уравнение", **session.current.json()}]
        session.hints = 0
        session.started = time.monotonic()
        session.attempt = uuid.uuid4().hex
        session.completed = False
        session.cup_play, session.cup_phase, session.cup_guess = False, "choose", None
        session.cup_answer_digits = ""
        session.rfid_operation, session.rfid_terms = "subtract", []
        session.cup_side = "left"
        session.cup_actions = []
        session.cup_delta = {"left": Linear(), "right": Linear()}
        session.cup_operation = "add" if session.current.left.b < 0 else "remove"
        return self.exercise(session)

    def active(self, session):
        if not session.current:
            raise ValueError("Сначала выберите задание.")
        if session.completed:
            raise ValueError("Задание уже завершено. Выберите следующее.")
        if session.mode == "challenge" and time.monotonic() - session.started >= 180:
            raise ValueError("Время вышло. Попробуйте задание ещё раз.")

    def transform(self, session, data):
        self.active(session)
        if len(session.history) >= 51:
            raise ValueError("Достигнут лимит 50 шагов. Начните задание заново.")
        op, value = data.get("operation"), str(data.get("value", ""))
        result = session.current.transform(op, value)
        if result == session.current:
            raise ValueError("Это действие ничего не меняет. Попробуйте другое число.")
        labels = {"add": "Прибавили", "subtract": "Вычли", "multiply": "Умножили на", "divide": "Разделили на"}
        session.current = result
        session.history.append({"label": f"{labels[op]} {value} с обеих сторон", **result.json()})
        if result.isolated():
            if session.cup_play:
                session.cup_phase = "answer"
            else:
                self.complete(session)
        return self.exercise(session)

    def complete(self, session, answer=None):
        if not session.completed:
            original = equation(BY_ID[session.task_id]["equation"])
            result = original.solution()
            if answer is None and result["kind"] == "one":
                answer = Fraction(result["value"])
            proof = None if answer is None else {"x": fmt(answer), "left": fmt(original.left.at(answer)),
                                                 "right": fmt(original.right.at(answer))}
            solution = {"version": 1, "original": BY_ID[session.task_id]["equation"],
                        "steps": session.history, "check": proof}
            self.store.record(session.attempt, session.task_id, session.mode, len(session.history) - 1,
                              session.hints, int(time.monotonic() - session.started), solution=solution)
            session.completed = True

    def answer(self, session, data):
        self.active(session)
        value = number(data.get("answer", ""))
        original = equation(BY_ID[session.task_id]["equation"])
        left, right = original.left.at(value), original.right.at(value)
        if left != right:
            return {"correct": False, "message": f"При x = {fmt(value)} слева получается {fmt(left)}, справа — {fmt(right)}. Значения отличаются: проверь последний шаг."}
        self.complete(session, value)
        return {"correct": True, "message": "Верно! Подстановка подтверждает равенство.", "exercise": self.exercise(session)}

    def save_practice(self, session):
        if not session.current or session.completed or session.mode != "practice":
            self.store.checkpoint(None)
            return
        self.store.checkpoint({"version": 1, "task_id": session.task_id, "history": session.history,
                               "hints": session.hints, "attempt": session.attempt,
                               "seconds": int(time.monotonic() - session.started), "cup_play": session.cup_play})

    def restore_practice(self, session):
        saved = self.store.settings().get("practice_session")
        if not saved:
            return False
        try:
            if saved["version"] != 1 or not isinstance(saved["history"], list) or not 1 <= len(saved["history"]) <= 51:
                raise ValueError("Invalid checkpoint")
            task = BY_ID[saved["task_id"]]
            original = equation(task["equation"])
            restored = []
            for step in saved["history"]:
                current = equation(step["left"] + "=" + step["right"])
                if current.solution() != original.solution() or not isinstance(step["label"], str):
                    raise ValueError("Invalid checkpoint equation")
                restored.append({"label": step["label"][:200], **current.json()})
                actions = step.get("actions", [])
                if isinstance(actions, list) and len(actions) == 2 and all(
                        isinstance(a, dict) and a.get("side") in ("left", "right") and
                        a.get("operation") in ("add", "remove") and a.get("kind") in BLOCKS for a in actions):
                    restored[-1]["actions"] = [{k: a[k] for k in ("side", "operation", "kind")} for a in actions]
            if equation(restored[0]["left"] + "=" + restored[0]["right"]) != original or (current.isolated() and not (saved.get("cup_play") is True and task["id"] in ADVENTURE_IDS)):
                raise ValueError("Invalid checkpoint history")
            hints, seconds = saved["hints"], saved["seconds"]
            if type(hints) is not int or type(seconds) is not int or not 0 <= hints <= 10000 or not 0 <= seconds <= 31536000:
                raise ValueError("Invalid checkpoint counters")
            attempt = saved["attempt"]
            if not isinstance(attempt, str) or len(attempt) != 32 or any(c not in "0123456789abcdef" for c in attempt):
                raise ValueError("Invalid checkpoint ID")
        except (ValueError, TypeError, KeyError):
            self.store.checkpoint(None)
            return False
        self.start(session, {"task_id": task["id"]})
        session.current, session.history = current, restored
        session.hints, session.attempt = hints, attempt
        session.started = time.monotonic() - seconds
        if saved.get("cup_play") is True and task["id"] in ADVENTURE_IDS:
            self.begin_student(session)
        return True

    def hint(self, session):
        self.active(session)
        session.hints += 1
        eq = session.current
        if eq.right.a and eq.left.a:
            text = f"Уберите x с одной стороны: вычтите {eq.right.a}x из обеих частей."
        elif eq.left.a and eq.left.b:
            text = f"Оставьте блоки x отдельно: вычтите ({fmt(eq.left.b)}) из обеих частей."
        elif eq.right.a and eq.right.b:
            text = f"Оставьте блоки x отдельно: вычтите ({fmt(eq.right.b)}) из обеих частей."
        else:
            coefficient = eq.left.a or eq.right.a
            text = f"Чтобы получить один x, разделите обе части на {fmt(coefficient)}."
        return {"text": text, "hints": session.hints}

    def undo(self, session):
        self.active(session)
        if len(session.history) < 2:
            raise ValueError("Пока нет действий для отмены.")
        session.history.pop()
        last = session.history[-1]
        session.current = equation(last["left"] + "=" + last["right"])
        if session.cup_play:
            self.begin_student(session)
        return self.exercise(session)

    def scan(self, session, data):
        side = data.get("side")
        if side not in ("left", "right"):
            raise ValueError("Выберите левую или правую чашу перед регистрацией.")
        uid = normalize_uid(data.get("uid", ""))
        tags = self.store.tags()
        if uid not in tags:
            raise ValueError(f"Неизвестная метка {uid}. Сначала свяжите её с блоком в настройках.")
        if tags[uid] not in BLOCKS:
            raise ValueError("Это метка команды. Откройте задание: команды работают при решении уравнений.")
        if any(block["uid"] == uid for blocks in session.blocks.values() for block in blocks):
            raise ValueError("Этот блок уже зарегистрирован. Для переноса сначала удалите его с чаши.")
        if sum(map(len, session.blocks.values())) >= 40:
            raise ValueError("На весах может быть до 40 блоков.")
        session.blocks[side].append({"uid": uid, "kind": tags[uid]})
        return self.lab(session)

    def guided_step(self, session):
        """Choose one equivalence-preserving step from the displayed equation."""
        eq = session.current
        if not eq:
            raise ValueError("Сначала выберите задание.")
        if eq.isolated():
            return None
        if eq.left.a and eq.right.a:
            op, value = "subtract", str(Linear(eq.right.a))
        else:
            variable_side = eq.left if eq.left.a else eq.right
            if not variable_side.a:
                raise ValueError("В этом уравнении нет единственного решения; учебный шаг недоступен.")
            if variable_side.b:
                op, value = "subtract", fmt(variable_side.b)
            else:
                op, value = "divide", fmt(variable_side.a)
        label = ("Вычесть (" + value + ") из обеих частей" if op == "subtract"
                 else "Разделить обе части на (" + value + ")")
        return {"operation": op, "value": value, "label": label}

    def rfid_pending(self, session):
        total = Linear()
        for kind in session.rfid_terms:
            block = BLOCKS[kind]
            total += Linear(Fraction(block["a"]), Fraction(block["b"]))
        return str(total)

    def scan_exercise(self, session, data):
        uid = normalize_uid(data.get("uid", ""))
        kind = self.store.tags().get(uid)
        if kind not in TAG_KINDS:
            raise ValueError("Неизвестная метка. Сначала привяжите её.")
        style = data.get("style", "guided")
        if style not in ("guided", "independent"):
            raise ValueError("Неизвестный режим решения метками.")
        if kind == "next" or (style == "guided" and session.completed):
            if not session.completed:
                raise ValueError("Сначала завершите текущее задание.")
            index = next(i for i, task in enumerate(PLAY_TASKS) if task["id"] == session.task_id)
            self.start(session, {"task_id": PLAY_TASKS[(index + 1) % len(PLAY_TASKS)]["id"], "mode": session.mode})
            message = "Новое задание. Прочитайте условие и поднесите метку снова."
        else:
            self.active(session)
            if kind == "hint":
                message = self.hint(session)["text"]
            elif kind == "undo":
                self.undo(session)
                session.rfid_terms = []
                message = "Последний шаг отменён."
            elif style == "guided" or kind == "guide":
                step = self.guided_step(session)
                if step:
                    # Assisted steps use the existing hint penalty, before completion is recorded.
                    old_hints = session.hints
                    session.hints += 1
                    try:
                        self.transform(session, step)
                    except (ValueError, MathError):
                        session.hints = old_hints
                        raise
                    session.history[-1]["label"] = "Метка · шаг с подсказкой: " + session.history[-1]["label"]
                    message = step["label"] + "."
                else:
                    self.complete(session)
                    message = "Неизвестное уже выделено. Решение подтверждено."
                session.rfid_terms = []
            elif kind in ("add", "subtract", "multiply", "divide"):
                session.rfid_operation, session.rfid_terms = kind, []
                message = "Выбрано: " + TAG_KINDS[kind]["label"] + ". Поднесите метки чисел или x."
            elif kind == "clear":
                session.rfid_terms = []
                message = "Набранное выражение очищено. Уравнение сохранено."
            elif kind == "apply":
                if not session.rfid_terms:
                    raise ValueError("Сначала наберите выражение метками чисел или x.")
                value = self.rfid_pending(session)
                self.transform(session, {"operation": session.rfid_operation, "value": value})
                session.history[-1]["label"] = "Метки · " + session.history[-1]["label"]
                session.rfid_terms = []
                message = session.history[-1]["label"] + "."
            elif kind in BLOCKS:
                if len(session.rfid_terms) >= 40:
                    raise ValueError("Набрано 40 блоков. Примените действие или очистите набор.")
                session.rfid_terms.append(kind)
                message = "Добавлено " + BLOCKS[kind]["label"] + ". Набрано: " + self.rfid_pending(session) + ". Поднесите «Применить»."
            else:
                raise ValueError("Эта метка не поддерживается.")
        return {"message": message, "kind": kind, "uid": uid, "exercise": self.exercise(session),
                "pending": self.rfid_pending(session)}

    def student_stage(self, session):
        return ("demo" if session.task_id == "cups-1" else "supported" if session.task_id == "cups-2" else "independent")

    def begin_student(self, session):
        session.cup_play = True
        session.cup_phase = "answer" if session.current.isolated() else "choose"
        session.cup_guess = None
        session.cup_answer_digits = ""
        session.cup_actions = []
        session.cup_delta = {"left": Linear(), "right": Linear()}
        demo = self.student_stage(session) == "demo"
        session.cup_side = "left" if demo else None
        session.cup_operation = ("remove" if session.current.left.b > 0 else "add") if demo else None

    def student_answer(self, session, value):
        self.active(session)
        if not session.cup_play or session.cup_phase != "answer":
            raise ValueError("Сначала освободи x, сохраняя равенство чаш.")
        result = self.answer(session, {"answer": str(value)})
        if result["correct"]:
            session.cup_phase = "won"
        return result

    def student_hint(self, session):
        self.active(session)
        if not session.cup_play:
            return self.hint(session)
        session.hints += 1
        if session.cup_phase == "answer":
            text = ("Набери цифры ответа по порядку, затем нажми «Проверить» или поднеси x. Например, 1 и 3 — это 13."
                    if BY_ID[session.task_id].get('answer_digits',1)>1 else
                    "Прочитай число на чаше напротив x. Пустая чаша — это 0. Покажи ответ числовой меткой или выбери его на экране.")
            return {"text":text}
        if self.cup_state(session)["pending"]:
            return {"text": "Ты изменил одну чашу. Выбери другую и повтори то же действие с такой же меткой."}
        if session.current.left.a and session.current.right.a:
            return {"text": "На обеих чашах есть x. Убери одинаковые x с обеих сторон, чтобы загадка осталась только на одной."}
        side = session.current.left if session.current.left.a else session.current.right
        return {"text": "Рядом с x лишние единицы. Убирай их одинаково с обеих чаш; числовая метка задаёт сразу несколько единиц." if side.b > 0
                else "Отрицательные единицы можно погасить положительными. Добавляй одинаково с обеих сторон."}

    def cup_state(self, session):
        if not session.current:
            raise ValueError("Сначала выберите задание.")
        preview = Equation(session.current.left + session.cup_delta["left"],
                           session.current.right + session.cup_delta["right"])
        return {"preview": preview, "pending": any(v != Linear() for v in session.cup_delta.values()),
                "side": session.cup_side, "operation": session.cup_operation}

    def scan_cup(self, session, data):
        uid = normalize_uid(data.get("uid", ""))
        kind = self.store.tags().get(uid)
        if kind not in BLOCKS:
            raise ValueError("Для чаш нужна метка числа или x. Её роль можно выбрать в «Мои метки».")
        if session.completed:
            if session.cup_play:
                task = next_level(self.store.progress()["best"], session.task_id)
                self.start(session, {"task_id": task["id"], "mode": session.mode})
                self.begin_student(session)
                return {"message": "Новый уровень. Прочитай условие и выбери свой ход.", "kind": kind, "uid": uid, "exercise": self.exercise(session)}
            return self.scan_exercise(session, {"uid": uid, "style": "guided"})
        self.active(session)
        if session.cup_play and session.cup_phase == "answer":
            if kind == "x":
                if session.cup_guess is None:
                    raise ValueError("Какое число скрывает x? Выбери ответ на экране, затем поднеси метку x.")
                value = session.cup_guess
            elif kind in NUMERIC_TAGS:
                if BY_ID[session.task_id].get('answer_digits',1)>1:
                    digits=session.cup_answer_digits
                    if len(digits)>=2:digits=""
                    session.cup_answer_digits=digits+kind
                    session.cup_guess=int(session.cup_answer_digits)
                    return {"message":"Набрано: "+session.cup_answer_digits+". Подтверди кнопкой «Проверить» или меткой x.",
                            "kind":kind,"uid":uid,"exercise":self.exercise(session)}
                value = int(kind)
            else:
                raise ValueError("Покажи ответ числовой меткой или выбери число на экране.")
            checked = self.student_answer(session, value)
            return {"message": checked["message"], "kind": kind, "uid": uid, "exercise": self.exercise(session)}
        source = data.get("source")
        if source is not None and source not in ("left", "right"):
            raise ValueError("Неизвестный считыватель.")
        side = source or data.get("side", session.cup_side)
        operation = data.get("operation", session.cup_operation)
        if operation not in ("add", "remove"):
            raise ValueError("Сначала выбери действие: добавить или убрать блок.")
        if side not in ("left", "right"):
            raise ValueError("Теперь выбери левую или правую чашу, затем поднеси метку.")
        value = Linear(Fraction(BLOCKS[kind]["a"]), Fraction(BLOCKS[kind]["b"]))
        delta = value.scale(1 if operation == "add" else -1)
        if session.cup_play:
            if kind == "0":
                raise ValueError("Ноль не меняет чашу. Метка 0 нужна для ответа; сейчас выбери число от 1 до 9.")
            if kind not in NUMERIC_TAGS+("x",) or (kind == "x" and not (session.current.left.a and session.current.right.a)):
                raise ValueError("Метка x изменяет чаши, когда x есть с обеих сторон. Сейчас выбери число от 1 до 9.")
            selected = session.current.left if side == "left" else session.current.right
            if operation == "remove" and ((value.a and selected.a < value.a) or (value.b and selected.b < value.b)):
                raise ValueError("На этой чаше нет столько блоков. Посмотри на весы и выбери другое действие или метку.")
            if abs((selected + delta).b) > BY_ID[session.task_id].get('max_units',9) or abs((selected + delta).a) > 5:
                raise ValueError("Блоков станет слишком много. Попробуй освободить x или нажми отмену.")
        if session.task_id in STARTER_IDS and (not session.cup_play or self.student_stage(session) == "demo"):
            expected = Linear(b=Fraction(-1 if session.current.left.b > 0 else 1))
            if kind != "1" or delta != expected:
                verb = "убрать +1" if expected.b < 0 else "добавить +1"
                raise ValueError("В этом уроке нужно " + verb + ". Эта метка означает " + BLOCKS[kind]["label"] + ".")
        if session.cup_delta[side] != Linear():
            if not session.cup_play:
                session.cup_side = "right" if side == "left" else "left"
            raise ValueError("Эта чаша уже изменилась. Теперь сделайте то же с другой чашей.")
        other = "right" if side == "left" else "left"
        if session.cup_delta[other] != Linear() and session.cup_delta[other] != delta:
            raise ValueError("На второй чаше нужно повторить то же действие с той же величиной.")
        session.cup_delta[side] = delta
        session.cup_actions.append({"side": side, "operation": operation, "kind": kind})
        side_name = "слева" if side == "left" else "справа"
        verb = "Добавили" if operation == "add" else "Убрали"
        message = verb + " " + BLOCKS[kind]["label"] + " " + side_name + "."
        if session.cup_delta[other] == delta:
            try:
                self.transform(session, {"operation": "add", "value": str(delta)})
            except ValueError:
                session.cup_delta[side] = Linear()
                session.cup_actions.pop()
                raise
            session.history[-1]["label"] = "Метки: " + verb + " " + BLOCKS[kind]["label"] + " по очереди с обеих чаш"
            session.history[-1]["actions"] = session.cup_actions.copy()
            session.cup_actions = []
            session.cup_delta = {"left": Linear(), "right": Linear()}
            session.cup_side = "left"
            if session.cup_play:
                if session.cup_phase == "answer":
                    message += " Чаши уравновешены! Теперь сам определи, сколько единиц скрывает x."
                    session.cup_side = None
                else:
                    self.begin_student(session)
                    message = "Обе чаши изменились одинаково — равенство сохранилось. Посмотри, стал ли x ближе к освобождению."
            else:
                if not session.completed:
                    session.cup_operation = "remove" if session.current.left.b > 0 else "add"
                message += " Обе чаши изменены одинаково." + (" Решение получено!" if session.completed else " Повторим ещё раз.")
        else:
            if session.cup_play and self.student_stage(session) != "demo":
                session.cup_side = None
                message += " Изменилась только одна чаша. Повтори то же " + ("справа" if other == "right" else "слева") + ", чтобы сохранить равенство."
            else:
                session.cup_side = other
                message += " Теперь " + ("правая" if other == "right" else "левая") + " чаша подсвечена: уберите метку на 2 секунды и поднесите снова."
        return {"message": message, "kind": kind, "uid": uid, "exercise": self.exercise(session)}

    def start_quiz(self, quiz_id):
        if quiz_id not in QUIZ_BY_ID:
            raise ValueError("Квиз не найден.")
        index = list(QUIZ_BY_ID).index(quiz_id)
        if not quiz_open(self.store.progress()["best"], index):
            raise ValueError("Сначала пройди шесть уровней этой главы.")
        return {"id": quiz_id, "index": 0, "wrong": 0, "answered": False, "completed": False,
                "attempt": uuid.uuid4().hex, "started": time.monotonic(), "feedback": ""}

    def quiz_answer(self, state, choice):
        if state["completed"] or state["answered"]:
            raise ValueError("Ответ уже принят. Нажми «Дальше».")
        question = QUIZ_BY_ID[state["id"]]["questions"][state["index"]]
        if type(choice) is not int or not 0 <= choice < len(question[1]):
            raise ValueError("Выбери один из ответов.")
        if choice != question[2]:
            state["wrong"] += 1
            state["feedback"] = "Попробуй ещё раз. " + question[3]
            return False
        state["answered"] = True
        state["feedback"] = "Верно! " + question[3]
        return True

    def quiz_next(self, state):
        if not state["answered"] or state["completed"]:
            raise ValueError("Сначала ответь на вопрос.")
        questions = QUIZ_BY_ID[state["id"]]["questions"]
        if state["index"] + 1 < len(questions):
            state.update(index=state["index"]+1, answered=False, feedback="")
        else:
            self.store.record(state["attempt"], state["id"], "quiz", len(questions), state["wrong"], int(time.monotonic()-state["started"]))
            state["completed"] = True
        return state

    def import_tags(self, session, tags):
        if not isinstance(tags, dict) or not 1 <= len(tags) <= 1000:
            raise ValueError("Нужно от 1 до 1000 меток.")
        validated = {}
        existing = self.store.tags()
        on_trays = {b["uid"] for blocks in session.blocks.values() for b in blocks}
        for uid, kind in tags.items():
            uid = normalize_uid(uid)
            if kind not in TAG_KINDS:
                raise ValueError("Неизвестное значение метки.")
            if uid in on_trays and existing.get(uid) != kind:
                raise ValueError("Сначала уберите из лаборатории метку " + uid + ". Импорт не выполнен.")
            validated[uid] = kind
        self.store.bind_many(validated)
        return self.store.tags()

    def dispatch(self, path, session, data):
        if path == "/api/exercise/start":
            return self.start(session, data)
        if path == "/api/exercise/scan":
            return self.scan_exercise(session, data)
        if path == "/api/exercise/transform":
            return self.transform(session, data)
        if path == "/api/exercise/answer":
            return self.answer(session, data)
        if path == "/api/exercise/hint":
            return self.hint(session)
        if path == "/api/exercise/undo":
            return self.undo(session)
        if path == "/api/lab/scan":
            return self.scan(session, data)
        if path == "/api/lab/simulate":
            if self.reader.mode != "simulator":
                raise ValueError("В аппаратном режиме используйте реальные метки.")
            kind, side = data.get("kind"), data.get("side")
            if kind not in BLOCKS or side not in ("left", "right"):
                raise ValueError("Выберите блок и чашу.")
            if sum(map(len, session.blocks.values())) >= 40:
                raise ValueError("На весах может быть до 40 блоков.")
            session.blocks[side].append({"uid": "SIM-" + uuid.uuid4().hex[:8], "kind": kind})
            return self.lab(session)
        if path == "/api/lab/remove":
            for side in session.blocks:
                session.blocks[side] = [b for b in session.blocks[side] if b["uid"] != data.get("uid")]
            return self.lab(session)
        if path == "/api/lab/clear":
            session.blocks = {"left": [], "right": []}
            return self.lab(session)
        if path == "/api/lab/x":
            session.x = number(data.get("value", ""))
            return self.lab(session)
        if path == "/api/equation/check":
            eq = equation(data.get("equation", ""))
            return eq.json()
        if path == "/api/tags/bind":
            kind = data.get("kind")
            uid = normalize_uid(data.get("uid", ""))
            if kind not in TAG_KINDS:
                raise ValueError("Неизвестный тип метки.")
            if any(b["uid"] == uid for blocks in session.blocks.values() for b in blocks):
                raise ValueError("Сначала удалите блок с чаши, затем измените его тип.")
            self.store.bind(uid, kind)
            return self.store.tags()
        if path == "/api/tags/remove":
            uid = normalize_uid(data.get("uid", ""))
            self.store.unbind(uid)
            return self.store.tags()
        if path == "/api/settings":
            values = {}
            if "name" in data:
                if not isinstance(data["name"], str) or not 1 <= len(data["name"].strip()) <= 32:
                    raise ValueError("Имя должно содержать от 1 до 32 символов.")
                values["name"] = data["name"].strip()
            for key in ("motion", "contrast"):
                if key in data:
                    if not isinstance(data[key], bool):
                        raise ValueError("Некорректная настройка интерфейса.")
                    values[key] = data[key]
            self.store.save_settings(values)
            return self.store.settings()
        if path == "/api/progress/reset":
            if data.get("confirm") != "RESET":
                raise ValueError("Подтвердите сброс прогресса.")
            self.store.reset_progress()
            return self.store.progress()
        raise LookupError("Маршрут не найден.")
