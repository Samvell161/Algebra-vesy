"""Small UID-only ISO14443A reader: SPI0 CE0, reset BCM25. No pip packages."""
import time


def crc_a(data):
    crc = 0x6363
    for value in data:
        value ^= crc & 0xff
        value ^= (value << 4) & 0xff
        crc = ((crc >> 8) ^ (value << 8) ^ (value << 3) ^ (value >> 4)) & 0xffff
    return [crc & 0xff, crc >> 8]


class CardReadError(OSError):
    """A recoverable RF/protocol failure, distinct from a broken SPI connection."""


class RC522:
    def __init__(self):
        import spidev
        import RPi.GPIO as GPIO
        self.gpio, self.spi = GPIO, None
        self.reset = False
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(25, GPIO.OUT, initial=GPIO.HIGH)
            self.reset = True
            self.spi = spidev.SpiDev()
            self.spi.open(0, 0)
            self.spi.max_speed_hz = 250000
            self.spi.mode = 0
            self.write(0x01, 0x0f)
            time.sleep(0.05)
            self.version = self.read(0x37)
            if self.version in (0x00, 0xff):
                raise OSError('RC522 не отвечает (VersionReg 0x%02X). Проверьте 3,3 В, SPI0 и RST BCM25.' % self.version)
            for register, value in [(0x2a, 0x8d), (0x2b, 0x3e), (0x2d, 30), (0x2c, 0),
                                    (0x15, 0x40), (0x11, 0x3d), (0x26, 0x70)]:
                self.write(register, value)
            self.write(0x14, self.read(0x14) | 3)
        except Exception:
            self.close()
            raise

    def write(self, register, value):
        self.spi.xfer2([(register << 1) & 0x7e, value])

    def read(self, register):
        return self.spi.xfer2([((register << 1) & 0x7e) | 0x80, 0])[1]

    def transceive(self, data, bits=0):
        self.write(0x01, 0)
        self.write(0x04, 0x7f)
        self.write(0x0a, 0x80)
        for value in data:
            self.write(0x09, value)
        self.write(0x0d, bits)
        self.write(0x01, 0x0c)
        self.write(0x0d, bits | 0x80)
        deadline = time.monotonic() + 0.05
        try:
            while time.monotonic() < deadline:
                irq = self.read(0x04)
                if irq & 0x30:
                    break
                if irq & 1:
                    return None
                time.sleep(0.001)
            else:
                raise OSError('RC522: нет ответа от контроллера SPI.')
            error = self.read(0x06)
            if error & 0xc0:
                raise OSError('RC522: ошибка контроллера (ErrorReg=0x%02X).' % error)
            if error & 0x1f:
                raise CardReadError('Нестабильный обмен с меткой (ErrorReg=0x%02X).' % error)
            size = self.read(0x0a) & 0x7f
            if size > 64:
                raise OSError('RC522: переполнение FIFO.')
            return [self.read(0x09) for _ in range(size)]
        finally:
            self.write(0x0d, bits)
            self.write(0x01, 0)

    def read_id_no_block(self):
        # WUPA detects a held card even after its previous selection; no false removal.
        if self.transceive([0x52], 7) is None:
            return None
        uid = []
        for cascade in (0x93, 0x95, 0x97):
            frame = self.transceive([cascade, 0x20])
            if frame is None or len(frame) != 5 or frame[0] ^ frame[1] ^ frame[2] ^ frame[3] != frame[4]:
                raise CardReadError('Не удалось прочитать UID метки.')
            select = [cascade, 0x70] + frame
            sak = self.transceive(select + crc_a(select))
            if not sak or len(sak) != 3 or crc_a(sak[:1]) != sak[1:]:
                raise CardReadError('Не удалось подтвердить UID метки.')
            uid.extend(frame[1:4] if frame[0] == 0x88 else frame[:4])
            if not sak[0] & 4:
                # Preserve the old SimpleMFRC522 five-byte ID for four-byte tags.
                halt = [0x50, 0]
                self.transceive(halt + crc_a(halt))
                return int.from_bytes(bytes(frame if cascade == 0x93 else uid), 'big')
        raise OSError('Неподдерживаемая длина UID.')

    def recover(self):
        # A failed selection can leave a card ACTIVE. Restart the RF field so
        # the next WUPA begins from a known state; the caller retains dedup state.
        self.write(0x01, 0)
        self.write(0x0d, 0)
        self.write(0x0a, 0x80)
        antenna = self.read(0x14)
        self.write(0x14, antenna & ~3)
        time.sleep(0.01)
        self.write(0x14, antenna | 3)
        time.sleep(0.02)

    def close(self):
        if self.spi is not None:
            try:
                self.write(0x14, 0)
            except Exception:
                pass
            self.spi.close()
            self.spi = None
        if self.reset:
            self.gpio.cleanup(25)
            self.reset = False
