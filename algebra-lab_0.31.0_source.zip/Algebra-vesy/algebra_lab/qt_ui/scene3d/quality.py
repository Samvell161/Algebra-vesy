"""Bounded graphics budgets; selecting a profile never changes lesson state."""
from dataclasses import dataclass
from pathlib import Path
from functools import lru_cache

@dataclass(frozen=True)
class Quality:
    key: str
    title: str
    shadow: int
    frame_width: int
    frame_height: int
    ambient_ms: int
    detailed: bool

PROFILES = {
    'smooth': Quality('smooth', 'Плавнее', 1024, 1024, 600, 160, False),
    'detail': Quality('detail', 'Детальнее', 2048, 1600, 900, 100, True),
}

@lru_cache(maxsize=16)
def default_quality(model=None):
    if model is None:
        try: model=Path('/proc/device-tree/model').read_text().rstrip('\0')
        except OSError: model=''
    return 'smooth' if any(name in model for name in ('Pi 3', 'Pi Zero', 'Pi 2', 'Raspberry Pi Model B Rev', 'Raspberry Pi Model B Plus')) else 'detail'

def quality(key=None):
    if key in PROFILES:return PROFILES[key]
    return PROFILES[default_quality()]
