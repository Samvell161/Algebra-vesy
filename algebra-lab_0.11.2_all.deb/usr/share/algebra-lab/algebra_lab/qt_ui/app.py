"""Qt child workspace sharing the established model, database and reader queue."""
import argparse
import fcntl
import os
import sys
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFontDatabase, QFont
from PyQt6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,
 QPushButton,QDialog,QScrollArea,QMessageBox,QComboBox)
import qtawesome as qta
from .balance import Balance
from ..service import Service, Session
from ..storage import Store
from ..hardware import Reader
from ..buttons import Buttons
from ..adventure import ADVENTURE_TASKS, LANDS, QUIZZES, QUIZ_BY_ID, level_open, quiz_open, next_level
from ..learning import game_progress
from ..math_engine import Linear

@lru_cache(maxsize=32)
def icon(name):
    return qta.icon(name, color='#35317c')

def pieces(value):
    result=[]
    for count,label in [(value.a,'x'),(value.b,'1')]:
        if count.denominator != 1 or abs(count)>9:return [str(value)]
        result += [('−' if count<0 else '')+label]*abs(int(count))
    return result if len(result)<=5 else [str(value)]

class Window(QMainWindow):
    def __init__(self, data, reader_mode=None):
        super().__init__()
        self.store=Store(data/'algebra.sqlite3')
        prefs=self.store.settings()
        self.reader=Reader(reader_mode or prefs.get('reader_mode','simulator'))
        self.buttons=Buttons(self.reader.emit,prefs.get('buttons_enabled',False))
        self.service=Service(self.store,self.reader);self.session=Session()
        self.service.restore_practice(self.session)
        self.seq=self.reader.sequence;self.legacy=False;self.closed=False
        self.setWindowTitle('Алгебра LAB · Новый интерфейс');self.resize(1024,600)
        root=QWidget();self.setCentralWidget(root);layout=QVBoxLayout(root);layout.setContentsMargins(16,10,16,10);layout.setSpacing(6)
        header_widget=QWidget();header_widget.setObjectName("header")
        header=QHBoxLayout(header_widget);header.setContentsMargins(12,0,8,0);layout.addWidget(header_widget)
        brand=QLabel('⚖ Алгебра LAB');brand.setObjectName('title');header.addWidget(brand);header.addStretch()
        self.xp=QLabel();header.addWidget(self.xp)
        self.button(header,'Для взрослого',self.adult,'fa5s.cog')
        self.heading=QLabel();self.heading.setObjectName('heading');self.heading.setAlignment(Qt.AlignmentFlag.AlignCenter);layout.addWidget(self.heading)
        row=QHBoxLayout();layout.addLayout(row)
        self.condition=QLabel();self.condition.setObjectName("equation");self.condition.setFont(QFont('DejaVu Sans',22,QFont.Weight.Bold));row.addWidget(self.condition)
        row.addStretch();self.remove=self.button(row,'− Убрать',lambda:self.operation('remove'));self.add=self.button(row,'+ Добавить',lambda:self.operation('add'))
        for b in [self.remove,self.add]:b.setCheckable(True)
        self.board=Balance();layout.addWidget(self.board,1)
        sides=QHBoxLayout();layout.addLayout(sides)
        self.left=self.button(sides,'Левая чаша',lambda:self.side('left'));sides.addStretch();self.right=self.button(sides,'Правая чаша',lambda:self.side('right'))
        self.answers=QWidget();answerrow=QHBoxLayout(self.answers);answerrow.setContentsMargins(0,0,0,0)
        self.answer=QComboBox();self.answer.setMinimumHeight(46);self.answer.addItems([str(i) for i in range(1,10)]);self.answer.setCurrentIndex(-1)
        self.answer.currentIndexChanged.connect(self.select_answer);answerrow.addWidget(QLabel('Сколько скрывает x?'));answerrow.addWidget(self.answer)
        self.button(answerrow,'Проверить',self.check);layout.addWidget(self.answers)
        self.feedback=QLabel();self.feedback.setWordWrap(True);self.feedback.setMinimumHeight(45);self.feedback.setObjectName('hint');layout.addWidget(self.feedback)
        footer=QHBoxLayout();layout.addLayout(footer)
        self.undo_button=self.button(footer,'Отменить',self.undo,'fa5s.undo');self.undo_button.setObjectName('undo')
        self.button(footer,'Карта',self.map,'fa5s.map');self.button(footer,'Мой путь',self.history)
        self.next_button=self.button(footer,'Дальше',self.next)
        self.hint_button=self.button(footer,'Подсказка',self.hint,'fa5s.lightbulb');self.hint_button.setObjectName('help')
        self.timer=QTimer(self);self.timer.timeout.connect(self.poll);self.timer.start(150)
        if not self.session.current:self.start(next_level(self.store.progress()['best'])['id'])
        else:
            if self.session.task_id not in {t['id'] for t in ADVENTURE_TASKS}:
                self.feedback.setText('Незавершённое дополнительное задание доступно в прежнем интерфейсе.')
            elif not self.session.cup_play:self.service.begin_student(self.session)
            self.refresh()

    def button(self,row,text,fn,ico=None):
        b=QPushButton(text)
        if ico:b.setIcon(icon(ico))
        b.clicked.connect(lambda checked=False:self.run(fn));row.addWidget(b);return b
    def run(self,fn):
        try:fn()
        except (ValueError,OSError) as exc:self.feedback.setText(str(exc))
    def start(self,task):
        self.service.start(self.session,{'task_id':task});self.service.begin_student(self.session)
        self.feedback.setText('Выбери действие и поднеси метку к нужной чаше.');self.refresh()
    def next(self):self.start(next_level(self.store.progress()['best'],self.session.task_id)['id'])
    def operation(self,op):
        if self.service.cup_state(self.session)['pending']:raise ValueError('Повтори действие на второй чаше или нажми «Отменить».')
        if self.session.completed or self.session.cup_phase!='choose':return
        if self.service.student_stage(self.session)=='demo':return
        self.session.cup_operation=op;self.refresh()
    def side(self,side):self.session.cup_side=side;self.refresh()
    def select_answer(self,index):self.session.cup_guess=index+1 if index>=0 else None
    def check(self):
        if self.session.cup_guess is None:raise ValueError('Выбери число для ответа.')
        self.feedback.setText(self.service.student_answer(self.session,self.session.cup_guess)['message']);self.refresh()
    def undo(self):
        if self.service.cup_state(self.session)['pending']:self.service.begin_student(self.session)
        else:self.service.undo(self.session)
        self.feedback.setText('Ход отменён.');self.refresh()
    def hint(self):self.feedback.setText(self.service.student_hint(self.session)['text']);self.refresh()
    def refresh(self):
        ex=self.service.exercise(self.session)
        if not ex:return
        stats=game_progress(self.store.progress());self.xp.setText('★ XP '+str(stats['xp']))
        self.heading.setText(ex['task']['title']+(' · Решено!' if self.session.completed else ' · Освободи x'))
        state=self.service.cup_state(self.session);preview=state['preview']
        self.condition.setText(ex['task']['equation'])
        self.condition.setToolTip('Исходное уравнение этого задания')
        result=self.session.current.solution()
        value=Fraction(result["value"]) if result["kind"]=="one" else 0
        diff=preview.right.at(value)-preview.left.at(value)
        self.board.set_blocks(pieces(preview.left),pieces(preview.right),0 if not diff else (5 if diff>0 else -5))
        choose=not self.session.completed and self.session.cup_phase=='choose'
        for b,op in [(self.remove,'remove'),(self.add,'add')]:
            b.setChecked(self.session.cup_operation==op);b.setEnabled(choose and not state['pending'] and self.service.student_stage(self.session)!='demo')
        for b,side in [(self.left,'left'),(self.right,'right')]:
            b.setCheckable(True);b.setChecked(self.session.cup_side==side);b.setEnabled(choose)
        self.answers.setVisible(not self.session.completed and self.session.cup_phase=='answer')
        self.answer.blockSignals(True);self.answer.setCurrentIndex((self.session.cup_guess or 0)-1);self.answer.blockSignals(False)
        self.next_button.setEnabled(self.session.completed);self.hint_button.setEnabled(not self.session.completed)
        self.undo_button.setEnabled(not self.session.completed and (state['pending'] or len(self.session.history)>1))
        self.service.save_practice(self.session)
    def poll(self):
        for e in self.reader.since(self.seq):
            self.seq=e['sequence']
            if QApplication.activeModalWidget():continue
            if e.get('type')=='button':self.run(lambda e=e:self.operation(e['operation']))
            else:self.run(lambda e=e:self.scan(e))
    def scan(self,event):
        result=self.service.scan_cup(self.session,event);self.feedback.setText(result['message']);self.refresh()
    def dialog(self,title):
        d=QDialog(self);d.setWindowTitle(title);d.resize(800,520)
        outer=QVBoxLayout(d);scroll=QScrollArea();scroll.setWidgetResizable(True);body=QWidget();rows=QVBoxLayout(body);scroll.setWidget(body);outer.addWidget(scroll)
        self.button(outer,'Закрыть',d.accept)
        return d,rows
    def map(self):
        d,rows=self.dialog('Карта приключения');best=self.store.progress()['best']
        for i,title in enumerate(LANDS):
            rows.addWidget(QLabel(title[0]))
            for task in ADVENTURE_TASKS[i*6:(i+1)*6]:
                b=self.button(rows,('✓ ' if task['id'] in best else '')+task['title']+' · '+task['equation'],lambda t=task:(self.start(t['id']),d.accept()))
                b.setEnabled(level_open(best,task['id']))
            b=self.button(rows,'Квиз главы',lambda q=QUIZZES[i]:(d.accept(),self.quiz(q['id'])))
            b.setEnabled(quiz_open(best,i))
        d.exec()
    def quiz(self,key):
        state=self.service.start_quiz(key)
        while not state['completed']:
            d,rows=self.dialog(QUIZ_BY_ID[key]['title']);q=QUIZ_BY_ID[key]['questions'][state['index']]
            label=QLabel(q[0]);label.setWordWrap(True);rows.addWidget(label);feedback=QLabel();feedback.setWordWrap(True)
            buttons=[]
            def choose(index):
                self.service.quiz_answer(state,index);feedback.setText(state['feedback'])
                for b in buttons:b.setEnabled(not state['answered'])
                forward.setEnabled(state['answered'])
            for i,text in enumerate(q[1]):buttons.append(self.button(rows,text,lambda i=i:choose(i)))
            rows.addWidget(feedback);forward=self.button(rows,'Дальше',lambda:(self.service.quiz_next(state),d.done(2)));forward.setEnabled(False)
            if d.exec()!=2:return
        self.feedback.setText('Квиз завершён! Результат сохранён.');self.refresh()
    def history(self):
        d,rows=self.dialog('Мой путь решения')
        for step in self.session.history:
            label=QLabel(step['label']+'\n'+step['left']+' = '+step['right']);label.setWordWrap(True);rows.addWidget(label)
        d.exec()
    def adult(self):
        if QMessageBox.question(self,'Для взрослого','Открыть прежний полный интерфейс? Там доступны настройки оборудования, привязка меток, статистика, лаборатория и дополнительные задания. Текущее решение будет сохранено.')==QMessageBox.StandardButton.Yes:
            self.legacy=True;self.close()
    def closeEvent(self,event):
        if not self.closed:
            self.closed=True;self.timer.stop();self.service.save_practice(self.session);self.buttons.close();self.reader.close();self.store.close()
        event.accept()

def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,default=Path(os.environ.get('XDG_DATA_HOME',str(Path.home()/'.local/share')))/'algebra-lab');parser.add_argument('--windowed',action='store_true');parser.add_argument('--fullscreen',action='store_true');parser.add_argument('--reader',choices=['simulator','rc522','rc522_dual'])
    args=parser.parse_args(argv);args.data_dir.mkdir(parents=True,exist_ok=True)
    with (args.data_dir/'desktop.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:print('Алгебра LAB уже запущена.',file=sys.stderr);return 1
        app=QApplication(sys.argv[:1]);app.setStyleSheet(Path(__file__).with_name('theme.qss').read_text())
        for path in Path('/usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):QFontDatabase.addApplicationFont(str(path))
        w=Window(args.data_dir,args.reader)
        if args.windowed:w.show()
        else:w.showFullScreen()
        result=app.exec()
    if w.legacy:
        os.execv(sys.executable,[sys.executable,str(Path(__file__).parents[2]/'launcher.py'),'--legacy','--data-dir',str(args.data_dir)])
    return result


if __name__ == "__main__":
    raise SystemExit(main())
