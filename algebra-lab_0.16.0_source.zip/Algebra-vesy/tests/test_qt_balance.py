"""Run with QT_QPA_PLATFORM=offscreen and the Qt dependencies installed."""
import unittest
try:
    from PyQt6.QtWidgets import QApplication
    from algebra_lab.qt_ui.balance import Balance
except ImportError:
    QApplication = None

@unittest.skipUnless(QApplication, 'Qt development dependencies required')
class QtBalanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_cached_render_and_both_tilts_keep_chain_anchors_inside_board(self):
        board = Balance();board.resize(992,203);board.show()
        for tilt in [-5,0,5]:
            board.set_blocks(['x','1','1'],['1']*4,tilt)
            self.app.processEvents()
            self.assertFalse(board.grab().isNull())
            self.assertEqual(len(board.attachments),4)
            for start,end in board.attachments:
                self.assertLess(start.y(),end.y())
                for point in (start,end):
                    self.assertTrue(0 <= point.x() <= board.width())
                    self.assertTrue(0 <= point.y() <= board.height())
            cached = board._cache.cacheKey()
            board.grab()
            self.assertEqual(board._cache.cacheKey(),cached)
        board.set_blocks(['x'],['1','1'],0);self.app.processEvents()
        self.assertNotEqual(board._cache.cacheKey(),cached)
        board.close()
