"""Cached vector illustration. Chains attach to the actual rotated beam endpoints."""
import math
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QPainterPath, QLinearGradient, QPixmap
from PyQt6.QtWidgets import QWidget, QSizePolicy

INK = '#39316f'


def gradient(y, height, light, dark):
    value = QLinearGradient(0, y, 0, y + height)
    value.setColorAt(0, QColor(light)); value.setColorAt(1, QColor(dark))
    return QBrush(value)


class Balance(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.left, self.right, self.tilt = [], [], 0
        self._cache = None
        self._cache_key = None
        self.setMinimumSize(400, 120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_blocks(self, left, right, tilt=0):
        left, right = list(left), list(right)
        tilt = max(-5, min(5, tilt))
        if (left, right, tilt) != (self.left, self.right, self.tilt):
            self.left, self.right, self.tilt = left, right, tilt
            self._cache_key = None
            self.update()

    def paintEvent(self, event):
        ratio = self.devicePixelRatioF()
        key = (self.width(), self.height(), ratio, self.tilt, tuple(self.left), tuple(self.right), self.font().family())
        if key != self._cache_key:
            self._cache = QPixmap(round(self.width()*ratio), round(self.height()*ratio))
            self._cache.setDevicePixelRatio(ratio)
            self._cache.fill(Qt.GlobalColor.transparent)
            painter = QPainter(self._cache)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            self.draw_balance(painter)
            painter.end()
            self._cache_key = key
        painter = QPainter(self)
        painter.drawPixmap(0, 0, self._cache)
        painter.end()

    def draw_balance(self, p):
        w, h = self.width(), self.height()
        scale = max(.48, min(1.05, h/245, w/1000))
        cx, cy = w/2, 33*scale
        arm = w*.275
        clearance = arm*math.sin(math.radians(5))
        cy = max(cy, clearance+18*scale)
        base = h-13*scale
        pan_half = min(w*.175, 170*scale)
        stroke = max(1.5, 3*scale)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor('#e5dfef'))
        p.drawEllipse(QRectF(cx-110*scale, base-3*scale, 220*scale, 13*scale))
        # Faceted upright and rounded foot, with no blur/shadow effect objects.
        support = QPainterPath(QPointF(cx, cy))
        support.lineTo(cx-36*scale, base-24*scale);support.lineTo(cx+36*scale, base-24*scale);support.closeSubpath()
        p.setPen(QPen(QColor(INK),stroke))
        p.setBrush(gradient(cy,base-cy,'#a594df','#6757b3'));p.drawPath(support)
        facet=QPainterPath(QPointF(cx+4*scale,cy+17*scale));facet.lineTo(cx+31*scale,base-26*scale);facet.lineTo(cx+5*scale,base-26*scale);facet.closeSubpath()
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#4a408e'));p.drawPath(facet)
        p.setPen(QPen(QColor(INK),stroke));p.setBrush(gradient(base-35*scale,35*scale,'#a593db','#51458e'))
        p.drawRoundedRect(QRectF(cx-100*scale,base-30*scale,200*scale,30*scale),15*scale,15*scale)
        p.setPen(QPen(QColor('#c3b6ef'),2*scale));p.drawLine(QPointF(cx-73*scale,base-24*scale),QPointF(cx+73*scale,base-24*scale))
        # Rotating beam, including its endpoint rings. Suspension uses the same transform.
        p.save();p.translate(cx,cy);p.rotate(self.tilt)
        beam=QPainterPath(QPointF(-arm, -9*scale));beam.lineTo(0,-16*scale);beam.lineTo(arm,-9*scale);beam.lineTo(arm,9*scale);beam.lineTo(0,16*scale);beam.lineTo(-arm,9*scale);beam.closeSubpath()
        p.setPen(QPen(QColor(INK),stroke));p.setBrush(gradient(-16*scale,32*scale,'#ffe78a','#f9be29'));p.drawPath(beam)
        p.setPen(QPen(QColor('#fff5bc'),3*scale));p.drawLine(QPointF(-arm+12*scale,-5*scale),QPointF(arm-12*scale,-5*scale))
        p.setPen(QPen(QColor(INK),stroke));p.setBrush(gradient(-15*scale,30*scale,'#ffe992','#ffca36'))
        for x in [-arm,arm]:p.drawEllipse(QPointF(x,0),15*scale,15*scale)
        p.restore()
        radians=math.radians(self.tilt)
        self.attachments=[]
        for direction, values, light, dark in [(-1,self.left,'#59d0ff','#1595e6'),(1,self.right,'#ffb2aa','#f15e71')]:
            x=cx+direction*arm*math.cos(radians)
            y=cy+direction*arm*math.sin(radians)
            rim=h-55*scale-clearance+direction*arm*math.sin(radians)
            p.setPen(QPen(QColor(INK),stroke));p.setBrush(QColor('#fbf8f5'))
            p.drawEllipse(QPointF(x,y+23*scale),8*scale,9*scale)
            for edge in [-1,1]:
                start=QPointF(x+edge*4*scale,y+30*scale)
                end=QPointF(x+edge*(pan_half-8*scale),rim-3*scale)
                self.chain(p,start,end,scale)
                self.attachments.append((start,end))
                p.setPen(QPen(QColor(INK),stroke));p.setBrush(QColor('#fbf8f5'));p.drawEllipse(end,5*scale,6*scale)
            # Blocks stand on the rim, with individual rims and upper highlights.
            items=values if len(values)<=5 else [' · '.join(map(str,values))]
            block_h=54*scale;gap=6*scale
            widths=[55*scale if len(str(text))<=2 else min(2*pan_half-20*scale,220*scale) for text in items]
            bx=x-(sum(widths)+max(0,len(items)-1)*gap)/2
            for text,bw in zip(items,widths):
                by=rim-block_h-3*scale
                is_x='x' in str(text).lower();negative='−' in str(text)
                colors=('#79d8ff','#229fea') if is_x else (('#ffb5ac','#f17676') if negative else ('#ffe58a','#ffc033'))
                p.setPen(QPen(QColor('#2173b7' if is_x else '#947025'),2*scale));p.setBrush(gradient(by,block_h,*colors))
                p.drawRoundedRect(QRectF(bx,by,bw,block_h),9*scale,9*scale)
                p.setPen(QPen(QColor('#fff2cf'),2*scale));p.drawLine(QPointF(bx+8*scale,by+6*scale),QPointF(bx+bw-8*scale,by+6*scale))
                font=QFont(self.font());font.setPixelSize(round((34 if len(str(text))<=2 else 19)*scale));font.setBold(True)
                p.setFont(font);p.setPen(QColor('#ffffff' if is_x else '#352c26'))
                p.drawText(QRectF(bx,by,bw,block_h),int(Qt.AlignmentFlag.AlignCenter),str(text));bx+=bw+gap
            bowl=QPainterPath(QPointF(x-pan_half,rim));bowl.cubicTo(x-pan_half*.85,rim+53*scale,x+pan_half*.85,rim+53*scale,x+pan_half,rim);bowl.quadTo(x,rim+12*scale,x-pan_half,rim);bowl.closeSubpath()
            p.setPen(QPen(QColor(INK),stroke));p.setBrush(gradient(rim,40*scale,light,dark));p.drawPath(bowl)
            p.setPen(QPen(QColor('#fff4ef'),3*scale));shine=QPainterPath(QPointF(x-pan_half+10*scale,rim+5*scale));shine.quadTo(x,rim+16*scale,x+pan_half-10*scale,rim+5*scale);p.drawPath(shine)
        # Central medallion overlays the rotating beam.
        p.setPen(QPen(QColor(INK),stroke));p.setBrush(gradient(cy-28*scale,56*scale,'#ffe991','#fac638'));p.drawEllipse(QPointF(cx,cy),28*scale,28*scale)
        p.setBrush(gradient(cy-11*scale,22*scale,'#9480d3','#6353ad'));p.drawEllipse(QPointF(cx,cy),11*scale,11*scale)

    @staticmethod
    def chain(p, start, end, scale):
        dx,dy=end.x()-start.x(),end.y()-start.y()
        length=math.hypot(dx,dy)
        count=max(2,min(32,round(length/(13*scale))))
        step=length/count
        p.save();p.translate(start);p.rotate(math.degrees(math.atan2(dy,dx))-90)
        for i in range(count):
            p.setBrush(QColor('#f9f7f5'))
            p.setPen(QPen(QColor(INK),max(1.4,2.5*scale)))
            p.drawRoundedRect(QRectF(-4*scale,i*step-2*scale,8*scale,step+4*scale),4*scale,4*scale)
            p.setPen(QPen(QColor('#a7a0c7'),max(.8,scale)))
            p.drawLine(QPointF(-2*scale,i*step+scale),QPointF(-2*scale,(i+1)*step-scale))
        p.restore()
