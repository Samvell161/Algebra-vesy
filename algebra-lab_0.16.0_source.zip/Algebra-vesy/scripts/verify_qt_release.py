"""Exercise the extracted Qt payload; no physical GPIO required."""
import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('package',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    subprocess.run(['dpkg-deb','-x',str(args.package),str(root)],check=True)
    payload=root/'usr/share/algebra-lab'
    sys.path.insert(0,str(payload))
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QFontDatabase
    from algebra_lab.qt_ui.app import Window
    app=QApplication([])
    for font in (root/'usr/share/fonts/truetype/algebra-lab').glob('*.ttf'):
        assert QFontDatabase.addApplicationFont(str(font))>=0
    app.setStyleSheet((payload/'algebra_lab/qt_ui/theme.qss').read_text())
    data=root/'profile';data.mkdir()
    w=Window(data);w.start('cups-4');w.show();app.processEvents()
    assert w.size().width()==1024 and w.height()<=600
    w.grab().save(str(args.output/'game.png'))
    w.store.bind('AA','2');w.operation('remove')
    w.reader.emit({'uid':'AA','source':'left'});w.poll();app.processEvents()
    assert w.board.tilt!=0
    w.grab().save(str(args.output/'left-changed.png'))
    w.reader.emit({'uid':'AA','source':'right'});w.poll();app.processEvents()
    assert w.session.cup_phase=='answer' and not w.session.completed
    assert w.height()<=600
    w.session.cup_guess=2;w.check();assert w.session.completed
    assert w.store.solutions()
    from unittest.mock import patch
    from algebra_lab import lesson_queue
    w.store.save_settings({'mobile_lessons_enabled':True})
    lesson_queue.submit(w.store.db,'a'*32,w.store.profile_id,'cups-1')
    with patch.object(w.mobile,'running',True):
        w.check_remote();app.processEvents()
        assert not w.remote_bar.isHidden()
        assert w.height()<=600 and w.remote_bar.geometry().bottom()<w.height()
        w.grab().save(str(args.output/'phone-lesson.png'))
        w.respond_remote('accepted')
        assert w.session.task_id=='cups-1' and not w.session.completed
    w.close()
print('PASS: extracted Qt UI at 1024x600, fonts, RFID paired step, explicit answer, saved history and accepted phone lesson')
